package com.periut.starac;

import java.util.concurrent.atomic.AtomicBoolean;
import net.minecraft.unmapped.C_85740840;

/**
 * Holds state shared between ReloadScreenManager and Minecraft mixins
 * for EarlyRenderLoop mode coordination.
 */
public final class StapiEarlyRenderLoopState {
    private static boolean usingEarlyRenderLoop = false;
    private static C_85740840 earlyRenderLoopScreen = null;
    private static AtomicBoolean earlyRenderLoopDone = null;

    private StapiEarlyRenderLoopState() {}

    public static boolean isUsingEarlyRenderLoop() {
        return usingEarlyRenderLoop;
    }

    public static void setUsingEarlyRenderLoop(boolean value) {
        usingEarlyRenderLoop = value;
    }

    public static C_85740840 getEarlyRenderLoopScreen() {
        return earlyRenderLoopScreen;
    }

    public static void setEarlyRenderLoopScreen(C_85740840 screen) {
        earlyRenderLoopScreen = screen;
    }

    public static AtomicBoolean getEarlyRenderLoopDone() {
        return earlyRenderLoopDone;
    }

    public static void setEarlyRenderLoopDone(AtomicBoolean done) {
        earlyRenderLoopDone = done;
    }

    public static void reset() {
        usingEarlyRenderLoop = false;
        earlyRenderLoopScreen = null;
        earlyRenderLoopDone = null;
    }
}
