package com.periut.starac.mixin.stapi;

import com.periut.starac.LWJGLHelper;
import com.periut.starac.StapiEarlyRenderLoopState;
import lombok.val;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_43718703;
import net.modificationstation.stationapi.api.client.resource.ReloadScreenManager;
import net.modificationstation.stationapi.api.resource.CompositeResourceReload;
import net.modificationstation.stationapi.api.resource.ResourceReload;
import net.modificationstation.stationapi.impl.client.resource.ReloadScreenApplicationExecutor;
import net.modificationstation.stationapi.impl.client.resource.ReloadScreenManagerImpl;
import net.modificationstation.stationapi.impl.client.resource.ReloadScreenTessellatorHolder;
import net.modificationstation.stationapi.mixin.resourceloader.client.MinecraftAccessor;
import net.modificationstation.stationapi.mixin.resourceloader.client.TessellatorAccessor;
import org.lwjgl.LWJGLException;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

import java.util.Optional;
import java.util.concurrent.Executor;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.lwjgl.opengl.GL11.*;

@Mixin(value = ReloadScreenManager.class, remap = false)
public class MixinReloadScreenManager {

    @Shadow
    private static Optional<Thread> thread;

    @Shadow
    private static Optional<ResourceReload> currentReload;

    @Shadow
    private static Executor applicationExecutor;

    /**
     * @author starac
     * @reason Replace LWJGL2-specific code with LWJGLHelper for LWJGL3 compatibility
     */
    @Overwrite
    public static void openEarly() throws LWJGLException {
        ReloadScreenManagerImpl.isMinecraftDone = false;
        applicationExecutor = ReloadScreenApplicationExecutor.INSTANCE;
        currentReload = Optional.of(new CompositeResourceReload());
        //noinspection deprecation
        final Minecraft minecraft = (Minecraft) FabricLoader.getInstance().getGameInstance();

        // Use starac's EarlyRenderLoop if available (LWJGL3 with proper event handling)
        if (LWJGLHelper.hasEarlyRenderLoop()) {
            System.out.println("[starac] Using EarlyRenderLoop for loading screen");
            starac_onStartupWithEarlyRenderLoop(minecraft);
            return;
        }

        // Fall back to LWJGL2 threaded approach
        if (LWJGLHelper.isLWJGL2()) {
            try {
                final Object drawable = LWJGLHelper.createSharedDrawable();
                thread = Optional.of(new Thread(() -> starac_onStartupThreaded(minecraft, drawable)));
                thread.ifPresent(Thread::start);
            } catch (LWJGLException e) {
                throw e;
            }
            return;
        }

        // No compatible approach available - skip early loading screen
        System.err.println("[starac] No compatible early loading screen implementation available");
    }

    /**
     * Sets up state for single-threaded early render loop.
     * Returns immediately - actual render loop runs from the Minecraft mixin.
     */
    @Unique
    private static void starac_onStartupWithEarlyRenderLoop(final Minecraft minecraft) {
        StapiEarlyRenderLoopState.setUsingEarlyRenderLoop(true);
        StapiEarlyRenderLoopState.setEarlyRenderLoopDone(new AtomicBoolean(false));

        // Create the ReloadScreen using reflection to access the package-private class
        try {
            Class<?> reloadScreenClass = Class.forName("net.modificationstation.stationapi.api.client.resource.ReloadScreen");
            Object tessellator = TessellatorAccessor.stationapi_create(48);
            ReloadScreenTessellatorHolder.reloadScreenTessellator = (net.minecraft.unmapped.C_96603444) tessellator;

            // Create done callback that sets our flag
            Runnable doneCallback = () -> StapiEarlyRenderLoopState.getEarlyRenderLoopDone().set(true);

            // Constructor: ReloadScreen(Screen parent, Runnable done, Tessellator tessellator)
            var constructor = reloadScreenClass.getDeclaredConstructor(
                    net.minecraft.unmapped.C_85740840.class,
                    Runnable.class,
                    net.minecraft.unmapped.C_96603444.class
            );
            constructor.setAccessible(true);
            Object screen = constructor.newInstance(
                    minecraft.f_70816363,
                    doneCallback,
                    tessellator
            );
            StapiEarlyRenderLoopState.setEarlyRenderLoopScreen((net.minecraft.unmapped.C_85740840) screen);

            val screenScaler = new C_43718703(minecraft.f_58088711, minecraft.f_31800787, minecraft.f_74192110);
            ((net.minecraft.unmapped.C_85740840) screen).m_55923303(minecraft, screenScaler.getScaledWidth(), screenScaler.getScaledHeight());

            // Call setTextRenderer via reflection
            var setTextRenderer = reloadScreenClass.getDeclaredMethod("setTextRenderer", C_23014920.class);
            setTextRenderer.setAccessible(true);
            setTextRenderer.invoke(screen,
                    new C_23014920(minecraft.f_58088711, "/font/default.png", minecraft.f_45465196));

        } catch (Exception e) {
            throw new RuntimeException("Failed to create ReloadScreen for EarlyRenderLoop", e);
        }
    }

    /**
     * Threaded approach for LWJGL2 using SharedDrawable.
     */
    @Unique
    private static void starac_onStartupThreaded(
            final Minecraft minecraft,
            final Object drawable
    ) {
        try {
            LWJGLHelper.makeCurrent(drawable);
        } catch (LWJGLException e) {
            throw new RuntimeException(e);
        }
        val done = new AtomicBoolean();

        // Create the ReloadScreen using reflection
        Object localReloadScreen;
        try {
            Class<?> reloadScreenClass = Class.forName("net.modificationstation.stationapi.api.client.resource.ReloadScreen");
            Object tessellator = TessellatorAccessor.stationapi_create(48);
            ReloadScreenTessellatorHolder.reloadScreenTessellator = (net.minecraft.unmapped.C_96603444) tessellator;

            var constructor = reloadScreenClass.getDeclaredConstructor(
                    net.minecraft.unmapped.C_85740840.class,
                    Runnable.class,
                    net.minecraft.unmapped.C_96603444.class
            );
            constructor.setAccessible(true);
            localReloadScreen = constructor.newInstance(
                    minecraft.f_70816363,
                    (Runnable) () -> done.set(true),
                    tessellator
            );

            val screenScaler = new C_43718703(minecraft.f_58088711, minecraft.f_31800787, minecraft.f_74192110);
            val screen = (net.minecraft.unmapped.C_85740840) localReloadScreen;
            val widthVal = screenScaler.getScaledWidth();
            val heightVal = screenScaler.getScaledHeight();
            screen.init(minecraft, widthVal, heightVal);

            var setTextRenderer = reloadScreenClass.getDeclaredMethod("setTextRenderer", C_23014920.class);
            setTextRenderer.setAccessible(true);
            setTextRenderer.invoke(localReloadScreen,
                    new C_23014920(minecraft.f_58088711, "/font/default.png", minecraft.f_45465196));

            val timer = ((MinecraftAccessor) minecraft).getTimer();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            glMatrixMode(GL_PROJECTION);
            glLoadIdentity();
            glOrtho(0.0, screenScaler.rawScaledWidth, screenScaler.rawScaledHeight, 0.0, 1000.0, 3000.0);
            glMatrixMode(GL_MODELVIEW);
            glLoadIdentity();
            glTranslatef(0.0f, 0.0f, -2000.0f);
            glViewport(0, 0, minecraft.f_31800787, minecraft.f_74192110);
            glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
            glDisable(GL_LIGHTING);
            glEnable(GL_TEXTURE_2D);
            glDisable(GL_FOG);
            while (!done.get()) {
                while (true) if (!Mouse.next()) break;
                while (true) if (!Keyboard.next()) break;
                val f = timer.partialTick;
                timer.advance();
                timer.partialTick = f;
                val mouseX = Mouse.getX() * widthVal / minecraft.f_31800787;
                val mouseY = heightVal - Mouse.getY() * heightVal / minecraft.f_74192110 - 1;
                screen.render(mouseX, mouseY, timer.partialTick);
                try {
                    LWJGLHelper.displayUpdate();
                } catch (LWJGLException e) {
                    throw new RuntimeException(e);
                }
            }
            glDisable(GL_LIGHTING);
            glDisable(GL_FOG);
            glEnable(GL_ALPHA_TEST);
            glAlphaFunc(GL_GREATER, 0.1f);
            try {
                LWJGLHelper.releaseContext(drawable);
            } catch (LWJGLException e) {
                throw new RuntimeException(e);
            }
            thread = Optional.empty();

        } catch (Exception e) {
            throw new RuntimeException("Failed to run threaded ReloadScreen", e);
        }
    }
}
