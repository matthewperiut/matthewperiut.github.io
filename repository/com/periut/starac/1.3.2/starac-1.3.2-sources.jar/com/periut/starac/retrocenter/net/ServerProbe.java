package com.periut.starac.retrocenter.net;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_58873528;
import com.periut.starac.retrocenter.RetroCenter;
import com.periut.starac.retrocenter.sync.ManifestStore;

/**
 * Server side of the pre-login probe (only ever classloaded on the server
 * side — see RetroSyncPacket.apply).
 *
 * Stateless serving: every FILE_REQ names (sha256, chunkIndex) and gets one
 * FILE_CHUNK back. The login handler is marked active so the login timeout
 * is frozen while a client is syncing (ServerLoginHandlerSyncMixin).
 */
public final class ServerProbe {

	private static final Map<C_10918870, Boolean> ACTIVE =
			Collections.synchronizedMap(new WeakHashMap<>());

	private ServerProbe() {
	}

	public static boolean isActive(C_10918870 handler) {
		return ACTIVE.containsKey(handler);
	}

	public static void handle(C_10918870 handler, RetroSyncPacket packet) {
		if (!(handler instanceof C_58873528)) {
			return; // the probe only runs during login
		}
		C_58873528 login = (C_58873528) handler;
		try {
			switch (packet.op) {
				case RetroSyncPacket.OP_QUERY: {
					try (DataInputStream in = packet.bodyIn()) {
						int protocol = in.readInt();
						if (protocol != RetroCenter.SYNC_PROTOCOL_VERSION) {
							RetroCenter.log("probe with protocol " + protocol + " (server has "
									+ RetroCenter.SYNC_PROTOCOL_VERSION + ") — ignoring");
							return;
						}
					}
					ACTIVE.put(handler, Boolean.TRUE);
					login.f_82327142.m_00234283(RetroSyncPacket.make(RetroSyncPacket.OP_MANIFEST,
							out -> ManifestStore.get().write(out)));
					break;
				}
				case RetroSyncPacket.OP_FILE_REQ: {
					String sha;
					int chunkIndex;
					try (DataInputStream in = packet.bodyIn()) {
						sha = in.readUTF();
						chunkIndex = in.readInt();
					}
					ManifestStore.Chunk chunk = ManifestStore.readChunk(sha, chunkIndex);
					if (chunk == null) {
						RetroCenter.log("file_req for unknown sha/chunk " + sha + "#" + chunkIndex);
						return;
					}
					login.f_82327142.m_00234283(RetroSyncPacket.make(RetroSyncPacket.OP_FILE_CHUNK, out -> {
						out.writeUTF(sha);
						out.writeInt(chunkIndex);
						out.writeInt(chunk.chunkCount);
						out.writeInt(chunk.data.length);
						out.write(chunk.data);
					}));
					break;
				}
				default:
					RetroCenter.log("unexpected probe opcode " + packet.op);
			}
		} catch (IOException e) {
			RetroCenter.log("probe handling failed: " + e);
		}
	}
}
