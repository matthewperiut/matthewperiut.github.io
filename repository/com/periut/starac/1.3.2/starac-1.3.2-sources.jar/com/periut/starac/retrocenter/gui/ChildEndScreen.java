package com.periut.starac.retrocenter.gui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_95462098;

/**
 * Shown by the HUB after a child instance ends with something to say:
 * a red title ("Minecraft Crashed" / "Disconnected") above a scrollable
 * text box with the full details (crash report, kick reason), and a
 * "Back to Main Menu" button. Scroll with the mouse wheel.
 */
public final class ChildEndScreen extends C_85740840 {

	private static final int LINE_HEIGHT = 10;

	private final String title;
	private final String details;
	private List<String> lines;
	private int scroll;

	public ChildEndScreen(String title, String details) {
		this.title = title;
		this.details = details != null ? details : "";
	}

	@Override
	public void m_41805697() {
		f_78519977.clear();
		f_78519977.add(new C_85125467(0, f_05230747 / 2 - 100, f_07021018 - 32, "Back to Main Menu"));
		lines = wrap(details, f_05230747 - 60);
		scroll = 0;
	}

	@Override
	protected void m_30778170(C_85125467 button) {
		if (button.f_92999450 == 0) {
			f_78495264.m_52715402(new C_95462098());
		}
	}

	@Override
	public void m_29921564() {
		super.m_29921564();
		int wheel = org.lwjgl.input.Mouse.getEventDWheel();
		if (wheel != 0) {
			scroll(-Integer.signum(wheel) * 3);
		}
	}

	@Override
	protected void m_29116903(char chr, int key) {
		if (key == org.lwjgl.input.Keyboard.KEY_DOWN) {
			scroll(3);
		} else if (key == org.lwjgl.input.Keyboard.KEY_UP) {
			scroll(-3);
		} else {
			super.m_29116903(chr, key);
		}
	}

	private void scroll(int deltaLines) {
		int visible = visibleLines();
		int max = Math.max(0, lines.size() - visible);
		scroll = Math.max(0, Math.min(max, scroll + deltaLines));
	}

	private int boxTop() {
		return 38;
	}

	private int boxBottom() {
		return f_07021018 - 44;
	}

	private int visibleLines() {
		return Math.max(1, (boxBottom() - boxTop() - 8) / LINE_HEIGHT);
	}

	@Override
	public void m_93956703(int mouseX, int mouseY, float delta) {
		m_34695786();
		m_50067982(f_11884601, title, f_05230747 / 2, 16, 0xFF5555);

		int top = boxTop();
		int bottom = boxBottom();
		m_57734177(28, top, f_05230747 - 28, bottom, 0xA0000000);
		m_57734177(29, top + 1, f_05230747 - 29, bottom - 1, 0x60000000);

		int visible = visibleLines();
		int y = top + 5;
		for (int i = scroll; i < Math.min(lines.size(), scroll + visible); i++) {
			m_62884682(f_11884601, lines.get(i), 34, y, 0xCCCCCC);
			y += LINE_HEIGHT;
		}

		// minimal scrollbar
		if (lines.size() > visible) {
			int trackTop = top + 2;
			int trackHeight = bottom - top - 4;
			int thumbHeight = Math.max(8, trackHeight * visible / lines.size());
			int thumbY = trackTop + (trackHeight - thumbHeight) * scroll / Math.max(1, lines.size() - visible);
			m_57734177(f_05230747 - 33, trackTop, f_05230747 - 30, trackTop + trackHeight, 0x40FFFFFF);
			m_57734177(f_05230747 - 33, thumbY, f_05230747 - 30, thumbY + thumbHeight, 0xC0FFFFFF);
		}

		super.m_93956703(mouseX, mouseY, delta);
	}

	@Override
	public boolean m_47190451() {
		return false;
	}

	private List<String> wrap(String text, int maxWidth) {
		List<String> result = new ArrayList<>();
		for (String raw : text.replace("\r", "").split("\n", -1)) {
			// preserve indentation from stack traces
			if (raw.isEmpty()) {
				result.add("");
				continue;
			}
			String line = raw.replace("\t", "    ");
			while (f_11884601.m_09235706(line) > maxWidth) {
				int cut = line.length();
				while (cut > 1 && f_11884601.m_09235706(line.substring(0, cut)) > maxWidth) {
					cut--;
				}
				// prefer breaking at a space/dot near the cut
				int nice = Math.max(line.lastIndexOf(' ', cut), line.lastIndexOf('.', cut));
				if (nice > cut / 2) {
					cut = nice + 1;
				}
				result.add(line.substring(0, cut));
				line = "    " + line.substring(cut);
			}
			result.add(line);
		}
		return result;
	}
}
