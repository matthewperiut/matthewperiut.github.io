package com.periut.starac.retrocenter.net;

import java.io.DataInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.periut.starac.mixin.lwjgl3.MinecraftAccessor;
import com.periut.starac.retrocenter.RetroCenter;
import com.periut.starac.retrocenter.gui.ModSyncScreen;
import com.periut.starac.retrocenter.sync.ModManifest;
import com.periut.starac.retrocenter.sync.ModSyncClient;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_04787565;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_43496149;
import net.minecraft.unmapped.C_88014908;

/**
 * Client-side pre-login probe, leveraging the very first connection attempt
 * (client classes only — never loaded server-side).
 *
 * When the server's handshake reply arrives — the earliest bidirectional
 * moment, BEFORE LoginHello — the login is held and a sync QUERY goes out
 * on the same connection:
 *
 * - server answers with its manifest:
 *     - mod set satisfied (client extras are fine) → release the held
 *       handshake, login proceeds on this same socket (retroauth's join
 *       logic runs as normal on the re-invocation),
 *     - mods missing → ModSyncScreen takes over the held connection
 *       (consent → download → child handoff),
 * - server kicks us ("Bad packet id" — no retrocenter) or stays silent past
 *   the deadline → remember "no retrocenter" for this host:port and
 *   reconnect cleanly WITHOUT probing: vanilla servers behave vanilla.
 */
public final class ProbeFlow {

	private static final long PROBE_TIMEOUT_MS = 4_000;

	private enum Phase {IDLE, PROBING, SYNCING, PASSED}

	/** host:port → does the server speak retrocenter? Session-scoped. */
	private static final Map<String, Boolean> verdicts = new ConcurrentHashMap<>();

	private static Phase phase = Phase.IDLE;
	private static C_88014908 handler;
	private static C_04787565 heldHandshake;
	private static String host = "";
	private static int port;
	private static long deadline;

	private ProbeFlow() {
	}

	/** ClientNetworkHandler ctor TAIL: a new outgoing connection exists. */
	public static void onConnectionStart(C_88014908 newHandler, String newHost, int newPort) {
		handler = newHandler;
		host = newHost;
		port = newPort;
		RetroCenter.lastConnectHost = newHost;
		RetroCenter.lastConnectPort = newPort;
		if (phase != Phase.SYNCING) {
			phase = Phase.IDLE;
		}
	}

	/**
	 * onHandshake HEAD. Returns true to hold the login while probing.
	 * Children probe too: their mod set matches, so they pass straight
	 * through on the same socket.
	 */
	public static boolean holdLogin(C_88014908 h, C_04787565 packet) {
		if (phase == Phase.PASSED) {
			phase = Phase.IDLE; // re-invocation after a successful probe
			return false;
		}
		Boolean known = verdicts.get(key());
		if (known != null && !known) {
			return false; // known vanilla server — connect normally
		}
		handler = h;
		heldHandshake = packet;
		phase = Phase.PROBING;
		deadline = System.currentTimeMillis() + PROBE_TIMEOUT_MS;
		RetroCenter.log("probing " + key() + " for retrocenter (login held)");
		h.m_43500316(RetroSyncPacket.make(RetroSyncPacket.OP_QUERY,
				out -> out.writeInt(RetroCenter.SYNC_PROTOCOL_VERSION)));
		return true;
	}

	/** ClientNetworkHandler.tick HEAD: probe deadline. */
	public static void clientTick(C_88014908 h) {
		if (phase == Phase.PROBING && h == handler && System.currentTimeMillis() > deadline) {
			RetroCenter.log("probe timed out — treating " + key() + " as non-retrocenter");
			noRetrocenter();
		}
	}

	/**
	 * onDisconnected HEAD. While probing, a disconnect (typically the "Bad
	 * packet id" kick from a server without the mod) is the no-support
	 * signal: swallow it and reconnect without probing. Returns true to
	 * cancel vanilla disconnect handling.
	 */
	public static boolean onDisconnected(C_88014908 h, String reason) {
		if (phase != Phase.PROBING || h != handler) {
			return false;
		}
		RetroCenter.log("probe rejected (" + reason + ") — " + key() + " has no retrocenter, reconnecting vanilla");
		noRetrocenter();
		return true;
	}

	/** Incoming sync packet on the client side (any phase). */
	public static void onSyncPacket(C_10918870 h, RetroSyncPacket packet) {
		if (packet.op == RetroSyncPacket.OP_MANIFEST && phase == Phase.PROBING) {
			verdicts.put(key(), true);
			ModManifest manifest;
			try (DataInputStream in = packet.bodyIn()) {
				manifest = ModManifest.read(in);
			} catch (IOException e) {
				RetroCenter.log("bad manifest: " + e);
				noRetrocenter();
				return;
			}
			List<ModManifest.Entry> missing = ModSyncClient.missingMods(manifest);
			if (missing.isEmpty()) {
				RetroCenter.log("mod set satisfied (" + manifest.entries.size()
						+ " server mods) — proceeding with login on the same connection");
				proceedWithLogin();
			} else {
				RetroCenter.log(missing.size() + "/" + manifest.entries.size()
						+ " server mods missing — opening sync screen");
				phase = Phase.SYNCING;
				Minecraft mc = MinecraftAccessor.getInstance();
				mc.m_52715402(new ModSyncScreen(mc, manifest, host, port, handler));
			}
		} else if (packet.op == RetroSyncPacket.OP_FILE_CHUNK && phase == Phase.SYNCING) {
			ModSyncClient.onChunk(packet);
		}
	}

	/** The sync screen finished (or aborted) — connection is done with. */
	public static void syncSessionEnded() {
		phase = Phase.IDLE;
		heldHandshake = null;
	}

	private static void proceedWithLogin() {
		phase = Phase.PASSED;
		C_04787565 held = heldHandshake;
		heldHandshake = null;
		handler.m_22756750(held); // re-invoke: vanilla/retroauth login flow runs now
	}

	private static void noRetrocenter() {
		verdicts.put(key(), false);
		phase = Phase.IDLE;
		heldHandshake = null;
		C_88014908 dead = handler;
		try {
			dead.m_62597307();
		} catch (Throwable ignored) {
		}
		// reconnect cleanly; the cached verdict skips the probe this time
		Minecraft mc = MinecraftAccessor.getInstance();
		mc.m_52715402(new C_43496149(mc, host, port));
	}

	private static String key() {
		return host + ":" + port;
	}
}
