package com.periut.starac.mixin.retrocenter;

import net.minecraft.unmapped.C_03562565;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Exposes b1.7.3's package-private packet-table registration — the same
 * trick OSL's networking impl uses for its own carrier packet.
 */
@Mixin(C_03562565.class)
public interface PacketRegistryInvoker {

	@Invoker("register")
	static void retrocenter$register(int id, boolean s2c, boolean c2s, Class<? extends C_03562565> clazz) {
		throw new AssertionError();
	}
}
