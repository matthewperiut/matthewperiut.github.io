package com.periut.starac.mixin.lwjgl3;

import net.minecraft.unmapped.C_31574624;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_31574624.class)
public abstract class MixinResourceDownloadThread {

	@Shadow public abstract void reload();

	@Inject(method = "run", at = @At("HEAD"), cancellable = true)
	private void noResourceLoading(CallbackInfo ci){
		ci.cancel();
		reload();
	}
}