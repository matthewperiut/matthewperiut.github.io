package com.periut.starac.mixin.retrocenter;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.periut.starac.retrocenter.net.ServerProbe;
import net.minecraft.unmapped.C_58873528;

/**
 * Freezes the vanilla "Took too long to log in" timeout while a client is
 * syncing mods over the pre-login probe — downloads can take longer than
 * the ~30s login budget.
 */
@Mixin(C_58873528.class)
public abstract class ServerLoginHandlerSyncMixin {

	@Shadow
	private int loginTicks;

	@Inject(method = "tick", at = @At("HEAD"))
	private void retrocenter$freezeLoginTimeout(CallbackInfo ci) {
		if (ServerProbe.isActive((C_58873528) (Object) this)) {
			this.loginTicks = 0;
		}
	}
}
