package com.periut.starac.mixin.retrocenter;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.periut.starac.retrocenter.net.ProbeFlow;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_04787565;
import net.minecraft.unmapped.C_88014908;

/**
 * Wires the pre-login probe into the very first connection attempt:
 * - remember the target of every outgoing connection,
 * - hold the login at the handshake while the probe runs on this same
 *   connection,
 * - translate a probe rejection (vanilla server kicking our carrier packet)
 *   into a clean re-connect without probing,
 * - drive the probe timeout from the connection pump.
 */
@Mixin(C_88014908.class)
public abstract class ClientNetworkHandlerProbeMixin {

	@Inject(method = "<init>", at = @At("RETURN"))
	private void retrocenter$onConnect(Minecraft minecraft, String host, int port, CallbackInfo ci) {
		ProbeFlow.onConnectionStart((C_88014908) (Object) this, host, port);
	}

	@Inject(method = "onHandshake", at = @At("HEAD"), cancellable = true)
	private void retrocenter$holdLoginForProbe(C_04787565 packet, CallbackInfo ci) {
		if (ProbeFlow.holdLogin((C_88014908) (Object) this, packet)) {
			ci.cancel();
		}
	}

	@Inject(method = "tick", at = @At("HEAD"))
	private void retrocenter$probeTimeout(CallbackInfo ci) {
		ProbeFlow.clientTick((C_88014908) (Object) this);
	}

	@Inject(method = "onDisconnected", at = @At("HEAD"), cancellable = true)
	private void retrocenter$probeRejected(String reason, Object[] args, CallbackInfo ci) {
		if (ProbeFlow.onDisconnected((C_88014908) (Object) this, reason)) {
			ci.cancel();
		}
	}
}
