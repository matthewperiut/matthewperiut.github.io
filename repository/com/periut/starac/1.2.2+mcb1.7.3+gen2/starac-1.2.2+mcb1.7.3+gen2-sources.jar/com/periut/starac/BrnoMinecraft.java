package com.periut.starac;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_35886751;
import net.minecraft.unmapped.C_43718703;
import net.minecraft.unmapped.C_95807626;
import org.lwjgl.LWJGLException;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.DisplayMode;

import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class BrnoMinecraft extends Minecraft {

    private final Frame frame;
    private int previousWidth;
    private int previousHeight;

    public BrnoMinecraft(int width, int height, boolean fullscreen) {
        super(null, null, null, width, height, fullscreen);
        this.previousWidth = width;
        this.previousHeight = height;
        this.frame = new Frame("Minecraft");
    }

    @Override
    public void m_49334482(C_95807626 throwable) { // displayUnexpectedThrowable(UnexpectedThrowable)
        // RetroCenter: a child instance must NOT open an AWT crash window
        // (closing it would System.exit the whole JVM, hub included). The
        // crash report is plumbed back to the hub, which shows it on its
        // own scrollable crash screen.
        if (com.periut.starac.retrocenter.RetroCenter.isChildInstance()) {
            com.periut.starac.retrocenter.bridge.HubBridge.lockChildPresenting();
            StringBuilder report = new StringBuilder();
            if (throwable.f_02058304 != null) {
                report.append(throwable.f_02058304).append("\n\n");
            }
            if (throwable.f_55253361 != null) {
                java.io.StringWriter stack = new java.io.StringWriter();
                throwable.f_55253361.printStackTrace(new java.io.PrintWriter(stack));
                report.append(stack);
            }
            com.periut.starac.retrocenter.bridge.HubBridge.noteChildCrash(report.toString());
            com.periut.starac.retrocenter.bridge.HubBridge.childGameEnded("crashed");
            Display.destroy(); // child path: detaches from the shared window
            return;
        }
        this.frame.removeAll();
        this.frame.add(new C_35886751(throwable), "Center");
        this.frame.validate();
        this.frame.setSize(this.f_31800787, this.f_74192110);
        this.frame.setLocationRelativeTo(null);
        this.frame.setAutoRequestFocus(true);
        this.frame.addWindowListener(new WindowAdapter() {
                                         public void windowClosing(WindowEvent we) {
                                             frame.dispose();
                                             System.exit(1);
                                         }
                                     }
        );
        this.frame.setVisible(true);
        Display.destroy();
    }

    @Override
    public void m_81815981() throws LWJGLException {
        super.m_81815981();
    }

    @Override
    public void m_67975642() {
        if (Display.getWidth() != this.f_31800787 || Display.getHeight() != this.f_74192110) {
            this.m_60801884(Display.getWidth(), Display.getHeight());
        }

        super.m_67975642();
    }

    @Override
    public void m_87006267() {
        try {
            this.f_96101654 = !this.f_96101654;

            if (this.f_96101654) {
                this.previousWidth = Display.getWidth();
                this.previousHeight = Display.getHeight();

                Display.setDisplayMode(Display.getDesktopDisplayMode());
                this.f_31800787 = Display.getDisplayMode().getWidth();
                this.f_74192110 = Display.getDisplayMode().getHeight();
            } else {
                this.f_31800787 = this.previousWidth;
                this.f_74192110 = this.previousHeight;
                Display.setDisplayMode(new DisplayMode(this.f_31800787, this.f_74192110));
            }

            if (this.f_31800787 <= 0) {
                this.f_31800787 = 1;
            }

            if (this.f_74192110 <= 0) {
                this.f_74192110 = 1;
            }

            if (this.f_70816363 != null) {
                this.m_60801884(this.f_31800787, this.f_74192110);
            }

            Display.setFullscreen(this.f_96101654);
            Display.update();
        } catch (Exception e) {
            //noinspection CallToPrintStackTrace
            e.printStackTrace();
        }
    }

    private void m_60801884(int width, int height) {
        if (width <= 0) {
            width = 1;
        }

        if (height <= 0) {
            height = 1;
        }

        this.f_31800787 = width;
        this.f_74192110 = height;
        if (this.f_70816363 != null) {
            C_43718703 scaler = new C_43718703(this.f_58088711, width, height);
            int scaledWidth = scaler.m_39119333();
            int scaledHeight = scaler.m_16103615();
            this.f_70816363.m_55923303(this, scaledWidth, scaledHeight);
        }
    }
}
