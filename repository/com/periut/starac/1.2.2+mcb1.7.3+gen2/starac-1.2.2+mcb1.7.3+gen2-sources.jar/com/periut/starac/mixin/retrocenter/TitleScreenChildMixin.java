package com.periut.starac.mixin.retrocenter;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.periut.starac.retrocenter.RetroCenter;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_95462098;

/**
 * A child instance has no business at the title screen: it was spawned to
 * play on exactly one server, so landing here means the player left it.
 * Shut down gracefully — the bridge gives the window back to the hub.
 */
@Mixin(C_95462098.class)
public abstract class TitleScreenChildMixin extends C_85740840 {

	@Inject(method = "init()V", at = @At("HEAD"), cancellable = true)
	private void retrocenter$closeChildAtTitle(CallbackInfo ci) {
		if (RetroCenter.isChildInstance()) {
			RetroCenter.log("child reached title screen — shutting down to return to hub");
			com.periut.starac.retrocenter.bridge.HubBridge.lockChildPresenting();
			ci.cancel();
			if (this.f_78495264 != null) {
				this.f_78495264.m_12353564();
			}
		}
	}
}
