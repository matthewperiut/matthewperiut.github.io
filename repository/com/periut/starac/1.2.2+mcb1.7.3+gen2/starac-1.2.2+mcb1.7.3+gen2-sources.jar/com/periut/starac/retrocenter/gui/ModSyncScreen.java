package com.periut.starac.retrocenter.gui;

import java.nio.file.Path;

import com.periut.starac.retrocenter.RetroCenter;
import com.periut.starac.retrocenter.bridge.ChildConfig;
import com.periut.starac.retrocenter.bridge.HubBridge;
import com.periut.starac.retrocenter.child.InProcessChildLauncher;
import com.periut.starac.retrocenter.net.ProbeFlow;
import com.periut.starac.retrocenter.profile.ServerProfiles;
import com.periut.starac.retrocenter.sync.ModManifest;
import com.periut.starac.retrocenter.sync.ModSyncClient;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_19869088;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_88014908;
import net.minecraft.unmapped.C_95462098;

/**
 * Consent + download + handoff over a HELD PRE-LOGIN connection.
 *
 * Opened by ProbeFlow when the server's manifest doesn't match this
 * instance's mod set. The login was never sent: no world, no player entity
 * — the server's login timeout is frozen by ServerLoginHandlerSyncMixin
 * while we stream files over the same socket. States:
 *
 *   CONSENT      mod list + size, [Download & Join] / [Cancel]
 *   DOWNLOADING  tick-driven chunk pull (this screen pumps the connection)
 *   LAUNCHING    profile ready → drop the probe connection, boot child,
 *                hand the window over
 *   HOSTING      hub parked; ticks again only once the window is back —
 *                then shows why the child ended
 *   FAILED       sync error, [Back]
 *
 * OSL-free: reached purely via the vanilla-carrier probe.
 */
public final class ModSyncScreen extends C_85740840 {

	private static final int BUTTON_ACCEPT = 0;
	private static final int BUTTON_CANCEL = 1;

	private enum State {CONSENT, DOWNLOADING, LAUNCHING, HOSTING, FAILED}

	private final Minecraft mc;
	private final ModManifest manifest;
	private final String host;
	private final int port;
	private final C_88014908 connection;

	private volatile State state = State.CONSENT;
	private ModSyncClient.DownloadSession session;
	private Path profileDir;
	private volatile String error;
	private int modListScroll;

	public ModSyncScreen(Minecraft mc, ModManifest manifest, String host, int port, C_88014908 connection) {
		this.mc = mc;
		this.manifest = manifest;
		this.host = host;
		this.port = port;
		this.connection = connection;
	}

	@Override
	public void m_41805697() {
		f_78519977.clear();
		if (state == State.CONSENT) {
			// same size/shape/position as the multiplayer screen's
			// Connect/Cancel buttons
			f_78519977.add(new C_85125467(BUTTON_ACCEPT, f_05230747 / 2 - 100, f_07021018 / 4 + 96 + 12, "Download & Join"));
			f_78519977.add(new C_85125467(BUTTON_CANCEL, f_05230747 / 2 - 100, f_07021018 / 4 + 120 + 12, "Cancel"));
		} else if (state == State.FAILED) {
			f_78519977.add(new C_85125467(BUTTON_CANCEL, f_05230747 / 2 - 100, f_07021018 / 4 + 120 + 12, "Back"));
		}
	}

	@Override
	protected void m_30778170(C_85125467 button) {
		if (button.f_92999450 == BUTTON_ACCEPT && state == State.CONSENT) {
			startDownload();
		} else if (button.f_92999450 == BUTTON_CANCEL) {
			abort();
		}
	}

	private void startDownload() {
		try {
			profileDir = ServerProfiles.profileDir(host, port);
			session = ModSyncClient.startSession(manifest, profileDir, connection);
			state = State.DOWNLOADING;
			m_55923303(mc, f_05230747, f_07021018); // rebuild buttons
		} catch (Exception e) {
			e.printStackTrace();
			fail(e.toString());
		}
	}

	@Override
	public void m_53520780() {
		switch (state) {
			case CONSENT:
			case DOWNLOADING:
				// We own the held pre-login connection: pump it so probe
				// chunks (and disconnects) keep flowing.
				try {
					connection.m_23385152();
				} catch (Throwable t) {
					t.printStackTrace();
					fail("connection lost: " + t);
					return;
				}
				if (state == State.DOWNLOADING && session != null) {
					session.tick();
					if (session.error() != null) {
						fail(session.error());
					} else if (session.isFinished()) {
						state = State.LAUNCHING;
					}
				}
				break;
			case LAUNCHING:
				launchChild();
				break;
			case HOSTING:
				// Safety net only: the wake callback normally swaps the hub
				// to its destination screen before this can ever tick again.
				if (!HubBridge.isChildRunning()) {
					mc.m_52715402(retrocenterDestinationScreen());
				}
				break;
			default:
		}
	}

	private void launchChild() {
		state = State.HOSTING;
		try {
			String username = mc.f_69329575 != null ? mc.f_69329575.f_18340302 : "Player";
			String sessionId = mc.f_69329575 != null ? mc.f_69329575.f_59704460 : "";

			ServerProfiles.seedInfraMods(profileDir);

			// Done with the probe connection — the child dials its own.
			try {
				connection.m_62597307();
			} catch (Throwable ignored) {
			}
			ProbeFlow.syncSessionEnded();

			ChildConfig config = new ChildConfig(host, port, username, sessionId,
					profileDir.toAbsolutePath().toString(),
					net.fabricmc.loader.api.FabricLoader.getInstance().getGameDir().toAbsolutePath().toString());
			HubBridge.setChildConfig(config);

			// At wake (context re-acquired, before anything renders) the hub
			// jumps straight to its destination: the main menu for a plain
			// disconnect, ChildEndScreen for kicks/crashes. No stale frames.
			final Minecraft mcRef = this.mc;
			HubBridge.setHubWakeCallback(() -> mcRef.m_52715402(retrocenterDestinationScreen()));

			InProcessChildLauncher.launch(config);
			HubBridge.handOwnershipToChild();
			// The hub's next Display.update() parks until the child returns.
		} catch (Throwable t) {
			t.printStackTrace();
			HubBridge.setHubWakeCallback(null);
			fail(t.toString());
			HubBridge.returnOwnershipToHub(null);
		}
	}

	private void abort() {
		RetroCenter.log("sync aborted by user");
		ModSyncClient.endSession();
		ProbeFlow.syncSessionEnded();
		try {
			connection.m_62597307();
		} catch (Throwable ignored) {
		}
		mc.m_52715402(new C_95462098());
	}

	private void fail(String message) {
		error = message;
		state = State.FAILED;
		ModSyncClient.endSession();
		ProbeFlow.syncSessionEnded();
		try {
			connection.m_62597307();
		} catch (Throwable ignored) {
		}
		m_55923303(mc, f_05230747, f_07021018);
	}

	@Override
	public void m_93956703(int mouseX, int mouseY, float delta) {
		m_34695786();
		// title in the multiplayer screen's title position
		m_50067982(f_11884601, "RetroCenter — " + host + ":" + port,
				f_05230747 / 2, f_07021018 / 4 - 60 + 20, 0xFFFFFF);

		switch (state) {
			case CONSENT: {
				m_50067982(f_11884601,
						"This server provides " + manifest.entries.size() + " mods ("
								+ formatSize(manifest.totalSize()) + ").",
						f_05230747 / 2, f_07021018 / 4 - 24, 0xAAAAAA);
				m_50067982(f_11884601,
						"Downloaded mods are executable code. Only continue if you trust this server.",
						f_05230747 / 2, f_07021018 / 4 - 12, 0xFF8888);

				// compact scrollable mod list (mouse wheel)
				int boxLeft = f_05230747 / 2 - 110;
				int boxRight = f_05230747 / 2 + 110;
				int boxTop = modListBoxTop();
				int boxBottom = modListBoxBottom();
				m_57734177(boxLeft, boxTop, boxRight, boxBottom, 0xA0000000);
				m_57734177(boxLeft + 1, boxTop + 1, boxRight - 1, boxBottom - 1, 0x60000000);

				int visible = modListVisibleLines();
				int y = boxTop + 4;
				for (int i = modListScroll; i < Math.min(manifest.entries.size(), modListScroll + visible); i++) {
					ModManifest.Entry entry = manifest.entries.get(i);
					String line = entry.modId + " " + entry.version + " (" + formatSize(entry.size) + ")";
					while (f_11884601.m_09235706(line) > boxRight - boxLeft - 16 && line.length() > 4) {
						line = line.substring(0, line.length() - 4) + "…";
					}
					m_62884682(f_11884601, line, boxLeft + 5, y, 0xCCCCCC);
					y += 11;
				}
				if (manifest.entries.size() > visible) {
					int trackTop = boxTop + 2;
					int trackHeight = boxBottom - boxTop - 4;
					int thumbHeight = Math.max(6, trackHeight * visible / manifest.entries.size());
					int thumbY = trackTop + (trackHeight - thumbHeight) * modListScroll
							/ Math.max(1, manifest.entries.size() - visible);
					m_57734177(boxRight - 5, trackTop, boxRight - 2, trackTop + trackHeight, 0x40FFFFFF);
					m_57734177(boxRight - 5, thumbY, boxRight - 2, thumbY + thumbHeight, 0xC0FFFFFF);
				}
				break;
			}
			case DOWNLOADING: {
				long total = Math.max(1, session != null ? session.bytesTotal() : 1);
				long done = session != null ? session.bytesDone() : 0;
				m_50067982(f_11884601, "Downloading mods...", f_05230747 / 2, 70, 0xFFFFFF);
				m_50067982(f_11884601,
						session != null ? session.currentFile() : "", f_05230747 / 2, 86, 0xAAAAAA);
				int barWidth = 200;
				int x = f_05230747 / 2 - barWidth / 2;
				int y = 104;
				int filled = (int) (barWidth * Math.min(1.0, (double) done / total));
				m_57734177(x - 1, y - 1, x + barWidth + 1, y + 7, 0xFF000000);
				m_57734177(x, y, x + filled, y + 6, 0xFF55FF55);
				m_50067982(f_11884601,
						formatSize(done) + " / " + formatSize(total), f_05230747 / 2, 116, 0xAAAAAA);
				break;
			}
			case LAUNCHING:
			case HOSTING:
				m_50067982(f_11884601, "Starting server instance...", f_05230747 / 2, 80, 0xFFFFFF);
				m_50067982(f_11884601,
						"The window will switch to the server's modded instance.", f_05230747 / 2, 96, 0xAAAAAA);
				break;
			case FAILED:
				m_50067982(f_11884601, "Mod sync failed", f_05230747 / 2, 70, 0xFF5555);
				m_50067982(f_11884601, String.valueOf(error), f_05230747 / 2, 90, 0xAAAAAA);
				break;
			default:
		}
		super.m_93956703(mouseX, mouseY, delta);
	}

	@Override
	public void m_29921564() {
		super.m_29921564();
		if (state == State.CONSENT) {
			int wheel = org.lwjgl.input.Mouse.getEventDWheel();
			if (wheel != 0) {
				int max = Math.max(0, manifest.entries.size() - modListVisibleLines());
				modListScroll = Math.max(0, Math.min(max, modListScroll - Integer.signum(wheel) * 2));
			}
		}
	}

	private int modListBoxTop() {
		return f_07021018 / 4;
	}

	private int modListBoxBottom() {
		// fill the space down to just above the Connect-position button
		return Math.max(modListBoxTop() + 26, f_07021018 / 4 + 96 + 12 - 6);
	}

	private int modListVisibleLines() {
		return Math.max(2, (modListBoxBottom() - modListBoxTop() - 6) / 11);
	}

	/**
	 * Where the hub lands after a child session: title screen for a plain
	 * disconnect, the EXACT vanilla DisconnectedScreen (raw translation keys
	 * + args replayed) for kicks, and the custom crash screen only for
	 * crashes.
	 */
	private static C_85740840 retrocenterDestinationScreen() {
		HubBridge.ChildExitInfo info = HubBridge.consumeChildExitInfo();
		if (info == null) {
			return new C_95462098();
		}
		if (info.crash) {
			return new ChildEndScreen("Minecraft Crashed", info.message);
		}
		Object[] args = info.args != null ? info.args : new Object[0];
		return new C_19869088(info.title, info.message, args);
	}

	@Override
	public boolean m_47190451() {
		return false;
	}

	private static String formatSize(long bytes) {
		if (bytes >= 1024 * 1024) {
			return String.format("%.1f MiB", bytes / (1024.0 * 1024.0));
		}
		return (bytes / 1024) + " KiB";
	}
}
