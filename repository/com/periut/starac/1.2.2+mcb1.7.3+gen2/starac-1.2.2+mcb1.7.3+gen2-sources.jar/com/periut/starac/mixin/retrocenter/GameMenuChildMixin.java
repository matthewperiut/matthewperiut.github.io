package com.periut.starac.mixin.retrocenter;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.periut.starac.retrocenter.RetroCenter;
import com.periut.starac.retrocenter.bridge.HubBridge;
import net.minecraft.unmapped.C_55401126;
import net.minecraft.unmapped.C_85125467;

/**
 * The earliest disconnect signal: the moment the player clicks "Disconnect"
 * (button id 1) in a child instance, lock presenting — the pause-menu frame
 * freezes and none of the teardown transition screens flicker through; the
 * next visible frame belongs to the hub.
 */
@Mixin(C_55401126.class)
public abstract class GameMenuChildMixin {

	@Inject(method = "buttonClicked", at = @At("HEAD"))
	private void retrocenter$freezeOnDisconnect(C_85125467 button, CallbackInfo ci) {
		if (button.f_92999450 == 1 && RetroCenter.isChildInstance()) {
			RetroCenter.log("child disconnect clicked — freezing presentation");
			HubBridge.lockChildPresenting();
		}
	}
}
