package com.periut.retrodragon.shim;

import com.periut.retrodragon.render.Primitives;
import com.periut.retrodragon.render.QuadIndices;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Everything the game drew this frame, recorded in submission order.
 *
 * <p>Under GL, a draw takes effect the moment beta calls it. Under WebGPU a draw is a command
 * recorded into an encoder, and the state it needs -- matrices, colour, fog, the bound texture -- has
 * to be captured AT THE CALL, not read back later, because by the time the frame is submitted beta
 * has moved on. So each batch carries its own copy of the uniform block, and the vertices are
 * appended to one buffer that is uploaded once.
 *
 * <h2>Why the vertices need no conversion</h2>
 *
 * Beta's Tessellator already packs vertices as 8 ints -- position 3f at 0, texture 2f at 12, colour
 * 4 bytes at 20, normal 3 bytes at 24 -- which is a 32-byte stride identical to what
 * {@code fixedfunc.wgsl} declares. Capturing a batch is therefore a straight copy of the bytes beta
 * was about to hand to {@code glVertexPointer}, with no repacking at all.
 *
 * <p>Not thread-safe. Every caller is the render thread, and immediate-mode drawing is inherently
 * serial.
 */
public final class DrawList {
	/** Bytes per vertex, matching beta's Tessellator and {@code fixedfunc.wgsl}. */
	public static final int STRIDE = 32;

	/** One uniform block per batch, at WebGPU's guaranteed dynamic-offset alignment. */
	public static final int UNIFORM_SLOT = 256;

	private static final int INITIAL_VERTICES = 16384;
	private static final int INITIAL_BATCHES = 512;

	private ByteBuffer vertices;
	private int vertexCount;

	private ByteBuffer uniforms;
	private int batchCount;

	private long[] pipelineKey = new long[INITIAL_BATCHES];
	private int[] firstVertex = new int[INITIAL_BATCHES];
	private int[] count = new int[INITIAL_BATCHES];
	private int[] texture = new int[INITIAL_BATCHES];
	private int[] glMode = new int[INITIAL_BATCHES];

	/**
	 * Index into {@link #buffers} for a batch whose vertices live in a buffer of their own, or -1
	 * for the ordinary case where they were copied into this frame's shared buffer.
	 *
	 * <p>Terrain needs this. A section's geometry changes only when the blocks in it change, so
	 * copying it into the frame buffer every frame would move tens of megabytes a second to
	 * reproduce data the GPU already has. Instead each section keeps its own buffer and the batch
	 * just points at it -- but it still has to occupy its true position in the frame's draw order,
	 * because the world is drawn before the GUI and depth-tested against it.
	 */
	private int[] external = new int[INITIAL_BATCHES];
	private final java.util.ArrayList<Object> buffers = new java.util.ArrayList<>();

	/**
	 * What the game was drawing when each batch was captured; see {@code api/DrawPhase}.
	 *
	 * <p>Recorded per batch rather than derived at replay because by replay the game has moved on --
	 * the phase is only knowable at the moment of capture. It is what lets the replay find "the end
	 * of the opaque world" without guessing from state, and what a shader extension routes on.
	 */
	private int[] phase = new int[INITIAL_BATCHES];

	// --- viewport --------------------------------------------------------------------------------
	//
	// Recorded per batch for the same reason the phase is: GL applies the viewport in force AT THE
	// CALL, and by replay the game has moved on. Beta itself only ever sets the full window, which
	// is a pass's default -- so the common case is the sentinel and costs no SetViewport at all.
	// Mods are what this exists for: OldMCLogo renders its 3D logo through a viewport covering just
	// the top strip of the title screen, and without this its perspective scene lands NDC-stretched
	// across the whole framebuffer.

	/** The full attachment -- no batch carries an explicit viewport. Impossible as a packed value. */
	public static final long VIEWPORT_FULL = -1L;

	private long[] viewport = new long[INITIAL_BATCHES];
	private long currentViewport = VIEWPORT_FULL;

	/**
	 * The framebuffer size the frame's explicit viewports are relative to, in the same units beta
	 * passes to {@code glViewport}. Zero until a frame records an explicit viewport; replay scales
	 * by attachment/framebuffer, so a range drawn into a resized target keeps its proportions.
	 */
	private int framebufferWidth;
	private int framebufferHeight;

	/** GL's values as called: bottom-left origin. The y flip needs the attachment and happens at replay. */
	public static long packViewport(int x, int y, int width, int height) {
		return (x & 0xFFFFL) << 48 | (y & 0xFFFFL) << 32 | (width & 0xFFFFL) << 16
			| height & 0xFFFFL;
	}

	public static int viewportX(long packed) {
		return (short) (packed >>> 48);
	}

	public static int viewportY(long packed) {
		return (short) (packed >>> 32);
	}

	public static int viewportWidth(long packed) {
		return (short) (packed >>> 16);
	}

	public static int viewportHeight(long packed) {
		return (short) packed;
	}

	/** Stamped onto every batch recorded from here on; {@link #VIEWPORT_FULL} for beta's default. */
	public void viewport(long packed) {
		currentViewport = packed;
	}

	public void framebufferSize(int width, int height) {
		framebufferWidth = width;
		framebufferHeight = height;
	}

	public long viewport(int batch) {
		return viewport[batch];
	}

	public int framebufferWidth() {
		return framebufferWidth;
	}

	public int framebufferHeight() {
		return framebufferHeight;
	}

	// --- pass segments ---------------------------------------------------------------------------
	//
	// Beta clears mid-frame -- the depth buffer between the world and the GUI, most notably -- and
	// under GL that takes effect immediately. WebGPU has no mid-pass clear at all: a clear is a
	// LOAD OP, chosen when the pass begins. So a clear ends the current pass and opens a new one,
	// and the frame becomes a sequence of segments rather than a single pass.
	private static final int INITIAL_SEGMENTS = 8;
	private static final int CLEAR_COLOR = 1;
	private static final int CLEAR_DEPTH = 2;

	private int[] segmentFirstBatch = new int[INITIAL_SEGMENTS];
	private int[] segmentFlags = new int[INITIAL_SEGMENTS];
	private float[] segmentClear = new float[INITIAL_SEGMENTS * 4];
	/** Range of {@link #copyTexture} entries to perform BEFORE this segment's pass opens. */
	private int[] segmentCopyFirst = new int[INITIAL_SEGMENTS];
	private int[] segmentCopyCount = new int[INITIAL_SEGMENTS];
	private int segmentCount;

	public DrawList() {
		vertices = direct(INITIAL_VERTICES * STRIDE);
		uniforms = direct(INITIAL_BATCHES * UNIFORM_SLOT);
		reset();
	}

	/**
	 * Ends the current segment and starts one whose pass begins with these load ops.
	 *
	 * <p>Coalesces with the segment already open when it is still empty: beta issues several
	 * consecutive clears at the top of a frame (colour, then depth), and each one starting its own
	 * empty render pass would cost a full attachment load/store round trip for nothing.
	 */
	public void clear(boolean color, boolean depth, float r, float g, float b, float a) {
		int flags = (color ? CLEAR_COLOR : 0) | (depth ? CLEAR_DEPTH : 0);
		int current = segmentCount - 1;
		// Coalescing is only safe into a segment that has neither drawn nor COPIED anything: a
		// segment's copies run before its pass opens, so folding a later clear into one would move
		// the clear in front of a copy the game made after it -- the copy would then read a cleared
		// framebuffer instead of the frame it was asking for.
		if (segmentFirstBatch[current] == batchCount && segmentCopyCount[current] == 0) {
			segmentFlags[current] |= flags;
			if (color) {
				setClear(current, r, g, b, a);
			}
			return;
		}
		openSegment(flags);
		setClear(segmentCount - 1, r, g, b, a);
	}

	/** Starts a segment at the current batch, with no copies of its own yet. */
	private void openSegment(int flags) {
		ensureSegments();
		segmentFirstBatch[segmentCount] = batchCount;
		segmentFlags[segmentCount] = flags;
		segmentCopyFirst[segmentCount] = copyCount;
		segmentCopyCount[segmentCount] = 0;
		setClear(segmentCount, 0.0F, 0.0F, 0.0F, 1.0F);
		segmentCount++;
	}

	private void setClear(int segment, float r, float g, float b, float a) {
		segmentClear[segment * 4] = r;
		segmentClear[segment * 4 + 1] = g;
		segmentClear[segment * 4 + 2] = b;
		segmentClear[segment * 4 + 3] = a;
	}

	private void ensureSegments() {
		if (segmentCount < segmentFirstBatch.length) {
			return;
		}
		int capacity = segmentFirstBatch.length * 2;
		segmentFirstBatch = java.util.Arrays.copyOf(segmentFirstBatch, capacity);
		segmentFlags = java.util.Arrays.copyOf(segmentFlags, capacity);
		segmentClear = java.util.Arrays.copyOf(segmentClear, capacity * 4);
		segmentCopyFirst = java.util.Arrays.copyOf(segmentCopyFirst, capacity);
		segmentCopyCount = java.util.Arrays.copyOf(segmentCopyCount, capacity);
	}

	// --- framebuffer copies -----------------------------------------------------------------------
	//
	// glCopyTexSubImage2D. Recorded in the frame's order rather than performed at the call, for the
	// same reason a draw is: at the call there is no encoder, no attachment and no frame -- and the
	// entire content of the call is WHEN it happens, since it captures everything drawn up to that
	// point and nothing after it.
	//
	// Each copy is attached to a segment and runs before that segment's pass opens, which is exactly
	// the boundary "after everything recorded so far" needs. A copy therefore ends the current
	// segment, in the same way a clear does.

	private static final int INITIAL_COPIES = 8;

	private int[] copyTexture = new int[INITIAL_COPIES];
	private int[] copyDstX = new int[INITIAL_COPIES];
	private int[] copyDstY = new int[INITIAL_COPIES];
	private int[] copySrcX = new int[INITIAL_COPIES];
	private int[] copySrcY = new int[INITIAL_COPIES];
	private int[] copyWidth = new int[INITIAL_COPIES];
	private int[] copyHeight = new int[INITIAL_COPIES];
	private int copyCount;

	/**
	 * Records one {@code glCopyTexSubImage2D}, in GL's own coordinates.
	 *
	 * @param name the destination texture, which must already be renderable -- see
	 *             {@code TextureStore.makeRenderable}
	 */
	public void copyToTexture(int name, int dstX, int dstY, int srcX, int srcY, int width,
			int height) {
		if (width <= 0 || height <= 0) {
			return;
		}
		int current = segmentCount - 1;
		// A segment that has drawn something, or that will clear when its pass opens, cannot take
		// this copy: it would run before both. An empty one that only holds earlier copies can.
		if (segmentFirstBatch[current] != batchCount || segmentFlags[current] != 0) {
			openSegment(0);
			current = segmentCount - 1;
		}
		if (copyCount == copyTexture.length) {
			int capacity = copyCount * 2;
			copyTexture = java.util.Arrays.copyOf(copyTexture, capacity);
			copyDstX = java.util.Arrays.copyOf(copyDstX, capacity);
			copyDstY = java.util.Arrays.copyOf(copyDstY, capacity);
			copySrcX = java.util.Arrays.copyOf(copySrcX, capacity);
			copySrcY = java.util.Arrays.copyOf(copySrcY, capacity);
			copyWidth = java.util.Arrays.copyOf(copyWidth, capacity);
			copyHeight = java.util.Arrays.copyOf(copyHeight, capacity);
		}
		copyTexture[copyCount] = name;
		copyDstX[copyCount] = dstX;
		copyDstY[copyCount] = dstY;
		copySrcX[copyCount] = srcX;
		copySrcY[copyCount] = srcY;
		copyWidth[copyCount] = width;
		copyHeight[copyCount] = height;
		copyCount++;
		segmentCopyCount[current]++;
	}

	public int copyCount() {
		return copyCount;
	}

	public int segmentCopyFirst(int segment) {
		return segmentCopyFirst[segment];
	}

	public int segmentCopyCount(int segment) {
		return segmentCopyCount[segment];
	}

	public int copyTexture(int copy) {
		return copyTexture[copy];
	}

	public int copyDstX(int copy) {
		return copyDstX[copy];
	}

	public int copyDstY(int copy) {
		return copyDstY[copy];
	}

	public int copySrcX(int copy) {
		return copySrcX[copy];
	}

	public int copySrcY(int copy) {
		return copySrcY[copy];
	}

	public int copyWidth(int copy) {
		return copyWidth[copy];
	}

	public int copyHeight(int copy) {
		return copyHeight[copy];
	}

	public int segmentCount() {
		return segmentCount;
	}

	public int segmentFirstBatch(int segment) {
		return segmentFirstBatch[segment];
	}

	/** Exclusive end batch of a segment; the last one runs to the end of the frame. */
	public int segmentEndBatch(int segment) {
		return segment + 1 < segmentCount ? segmentFirstBatch[segment + 1] : batchCount;
	}

	public boolean segmentClearsColor(int segment) {
		return (segmentFlags[segment] & CLEAR_COLOR) != 0;
	}

	public boolean segmentClearsDepth(int segment) {
		return (segmentFlags[segment] & CLEAR_DEPTH) != 0;
	}

	public float segmentClear(int segment, int channel) {
		return segmentClear[segment * 4 + channel];
	}

	private static ByteBuffer direct(int bytes) {
		return ByteBuffer.allocateDirect(bytes).order(ByteOrder.nativeOrder());
	}

	/**
	 * Records one batch.
	 *
	 * @param source     beta's own vertex bytes, read from its current position; not consumed
	 * @param vertices   how many vertices {@code source} holds
	 * @param glMode     the {@code glDrawArrays} primitive mode ({@code GL_QUADS} for most of beta)
	 * @param uniformBlock the state this batch draws under, exactly {@link GlState#UNIFORM_BYTES}
	 */
	public void add(ByteBuffer source, int vertices, int glMode, long pipelineKey, int texture,
			ByteBuffer uniformBlock) {
		add(source, vertices, glMode, pipelineKey, texture, uniformBlock, 0);
	}

	public void add(ByteBuffer source, int vertices, int glMode, long pipelineKey, int texture,
			ByteBuffer uniformBlock, int phase) {
		if (vertices <= 0) {
			return;
		}
		ensureVertices(vertices);

		// Merge into the previous batch when nothing that affects the draw has changed. Beta emits
		// long runs of these -- every string of text, every GUI element on a screen, every particle
		// -- and they differ only in vertex data. Merging turns a screenful of text from hundreds of
		// draws into one, and it is exact rather than approximate: the batches share a pipeline, a
		// texture, a primitive mode and a byte-identical uniform block, so one draw over the
		// concatenated vertices is the same GPU work.
		if (canMerge(glMode, pipelineKey, texture, uniformBlock, phase)) {
			copy(source, vertices * STRIDE, this.vertices, vertexCount * STRIDE);
			count[batchCount - 1] += vertices;
			vertexCount += vertices;
			merged++;
			return;
		}

		ensureBatches();

		// Bulk copies, not per-byte loops: both buffers are direct, so this is an intrinsified
		// memcpy. A busy frame moves a few megabytes through here, and the naive loop showed up as
		// the single most expensive thing in the capture path.
		copy(source, vertices * STRIDE, this.vertices, vertexCount * STRIDE);
		copy(uniformBlock, GlState.UNIFORM_BYTES, uniforms, batchCount * UNIFORM_SLOT);

		this.pipelineKey[batchCount] = pipelineKey;
		this.firstVertex[batchCount] = vertexCount;
		this.count[batchCount] = vertices;
		this.texture[batchCount] = texture;
		this.glMode[batchCount] = glMode;
		this.external[batchCount] = -1;
		this.phase[batchCount] = phase;
		this.viewport[batchCount] = currentViewport;

		vertexCount += vertices;
		batchCount++;
	}

	/**
	 * Records a batch whose vertices are already on the GPU, in a buffer the caller owns.
	 *
	 * <p>Never merges with a neighbour: two batches in different buffers cannot become one draw.
	 *
	 * @param buffer      an opaque handle the renderer knows how to bind
	 * @param firstVertex offset within that buffer, in vertices
	 */
	public void addExternal(Object buffer, int firstVertex, int vertices, int glMode,
			long pipelineKey, int texture, ByteBuffer uniformBlock) {
		addExternal(buffer, firstVertex, vertices, glMode, pipelineKey, texture, uniformBlock, 0);
	}

	public void addExternal(Object buffer, int firstVertex, int vertices, int glMode,
			long pipelineKey, int texture, ByteBuffer uniformBlock, int phase) {
		if (vertices <= 0 || buffer == null) {
			return;
		}
		// Two allocations that are adjacent in the same buffer, under identical state, are one
		// draw. This is what the terrain arena exists for: at the default view distance it turns
		// hundreds of per-section draws into a handful of runs.
		if (canMergeExternal(buffer, firstVertex, glMode, pipelineKey, texture, uniformBlock, phase)) {
			count[batchCount - 1] += vertices;
			merged++;
			return;
		}
		ensureBatches();
		copy(uniformBlock, GlState.UNIFORM_BYTES, uniforms, batchCount * UNIFORM_SLOT);

		int handle = buffers.indexOf(buffer);
		if (handle < 0) {
			handle = buffers.size();
			buffers.add(buffer);
		}

		this.pipelineKey[batchCount] = pipelineKey;
		this.firstVertex[batchCount] = firstVertex;
		this.count[batchCount] = vertices;
		this.texture[batchCount] = texture;
		this.glMode[batchCount] = glMode;
		this.external[batchCount] = handle;
		this.phase[batchCount] = phase;
		this.viewport[batchCount] = currentViewport;
		batchCount++;
	}

	/** The buffer a batch draws from, or null when it uses this frame's shared vertex buffer. */
	public Object buffer(int batch) {
		int handle = external[batch];
		return handle < 0 ? null : buffers.get(handle);
	}

	/**
	 * Whether a batch can be appended to the previous one instead of starting its own draw.
	 *
	 * <p>Only within a segment: a pass boundary is a clear, and geometry cannot cross it. Indexed
	 * primitives merge because the index pattern is relative to the batch's base vertex and repeats
	 * -- quad N of a merged batch indexes exactly the vertices it did before. Strips and fans do NOT
	 * merge: concatenating two strips would create phantom triangles across the join.
	 */
	private boolean canMerge(int glMode, long pipelineKey, int texture, ByteBuffer uniformBlock,
			int phase) {
		if (batchCount == 0 || segmentFirstBatch[segmentCount - 1] == batchCount) {
			return false;
		}
		int previous = batchCount - 1;
		// A merged batch has ONE phase, and the replay uses phase boundaries to decide where a
		// shader extension's hooks fire and which batches a shadow map contains. Folding the first
		// entity draw into the last terrain one would move the deferred hook past geometry that
		// belongs before it.
		if (this.phase[previous] != phase) {
			return false;
		}
		// And ONE viewport, for the same reason: it is replayed per batch.
		if (this.viewport[previous] != currentViewport) {
			return false;
		}
		if (this.external[previous] >= 0) {
			// The previous batch draws from its own buffer; this one's vertices are in the shared
			// buffer, so they cannot be one draw.
			return false;
		}
		if (this.glMode[previous] != glMode || this.pipelineKey[previous] != pipelineKey
				|| this.texture[previous] != texture) {
			return false;
		}
		if (glMode != 4 && glMode != 7 && glMode != 1 && glMode != 0) {
			// GL_TRIANGLES, GL_QUADS, GL_LINES and GL_POINTS are the modes where each primitive is
			// self-contained. Everything else depends on its neighbours.
			return false;
		}
		// Same quad-alignment rule as canMergeExternal, for the same reason.
		if (glMode == 7 && this.count[previous] % QuadIndices.VERTICES_PER_QUAD != 0) {
			return false;
		}
		return sameUniforms(previous, uniformBlock);
	}

	/**
	 * Whether an arena-backed batch continues the previous one exactly.
	 *
	 * <p>Requires true adjacency -- {@code firstVertex + count} of the previous batch must equal this
	 * one's first vertex. Anything looser would draw the gap between them, which is either another
	 * section that was deliberately culled or unallocated space.
	 */
	private boolean canMergeExternal(Object buffer, int firstVertex, int glMode, long pipelineKey,
			int texture, ByteBuffer uniformBlock, int phase) {
		if (batchCount == 0 || segmentFirstBatch[segmentCount - 1] == batchCount) {
			return false;
		}
		int previous = batchCount - 1;
		if (this.phase[previous] != phase) {
			return false;
		}
		if (this.viewport[previous] != currentViewport) {
			return false;
		}
		if (external[previous] < 0 || buffers.get(external[previous]) != buffer) {
			return false;
		}
		if (this.glMode[previous] != glMode || this.pipelineKey[previous] != pipelineKey
				|| this.texture[previous] != texture) {
			return false;
		}
		if (this.firstVertex[previous] + this.count[previous] != firstVertex) {
			return false;
		}
		// An indexed quad batch draws the pattern 4q+{0,1,2,0,2,3} offset by a base vertex, so quad
		// boundaries in a MERGED run sit every four vertices from the run's start. A previous batch
		// whose vertex count is not a multiple of four shifts every quad after it by the remainder,
		// which does not drop geometry -- it draws triangles spanning two unrelated faces. Beta's
		// terrain never produces such a batch; refusing to merge one costs a draw call and removes
		// the possibility entirely.
		if (Primitives.indexing(glMode) == Primitives.Indexing.QUADS
				&& this.count[previous] % QuadIndices.VERTICES_PER_QUAD != 0) {
			return false;
		}
		return sameUniforms(previous, uniformBlock);
	}

	/**
	 * Whether a batch's uniform block is byte-identical to the one already stored for {@code batch}.
	 *
	 * <p>{@link ByteBuffer#mismatch} rather than a loop over {@code get}: it is a JDK intrinsic that
	 * compares machine words, where the loop was 256 bounds-checked single-byte reads. This runs
	 * once per batch and terrain alone offers it hundreds of times a frame, every frame, for the
	 * express purpose of failing fast -- so it is worth having it fail fast cheaply.
	 */
	private boolean sameUniforms(int batch, ByteBuffer uniformBlock) {
		int slot = batch * UNIFORM_SLOT;
		int position = uniforms.position();
		int limit = uniforms.limit();
		int blockPosition = uniformBlock.position();
		int blockLimit = uniformBlock.limit();
		try {
			uniforms.clear().position(slot).limit(slot + GlState.UNIFORM_BYTES);
			uniformBlock.limit(blockPosition + GlState.UNIFORM_BYTES);
			return uniforms.mismatch(uniformBlock) < 0;
		} finally {
			uniforms.limit(limit).position(position);
			uniformBlock.limit(blockLimit).position(blockPosition);
		}
	}

	/** How many batches were folded into a neighbour this frame; a direct measure of the win. */
	public int mergedCount() {
		return merged;
	}

	private int merged;

	/** Copies {@code bytes} from {@code source}'s position into {@code destination} at an offset,
	 * leaving both buffers' position and limit exactly as they were -- beta reuses its buffer. */
	private static void copy(ByteBuffer source, int bytes, ByteBuffer destination, int at) {
		int sourcePosition = source.position();
		int sourceLimit = source.limit();
		int destinationPosition = destination.position();
		int destinationLimit = destination.limit();
		try {
			source.limit(sourcePosition + bytes);
			destination.clear().position(at);
			destination.put(source);
		} finally {
			source.position(sourcePosition).limit(sourceLimit);
			destination.limit(destinationLimit).position(destinationPosition);
		}
	}

	private void ensureVertices(int extra) {
		int needed = (vertexCount + extra) * STRIDE;
		if (needed <= vertices.capacity()) {
			return;
		}
		int capacity = vertices.capacity();
		while (capacity < needed) {
			capacity *= 2;
		}
		ByteBuffer grown = direct(capacity);
		vertices.position(0).limit(vertexCount * STRIDE);
		grown.put(vertices);
		grown.clear();
		vertices = grown;
	}

	private void ensureBatches() {
		if (batchCount < pipelineKey.length) {
			return;
		}
		int capacity = pipelineKey.length * 2;
		pipelineKey = java.util.Arrays.copyOf(pipelineKey, capacity);
		firstVertex = java.util.Arrays.copyOf(firstVertex, capacity);
		count = java.util.Arrays.copyOf(count, capacity);
		texture = java.util.Arrays.copyOf(texture, capacity);
		glMode = java.util.Arrays.copyOf(glMode, capacity);
		external = java.util.Arrays.copyOf(external, capacity);
		phase = java.util.Arrays.copyOf(phase, capacity);
		viewport = java.util.Arrays.copyOf(viewport, capacity);

		ByteBuffer grown = direct(capacity * UNIFORM_SLOT);
		uniforms.position(0).limit(batchCount * UNIFORM_SLOT);
		grown.put(uniforms);
		grown.clear();
		uniforms = grown;
	}

	public int batchCount() {
		return batchCount;
	}

	public int vertexCount() {
		return vertexCount;
	}

	public long pipelineKey(int batch) {
		return pipelineKey[batch];
	}

	public int firstVertex(int batch) {
		return firstVertex[batch];
	}

	public int count(int batch) {
		return count[batch];
	}

	public int texture(int batch) {
		return texture[batch];
	}

	public int glMode(int batch) {
		return glMode[batch];
	}

	/** What the game was drawing when this batch was captured; see {@code api/DrawPhase}. */
	public int phase(int batch) {
		return phase[batch];
	}

	/**
	 * The first batch at or after {@code from} whose phase is not part of the world.
	 *
	 * <p>Where the world ends and the GUI begins, which is where a shader extension's composite
	 * chain has to run: everything before it goes through the extension's target, everything after
	 * it is drawn on the result.
	 */
	public int firstNonWorldBatch(int from) {
		for (int batch = from; batch < batchCount; batch++) {
			if (!com.periut.retrodragon.api.DrawPhase.isWorld(phase[batch])) {
				return batch;
			}
		}
		return batchCount;
	}

	/**
	 * The first batch at or after {@code from} that is drawn AFTER the opaque world.
	 *
	 * <p>Where a deferred pass belongs: the opaque scene is complete and its depth is final, but
	 * nothing translucent has been blended over it yet. Beta's order puts sky and clouds first, then
	 * opaque terrain and entities, then translucent terrain and everything else, so the boundary is
	 * the first translucent-or-later phase.
	 */
	public int firstTranslucentBatch(int from) {
		for (int batch = from; batch < batchCount; batch++) {
			switch (phase[batch]) {
				case com.periut.retrodragon.api.DrawPhase.TERRAIN_TRANSLUCENT,
					com.periut.retrodragon.api.DrawPhase.PARTICLES,
					com.periut.retrodragon.api.DrawPhase.WEATHER,
					com.periut.retrodragon.api.DrawPhase.HAND,
					com.periut.retrodragon.api.DrawPhase.GUI -> {
					return batch;
				}
				default -> {
					// still opaque
				}
			}
		}
		return batchCount;
	}

	/** Byte offset of this batch's uniform block, ready to pass as a dynamic offset. */
	public int uniformOffset(int batch) {
		return batch * UNIFORM_SLOT;
	}

	/** Vertex bytes, position 0, limited to live data -- hand straight to a buffer write. */
	public ByteBuffer vertexData() {
		return vertices.position(0).limit(vertexCount * STRIDE);
	}

	public ByteBuffer uniformData() {
		return uniforms.position(0).limit(batchCount * UNIFORM_SLOT);
	}

	/** Drops the frame. Capacity is kept, so a steady-state frame allocates nothing. */
	public void reset() {
		vertices.clear();
		uniforms.clear();
		vertexCount = 0;
		batchCount = 0;
		merged = 0;
		buffers.clear();
		currentViewport = VIEWPORT_FULL;
		// One segment always exists, so a batch can be recorded before any clear arrives -- a mod
		// that draws before beta's first glClear would otherwise have nowhere to go.
		segmentCount = 1;
		segmentFirstBatch[0] = 0;
		segmentFlags[0] = 0;
		copyCount = 0;
		segmentCopyFirst[0] = 0;
		segmentCopyCount[0] = 0;
		setClear(0, 0.0F, 0.0F, 0.0F, 1.0F);
	}
}
