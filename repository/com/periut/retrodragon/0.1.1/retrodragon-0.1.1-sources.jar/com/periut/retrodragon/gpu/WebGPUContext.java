package com.periut.retrodragon.gpu;

import com.periut.webgpu.WGPUAdapterInfo;
import com.periut.webgpu.WGPUDeviceDescriptor;
import com.periut.webgpu.WGPUQueueWorkDoneCallback;
import com.periut.webgpu.WGPUQueueWorkDoneCallbackInfo;
import com.periut.webgpu.WGPURequestAdapterCallback;
import com.periut.webgpu.WGPURequestAdapterCallbackInfo;
import com.periut.webgpu.WGPURequestDeviceCallback;
import com.periut.webgpu.WGPURequestDeviceCallbackInfo;
import com.periut.webgpu.WGPUSupportedFeatures;
import com.periut.webgpu.WGPUUncapturedErrorCallback;
import com.periut.webgpu.WGPUUncapturedErrorCallbackInfo;

import java.lang.foreign.Arena;
import java.lang.foreign.MemorySegment;
import java.lang.foreign.ValueLayout;

import static com.periut.webgpu.webgpu_h.*;

/**
 * Owns the WebGPU objects that outlive a frame: instance, adapter, device and queue.
 *
 * <p>Everything else in the renderer hangs off this. It is deliberately separate from surface and
 * swapchain handling, because a device is useful without a window -- headless is how the pipeline
 * and shader permutations get tested in CI, where there is no display at all.
 *
 * <p><b>Threading.</b> A WebGPU device is not thread-affine the way a GL context is, but Dawn's
 * callbacks only run inside {@link #processEvents()}. Call that from whichever thread drives the
 * frame, and do not assume a callback has fired until it has.
 *
 * <p>Held in a long-lived {@link Arena}: the callback stubs registered with Dawn must stay alive as
 * long as the device can invoke them. Letting them be collected turns a later error report into a
 * JVM crash inside native code, which is a spectacularly unhelpful way to learn about a validation
 * error.
 */
public final class WebGPUContext implements AutoCloseable {
	private final Arena arena = Arena.ofShared();
	private MemorySegment instance = MemorySegment.NULL;
	private MemorySegment adapter = MemorySegment.NULL;
	private MemorySegment device = MemorySegment.NULL;
	private MemorySegment queue = MemorySegment.NULL;
	private int backendType = -1;
	private String adapterName = "unknown adapter";

	private WebGPUContext() {
	}

	/**
	 * Brings up instance, adapter and device, blocking until each resolves.
	 *
	 * @throws IllegalStateException if any stage fails; there is no partial success worth returning.
	 */
	public static WebGPUContext create() {
		WebGPUNatives.load();
		WebGPUContext ctx = new WebGPUContext();
		try {
			ctx.init();
			return ctx;
		} catch (RuntimeException e) {
			ctx.close();
			throw e;
		}
	}

	private void init() {
		instance = wgpuCreateInstance(instanceDescriptor());
		if (instance.equals(MemorySegment.NULL)) {
			throw new IllegalStateException("wgpuCreateInstance returned NULL");
		}

		adapter = awaitAdapter();
		MemorySegment info = WGPUAdapterInfo.allocate(arena);
		wgpuAdapterGetInfo(adapter, info);
		backendType = WGPUAdapterInfo.backendType(info);
		// Copied out now, not lazily: the strings belong to the adapter info struct, and reading them
		// after it goes out of scope is a use-after-free rather than a wrong name.
		String name = readMessage(WGPUAdapterInfo.device(info));
		if (!name.isEmpty()) {
			adapterName = name;
		}

		device = awaitDevice();
		queue = wgpuDeviceGetQueue(device);
		if (queue.equals(MemorySegment.NULL)) {
			throw new IllegalStateException("wgpuDeviceGetQueue returned NULL");
		}

		// Once, here, rather than per frame in markFrameSubmitted -- see the field comments for what
		// per-frame cost this: an upcall stub is a code blob, and 300k of them end the run.
		workDoneInfo = WGPUQueueWorkDoneCallbackInfo.allocate(arena);
		WGPUQueueWorkDoneCallbackInfo.mode(workDoneInfo, WGPUCallbackMode_AllowProcessEvents());
		WGPUQueueWorkDoneCallbackInfo.callback(workDoneInfo,
			WGPUQueueWorkDoneCallback.allocate(
				(status, message, u1, u2) -> inFlight.decrementAndGet(), arena));
		// Sized from the descriptor rather than a guess, so a WGPUFuture that grows cannot overflow it.
		MemorySegment future = arena.allocate(
			wgpuQueueOnSubmittedWorkDone$descriptor().returnLayout().orElseThrow());
		futureSink = (byteSize, byteAlignment) -> future;
	}

	private MemorySegment instanceDescriptor() {
		MemorySegment desc = com.periut.webgpu.WGPUInstanceDescriptor.allocate(arena);
		com.periut.webgpu.WGPUInstanceDescriptor.nextInChain(desc, toggles());
		return desc;
	}

	/** Every feature the adapter advertises, for diagnosing what is and is not available. */
	public java.util.List<Integer> features() {
		java.util.List<Integer> names = new java.util.ArrayList<>();
		if (adapter.equals(MemorySegment.NULL)) {
			return names;
		}
		try (Arena tmp = Arena.ofConfined()) {
			MemorySegment supported = WGPUSupportedFeatures.allocate(tmp);
			wgpuAdapterGetFeatures(adapter, supported);
			long count = WGPUSupportedFeatures.featureCount(supported);
			MemorySegment list = WGPUSupportedFeatures.features(supported).reinterpret(count * 4L);
			for (long i = 0; i < count; i++) {
				names.add(list.getAtIndex(ValueLayout.JAVA_INT, i));
			}
		}
		return names;
	}

	/**
	 * A {@code WGPUDawnTogglesDescriptor} enabling {@code allow_unsafe_apis}.
	 *
	 * <p>Dawn hides non-standard features behind that toggle -- multi-draw indirect among them, which
	 * it implements on Metal via {@code MTLIndirectCommandBuffer}. The shipped native does contain
	 * it: {@code wgpuRenderPassEncoderMultiDrawIndirect} is an exported symbol, and the binary
	 * carries the string {@code "Feature %s is guarded by toggle allow_unsafe_apis."}. So the
	 * capability is present and the only question is whether it is advertised.
	 *
	 * <p>Chained onto the ADAPTER request rather than the instance. An earlier attempt put it on the
	 * instance descriptor and the adapter still reported 38 features with multi-draw absent, which
	 * is consistent with Dawn evaluating toggles per adapter.
	 */
	private MemorySegment toggles() {
		MemorySegment names = arena.allocate(ValueLayout.ADDRESS, 1);
		names.setAtIndex(ValueLayout.ADDRESS, 0, arena.allocateFrom("allow_unsafe_apis"));

		MemorySegment toggles = com.periut.webgpu.WGPUDawnTogglesDescriptor.allocate(arena);
		com.periut.webgpu.WGPUChainedStruct.sType(
			com.periut.webgpu.WGPUDawnTogglesDescriptor.chain(toggles),
			WGPUSType_DawnTogglesDescriptor());
		com.periut.webgpu.WGPUDawnTogglesDescriptor.enabledToggleCount(toggles, 1);
		com.periut.webgpu.WGPUDawnTogglesDescriptor.enabledToggles(toggles, names);
		return toggles;
	}

	/**
	 * The native API to demand of Dawn, or 0 to let it choose.
	 *
	 * <p>{@code -Dretrogpu.backendType=d3d12|vulkan|opengl|gles|metal}. Dawn's default is the right
	 * one to ship -- D3D12 on Windows, Metal on macOS, Vulkan on Linux -- so this is a measuring
	 * tool, not a setting.
	 *
	 * <p>It answers a question no other measurement can: how much of the WebGPU renderer's cost is
	 * the API underneath it, and how much is the command stream this mod hands it. Running the same
	 * frame through two backends on ONE machine holds the CPU-side work, the driver's hardware and
	 * the scene constant and varies only the translation layer, which is the difference between "the
	 * D3D12 backend is slow here" and "we submit too much work". Comparing Windows against a
	 * different machine's Linux/Vulkan run cannot separate those.
	 *
	 * <p>Not every backend is present in every Dawn build, and a build that lacks one simply returns
	 * no adapter -- see the failure message in {@link #awaitAdapter()}.
	 */
	private static int forcedBackend() {
		return switch (System.getProperty("retrogpu.backendType", "").toLowerCase(java.util.Locale.ROOT)) {
			case "d3d12" -> WGPUBackendType_D3D12();
			case "d3d11" -> WGPUBackendType_D3D11();
			case "vulkan" -> WGPUBackendType_Vulkan();
			case "metal" -> WGPUBackendType_Metal();
			case "opengl", "gl" -> WGPUBackendType_OpenGL();
			case "gles", "opengles" -> WGPUBackendType_OpenGLES();
			default -> 0;
		};
	}

	/**
	 * The WebGPU feature level to ask for, or 0 to leave it at Dawn's default.
	 *
	 * <p>{@code -Dretrogpu.featureLevel=core|compatibility}. Zero-initialised means
	 * {@code WGPUFeatureLevel_Undefined}, which Dawn reads as Core -- so leaving it alone is what
	 * this mod has always done and what it should keep doing in production.
	 *
	 * <p>It exists because <b>Core is what hides the D3D11 backend</b>. D3D11 cannot implement
	 * everything core WebGPU requires, so Dawn only ever offers a D3D11 adapter to a request that
	 * asked for Compatibility; a Core request gets "unavailable" and no explanation, which reads
	 * exactly like a backend that was never compiled in. It was compiled in -- {@code d3d11.dll} is
	 * in the binary next to {@code d3d12.dll}.
	 *
	 * <p><b>A Compatibility run is not a like-for-like comparison.</b> The level restricts what the
	 * device can do, so a D3D11-vs-D3D12 measurement is only honest if D3D12 is measured at the same
	 * level, and even then the renderer may lose features or fail outright. Treat any number from it
	 * as indicative, not as parity.
	 */
	private static int forcedFeatureLevel() {
		return switch (System.getProperty("retrogpu.featureLevel", "").toLowerCase(java.util.Locale.ROOT)) {
			case "core" -> WGPUFeatureLevel_Core();
			case "compat", "compatibility" -> WGPUFeatureLevel_Compatibility();
			default -> 0;
		};
	}

	private MemorySegment awaitAdapter() {
		MemorySegment[] out = {MemorySegment.NULL};
		int[] status = {-1};
		MemorySegment cbInfo = WGPURequestAdapterCallbackInfo.allocate(arena);
		WGPURequestAdapterCallbackInfo.mode(cbInfo, WGPUCallbackMode_AllowProcessEvents());
		WGPURequestAdapterCallbackInfo.callback(cbInfo,
			WGPURequestAdapterCallback.allocate((st, ad, msg, u1, u2) -> {
				status[0] = st;
				out[0] = ad;
			}, arena));

		MemorySegment options = com.periut.webgpu.WGPURequestAdapterOptions.allocate(arena);
		com.periut.webgpu.WGPURequestAdapterOptions.nextInChain(options, toggles());
		int forced = forcedBackend();
		if (forced != 0) {
			com.periut.webgpu.WGPURequestAdapterOptions.backendType(options, forced);
		}
		int level = forcedFeatureLevel();
		if (level != 0) {
			com.periut.webgpu.WGPURequestAdapterOptions.featureLevel(options, level);
		}
		wgpuInstanceRequestAdapter(arena, instance, options, cbInfo);
		pumpUntil(() -> status[0] != -1, "adapter");
		if (out[0].equals(MemorySegment.NULL)) {
			String forcedNote = forced == 0 ? ""
				: " -- -Dretrogpu.backendType=" + System.getProperty("retrogpu.backendType")
					+ " was requested, and this Dawn build may not contain that backend";
			throw new IllegalStateException("no WebGPU adapter (status " + status[0] + ")"
				+ forcedNote);
		}
		return out[0];
	}

	private MemorySegment awaitDevice() {
		MemorySegment desc = WGPUDeviceDescriptor.allocate(arena);
		// Registered up front rather than after creation: a validation error during the very first
		// pipeline build is exactly when you most want to be told, and Dawn reports those through
		// this callback rather than a return code.
		MemorySegment errInfo = WGPUDeviceDescriptor.uncapturedErrorCallbackInfo(desc);
		WGPUUncapturedErrorCallbackInfo.callback(errInfo,
			WGPUUncapturedErrorCallback.allocate((dev, type, msg, u1, u2) -> report(type, msg),
				arena));

		MemorySegment[] out = {MemorySegment.NULL};
		int[] status = {-1};
		String[] message = {""};
		MemorySegment cbInfo = WGPURequestDeviceCallbackInfo.allocate(arena);
		WGPURequestDeviceCallbackInfo.mode(cbInfo, WGPUCallbackMode_AllowProcessEvents());
		WGPURequestDeviceCallbackInfo.callback(cbInfo,
			WGPURequestDeviceCallback.allocate((st, dev, msg, u1, u2) -> {
				status[0] = st;
				out[0] = dev;
				message[0] = readMessage(msg);
			}, arena));

		wgpuAdapterRequestDevice(arena, adapter, desc, cbInfo);
		pumpUntil(() -> status[0] != -1, "device");
		if (out[0].equals(MemorySegment.NULL)) {
			throw new IllegalStateException("no WebGPU device (status " + status[0] + "): " + message[0]);
		}
		return out[0];
	}

	private int errorsReported;
	private String lastError = "";
	private int repeats;
	private final java.util.concurrent.atomic.AtomicInteger errorCount =
		new java.util.concurrent.atomic.AtomicInteger();
	private volatile String firstError;

	/**
	 * Every validation error Dawn has reported.
	 *
	 * <p>Exposed so tests can ASSERT on it. Printing to stderr is not enough: a test that renders
	 * successfully-looking pixels while the device logs a thousand validation failures still passes,
	 * and that is precisely how a bug that made every draw in a terrain-only frame fail survived a
	 * suite with pixel-exact checks in it. Any test that submits work should end by requiring this
	 * to be zero.
	 */
	public int errorCount() {
		return errorCount.get();
	}

	/** The first error, which is almost always the one that caused the rest. */
	public String firstError() {
		return firstError;
	}

	/**
	 * Logs a validation error, but refuses to let one keep logging forever.
	 *
	 * <p>A persistent per-draw fault produces several multi-line messages PER DRAW. At a few hundred
	 * draws a frame that is tens of thousands of formatted strings a second going to stderr, which
	 * buries the first and most useful message, starves the render thread, and makes a recoverable
	 * mistake look like a hang. The first occurrences are printed in full, repeats are counted, and
	 * the total is capped.
	 */
	private void report(int type, MemorySegment message) {
		String text = readMessage(message);
		if (errorCount.getAndIncrement() == 0) {
			firstError = text;
		}
		if (text.equals(lastError)) {
			// Same fault again: count it rather than reprinting it. A frame-after-frame failure
			// says nothing new after the first time.
			repeats++;
			return;
		}
		if (repeats > 0) {
			System.err.println("[RetroDragon] ...and " + repeats + " more of the previous error");
			repeats = 0;
		}
		lastError = text;
		if (++errorsReported > MAX_ERRORS_REPORTED) {
			if (errorsReported == MAX_ERRORS_REPORTED + 1) {
				System.err.println("[RetroDragon] too many distinct WebGPU errors; silencing further"
					+ " reports. The first ones above are the ones worth reading.");
			}
			return;
		}
		System.err.println("[RetroDragon] uncaptured WebGPU error (type " + type + "): " + text);
	}

	private static final int MAX_ERRORS_REPORTED =
		Integer.getInteger("retrogpu.maxErrorsReported", 40);

	/** Dawn hands back a WGPUStringView (pointer + length), not a NUL-terminated C string. */
	private static String readMessage(MemorySegment stringView) {
		try {
			if (stringView.equals(MemorySegment.NULL)) {
				return "";
			}
			MemorySegment view = stringView.reinterpret(16);
			MemorySegment data = view.get(ValueLayout.ADDRESS, 0);
			long length = view.get(ValueLayout.JAVA_LONG, 8);
			if (data.equals(MemorySegment.NULL) || length <= 0) {
				return "";
			}
			byte[] bytes = data.reinterpret(length).toArray(ValueLayout.JAVA_BYTE);
			return new String(bytes, java.nio.charset.StandardCharsets.UTF_8);
		} catch (RuntimeException e) {
			return "<unreadable message>";
		}
	}

	private void pumpUntil(java.util.function.BooleanSupplier done, String what) {
		for (int i = 0; i < 500 && !done.getAsBoolean(); i++) {
			wgpuInstanceProcessEvents(instance);
			try {
				Thread.sleep(2);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				throw new IllegalStateException("interrupted awaiting " + what, e);
			}
		}
		if (!done.getAsBoolean()) {
			throw new IllegalStateException("timed out awaiting " + what);
		}
	}

	/** Drives Dawn's callbacks. Call once per frame. */
	public void processEvents() {
		wgpuInstanceProcessEvents(instance);
	}

	/** Frames submitted whose work the GPU has not yet reported finished. */
	private final java.util.concurrent.atomic.AtomicInteger inFlight =
		new java.util.concurrent.atomic.AtomicInteger();

	/**
	 * The work-done callback info, built once in {@link #init} and handed to Dawn every frame.
	 *
	 * <p><b>This used to be rebuilt per frame, and that was a leak with teeth.</b>
	 * {@code WGPUQueueWorkDoneCallback.allocate} is {@code Linker.upcallStub}, which is a JIT code
	 * blob, not heap -- and allocating it from this context's long-lived arena means it lives until
	 * the context closes. One per frame fills the whole 240 MB CodeCache in ~300k frames, which on
	 * the title screen at an uncapped 5000 fps is under a minute. The JIT shuts off first
	 * ("CodeHeap is full. Compiler has been disabled"), and then the next stub allocation anywhere in
	 * the JVM throws {@code OutOfMemoryError} -- which beta catches and reports as
	 * "Minecraft has run out of memory", pointing at the heap, which was never the problem.
	 *
	 * <p>One stub is all that was ever needed: it closes over nothing but {@link #inFlight} and does
	 * the same thing every frame. Same for the info struct beside it -- another ~32 bytes of native
	 * memory a frame that nothing ever freed.
	 */
	private MemorySegment workDoneInfo = MemorySegment.NULL;

	/**
	 * Scratch for the {@code WGPUFuture} that {@code wgpuQueueOnSubmittedWorkDone} returns by value.
	 *
	 * <p>Nothing reads it, but FFM has to put it somewhere, and the somewhere is whatever allocator
	 * is passed -- so passing {@link #arena} leaked that too, every frame. Reusing one segment is
	 * safe precisely because the value is never read.
	 */
	private java.lang.foreign.SegmentAllocator futureSink;

	/**
	 * Registers a completion callback for everything submitted so far, and counts it as in flight.
	 *
	 * <p>Call once per frame, after submitting. Pairs with {@link #awaitFramesInFlight}.
	 */
	public void markFrameSubmitted() {
		inFlight.incrementAndGet();
		wgpuQueueOnSubmittedWorkDone(futureSink, queue, workDoneInfo);
	}

	/**
	 * Blocks until at most {@code limit} frames are still executing.
	 *
	 * <p><b>Without this the renderer can outrun the compositor without bound.</b> Nothing in a
	 * submit-and-present loop waits for the GPU, so a cheap CPU frame -- world load, where most of the
	 * cost is upload rather than draw -- queues work far faster than it retires. On macOS that starves
	 * the window server's drawable pool, and the symptom is not a dropped frame or a slow game: the
	 * whole desktop stops responding and the machine needs a restart.
	 *
	 * <p>Two frames is the usual choice: enough for the CPU to prepare the next while the GPU works
	 * on the last, and not enough to build a backlog.
	 */
	public void awaitFramesInFlight(int limit) {
		if (inFlight.get() <= limit) {
			// The overwhelmingly common case. Checked first so the fence costs one atomic read on a
			// frame that is not actually behind.
			return;
		}
		// Bounded rather than unbounded: if a callback is somehow never delivered, a stuck renderer
		// is still better than a stuck machine, so give up and carry on.
		for (int spins = 0; inFlight.get() > limit && spins < 10_000; spins++) {
			wgpuInstanceProcessEvents(instance);
			if (spins < 64) {
				Thread.onSpinWait();
			} else {
				// Past a short spin, YIELD. A tight loop calling processEvents burns a core, and on
				// this renderer the game logic and the driver's own threads are competing for it --
				// which showed up as "Max FPS" running SLOWER than vsync, the opposite of what
				// removing the frame cap is supposed to do.
				Thread.yield();
			}
		}
	}

	public int framesInFlight() {
		return inFlight.get();
	}

	/**
	 * Waits until the GPU has retired everything submitted, or {@code timeoutMillis} elapses.
	 *
	 * <p>For TEARDOWN, where {@link #awaitFramesInFlight} is the wrong tool: that one is spin-bounded
	 * because it sits on the per-frame path and must never stall a frame for long. Here the opposite
	 * is wanted -- the pipeline has to be genuinely empty before a surface is released, and it is
	 * worth waiting milliseconds to be sure.
	 *
	 * <p>Releasing a surface while work is still executing leaves the compositor holding a reference
	 * to something being destroyed. On macOS the result is not a crash in the process, it is the
	 * whole render server hanging -- the game exits cleanly and the desktop dies with it.
	 *
	 * @return true if the pipeline drained; false on timeout, which is worth logging
	 */
	public boolean drain(long timeoutMillis) {
		long deadline = System.nanoTime() + timeoutMillis * 1_000_000L;
		while (inFlight.get() > 0 && System.nanoTime() < deadline) {
			wgpuInstanceProcessEvents(instance);
			try {
				Thread.sleep(1);
			} catch (InterruptedException e) {
				Thread.currentThread().interrupt();
				break;
			}
		}
		return inFlight.get() == 0;
	}

	public MemorySegment instance() {
		return instance;
	}

	public MemorySegment adapter() {
		return adapter;
	}

	public MemorySegment device() {
		return device;
	}

	public MemorySegment queue() {
		return queue;
	}

	/** One of {@code WGPUBackendType_*}; see {@link #backendName()}. */
	public int backendType() {
		return backendType;
	}

	/**
	 * The native API Dawn resolved to. Nothing here chooses it -- Dawn picks its default backend per
	 * platform, which in practice is:
	 *
	 * <pre>
	 *   macOS    Metal
	 *   Windows  D3D12
	 *   Linux    Vulkan
	 * </pre>
	 *
	 * <p>OpenGL/OpenGLES are Dawn fallbacks it will not pick while a Vulkan driver is present, so
	 * seeing one of those on Linux means the Vulkan loader found no device. Logged at startup rather
	 * than assumed, because "which API is this run on" is the first question any GPU bug asks.
	 */
	public String backendName() {
		if (backendType == WGPUBackendType_Metal()) return "Metal";
		if (backendType == WGPUBackendType_Vulkan()) return "Vulkan";
		if (backendType == WGPUBackendType_D3D12()) return "D3D12";
		if (backendType == WGPUBackendType_OpenGL()) return "OpenGL";
		if (backendType == WGPUBackendType_OpenGLES()) return "OpenGLES";
		return "unknown(" + backendType + ")";
	}

	/** What the adapter calls itself, e.g. {@code "Apple M2"} or {@code "AMD Radeon 780M"}. */
	public String adapterName() {
		return adapterName;
	}

	/** The startup one-liner: the native API Dawn picked, and on what. */
	public String apiSummary() {
		return "WebGPU (Dawn) on " + backendName() + " -- " + adapterName;
	}

	public boolean hasFeature(int feature) {
		if (adapter.equals(MemorySegment.NULL)) {
			return false;
		}
		try (Arena tmp = Arena.ofConfined()) {
			MemorySegment supported = WGPUSupportedFeatures.allocate(tmp);
			wgpuAdapterGetFeatures(adapter, supported);
			long count = WGPUSupportedFeatures.featureCount(supported);
			MemorySegment list = WGPUSupportedFeatures.features(supported).reinterpret(count * 4L);
			for (long i = 0; i < count; i++) {
				if (list.getAtIndex(ValueLayout.JAVA_INT, i) == feature) {
					return true;
				}
			}
			return false;
		}
	}

	@Override
	public void close() {
		// Reverse creation order; Dawn refcounts, so releasing a parent before its children is a
		// use-after-free rather than a no-op.
		if (!queue.equals(MemorySegment.NULL)) wgpuQueueRelease(queue);
		if (!device.equals(MemorySegment.NULL)) wgpuDeviceRelease(device);
		if (!adapter.equals(MemorySegment.NULL)) wgpuAdapterRelease(adapter);
		if (!instance.equals(MemorySegment.NULL)) wgpuInstanceRelease(instance);
		queue = device = adapter = instance = MemorySegment.NULL;
		arena.close();
	}
}
