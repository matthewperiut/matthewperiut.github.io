package com.periut.accessoryapi.impl.mixin.client;

import com.periut.accessoryapi.api.PlayerExtraHP;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_43718703;
import net.minecraft.unmapped.C_97866173;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

@Mixin(C_97866173.class)
public class InGameGuiMixinHearts {
    @Shadow
    private Minecraft minecraft;

    @Shadow
    private Random random;

    @Unique
    private void renderHearts(C_97866173 instance) {
        int maxHealth = 20 + ((PlayerExtraHP) (minecraft).f_28396371).getExtraHP();
        if (!(maxHealth > 20))
            return;
        final C_43718703 scaledresolution = new C_43718703(minecraft.f_58088711, minecraft.f_31800787, minecraft.f_74192110);
        final int width = scaledresolution.m_39119333();
        final int height = scaledresolution.m_16103615();
        GL11.glBindTexture(3553, minecraft.f_45465196.m_33729172("/gui/icons.png"));
        GL11.glEnable(3042);
        GL11.glBlendFunc(775, 769);
        GL11.glColor3f(1.0f, 1.0f, 1.0f);
        GL11.glDisable(3042);
        boolean flag1 = minecraft.f_28396371.f_02385719 / 3 % 2 == 1;
        if (minecraft.f_28396371.f_02385719 < 10) {
            flag1 = false;
        }
        final int halfHearts = minecraft.f_28396371.f_05442563 - 20;
        final int prevHalfHearts = minecraft.f_28396371.f_08026980 - 20;
        if (minecraft.f_17639899.m_20190380()) {
            for (int heart = 0; heart < maxHealth / 2 - 10; ++heart) {
                int yPos = height - 32 - (((heart / 10) + 1) * 10);
                int k5 = 0;
                if (flag1) {
                    k5 = 1;
                }
                final int xPos = width / 2 - 91 + (heart % 10) * 8;
                if (minecraft.f_28396371.f_05442563 <= 4) {
                    yPos += this.random.nextInt(2);
                }
                instance.m_66359748(xPos, yPos, 16 + k5 * 9, 0, 9, 9);
                if (flag1) {
                    if (heart * 2 + 1 < prevHalfHearts) {
                        instance.m_66359748(xPos, yPos, 70, 0, 9, 9);
                    }
                    if (heart * 2 + 1 == prevHalfHearts) {
                        instance.m_66359748(xPos, yPos, 79, 0, 9, 9);
                    }
                }
                if (heart * 2 + 1 < halfHearts) {
                    instance.m_66359748(xPos, yPos, 52, 0, 9, 9);
                }
                if (heart * 2 + 1 == halfHearts) {
                    instance.m_66359748(xPos, yPos, 61, 0, 9, 9);
                }
            }
        }
        GL11.glDisable(3042);
    }

    public void blitHeart(C_97866173 instance, int a, int b, int c, int d, int e, int f) {
        C_43718703 var5 = new C_43718703(this.minecraft.f_58088711, this.minecraft.f_31800787, this.minecraft.f_74192110);
        int var6 = var5.m_39119333();
        int allowedHearts = (((PlayerExtraHP) minecraft.f_28396371).getExtraHP() < 0 ? 10 + (((PlayerExtraHP) minecraft.f_28396371).getExtraHP() / 2) : 10);
        int var19 = var6 / 2 - 91 + allowedHearts * 8;
        if (a < var19)
            instance.m_66359748(a,b,c,d,e,f);
    }
    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/InGameHud;drawTexture(IIIIII)V", ordinal = 6))
    public void blitHeart0(C_97866173 instance, int a, int b, int c, int d, int e, int f) {
        blitHeart(instance, a, b, c, d, e, f);
    }
    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/InGameHud;drawTexture(IIIIII)V", ordinal = 7))
    public void blitHeart1(C_97866173 instance, int a, int b, int c, int d, int e, int f) {
        blitHeart(instance, a, b, c, d, e, f);
    }
    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/InGameHud;drawTexture(IIIIII)V", ordinal = 8))
    public void blitHeart2(C_97866173 instance, int a, int b, int c, int d, int e, int f) {
        blitHeart(instance, a, b, c, d, e, f);
    }
    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/InGameHud;drawTexture(IIIIII)V", ordinal = 9))
    public void blitHeart3(C_97866173 instance, int a, int b, int c, int d, int e, int f) {
        blitHeart(instance, a, b, c, d, e, f);
    }

    @Inject(method = "render", at = @At(value = "TAIL"))
    public void renderExtraHud(float bl, boolean i, int j, int par4, CallbackInfo ci) {
        C_97866173 instance = (C_97866173) (Object) this;
        renderHearts(instance);
    }

    public void moveBubblesUpDependingOnExtraHP(C_97866173 instance, int a, int b, int c, int d, int e, int f)
    {
        int multiplier = (((PlayerExtraHP) minecraft.f_28396371).getExtraHP() + 18) / 20;
        int movement = 10 * multiplier + (multiplier > 0 ? 1 : 0);
        instance.m_66359748(a,b-movement,c,d,e,f);
    }
    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/InGameHud;drawTexture(IIIIII)V", ordinal = 11))
    public void moveBubblesUpDependingOnExtraHP1(C_97866173 instance, int a, int b, int c, int d, int e, int f)
    {
        moveBubblesUpDependingOnExtraHP(instance, a, b, c, d, e, f);
    }
    @Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/InGameHud;drawTexture(IIIIII)V", ordinal = 12))
    public void moveBubblesUpDependingOnExtraHP2(C_97866173 instance, int a, int b, int c, int d, int e, int f)
    {
        moveBubblesUpDependingOnExtraHP(instance, a, b, c, d, e, f);
    }
}
