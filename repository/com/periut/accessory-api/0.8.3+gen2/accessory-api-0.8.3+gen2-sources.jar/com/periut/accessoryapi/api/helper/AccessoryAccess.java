package com.periut.accessoryapi.api.helper;

import com.periut.accessoryapi.AccessoryAPI;
import com.periut.accessoryapi.api.Accessory;
import java.util.ArrayList;
import java.util.Arrays;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;

public class AccessoryAccess {

    /**
     * @param player The player you are checking.
     * @return The full array of the player's accessories.
     */
    public static C_88708284[] getAccessories(C_40996800 player) {
        return Arrays.copyOfRange(player.f_29439708.f_52412003, AccessoryAPI.config.armorOffset, player.f_29439708.f_52412003.length);
    }

    /**
     * @param player The player you are checking.
     * @param slot   The index of the accessory inventory you want to check, DO NOT offset for armour slots.
     * @return The accessory in the specified slot.
     */
    public static C_88708284 getAccessory(C_40996800 player, int slot) {
        return getAccessories(player)[slot];
    }

    /**
     * @param player The player you are giving the accessory to.
     * @param slot   The slot you are placing the accessory in.
     * @param item   The item you would like to place.
     */
    public static void setAccessory(C_40996800 player, int slot, C_88708284 item) {
        player.f_29439708.f_52412003[slot + AccessoryAPI.config.armorOffset] = item;
    }

    /**
     * @param player The player you are checking.
     * @param type   The type of accessory you are looking for.
     * @return The array of the player's accessories that match the type.
     */
    public static C_88708284[] getAccessories(C_40996800 player, String type) {
        var foundItems = new ArrayList<C_88708284>();
        for (C_88708284 item : getAccessories(player)) {
            if (item != null && item.m_23235460() instanceof Accessory accessory) {
                if (Arrays.asList(accessory.getAccessoryTypes(item)).contains(type)) {
                    foundItems.add(item);
                }
            }
        }
        return foundItems.toArray(C_88708284[]::new);
    }

    /*
         Maybe change this method to use <T extends ItemBase & Accessory>
         for the sake of only checking applicable slots.
    */

    /**
     * @param player   The player you are checking.
     * @param itemType The item you are looking for.
     * @return Whether the player has any items that match the provided item type.
     */
    public static boolean hasAccessory(C_40996800 player, C_98888256 itemType) {
        for (C_88708284 item : getAccessories(player)) {
            if (item != null && item.m_23235460() == itemType) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param player The player you are checking.
     * @param type   The type of accessory you are looking for.
     * @return Whether the player has any accessories in their inventory that match the type.
     */
    public static boolean hasAnyAccessoriesOfType(C_40996800 player, String type) {
        for (C_88708284 item : getAccessories(player)) {
            if (item != null && item.m_23235460() instanceof Accessory accessory) {
                if (Arrays.asList(accessory.getAccessoryTypes(item)).contains(type)) {
                    return true;
                }
            }
        }
        return false;
    }
}
