package com.periut.accessoryapi.impl.slot;

import com.periut.accessoryapi.AccessoryAPI;
import java.util.ArrayList;
import java.util.Collections;
import net.minecraft.unmapped.C_09553359;
import net.minecraft.unmapped.C_12356698;
import net.minecraft.unmapped.C_97313606;

public class AccessorySlotStorage {
    private static final int startX = 62;
    private static final int startY = 8;
    public static ArrayList<AccessorySlotInfo> slotInfo = new ArrayList<>();
    public static ArrayList<PreservedSlot> slotOrder = new ArrayList<>();
    public static int extraSlots = 0;

    public static void initializeCustomAccessoryPositions() {
        // This whole function is a little slow, but it's called once per world run, so it's okay
        slotOrder.clear();

        ArrayList<PreservedSlot> taken = new ArrayList<>();
        ArrayList<AccessorySlotInfo> info = (ArrayList<AccessorySlotInfo>) slotInfo.clone();

        for (AccessorySlotInfo a : slotInfo) {
            if (a.applyPreferred) {
                boolean available = true;
                int h = a.h;
                int v = a.v;
                C_97313606 pos = new C_97313606(startX + h * 18, startY + v * 18);
                for (PreservedSlot slot : taken) {
                    if (slot.pos.equals(pos)) {
                        available = false;
                        break;
                    }
                }
                boolean secondary = false;
                if (!available) {
                    for (int x = 0; x < 6; x++) {
                        available = true;
                        pos = new C_97313606(startX + x * 18, startY + v * 18);
                        for (PreservedSlot slot : taken) {
                            if (slot.pos.equals(pos)) {
                                available = false;
                                break;
                            }
                        }

                        if (available) {
                            secondary = true;
                            break;
                        }
                    }
                }

                if (available || secondary) {
                    taken.add(new PreservedSlot(a.type, pos));
                    taken.get(taken.size() - 1).texture = a.texture;
                    taken.get(taken.size() - 1).tx = a.tx;
                    taken.get(taken.size() - 1).ty = a.ty;
                    info.remove(a);
                }
            }
        }

        for (int h = 0; h < 6; h++) {
            for (int v = 0; v < 4; v++) {
                boolean available = true;
                for (PreservedSlot slot : taken) {
                    if (slot.pos.f_77181208 == (startX + h * 18) && (slot.pos.f_93738510 == startY + v * 18)) {
                        slotOrder.add(slot);
                        available = false;
                        break;
                    }
                }

                if (available) {
                    if (info.size() > 0) {
                        AccessorySlotInfo accessory = info.get(0);
                        slotOrder.add(new PreservedSlot(accessory.type, new C_97313606(startX + h * 18, startY + v * 18)));
                        slotOrder.get(slotOrder.size() - 1).texture = accessory.texture;
                        slotOrder.get(slotOrder.size() - 1).tx = accessory.tx;
                        slotOrder.get(slotOrder.size() - 1).ty = accessory.ty;
                        info.remove(0); // Remove the accessory from the list after adding
                    }
                }
            }
        }
        Collections.reverse(slotOrder);

        if (slotOrder.size() > 8)
            extraSlots = slotOrder.size() - 8;
        if (slotOrder.isEmpty())
            AccessoryAPI.noSlotsAdded = true;
    }

    public static void showOverflowSlots(C_09553359 container) {
        int start = container.f_84566804.size() - slotOrder.size();
        int end = container.f_84566804.size();

        for (int i = start; i < end; i++) {
            C_12356698 slot = (C_12356698) container.f_84566804.get(i);
            if (slot.f_95205544 > 114 && slot.f_40293340 > 500) {
                slot.f_40293340 -= 1000;
            }
        }
    }

    public static void hideOverflowSlots(C_09553359 container) {
        int start = container.f_84566804.size() - slotOrder.size();
        int end = container.f_84566804.size();

        for (int i = start; i < end; i++) {
            C_12356698 slot = (C_12356698) container.f_84566804.get(i);
            if (slot.f_95205544 > 114 && slot.f_40293340 < 500) {
                slot.f_40293340 += 1000;
            }
        }
    }

    public static class PreservedSlot {
        public String slotType;
        public String texture = "";
        public int tx;
        public int ty;
        public C_97313606 pos;

        public PreservedSlot(String slotType, C_97313606 pos) {
            this.slotType = slotType;
            this.pos = pos;
        }
    }
}
