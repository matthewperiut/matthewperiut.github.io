package com.periut.testmod.accessory;

import com.periut.accessoryapi.api.Accessory;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.template.item.TemplateItem;
import net.modificationstation.stationapi.api.util.Identifier;

public class TestAccessory extends TemplateItem implements Accessory {
    protected final String[] types;

    public TestAccessory(Identifier identifier, String... types) {
        super(identifier);
        setTranslationKey(identifier);
        m_30881980(1);
        m_83617391(100);
        this.types = types;
    }

    @Override
    public String[] getAccessoryTypes(C_88708284 item) {
        return types;
    }
}
