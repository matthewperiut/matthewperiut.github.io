package com.periut.testmod.accessory;

import com.periut.testmod.client.RainbowCapeRenderer;
import com.periut.testmod.client.RainbowGloveRenderer;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.util.Identifier;

public class RainbowAccessory extends TestAccessoryWithRenderer {
    public RainbowAccessory(Identifier identifier, String... types) {
        super(identifier, types);
    }

    @Override
    public C_88708284 tickWhileWorn(C_40996800 player, C_88708284 itemStack) {
        var hue = itemStack.getStationNbt().m_93225250("hue");
        if (hue >= 1) {
            hue = 0;
        } else {
            hue += 1f / 360;
        }
        itemStack.getStationNbt().m_72136054("hue", (Float) hue);
        return super.tickWhileWorn(player, itemStack);
    }

    @Override
    public void constructRenderer() {
        if (types.length > 0) {
            if (types[0].equals("cape")) {
                renderer = new RainbowCapeRenderer("assets/testmod/textures/capes/cape.png");
            } else if (types[0].equals("gloves")) {
                renderer = new RainbowGloveRenderer("assets/testmod/textures/armour/test.png");
            }
        }
    }
}
