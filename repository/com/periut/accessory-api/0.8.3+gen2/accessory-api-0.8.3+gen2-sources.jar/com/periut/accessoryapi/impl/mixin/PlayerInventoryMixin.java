package com.periut.accessoryapi.impl.mixin;

import com.periut.accessoryapi.AccessoryAPI;
import com.periut.accessoryapi.api.Accessory;
import com.periut.accessoryapi.impl.slot.AccessorySlotStorage;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_79370641;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_87542771.class)
public class PlayerInventoryMixin {
    @Shadow
    public C_88708284[] main;

    @Shadow
    public C_88708284[] armor;

    @Shadow
    public C_40996800 player;

    @Inject(method = "<init>", at = @At("TAIL"))
    public void setNewSize(C_40996800 par1, CallbackInfo ci) {
        armor = new C_88708284[AccessoryAPI.config.armorOffset + AccessorySlotStorage.slotInfo.size()];
    }

    @ModifyConstant(method = "readNbt", constant = @Constant(intValue = 4), require = 1)
    private int modifyArmourSize(int original) {
        return AccessoryAPI.config.armorOffset + AccessorySlotStorage.slotInfo.size();
    }

    @Inject(method = "readNbt", at = @At("TAIL"))
    public void fromTag(C_79370641 par1, CallbackInfo ci) {
        int reg_inv_size = main.length;
        for (int slot = reg_inv_size; slot < armor.length + reg_inv_size; slot++) {
            int armour_pos = slot - reg_inv_size;
            C_88708284 item = armor[armour_pos];

            if (item != null) {
                if (item.m_23235460() instanceof Accessory accessory) {
                    accessory.onAccessoryAdded(player, item);
                }
            }
        }
    }

    @Inject(method = "setStack", at = @At("HEAD"))
    public void onSetInventoryItem(int i, C_88708284 newItem, CallbackInfo ci) {
        if (i < 36) {
            return;
        }
        if (i >= armor.length) {

            int pos = i - main.length;
            C_88708284 oldItem = armor[pos];

            if (oldItem != null) {
                if (oldItem.m_23235460() instanceof Accessory accessory) {
                    accessory.onAccessoryRemoved(player, oldItem);
                }
            }

            if (newItem != null) {
                // For example, you could set the item count:
                if (newItem.m_23235460() instanceof Accessory accessory) {
                    accessory.onAccessoryAdded(player, newItem);
                }
            }
        }
    }

    @Inject(method = "removeStack", at = @At("HEAD"))
    public void onTakeInventoryItem(int i, int par2, CallbackInfoReturnable<C_88708284> cir) {
        if (i < 36) {
            return;
        }
        if (i >= main.length) {
            int pos = i - main.length;
            C_88708284 oldItem = armor[pos];
            if (oldItem != null) {
                if (oldItem.m_23235460() instanceof Accessory accessory) {
                    accessory.onAccessoryRemoved(player, oldItem);
                }
            }
        }
    }
}
