package com.periut.accessoryapi.impl.mixin;

import com.periut.accessoryapi.api.PlayerExtraHP;
import com.periut.accessoryapi.api.PlayerVisibility;
import com.periut.accessoryapi.api.TickableInArmorSlot;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_40996800.class)
public abstract class PlayerBaseMixin extends C_74425583 implements PlayerExtraHP, PlayerVisibility
{

    private PlayerBaseMixin(C_64041439 arg) {
        super(arg);
    }

    @Inject(method = "tick", at = @At("TAIL"))
    public void tick(CallbackInfo ci) {
        C_40996800 player = (C_40996800) ((Object) this);
        for (int i = 0; i < player.f_29439708.f_52412003.length; i++) {
            C_88708284 item = player.f_29439708.f_52412003[i];
            if (item != null) {
                if (item.m_23235460() instanceof TickableInArmorSlot tickable) {
                    var newItem = tickable.tickWhileWorn(player, item);
                    if (newItem != item) {
                        player.f_29439708.f_52412003[i] = newItem;
                    }
                }
            }
        }
    }

    @Inject(method = "writeNbt", at = @At("HEAD"))
    public void writeCustomDataToTag(C_74087615 tag, CallbackInfo ci) {
        tag.m_20318863("ExtraHP", getExtraHP());
    }

    @Inject(method = "readNbt", at = @At("HEAD"))
    public void readCustomDataFromTag(C_74087615 tag, CallbackInfo ci) {

        if (tag.m_97612750("ExtraHP")) {
            setExtraHP(tag.m_35587574("ExtraHP"));
        } else {
            setExtraHP(0);
        }
    }

    @Inject(method = "tickMovement", at = @At("HEAD"))
    public void updateDespawnCounter(CallbackInfo ci) {
        if (this.f_94306729.f_91285239 == 0 && (this.f_05442563 >= 20 && this.f_05442563 < 20 + getExtraHP()) && this.f_41909716 % 20 * 12 == 0) {
            this.f_05442563 += 1;
            this.f_02385719 = this.f_64952793 / 2;
        }
    }

    @Inject(method = "initDataTracker", at = @At("TAIL"))
    public void initDataTracker(CallbackInfo ci)
    {
        this.f_88296653.m_94812360(31, (int)0);
    }

    public int getExtraHP() {
        return this.f_88296653.m_09089969(31);
    }

    public void setExtraHP(int extraHP) {
        this.f_88296653.m_52395024(31, extraHP);
        if (f_05442563 > 20 + extraHP)
        {
            f_05442563 = 20 + extraHP;
        }
    }

    public void addExtraHP(int extraHP) {
        setExtraHP(getExtraHP() + extraHP);
    }

    @Override
    public void setInvisible(boolean invisible)
    {
        // setFlag
        m_95740281(7, invisible);
    }

    @Override
    public boolean isInvisible()
    {
        // isFlagSet
        return m_31730897(7);
    }
}
