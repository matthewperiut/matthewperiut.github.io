package com.periut.testmod.client;

import com.periut.accessoryapi.api.render.builtin.GloveRenderer;
import java.awt.*;
import net.minecraft.unmapped.C_34859172;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_88708284;

public class RainbowGloveRenderer extends GloveRenderer {
    public RainbowGloveRenderer(String texture) {
        super(texture);
    }

    @Override
    public void renderFirstPerson(C_40996800 player, C_34859172 renderer, C_88708284 itemStack) {
        float hue = (player.f_41909716 % 365) / 365.f;
        color = Color.getHSBColor(hue, 1, 1);
        super.renderFirstPerson(player, renderer, itemStack);
    }

    @Override
    public void renderThirdPerson(C_40996800 player, C_34859172 renderer, C_88708284 itemStack, double x, double y, double z, float h, float v) {
        float hue = (player.f_41909716 % 365) / 365.f;
        color = Color.getHSBColor(hue, 1, 1);
        super.renderThirdPerson(player, renderer, itemStack, x, y, z, h, v);
    }
}
