package com.periut.testmod.item;

import com.periut.accessoryapi.api.PlayerExtraHP;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.template.item.TemplateItem;
import net.modificationstation.stationapi.api.util.Identifier;
import org.jetbrains.annotations.NotNull;

public class HealthItem extends TemplateItem {
    public HealthItem(@NotNull Identifier identifier) {
        super(identifier);
    }

    @Override
    public C_88708284 m_94551825(C_88708284 arg, C_64041439 arg2, C_40996800 arg3) {
        System.out.println("wow");
        ((PlayerExtraHP) arg3).setExtraHP(((PlayerExtraHP) arg3).getExtraHP() + 1);
        System.out.println(((PlayerExtraHP) arg3).getExtraHP());
        return super.m_94551825(arg, arg2, arg3);
    }
}
