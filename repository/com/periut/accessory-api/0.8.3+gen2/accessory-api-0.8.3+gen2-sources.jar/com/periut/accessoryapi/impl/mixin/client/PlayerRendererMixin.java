package com.periut.accessoryapi.impl.mixin.client;

import com.periut.accessoryapi.AccessoryAPIClient;
import com.periut.accessoryapi.api.PlayerVisibility;
import com.periut.accessoryapi.api.helper.AccessoryAccess;
import com.periut.accessoryapi.api.render.HasCustomRenderer;
import com.periut.accessoryapi.impl.slot.AccessorySlotStorage;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_32232284;
import net.minecraft.unmapped.C_34859172;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_53593123;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_34859172.class)
public abstract class PlayerRendererMixin extends C_53593123 {
    @Unique
    C_40996800 player;

    @Inject(method = "bindTexture", at = @At("HEAD"))
    protected void method_344(C_40996800 player, int f, float par3, CallbackInfoReturnable<Boolean> cir) {
        this.player = player;
    }

    @Inject(method = "render(Lnet/minecraft/entity/Entity;DDDFF)V", at = @At(value = "HEAD"), cancellable = true)
    private void thirdPersonRenderHEAD(C_42232651 d, double x, double y, double z, float h, float v, CallbackInfo ci) {
        if (((PlayerVisibility) d).isInvisible())
            ci.cancel();
    }

    @Inject(method = "render(Lnet/minecraft/entity/Entity;DDDFF)V", at = @At(value = "TAIL"))
    private void thirdPersonRender(C_42232651 d, double x, double y, double z, float h, float v, CallbackInfo ci) {
        if (((PlayerVisibility) d).isInvisible())
            return;

        AccessoryAPIClient.capeEnabled = true;
        if (C_32232284.f_14776289.f_60495800 == null) return;
        try {
            if (player == null)
                return;

            final C_34859172 renderer = (C_34859172) (Object) this;

            for (int i = 0; i < AccessorySlotStorage.slotOrder.size() + 4; i++) {
                C_88708284 item = player.f_29439708.m_34290324(i);
                if (item == null) continue;
                if (item.m_23235460() instanceof HasCustomRenderer itemWithRenderer) {
                    if (itemWithRenderer.getRenderer() == null) {
                        itemWithRenderer.constructRenderer();
                    } else {
                        itemWithRenderer.getRenderer().renderThirdPerson(player, renderer, item, x, y, z, h, v);
                    }
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Redirect(
            method = "renderMore(Lnet/minecraft/entity/player/PlayerEntity;F)V",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/entity/player/PlayerEntity;playerCapeUrl:Ljava/lang/String;"
            )
    )
    private String toggleCapeRendering(C_40996800 instance) {
        if (!AccessoryAPIClient.capeEnabled) {
            return null;
        } else {
            return instance.f_71214517;
        }
    }

    @Inject(method = "renderHand", at = @At("TAIL"))
    private void firstPersonRender(CallbackInfo ci) {
        if (C_32232284.f_14776289.f_60495800 == null) return;

        C_40996800 player = ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_28396371;
        for (C_88708284 item : AccessoryAccess.getAccessories(player)) {
            if (item == null) continue;
            if (item.m_23235460() instanceof HasCustomRenderer itemWithRenderer) {
                if (itemWithRenderer.getRenderer() == null) {
                    itemWithRenderer.constructRenderer();
                } else {
                    itemWithRenderer.getRenderer().renderFirstPerson(player, (C_34859172) (Object) this, item);
                }
            }
        }
    }
}
