package com.periut.testmod.mixin;

import com.periut.testmod.ItemListener;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_40996800.class)
public class PlayerEntityMixin {
    @Inject(method = "<init>", at = @At(value = "TAIL"))
    public void onInit(C_64041439 par1, CallbackInfo ci) {
        C_40996800 player = (C_40996800) (Object) this;
        C_98888256[] items = {ItemListener.testCape, ItemListener.testGloves, ItemListener.testMisc, ItemListener.testPendant, ItemListener.testRing, ItemListener.testShield, ItemListener.testAll, ItemListener.slime, ItemListener.blueSlime, ItemListener.rainbowGloves, ItemListener.rainbowCape, C_98888256.f_56682976};

        for (int i = 0; i < items.length; i++) {
            player.f_29439708.m_33431716(i, new C_88708284(items[i], 1));
        }
    }
}
