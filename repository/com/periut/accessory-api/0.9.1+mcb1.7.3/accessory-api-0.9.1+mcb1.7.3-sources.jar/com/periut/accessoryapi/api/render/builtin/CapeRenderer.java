package com.periut.accessoryapi.api.render.builtin;

import com.periut.accessoryapi.AccessoryAPIClient;
import com.periut.accessoryapi.api.render.RenderingHelper;
import net.minecraft.unmapped.C_34859172;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_82280655;
import net.minecraft.unmapped.C_88708284;
import org.lwjgl.opengl.GL11;

public class CapeRenderer extends ConfigurableRenderer {
    private static final C_82280655 model = new C_82280655(0.0f);

    public CapeRenderer(String texture) {
        super(texture);
    }

    @Override
    public void renderThirdPerson(C_40996800 player, C_34859172 renderer, C_88708284 itemStack, double x, double y, double z, float h, float v) {
        AccessoryAPIClient.capeEnabled = false;

        RenderingHelper.beforeBiped(player, renderer, model, x, y, z, h, v);
        var xAsFloat = (float) x;

        bindTextureAndApplyColors(player.m_95186532(h));

        GL11.glPushMatrix();
        GL11.glTranslatef(0.0f, 0.0f, 0.125f);
        final double d = player.f_99890177 + (player.f_22466577 - player.f_99890177) * xAsFloat - (player.f_59999765 + (player.f_78826675 - player.f_59999765) * xAsFloat);
        final double d2 = player.f_62909408 + (player.f_60272612 - player.f_62909408) * xAsFloat - (player.f_90348373 + (player.f_31030949 - player.f_90348373) * xAsFloat);
        final double d3 = player.f_49011524 + (player.f_22361063 - player.f_49011524) * xAsFloat - (player.f_88346412 + (player.f_97691941 - player.f_88346412) * xAsFloat);
        final float f2 = player.f_14416847 + (player.f_21972499 - player.f_14416847) * xAsFloat;
        final double d4 = C_45510667.m_61414107(f2 * 3.141593f / 180.0f);
        final double d5 = -C_45510667.m_64246150(f2 * 3.141593f / 180.0f);
        float f3 = (float) d2 * 10.0f;
        if (f3 < -6.0f) {
            f3 = -6.0f;
        }
        if (f3 > 32.0f) {
            f3 = 32.0f;
        }
        float f4 = (float) (d * d4 + d3 * d5) * 100.0f;
        final float f5 = (float) (d * d5 - d3 * d4) * 100.0f;
        if (f4 < 0.0f) {
            f4 = 0.0f;
        }
        final float f6 = player.f_50213638 + (player.f_03780072 - player.f_50213638) * xAsFloat;
        f3 += C_45510667.m_61414107((player.f_47980428 + (player.f_37851489 - player.f_47980428) * xAsFloat) * 6.0f) * 32.0f * f6;
        if (player.m_40164672()) {
            f3 += 25.0f;
        }
        GL11.glRotatef(6.0f + f4 / 2.0f + f3, 1.0f, 0.0f, 0.0f);
        GL11.glRotatef(f5 / 2.0f, 0.0f, 0.0f, 1.0f);
        GL11.glRotatef(-f5 / 2.0f, 0.0f, 1.0f, 0.0f);
        GL11.glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
        model.m_87982748(0.0625f);
        GL11.glPopMatrix();
        RenderingHelper.afterBiped(model);
    }
}
