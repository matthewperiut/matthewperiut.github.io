package com.periut.accessoryapi.config;

import net.minecraft.unmapped.C_16154270;

public enum Style {
    AETHER("style.accessoryapi:aether"),
    BAUBLES("style.accessoryapi:baubles"),
    TRINKETS("style.accessoryapi:trinkets");

    final String translationKey;

    Style(String translationKey) {
        this.translationKey = translationKey;
    }

    public String getTranslationKey() {
        return translationKey;
    }

    public String getTranslatedName() {
        return C_16154270.m_56062593().m_77288988(translationKey);
    }

    public Style nextStyle() {
        if (ordinal() >= values().length) {
            return values()[0];
        } else {
            return values()[ordinal() + 1];
        }
    }
}
