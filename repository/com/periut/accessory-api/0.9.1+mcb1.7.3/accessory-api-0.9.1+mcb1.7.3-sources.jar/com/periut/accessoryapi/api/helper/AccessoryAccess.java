package com.periut.accessoryapi.api.helper;

import com.periut.accessoryapi.api.Accessory;
import com.periut.accessoryapi.api.AccessoryHolder;
import com.periut.accessoryapi.api.AccessoryInventory;
import java.util.ArrayList;
import java.util.Arrays;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;

public class AccessoryAccess {

    /**
     * @param player The player you are checking.
     * @return The player's accessory inventory (the live storage, separate from vanilla armor).
     */
    public static AccessoryInventory getAccessoryInventory(C_40996800 player) {
        return ((AccessoryHolder) player).getAccessoryInventory();
    }

    /**
     * @param player The player you are checking.
     * @return The full array of the player's accessories (a copy — use the inventory to modify).
     */
    public static C_88708284[] getAccessories(C_40996800 player) {
        AccessoryInventory inventory = getAccessoryInventory(player);
        C_88708284[] accessories = new C_88708284[inventory.m_54518913()];
        for (int i = 0; i < accessories.length; i++) {
            accessories[i] = inventory.m_87969967(i);
        }
        return accessories;
    }

    /**
     * @param player The player you are checking.
     * @param slot   The index of the accessory inventory you want to check, DO NOT offset for armour slots.
     * @return The accessory in the specified slot.
     */
    public static C_88708284 getAccessory(C_40996800 player, int slot) {
        return getAccessoryInventory(player).m_87969967(slot);
    }

    /**
     * @param player The player you are giving the accessory to.
     * @param slot   The slot you are placing the accessory in.
     * @param item   The item you would like to place.
     */
    public static void setAccessory(C_40996800 player, int slot, C_88708284 item) {
        getAccessoryInventory(player).m_33431716(slot, item);
    }

    /**
     * @param player The player you are checking.
     * @param type   The type of accessory you are looking for.
     * @return The array of the player's accessories that match the type.
     */
    public static C_88708284[] getAccessories(C_40996800 player, String type) {
        var foundItems = new ArrayList<C_88708284>();
        for (C_88708284 item : getAccessories(player)) {
            if (item != null && item.m_23235460() instanceof Accessory accessory) {
                if (Arrays.asList(accessory.getAccessoryTypes(item)).contains(type)) {
                    foundItems.add(item);
                }
            }
        }
        return foundItems.toArray(C_88708284[]::new);
    }

    /**
     * @param player   The player you are checking.
     * @param itemType The item you are looking for.
     * @return Whether the player has any items that match the provided item type.
     */
    public static boolean hasAccessory(C_40996800 player, C_98888256 itemType) {
        for (C_88708284 item : getAccessories(player)) {
            if (item != null && item.m_23235460() == itemType) {
                return true;
            }
        }
        return false;
    }

    /**
     * @param player The player you are checking.
     * @param type   The type of accessory you are looking for.
     * @return Whether the player has any accessories in their inventory that match the type.
     */
    public static boolean hasAnyAccessoriesOfType(C_40996800 player, String type) {
        for (C_88708284 item : getAccessories(player)) {
            if (item != null && item.m_23235460() instanceof Accessory accessory) {
                if (Arrays.asList(accessory.getAccessoryTypes(item)).contains(type)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Removes the first equipped accessory matching the item type (fires removal callbacks).
     * Replaces old patterns like {@code player.inventory.armor[6] = null}.
     *
     * @param player   The player to remove the accessory from.
     * @param itemType The item to remove.
     * @return Whether an accessory was removed.
     */
    public static boolean removeAccessory(C_40996800 player, C_98888256 itemType) {
        AccessoryInventory inventory = getAccessoryInventory(player);
        for (int i = 0; i < inventory.m_54518913(); i++) {
            C_88708284 item = inventory.m_87969967(i);
            if (item != null && item.m_23235460() == itemType) {
                inventory.m_33431716(i, null);
                return true;
            }
        }
        return false;
    }

    /**
     * Drops all of the player's accessories at their position, like a death drop.
     * Useful for mods that implement custom death/drop handling.
     *
     * @param player The player whose accessories should drop.
     */
    public static void dropAccessories(C_40996800 player) {
        getAccessoryInventory(player).dropAll();
    }
}
