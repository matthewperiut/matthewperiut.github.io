package com.periut.accessoryapi.impl.mixin.client;

import com.periut.accessoryapi.AccessoryAPI;
import com.periut.accessoryapi.impl.slot.AccessoryButton;
import com.periut.accessoryapi.impl.slot.AccessorySlotStorage.PreservedSlot;
import net.minecraft.unmapped.C_09553359;
import net.minecraft.unmapped.C_12356698;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_57778754;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85589673;
import net.minecraft.unmapped.C_87711245;
import org.lwjgl.opengl.GL11;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.periut.accessoryapi.impl.slot.AccessoryInventoryPlacement.resetPlayerInv;
import static com.periut.accessoryapi.impl.slot.AccessorySlotStorage.*;

@Mixin(value = C_85589673.class)
public abstract class PlayerInventoryGuiMixin extends C_87711245 {
    // uses the aether-style armour slot by having the armour slots on the right of the player rendering
    @Unique
    private static final int AETHER_U = 0, AETHER_V = 0, AETHER_W = 154, AETHER_H = 72;
    // regular armour slot location
    @Unique
    private static final int REGULAR_U = 72, REGULAR_V = 0, REGULAR_W = 82, REGULAR_H = 72;
    @Unique
    private static final int SLOT_U = 154, SLOT_V = 54, SLOT_W = 18, SLOT_H = 18;
    @Unique
    private static final int CRAFT_U = 172, CRAFT_V = 0, CRAFT_W = 36, CRAFT_H = 72;
    @Unique
    private static final int CRAFT_X = 117;
    @Unique
    private static final int CORNER_INSET = 7;
    @Unique
    boolean extended = false;
    @Unique
    int wpx = 0;
    @Shadow
    private float mouseX;
    public PlayerInventoryGuiMixin(net.minecraft.unmapped.C_46053237 arg) {
        super(arg);
    }

    @Inject(method = "init", at = @At("TAIL"))
    public void init(CallbackInfo ci) {
        int startX = (f_05230747 - f_99871233) / 2;
        int startY = (f_07021018 - f_73003637) / 2;

        if (slotOrder.size() > 8) f_78519977.add(new AccessoryButton(250, startX + 115, startY + 6));
    }

    @Inject(method = "buttonClicked", at = @At("TAIL"))
    protected void buttonClicked(C_85125467 button, CallbackInfo ci) {
        if (button.f_92999450 == 250) {
            int startX = (f_05230747 - f_99871233) / 2;
            int startY = (f_07021018 - f_73003637) / 2;
            extended = !extended;
            ((AccessoryButton) button).goBack = extended;

            if (extended) {
                for (int i = 0; i < 5; i++) {
                    ((C_12356698) f_76651046.f_84566804.get(i)).f_40293340 = 1000;
                }

                button.f_99054304 = startX + 165;
                button.f_24716782 = startY + 1;
                showOverflowSlots((C_09553359) f_76651046);
            } else {
                resetPlayerInv(f_76651046);
                button.f_99054304 = startX + 115;
                button.f_24716782 = startY + 6;
                hideOverflowSlots((C_09553359) f_76651046);
            }


            AccessoryButton.time_clicked = System.currentTimeMillis();
        }
    }

    @Inject(method = "drawBackground", at = @At(value = "INVOKE", target = "Lorg/lwjgl/opengl/GL11;glEnable(I)V", ordinal = 0))
    public void bindAetherPlayerGuiTexture(float par1, CallbackInfo ci) {
        if (AccessoryAPI.noSlotsAdded)
            return;

        int var2 = f_78495264.f_45465196.m_33729172("/assets/accessoryapi/inventory.png");
        f_78495264.f_45465196.m_72568250(var2);

        int startX = (f_05230747 - f_99871233) / 2;
        int startY = (f_07021018 - f_73003637) / 2;
        if (AccessoryAPI.config.aetherStyleArmor) {
            //blit(startX + texOffsetX, startY + texOffsetY, texOffsetX, texOffsetY, topSizeX, topSizeY);
            m_66359748(startX + CORNER_INSET, startY + CORNER_INSET, AETHER_U, AETHER_V, AETHER_W, AETHER_H);
        } else {
            m_66359748(startX + CORNER_INSET + REGULAR_U, startY + CORNER_INSET + REGULAR_V, REGULAR_U, REGULAR_V, REGULAR_W, REGULAR_H);
        }

        int craft_centering_shift = 0;
        if (slotOrder.size() < 1)
            craft_centering_shift -= 18;
        else if (slotOrder.size() < 5)
            craft_centering_shift -= 9;

        if (!extended)
            m_66359748(startX + CRAFT_X + CORNER_INSET + craft_centering_shift, startY + CORNER_INSET, CRAFT_U, CRAFT_V, CRAFT_W, CRAFT_H);

        // blank tile (first inventory slot, bottom left)

        int start = f_76651046.f_84566804.size() - slotOrder.size();
        int end = f_76651046.f_84566804.size();
        int extra = (slotOrder.size() > 8 ? slotOrder.size() - 8 : 0);

        for (int i = start + (!extended ? extra : 0); i < end; i++) {
            C_12356698 slot = (C_12356698) f_76651046.f_84566804.get(i);
            PreservedSlot info = slotOrder.get(i - start);
            f_78495264.f_45465196.m_72568250(var2);
            m_66359748(startX + slot.f_95205544 - 1, startY + slot.f_40293340 - 1, SLOT_U, SLOT_V, SLOT_W, SLOT_H);
            if (!slot.m_66326040()) {
                if (!info.texture.isEmpty()) {
                    int slot_tex = f_78495264.f_45465196.m_33729172(info.texture);
                    f_78495264.f_45465196.m_72568250(slot_tex);
                    m_66359748(startX + slot.f_95205544, startY + slot.f_40293340, info.tx, info.ty, 16, 16);
                }
            }
        }
    }

    @Redirect(method = "drawBackground", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/ingame/InventoryScreen;drawTexture(IIIIII)V"))
    public void blitButCaptureWindowPos(C_85589673 instance, int i, int j, int k, int l, int m, int n) {
        instance.m_66359748(i, j, k, l, m, n);
        wpx = i; // window pos x
    }

    @Redirect(method = "drawBackground", at = @At(value = "INVOKE", target = "Lorg/lwjgl/opengl/GL11;glTranslatef(FFF)V"))
    public void translateAetherPlayerModel(float x, float y, float z) {
        if (!AccessoryAPI.config.aetherStyleArmor || AccessoryAPI.noSlotsAdded) {
            GL11.glTranslatef(x, y, z);
            return;
        }

        if (x != 0.f) {
            GL11.glTranslatef(x - 18, y - 50, z);
        }
    }

    @Redirect(method = "drawBackground", at = @At(value = "FIELD", target = "Lnet/minecraft/entity/player/ClientPlayerEntity;yaw:F", opcode = Opcodes.PUTFIELD, ordinal = 0))
    private void injected(C_57778754 instance, float value) {
        float newValue;
        if (!AccessoryAPI.config.aetherStyleArmor || AccessoryAPI.noSlotsAdded) {
            newValue = value;
        } else {
            float var9 = (float) (wpx + 33) - mouseX;
            newValue = (float) Math.atan(var9 / 40.0F) * 40.0F;
        }
        instance.f_80130373 = newValue;
    }

    @Redirect(method = "drawForeground", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/font/TextRenderer;draw(Ljava/lang/String;III)V", ordinal = 0))
    // net.minecraft.client.gui.screen.container.ContainerBase
    public void renderForeground(C_23014920 instance, String i, int j, int k, int color) {

    }
}