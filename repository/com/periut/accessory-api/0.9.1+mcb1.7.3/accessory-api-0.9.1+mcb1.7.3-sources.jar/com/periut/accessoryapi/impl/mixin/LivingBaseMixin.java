package com.periut.accessoryapi.impl.mixin;

import com.periut.accessoryapi.api.BossLivingEntity;
import com.periut.accessoryapi.api.PlayerExtraHP;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = C_74425583.class, priority = 900)
abstract public class LivingBaseMixin extends C_42232651 implements BossLivingEntity
{
    @Shadow public int maxHealth;

    @Shadow public int health;
    @Unique int maxHP = -1;
    @Unique String parsedBossName = "";

    private LivingBaseMixin(C_64041439 arg) {
        super(arg);
    }

    @Inject(method = "heal", at = @At("HEAD"), cancellable = true)
    public void addHealth(int health, CallbackInfo ci)
    {
        int extraHP = 0;
        if (((Object) this) instanceof PlayerExtraHP playerExtraHP)
        {
            extraHP = playerExtraHP.getExtraHP();
        }

        if (this.health > 0) {
            this.health += health;
            if (this.health > 20 + extraHP) {
                this.health = 20 + extraHP;
            }

            this.f_02385719 = this.maxHealth / 2;
        }

        ci.cancel();
    }

    @Override
    public void setBoss(boolean boss)
    {
        // setFlag
        m_95740281(6, boss);
        f_88296653.m_52395024(30, health);
        prevHP = health;
    }

    @Override
    public boolean isBoss()
    {
        // isFlagSet
        return m_31730897(6);
    }

    @Override
    public int getHP() {
        return f_88296653.m_09089969(30);
    }

    @Override
    public int getMaxHP()
    {
        if (maxHP == -1)
        {
            maxHP = health;
            if ((Object) this instanceof PlayerExtraHP extraHP)
            {
                maxHP += extraHP.getExtraHP();
            }
        }
        return maxHP;
    }

    @Override
    public String getName()
    {
        if (parsedBossName.isEmpty())
        {
            if (((Object) this) instanceof C_40996800 player) {
                parsedBossName = player.f_59008391 + " ";
            }
            else {
                String input = m_06252001();
                StringBuilder output = new StringBuilder();
                for (int i = 0; i < input.length(); i++)
                {
                    if (Character.isUpperCase(input.charAt(i)) && i != 0) {
                        output.append(" ");
                    }

                    output.append(input.charAt(i));
                }

                parsedBossName = output + " ";
                String customTitle = getCustomTitle();
                if (!customTitle.isEmpty()) {
                    parsedBossName += customTitle + " ";
                }
            }
        }
        return parsedBossName;
    }

    @Inject(method = "initDataTracker", at = @At("RETURN"))
    protected void initDataTrackerBossHP(CallbackInfo ci)
    {
        f_88296653.m_94812360(30, (int) 0);
    }

    @Unique int prevHP = 0;
    @Inject(method = "tick", at = @At("TAIL"))
    protected void updateHP(CallbackInfo ci) {
        if (isBoss()) {
            if (prevHP == 0) {
                prevHP = health;
            } else {
                if (health != prevHP) {
                    f_88296653.m_52395024(30, health);
                    prevHP = health;
                }
            }
        }
    }
}
