package com.periut.accessoryapi.impl.slot;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_85125467;
import org.lwjgl.opengl.GL11;

public class AccessoryButton extends C_85125467 {
    public static long time_clicked = 0;
    public boolean goBack = false;

    public AccessoryButton(int id, int x, int y) {
        super(id, x, y, 10, 10, "");
    }

    @Override
    public void m_43811351(Minecraft minecraft, int i, int j) {
        if (f_59331544) {
            GL11.glBindTexture(3553, minecraft.f_45465196.m_33729172("/assets/accessoryapi/buttons.png"));
            GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

            boolean hovered = i >= f_99054304 && j >= f_24716782 && i < f_99054304 + f_64784750 && j < f_24716782 + f_00173992;

            int tpx = hovered ? 30 : 10; // texture position x
            int tpy = goBack ? 10 : 0; // texture position y

            m_66359748(f_99054304, f_24716782, tpx, tpy, 10, 10);
            m_77395853(minecraft, i, j);
        }
    }
}
