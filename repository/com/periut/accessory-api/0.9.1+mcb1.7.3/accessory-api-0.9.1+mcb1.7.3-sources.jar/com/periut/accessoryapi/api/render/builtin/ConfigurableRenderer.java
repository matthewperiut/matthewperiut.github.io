package com.periut.accessoryapi.api.render.builtin;

import com.periut.accessoryapi.api.render.AccessoryRenderer;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import net.minecraft.unmapped.C_32232284;
import net.minecraft.unmapped.C_82920792;

public abstract class ConfigurableRenderer implements AccessoryRenderer {
    protected String texture;
    protected Color color = Color.WHITE;

    public ConfigurableRenderer(String texture) {
        super();
        this.texture = texture;
    }

    public ConfigurableRenderer withColor(Color color) {
        this.color = color;
        return this;
    }

    protected void bindTextureAndApplyColors(float brightness) {
        C_82920792 textureManager = C_32232284.f_14776289.f_60495800;
        if (textureManager == null) {
            System.err.println("The entity texture manager is currently null");
            return;
        }
        textureManager.m_72568250(textureManager.m_33729172(texture));
        GL11.glColor3f(brightness * color.getRed() / 255f, brightness * color.getGreen() / 255f, brightness * color.getBlue() / 255f);
    }
}
