package com.periut.accessoryapi.impl.mixin;

import com.periut.accessoryapi.api.TickableInArmorSlot;
import net.minecraft.unmapped.C_97645581;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(C_97645581.class)
public class ArmorMixin implements TickableInArmorSlot {
}
