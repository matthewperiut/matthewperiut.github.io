package com.periut.accessoryapi.impl.mixin;

import com.periut.accessoryapi.AccessoryAPI;
import com.periut.accessoryapi.api.AccessoryHolder;
import com.periut.accessoryapi.api.AccessoryInventory;
import com.periut.accessoryapi.impl.slot.AccessorySlot;
import com.periut.accessoryapi.impl.slot.AccessorySlotStorage;
import net.minecraft.unmapped.C_09553359;
import net.minecraft.unmapped.C_12356698;
import net.minecraft.unmapped.C_46053237;
import net.minecraft.unmapped.C_87542771;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.periut.accessoryapi.impl.slot.AccessoryInventoryPlacement.getCraftingOffset;
import static com.periut.accessoryapi.impl.slot.AccessorySlotStorage.hideOverflowSlots;
import static com.periut.accessoryapi.impl.slot.AccessorySlotStorage.slotOrder;

@Mixin(C_09553359.class)
public abstract class PlayerContainerMixin extends C_46053237 {
    @Unique
    private static final int craft_centering_shift = getCraftingOffset();
    @Unique
    int slotCounter = 0;

    @ModifyArg(method = "<init>(Lnet/minecraft/entity/player/PlayerInventory;Z)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/screen/PlayerScreenHandler;addSlot(Lnet/minecraft/screen/slot/Slot;)V"), index = 0)
    private C_12356698 changeTopSlots(C_12356698 par1) {
        AccessorySlotStorage.initializeCustomAccessoryPositions();
        if (AccessoryAPI.noSlotsAdded)
            return par1;

        if (par1.f_95205544 == 144) // x of crafting result
        {
            par1.f_95205544 = 134 + craft_centering_shift;
            par1.f_40293340 = 62;
            slotCounter = 0;
        }

        if (slotCounter > 0 && slotCounter < 5) // 1, 2, 3, 4 are crafting slots
        {
            par1.f_95205544 += 37 + craft_centering_shift;
            par1.f_40293340 -= 18;
        }

        if (AccessoryAPI.config.aetherStyleArmor) {
            if (slotCounter > 4 && slotCounter < 9) // armour
            {
                par1.f_95205544 += 54;
            }
        }

        slotCounter++;
        return par1;
    }

    @Inject(method = "<init>(Lnet/minecraft/entity/player/PlayerInventory;Z)V", at = @At(value = "TAIL"))
    private void addSlots(C_87542771 inv, boolean par2, CallbackInfo ci) {
        if (AccessoryAPI.noSlotsAdded)
            return;

        // accessory slots are backed by the player's own AccessoryInventory,
        // not by extra indices grafted onto the vanilla armor array
        AccessoryInventory accessories = ((AccessoryHolder) inv.f_31714243).getAccessoryInventory();
        int slotnum = 0;

        for (AccessorySlotStorage.PreservedSlot slot : slotOrder) {
            m_97138749(new AccessorySlot(accessories, slotnum, slot.pos.f_77181208 + 18, slot.pos.f_93738510, slot.slotType));
            slotnum++;
        }

        hideOverflowSlots((C_09553359) (Object) this);
    }
}
