package com.periut.accessoryapi.impl.mixin;

import com.periut.accessoryapi.impl.AccessoryPersistence;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_79370641;
import net.minecraft.unmapped.C_87542771;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * The armor array is no longer resized — accessories live in their own
 * {@link com.periut.accessoryapi.api.AccessoryInventory}. This mixin only
 * migrates items that older versions of the mod stored as extra armor slots
 * (Slot bytes >= 100 + armorOffset) into the new storage.
 */
@Mixin(C_87542771.class)
public class PlayerInventoryMixin {
    @Shadow
    public C_40996800 player;

    @Inject(method = "readNbt", at = @At("TAIL"))
    public void accessoryapi$migrateLegacyAccessories(C_79370641 nbt, CallbackInfo ci) {
        AccessoryPersistence.migrateLegacyInventory(player, nbt);
    }
}
