package com.periut.accessoryapi.impl;

import com.periut.accessoryapi.AccessoryAPI;
import com.periut.accessoryapi.api.Accessory;
import com.periut.accessoryapi.api.AccessoryHolder;
import com.periut.accessoryapi.api.AccessoryInventory;
import com.periut.accessoryapi.api.PlayerExtraHP;
import com.periut.accessoryapi.impl.mixin.WorldAccessor;
import com.periut.accessoryapi.impl.mixin.WorldStorageAccessor;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.logging.Logger;
import net.minecraft.unmapped.C_08489468;
import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_68019318;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_79370641;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_97075175;

/**
 * Per-player accessory data, persisted to its own file:
 * {@code <world>/accessories/<playername>.dat}
 * <p>
 * The file holds the player's accessory items (keyed by slot type, not raw index)
 * and their ExtraHP. Because it lives outside the player tag, ExtraHP survives
 * death/respawn, and accessory items can be cleared on death independently of
 * the vanilla inventory.
 */
public final class AccessoryPersistence {
    private static final Logger LOGGER = Logger.getLogger("Minecraft");

    private AccessoryPersistence() {
    }

    /** @return the player's accessory data file, or null when there is no local world storage (e.g. multiplayer client). */
    public static File getFile(C_40996800 player) {
        if (player == null || player.f_94306729 == null || player.f_59008391 == null) {
            return null;
        }
        // World.getWorldStorage() is server-only; read the field via accessor instead
        C_08489468 storage = ((WorldAccessor) player.f_94306729).accessoryapi$getStorage();
        if (!(storage instanceof C_68019318 worldStorage)) {
            return null;
        }
        File worldDir = ((WorldStorageAccessor) worldStorage).accessoryapi$getWorldDirectory();
        return new File(new File(worldDir, "accessories"), player.f_59008391 + ".dat");
    }

    public static void save(C_40996800 player) {
        File file = getFile(player);
        if (file == null) {
            return;
        }

        C_74087615 root = new C_74087615();
        root.m_20318863("ExtraHP", ((PlayerExtraHP) player).getExtraHP());
        C_79370641 items = new C_79370641();
        ((AccessoryHolder) player).getAccessoryInventory().writeNbt(items);
        root.m_21770494("Accessories", (C_97075175) items);

        try {
            file.getParentFile().mkdirs();
            // write-then-rename so a crash mid-write can't corrupt the existing file
            File tmp = new File(file.getParentFile(), "_" + file.getName() + ".tmp");
            C_08565163.m_39608025(root, new FileOutputStream(tmp));
            if (file.exists()) {
                file.delete();
            }
            tmp.renameTo(file);
        } catch (Exception e) {
            LOGGER.warning("[" + AccessoryAPI.MOD_ID + "] Failed to save accessory data for " + player.f_59008391);
        }
    }

    public static void load(C_40996800 player) {
        File file = getFile(player);
        if (file == null || !file.exists()) {
            return;
        }

        try {
            C_74087615 root = C_08565163.m_38706312(new FileInputStream(file));
            if (root == null) {
                return;
            }
            if (root.m_97612750("ExtraHP")) {
                ((PlayerExtraHP) player).setExtraHP(root.m_35587574("ExtraHP"));
            }
            ((AccessoryHolder) player).getAccessoryInventory().readNbt(root.m_95654166("Accessories"));
        } catch (Exception e) {
            LOGGER.warning("[" + AccessoryAPI.MOD_ID + "] Failed to load accessory data for " + player.f_59008391);
        }
    }

    /**
     * One-time migration from the old format, where accessories were saved as extra
     * vanilla armor slots ({@code Slot >= 100 + armorOffset} in the "Inventory" list).
     * Only runs while the player has no accessory file yet — once saved, the new
     * file is the single source of truth.
     */
    public static void migrateLegacyInventory(C_40996800 player, C_79370641 inventoryNbt) {
        if (player == null || player.f_94306729 == null || player.f_94306729.f_50876584) {
            return;
        }
        File file = getFile(player);
        if (file == null || file.exists()) {
            return;
        }

        int offset = 100 + AccessoryAPI.config.armorOffset;
        AccessoryInventory accessories = ((AccessoryHolder) player).getAccessoryInventory();
        for (int i = 0; i < inventoryNbt.m_89439680(); i++) {
            C_74087615 entry = (C_74087615) inventoryNbt.m_59132367(i);
            int slot = entry.m_84056038("Slot") & 255;
            if (slot < offset) {
                continue;
            }
            C_88708284 stack = new C_88708284(entry);
            if (stack.m_23235460() == null) {
                continue;
            }
            // old storage was positional: armor[armorOffset + i] <-> accessory slot i.
            // Keep that position when it still exists, is free, and its type still
            // fits the item; otherwise fall back to any fitting slot -> empty main
            // inventory -> drop at the player's feet.
            int target = slot - offset;
            if (target < accessories.m_54518913() && accessories.m_87969967(target) == null
                    && accessoryFits(stack, accessories.getSlotType(target))) {
                accessories.m_33431716(target, stack);
            } else {
                accessories.equipOrStash(stack);
            }
        }
    }

    private static boolean accessoryFits(C_88708284 stack, String slotType) {
        if (!(stack.m_23235460() instanceof Accessory accessory)) {
            return false;
        }
        String[] types = accessory.getAccessoryTypes(stack);
        if (types == null) {
            return false;
        }
        for (String type : types) {
            if (slotType.equals(type)) {
                return true;
            }
        }
        return false;
    }
}
