package com.periut.accessoryapi.impl.mixin.client;

import com.periut.accessoryapi.api.BossLivingEntity;
import com.periut.accessoryapi.api.helper.AccessoryAccess;
import com.periut.accessoryapi.api.render.HasCustomRenderer;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_25850426;
import net.minecraft.unmapped.C_29058632;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43718703;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_94584382;
import net.minecraft.unmapped.C_97866173;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.List;

@Mixin(C_97866173.class)
public class InGameGuiMixinHUD extends C_29058632 {
    @Shadow
    private Minecraft minecraft;

    @Unique
    boolean pumpkin = false;

    @Unique
    C_74425583 boss = null;
    @Unique
    int frames = 0;

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerInventory;getArmorStack(I)Lnet/minecraft/item/ItemStack;"))
    public void renderHud(float bl, boolean i, int j, int par4, CallbackInfo ci) {
        C_97866173 instance = (C_97866173) (Object) this;
        C_43718703 scaler = new C_43718703(this.minecraft.f_58088711, this.minecraft.f_31800787, this.minecraft.f_74192110);
        int width = scaler.m_39119333();
        int height = scaler.m_16103615();

        frames++;
        if (frames > 120) {
            frames = 0;
            List<C_74425583> bosses = new ArrayList<>();
            C_40996800 player = minecraft.f_28396371;
            List<C_74425583> entities = player.f_94306729.m_11058721(C_74425583.class, C_82690114.m_23878395(player.f_78826675 - 20, player.f_31030949 - 20, player.f_97691941 - 20, player.f_78826675 + 20, player.f_31030949 + 20, player.f_97691941 + 20));

            C_94584382 start = C_94584382.m_35957932(player.f_78826675, player.f_31030949, player.f_97691941);
            for (C_74425583 entity : entities) {
                if (entity instanceof BossLivingEntity check) {
                    if (check.isBoss()) {
                        if (entity.equals(player))
                            continue;

                        C_94584382 end = C_94584382.m_35957932(entity.f_78826675, entity.f_31030949, entity.f_97691941);
                        C_24654288 hitResult = player.f_94306729.m_40214598(start, end, false);
                        if (hitResult == null) {
                            bosses.add(entity);
                        } else if (hitResult.f_92820457 == C_25850426.f_19478796) {
                            bosses.add(entity);
                        }
                    }
                }
            }

            if (bosses.isEmpty()) {
                boss = null;
            }
            if (bosses.size() == 1) {
                boss = bosses.get(0);
            } else if (bosses.size() > 1) {
                C_74425583 closest = bosses.get(0);
                for (C_74425583 b : bosses) {
                    if (player.m_22973163(b) > closest.m_22973163(player)) {
                        closest = b;
                    }
                }
                boss = closest;
            }
        }

        if (boss != null) {
            final String title = ((BossLivingEntity) boss).getName();
            minecraft.f_21497584.m_27673420(title, width / 2 - minecraft.f_21497584.m_09235706(title) / 2, 2, -1);
            GL11.glBindTexture(3553, minecraft.f_45465196.m_33729172("/assets/accessoryapi/bossHPBar.png"));
            GL11.glEnable(3042);
            GL11.glBlendFunc(775, 769);
            GL11.glColor3f(1.0f, 1.0f, 1.0f);
            GL11.glDisable(3042);
            instance.m_66359748(width / 2 - 128, 12, 0, 16, 256, 32);
            final int w = (int) (((BossLivingEntity) boss).getHP() / (float) ((BossLivingEntity) boss).getMaxHP() * 256.0f);
            instance.m_66359748(width / 2 - 128, 12, 0, 0, w, 16);

            if (!boss.m_48190713()) {
                ((BossLivingEntity) boss).setBoss(false);
                boss = null;
            }
        }


        if (pumpkin) {
            pumpkin = false;
            return;
        }

        for (C_88708284 item : minecraft.f_28396371.f_29439708.f_52412003) {
            accessoryapi$renderItemHud(item, scaler, width, height);
        }
        for (C_88708284 item : AccessoryAccess.getAccessories(minecraft.f_28396371)) {
            accessoryapi$renderItemHud(item, scaler, width, height);
        }

    }

    @Unique
    private void accessoryapi$renderItemHud(C_88708284 item, C_43718703 scaler, int width, int height) {
        if (item == null)
            return;
        if (item.m_23235460() instanceof HasCustomRenderer customRenderer) {
            if (customRenderer.getRenderer() != null) {
                customRenderer.getRenderer().renderHUD(minecraft.f_28396371, item, minecraft, scaler, width, height);
            }
        }
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/hud/InGameHud;renderPumpkinOverlay(II)V"))
    public void setPumpkin(float bl, boolean i, int j, int par4, CallbackInfo ci) {
        pumpkin = true;
    }
}
