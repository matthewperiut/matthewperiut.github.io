package com.periut.accessoryapi.impl.slot;

import com.periut.accessoryapi.AccessoryAPI;
import net.minecraft.unmapped.C_09553359;

import static com.periut.accessoryapi.impl.slot.AccessorySlotStorage.hideOverflowSlots;
import static com.periut.accessoryapi.impl.slot.AccessorySlotStorage.slotInfo;

public class AccessoryInventoryPlacement {
    public static int getCraftingOffset() {
        int craft_centering_shift = 0;
        if (slotInfo.size() < 1)
            craft_centering_shift -= 18;
        else if (slotInfo.size() < 5)
            craft_centering_shift -= 9;

        return craft_centering_shift;
    }

    public static void resetPlayerInv(net.minecraft.unmapped.C_46053237 container) {
        if (AccessoryAPI.noSlotsAdded)
            return;

        if (container instanceof C_09553359 pc) {
            int crafting_offset_x = getCraftingOffset();

            // crafting result pos ( for aether )
            pc.m_89372629(0).f_95205544 = 134 + crafting_offset_x;
            pc.m_89372629(0).f_40293340 = 62;

            int slot = 1; // skip crafting result
            for (int y = 0; y < 2; ++y) {
                for (int x = 0; x < 2; ++x) {
                    pc.m_89372629(slot).f_95205544 = 125 + (18 * x) + crafting_offset_x;
                    pc.m_89372629(slot).f_40293340 = 8 + (18 * y);
                    slot++;
                }
            }

            hideOverflowSlots(pc);
        }
    }
}
