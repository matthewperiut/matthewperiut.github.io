package com.periut.accessoryapi.api;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_88708284;

public interface TickableInArmorSlot {
    default C_88708284 tickWhileWorn(C_40996800 player, C_88708284 ItemStack) {
        return ItemStack;
    }
}
