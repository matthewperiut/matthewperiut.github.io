package com.periut.accessoryapi.impl.mixin.server;

import com.periut.accessoryapi.api.AccessoryHolder;
import com.periut.accessoryapi.impl.AccessoryPersistence;
import com.periut.accessoryapi.impl.slot.AccessorySlotStorage;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Syncs accessories to other clients by extending the vanilla equipment system:
 * equipment slot 0 is the held item, 1-4 are armor, and 5+ are accessory slots.
 * <p>
 * The {@code equipment} array is the "last shown" cache that tick() diffs against
 * to decide when to send EntityEquipmentUpdateS2CPackets; resizing it (and answering
 * getEquipment for slots >= 5 from the accessory inventory) makes both the per-tick
 * diff and EntityTrackerEntry's initial sync (which iterates getEquipment()) cover
 * accessories with no custom packets.
 */
@Mixin(C_49202226.class)
public class ServerPlayerMixin {
    @Shadow
    private C_88708284[] equipment;

    @Inject(method = "<init>", at = @At("TAIL"))
    private void accessoryapi$resizeEquipmentCache(CallbackInfo ci) {
        // 1 held item + 4 armor + accessory slots
        equipment = new C_88708284[5 + AccessorySlotStorage.getSlotCount()];
    }

    @ModifyConstant(method = "tick()V", constant = @Constant(intValue = 5), require = 1)
    private int accessoryapi$syncAccessoriesInTick(int original) {
        return equipment.length;
    }

    @Inject(method = "getEquipment(I)Lnet/minecraft/item/ItemStack;", at = @At("HEAD"), cancellable = true)
    private void accessoryapi$getAccessoryEquipment(int slot, CallbackInfoReturnable<C_88708284> cir) {
        if (slot >= 5) {
            var accessories = ((AccessoryHolder) this).getAccessoryInventory();
            cir.setReturnValue(slot - 5 < accessories.m_54518913() ? accessories.m_87969967(slot - 5) : null);
        }
    }

    // ServerPlayerEntity.onKilledBy does not call super, so PlayerBaseMixin's death
    // hook never runs on the server player — drop and persist here instead.
    @Inject(method = "onKilledBy", at = @At("TAIL"))
    private void accessoryapi$dropAccessoriesOnDeath(C_42232651 adversary, CallbackInfo ci) {
        ((AccessoryHolder) this).getAccessoryInventory().dropAll();
        AccessoryPersistence.save((C_40996800) (Object) this);
    }
}
