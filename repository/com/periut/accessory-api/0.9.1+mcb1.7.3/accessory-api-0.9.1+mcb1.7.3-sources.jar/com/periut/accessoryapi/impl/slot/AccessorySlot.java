package com.periut.accessoryapi.impl.slot;

import com.periut.accessoryapi.api.Accessory;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_12356698;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_88708284;

public class AccessorySlot extends C_12356698 {
    // delay while pressing accessory slot button to prevent taking / inserting item
    private static final long MILLISECONDS_DELAY = 50;
    String type;

    public AccessorySlot(C_43616774 arg, int i, int j, int k, String type) {
        super(arg, i, j, k);
        this.type = type;
    }

    public int m_72821612() {
        return 1;
    }

    public boolean m_74355745(C_88708284 item) {
        if (cancelSlotButtonInterference())
            return false;

        if (item.m_23235460() instanceof Accessory accessory) {
            for (String type : accessory.getAccessoryTypes(item)) {
                if (type.equals(this.type)) {
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public C_88708284 m_96468135(int i) {
        if (cancelSlotButtonInterference())
            return null;
        return super.m_96468135(i);
    }

    private boolean cancelSlotButtonInterference() {
        EnvType side = FabricLoader.getInstance().getEnvironmentType();
        if (side == EnvType.CLIENT) {
            Minecraft mc = (Minecraft) FabricLoader.getInstance().getGameInstance();
            if (mc.m_55181026() == null)
                return !clientCanInsert();
            else
                return false;
            // revert to default behavior if on server,
            // because I don't want to make a custom packet to sync pressing the button atm
            // todo: button/slot interference multiplayer fix
        } else {
            return false;
        }
    }

    @Environment(EnvType.CLIENT)
    private boolean clientCanInsert() {
        return AccessoryButton.time_clicked + MILLISECONDS_DELAY <= System.currentTimeMillis();
    }
}
