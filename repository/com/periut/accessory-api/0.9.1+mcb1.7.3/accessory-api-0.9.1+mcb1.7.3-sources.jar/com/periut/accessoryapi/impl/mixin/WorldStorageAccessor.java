package com.periut.accessoryapi.impl.mixin;

import java.io.File;
import net.minecraft.unmapped.C_68019318;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_68019318.class)
public interface WorldStorageAccessor {
    @Invoker("getDirectory")
    File accessoryapi$getWorldDirectory();
}
