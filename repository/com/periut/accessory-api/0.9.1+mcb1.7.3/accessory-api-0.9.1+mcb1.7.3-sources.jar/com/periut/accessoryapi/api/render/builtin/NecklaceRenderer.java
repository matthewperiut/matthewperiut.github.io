package com.periut.accessoryapi.api.render.builtin;

import com.periut.accessoryapi.api.render.RenderingHelper;
import net.minecraft.unmapped.C_34859172;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_82280655;
import net.minecraft.unmapped.C_88708284;

public class NecklaceRenderer extends ConfigurableRenderer {
    private static final C_82280655 model = new C_82280655(0.6f);

    public NecklaceRenderer(String texture) {
        super(texture);
    }

    @Override
    public void renderThirdPerson(C_40996800 player, C_34859172 renderer, C_88708284 itemStack, double x, double y, double z, float h, float v) {
        RenderingHelper.beforeBiped(player, renderer, model, x, y, z, h, v);
        bindTextureAndApplyColors(player.m_95186532(h));
        model.f_07735729.m_71968273(0.0625f);
        RenderingHelper.afterBiped(model);
    }
}
