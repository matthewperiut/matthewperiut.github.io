package com.periut.accessoryapi.api;

import com.periut.accessoryapi.impl.slot.AccessorySlotStorage;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_79370641;
import net.minecraft.unmapped.C_88708284;

/**
 * Per-player accessory storage, separate from the vanilla armor array.
 * <p>
 * Each slot is identified by its accessory type plus an ordinal among slots of the
 * same type (e.g. the second "ring" slot is {@code ("ring", 1)}), so persisted items
 * survive mods being added/removed or slots being registered in a different order —
 * no raw index assumptions.
 */
public class AccessoryInventory implements C_43616774 {
    private final C_40996800 owner;
    private final C_88708284[] stacks;
    private final String[] slotTypes;
    private final int[] slotTypeIndices;

    public AccessoryInventory(C_40996800 owner) {
        AccessorySlotStorage.ensureInitialized();
        this.owner = owner;
        int count = AccessorySlotStorage.slotOrder.size();
        stacks = new C_88708284[count];
        slotTypes = new String[count];
        slotTypeIndices = new int[count];
        Map<String, Integer> seen = new HashMap<>();
        for (int i = 0; i < count; i++) {
            String type = AccessorySlotStorage.slotOrder.get(i).slotType;
            slotTypes[i] = type;
            slotTypeIndices[i] = seen.merge(type, 1, Integer::sum) - 1;
        }
    }

    public C_40996800 getOwner() {
        return owner;
    }

    /** The accessory type of the given slot (e.g. "ring"). */
    public String getSlotType(int slot) {
        return slotTypes[slot];
    }

    /** The ordinal of this slot among slots of the same type (0 for the first "ring" slot, 1 for the second, ...). */
    public int getSlotTypeIndex(int slot) {
        return slotTypeIndices[slot];
    }

    /** @return the slot index for the given (type, ordinal) pair, or -1 if no such slot is registered. */
    public int getSlotFor(String type, int typeIndex) {
        for (int i = 0; i < stacks.length; i++) {
            if (slotTypes[i].equals(type) && slotTypeIndices[i] == typeIndex) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public int m_54518913() {
        return stacks.length;
    }

    @Override
    public C_88708284 m_87969967(int slot) {
        return stacks[slot];
    }

    @Override
    public C_88708284 m_07546956(int slot, int amount) {
        C_88708284 stack = stacks[slot];
        if (stack == null) {
            return null;
        }
        if (stack.f_60602012 <= amount) {
            stacks[slot] = null;
            fireRemoved(stack);
            m_38999452();
            return stack;
        }
        C_88708284 split = stack.m_67861752(amount);
        if (stack.f_60602012 == 0) {
            stacks[slot] = null;
            fireRemoved(stack);
        }
        m_38999452();
        return split;
    }

    /** Sets the stack and fires {@link Accessory#onAccessoryRemoved}/{@link Accessory#onAccessoryAdded} callbacks. */
    @Override
    public void m_33431716(int slot, C_88708284 stack) {
        C_88708284 old = stacks[slot];
        stacks[slot] = stack;
        if (old != null) {
            fireRemoved(old);
        }
        if (stack != null && stack.m_23235460() instanceof Accessory accessory) {
            accessory.onAccessoryAdded(owner, stack);
        }
        m_38999452();
    }

    /** Sets the stack without firing accessory callbacks (used for ticking replacements and remote-player sync). */
    public void replaceStack(int slot, C_88708284 stack) {
        stacks[slot] = stack;
        m_38999452();
    }

    /**
     * Equips the stack into the first empty slot whose type the item accepts
     * (per {@link Accessory#getAccessoryTypes}).
     *
     * @return whether a fitting empty slot was found.
     */
    public boolean equipAnywhere(C_88708284 stack) {
        if (stack == null || !(stack.m_23235460() instanceof Accessory accessory)) {
            return false;
        }
        String[] types = accessory.getAccessoryTypes(stack);
        if (types == null) {
            return false;
        }
        for (int i = 0; i < stacks.length; i++) {
            if (stacks[i] != null) {
                continue;
            }
            for (String type : types) {
                if (slotTypes[i].equals(type)) {
                    m_33431716(i, stack);
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Standard recovery chain for items that can no longer go where they were saved:
     * any fitting empty accessory slot, else an empty main-inventory slot, else
     * dropped at the owner's feet — nothing is silently deleted.
     */
    public void equipOrStash(C_88708284 stack) {
        if (stack == null) {
            return;
        }
        if (!equipAnywhere(stack) && !owner.f_29439708.m_21544200(stack)) {
            owner.m_90783905(stack, false);
        }
    }

    /** Drops every accessory at the owner's position (vanilla death-scatter style) and clears the inventory. */
    public void dropAll() {
        for (int i = 0; i < stacks.length; i++) {
            C_88708284 stack = stacks[i];
            if (stack != null) {
                stacks[i] = null;
                fireRemoved(stack);
                owner.m_90783905(stack, true);
            }
        }
        m_38999452();
    }

    private void fireRemoved(C_88708284 stack) {
        if (stack.m_23235460() instanceof Accessory accessory) {
            accessory.onAccessoryRemoved(owner, stack);
        }
    }

    /** Writes non-empty slots as {Type, TypeIndex, id, Damage, Count} compounds. */
    public C_79370641 writeNbt(C_79370641 list) {
        for (int i = 0; i < stacks.length; i++) {
            if (stacks[i] != null) {
                C_74087615 entry = new C_74087615();
                entry.m_91017064("Type", slotTypes[i]);
                entry.m_20318863("TypeIndex", slotTypeIndices[i]);
                stacks[i].m_58480627(entry);
                list.m_43125067(entry);
            }
        }
        return list;
    }

    /**
     * Places saved items back by (type, ordinal). Items whose exact slot no longer
     * exists (a mod was removed, fewer slots of that type) fall back through
     * {@link #equipOrStash}: any other fitting slot, then the main inventory, then
     * a drop at the player's feet — nothing is silently deleted.
     */
    public void readNbt(C_79370641 list) {
        for (int i = 0; i < list.m_89439680(); i++) {
            C_74087615 entry = (C_74087615) list.m_59132367(i);
            C_88708284 stack = new C_88708284(entry);
            if (stack.m_23235460() == null) {
                continue;
            }
            int slot = getSlotFor(entry.m_47517355("Type"), entry.m_35587574("TypeIndex"));
            if (slot != -1 && stacks[slot] == null) {
                m_33431716(slot, stack);
            } else {
                equipOrStash(stack);
            }
        }
    }

    @Override
    public String m_03432210() {
        return "Accessories";
    }

    @Override
    public int m_48421899() {
        return 1;
    }

    @Override
    public void m_38999452() {
    }

    @Override
    public boolean m_93421545(C_40996800 player) {
        return player == owner;
    }
}
