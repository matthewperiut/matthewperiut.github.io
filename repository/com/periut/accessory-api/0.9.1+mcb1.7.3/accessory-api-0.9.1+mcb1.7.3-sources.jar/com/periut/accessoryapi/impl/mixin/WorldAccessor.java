package com.periut.accessoryapi.impl.mixin;

import net.minecraft.unmapped.C_08489468;
import net.minecraft.unmapped.C_64041439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * World.getWorldStorage() is @Environment(SERVER) and doesn't exist in the client
 * jar, but the underlying storage field is present on both sides — read it directly
 * so singleplayer (client-authoritative) persistence works.
 */
@Mixin(C_64041439.class)
public interface WorldAccessor {
    @Accessor("storage")
    C_08489468 accessoryapi$getStorage();
}
