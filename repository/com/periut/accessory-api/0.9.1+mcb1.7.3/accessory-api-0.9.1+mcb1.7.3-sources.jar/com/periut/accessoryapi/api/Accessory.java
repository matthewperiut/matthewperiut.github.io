package com.periut.accessoryapi.api;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_88708284;

public interface Accessory extends TickableInArmorSlot {
    /**
     * Determines what accessory slots your item goes to
     *
     * @param item The instance being accessed specifically.
     * @return Accessory Type String array
     */
    String[] getAccessoryTypes(C_88708284 item);

    default void onAccessoryAdded(C_40996800 player, C_88708284 accessory) {
    }

    default void onAccessoryRemoved(C_40996800 player, C_88708284 accessory) {
    }
}