package com.periut.accessoryapi.api.render;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_34859172;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43718703;
import net.minecraft.unmapped.C_88708284;

public interface AccessoryRenderer {
    AccessoryRenderer NULL_RENDERER = new AccessoryRenderer() {
    };

    default void renderThirdPerson(C_40996800 player, C_34859172 renderer, C_88708284 itemStack, double x, double y, double z, float h, float v) {
    }

    default void renderFirstPerson(C_40996800 player, C_34859172 renderer, C_88708284 itemStack) {
    }

    default void renderHUD(C_40996800 player, C_88708284 itemStack, Minecraft minecraft, C_43718703 screenScaler, int scaledWidth, int scaledHeight) {
    }
}
