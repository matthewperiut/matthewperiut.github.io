package com.periut.accessoryapi.impl.mixin;

import com.periut.accessoryapi.api.AccessoryHolder;
import com.periut.accessoryapi.api.AccessoryInventory;
import com.periut.accessoryapi.api.PlayerExtraHP;
import com.periut.accessoryapi.api.PlayerVisibility;
import com.periut.accessoryapi.api.TickableInArmorSlot;
import com.periut.accessoryapi.impl.AccessoryPersistence;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_40996800.class)
public abstract class PlayerBaseMixin extends C_74425583 implements PlayerExtraHP, PlayerVisibility, AccessoryHolder
{
    @Unique
    private AccessoryInventory accessoryapi$accessories;
    @Unique
    private boolean accessoryapi$persistentDataLoaded = false;
    @Unique
    private boolean accessoryapi$nbtApplied = false;

    private PlayerBaseMixin(C_64041439 arg) {
        super(arg);
    }

    @Override
    public AccessoryInventory getAccessoryInventory() {
        if (accessoryapi$accessories == null) {
            accessoryapi$accessories = new AccessoryInventory((C_40996800) (Object) this);
        }
        return accessoryapi$accessories;
    }

    @Inject(method = "tick", at = @At("HEAD"))
    public void accessoryapi$loadPersistentData(CallbackInfo ci) {
        // Lazy-load on the first tick of every player entity. This single hook covers
        // world load, server join, and the fresh entities created on respawn (both the
        // singleplayer client respawn and PlayerManager.respawnPlayer on servers).
        // On multiplayer clients there is no local storage; contents arrive over the network.
        if (!accessoryapi$persistentDataLoaded) {
            accessoryapi$persistentDataLoaded = true;
            if (!this.f_94306729.f_50876584) {
                AccessoryPersistence.load((C_40996800) (Object) this);
                // Fresh spawn (no NBT was applied to this entity = respawn or first join):
                // vanilla starts the player at 20 health, so fill the extra hearts too.
                // World/server loads go through readNbt and keep their saved health.
                if (!accessoryapi$nbtApplied) {
                    this.f_05442563 = 20 + getExtraHP();
                }
            }
        }
    }

    @Inject(method = "tick", at = @At("TAIL"))
    public void tick(CallbackInfo ci) {
        C_40996800 player = (C_40996800) ((Object) this);
        for (int i = 0; i < player.f_29439708.f_52412003.length; i++) {
            C_88708284 item = player.f_29439708.f_52412003[i];
            if (item != null) {
                if (item.m_23235460() instanceof TickableInArmorSlot tickable) {
                    var newItem = tickable.tickWhileWorn(player, item);
                    if (newItem != item) {
                        player.f_29439708.f_52412003[i] = newItem;
                    }
                }
            }
        }

        AccessoryInventory accessories = getAccessoryInventory();
        for (int i = 0; i < accessories.m_54518913(); i++) {
            C_88708284 item = accessories.m_87969967(i);
            if (item != null) {
                if (item.m_23235460() instanceof TickableInArmorSlot tickable) {
                    var newItem = tickable.tickWhileWorn(player, item);
                    if (newItem != item) {
                        accessories.replaceStack(i, newItem);
                    }
                }
            }
        }
    }

    @Inject(method = "onKilledBy", at = @At("TAIL"))
    public void accessoryapi$dropAccessoriesOnDeath(C_42232651 adversary, CallbackInfo ci) {
        // Mirrors inventory.dropInventory() in this method: scatter the accessories too.
        // Note ServerPlayerEntity.onKilledBy does NOT call super — it has its own hook.
        getAccessoryInventory().dropAll();
        if (!this.f_94306729.f_50876584) {
            // persist immediately: items are gone, ExtraHP stays for the respawned player
            AccessoryPersistence.save((C_40996800) (Object) this);
        }
    }

    @Inject(method = "writeNbt", at = @At("HEAD"))
    public void writeCustomDataToTag(C_74087615 tag, CallbackInfo ci) {
        tag.m_20318863("ExtraHP", getExtraHP());
        // Piggyback on every vanilla player save (level.dat in singleplayer,
        // players/<name>.dat on servers) to write our separate accessory file.
        if (!this.f_94306729.f_50876584 && accessoryapi$persistentDataLoaded) {
            AccessoryPersistence.save((C_40996800) (Object) this);
        }
    }

    @Inject(method = "readNbt", at = @At("HEAD"))
    public void readCustomDataFromTag(C_74087615 tag, CallbackInfo ci) {
        // saved data applied -> this is a world load/join, not a fresh respawn
        accessoryapi$nbtApplied = true;
        // Legacy fallback — the accessories file (loaded on first tick) takes precedence.
        if (tag.m_97612750("ExtraHP")) {
            setExtraHP(tag.m_35587574("ExtraHP"));
        } else {
            setExtraHP(0);
        }
    }

    @Inject(method = "tickMovement", at = @At("HEAD"))
    public void updateDespawnCounter(CallbackInfo ci) {
        if (this.f_94306729.f_91285239 == 0 && (this.f_05442563 >= 20 && this.f_05442563 < 20 + getExtraHP()) && this.f_41909716 % 20 * 12 == 0) {
            this.f_05442563 += 1;
            this.f_02385719 = this.f_64952793 / 2;
        }
    }

    @Inject(method = "initDataTracker", at = @At("TAIL"))
    public void initDataTracker(CallbackInfo ci)
    {
        this.f_88296653.m_94812360(31, (int)0);
    }

    public int getExtraHP() {
        return this.f_88296653.m_09089969(31);
    }

    public void setExtraHP(int extraHP) {
        this.f_88296653.m_52395024(31, extraHP);
        if (f_05442563 > 20 + extraHP)
        {
            f_05442563 = 20 + extraHP;
        }
    }

    public void addExtraHP(int extraHP) {
        setExtraHP(getExtraHP() + extraHP);
    }

    @Override
    public void setInvisible(boolean invisible)
    {
        // setFlag
        m_95740281(7, invisible);
    }

    @Override
    public boolean isInvisible()
    {
        // isFlagSet
        return m_31730897(7);
    }
}
