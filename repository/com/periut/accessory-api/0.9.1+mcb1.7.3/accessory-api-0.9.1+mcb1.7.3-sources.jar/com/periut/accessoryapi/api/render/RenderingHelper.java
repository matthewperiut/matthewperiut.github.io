package com.periut.accessoryapi.api.render;

import com.periut.accessoryapi.impl.mixin.client.LivingEntityRendererAccessor;
import net.minecraft.unmapped.C_34859172;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_82280655;
import net.minecraft.unmapped.C_88708284;
import org.lwjgl.opengl.GL11;

public class RenderingHelper {
    public static void beforeBiped(C_40996800 player, C_34859172 playerRenderer, C_82280655 model, double x, double y, double z, float h, float v) {
        final C_88708284 itemStack = player.m_01577449();
        model.f_43650389 = (itemStack != null);
        model.f_60604394 = player.m_40164672();
        double d3 = y - player.f_85480687;

        GL11.glPushMatrix();
        GL11.glEnable(2884);
        model.f_48140049 = ((LivingEntityRendererAccessor) playerRenderer).invoke820(player, v);
        model.f_12948580 = player.m_38054694();
        final float f2 = player.f_14416847 + (player.f_21972499 - player.f_14416847) * v;
        final float f3 = player.f_74900774 + (player.f_80130373 - player.f_74900774) * v;
        final float f4 = player.f_45219594 + (player.f_03549461 - player.f_45219594) * v;
        ((LivingEntityRendererAccessor) playerRenderer).invoke826(player, x, d3, z);
        final float f5 = ((LivingEntityRendererAccessor) playerRenderer).invoke828(player, v);
        ((LivingEntityRendererAccessor) playerRenderer).invoke824(player, f5, f2, v);
        final float f6 = 0.0625f;
        GL11.glEnable(32826);
        GL11.glScalef(-1.0f, -1.0f, 1.0f);
        ((LivingEntityRendererAccessor) playerRenderer).invoke823(player, v);
        GL11.glTranslatef(0.0f, -24.0f * f6 - 0.0078125f, 0.0f);
        float f7 = Math.min(player.f_47083104 + (player.f_18020014 - player.f_47083104) * v, 1.0f);
        final float f8 = player.f_00715684 - player.f_18020014 * (1.0f - v);
        GL11.glEnable(3008);
        model.m_42818616(f8, f7, f5, f3 - f2, f4, f6);
    }

    public static void afterBiped(C_82280655 model) {
        GL11.glDisable(3042);
        GL11.glDisable(32826);

        GL11.glPopMatrix();
        model.f_60604394 = false;
        model.f_43650389 = false;
    }
}
