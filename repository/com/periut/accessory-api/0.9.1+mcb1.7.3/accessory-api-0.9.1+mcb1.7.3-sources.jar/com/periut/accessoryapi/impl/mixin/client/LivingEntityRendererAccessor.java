package com.periut.accessoryapi.impl.mixin.client;

import net.minecraft.unmapped.C_71252617;
import net.minecraft.unmapped.C_74425583;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_71252617.class)
public interface LivingEntityRendererAccessor {
    @Invoker("getHeadBob")
    float invoke828(C_74425583 living, float f);

    @Invoker("getHandSwingProgress")
    float invoke820(C_74425583 living, float f);

    @Invoker("applyTranslation")
    void invoke826(C_74425583 arg, double d, double d1, double d2);

    @Invoker("applyHandSwingRotation")
    void invoke824(C_74425583 arg, float f, float f1, float f2);

    @Invoker("applyScale")
    void invoke823(C_74425583 living, float f);
}
