package com.periut.retroapi.mixin.storage;

import com.periut.retroapi.storage.ChunkExtendedBlocks;
import com.periut.retroapi.storage.ExtendedBlocksAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;
import java.util.Random;
import java.util.Set;
import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_97313606;

@Mixin(C_64041439.class)
public abstract class WorldMixin {

	@Shadow
	public Random random;

	@Shadow
	private Set<C_97313606> activeChunks;

	@Shadow
	public abstract C_14917579 getChunk(int chunkX, int chunkZ);


	@ModifyConstant(method = "setBlockMeta(IIII)V", constant = @Constant(intValue = 255))
	private int retroapi$widenUpdateClientsIndex(int original) {
		return 0xFFF;
	}

	@Inject(method = "manageChunkUpdatesAndEvents", at = @At("TAIL"))
	private void retroapi$tickExtendedBlocks(CallbackInfo ci) {
		// Vanilla random-ticks 80 positions per chunk from 32768 total (16*16*128).
		// For each extended block with TICKS_RANDOMLY, give it the same probability: 80/32768.
		//
		// Two-phase: collect the positions that win the roll first, THEN tick them. onTick
		// handlers mutate the extended-block maps (grass spread, sapling growth, torch state),
		// including across chunk borders, so iterating the live maps while ticking throws
		// ConcurrentModificationException.
		java.util.ArrayList<int[]> due = null;
		for (C_97313606 pos : activeChunks) {
			C_14917579 chunk = getChunk(pos.f_77181208, pos.f_93738510);
			if (chunk == null) continue;

			ChunkExtendedBlocks ext = ((ExtendedBlocksAccess) chunk).retroapi$getExtendedBlocks();
			if (ext.isEmpty()) continue;

			int worldX = pos.f_77181208 * 16;
			int worldZ = pos.f_93738510 * 16;

			for (Map.Entry<Integer, Integer> entry : ext.getBlockIds().entrySet()) {
				int blockId = entry.getValue();
				if (blockId <= 0 || blockId >= C_81592558.f_08006312.length) continue;
				if (!C_81592558.f_08006312[blockId]) continue;

				// 80/32768 ~ 0.00244 chance per tick, matching vanilla random tick rate
				if (random.nextInt(32768) >= 80) continue;

				int index = entry.getKey();
				if (due == null) due = new java.util.ArrayList<>();
				due.add(new int[]{
					worldX + ChunkExtendedBlocks.indexToX(index),
					ChunkExtendedBlocks.indexToY(index),
					worldZ + ChunkExtendedBlocks.indexToZ(index)
				});
			}
		}

		if (due != null) {
			C_64041439 self = (C_64041439) (Object) this;
			for (int[] p : due) {
				// Re-resolve: an earlier tick in this batch may have replaced the block.
				int blockId = self.m_33234383(p[0], p[1], p[2]);
				if (blockId <= 0 || blockId >= C_81592558.f_08006312.length) continue;
				if (!C_81592558.f_08006312[blockId]) continue;
				C_81592558 block = C_81592558.f_44428008[blockId];
				if (block != null) {
					block.m_56075420(self, p[0], p[1], p[2], random);
				}
			}
		}
	}
}

