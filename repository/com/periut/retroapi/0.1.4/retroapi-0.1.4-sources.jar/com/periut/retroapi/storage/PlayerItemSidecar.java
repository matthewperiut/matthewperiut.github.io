package com.periut.retroapi.storage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_79370641;

/**
 * Sidecar for modded items in PLAYER inventories ({@code retroapi/player_items.dat}) — the same
 * architecture as chest inventories: modded stacks are stripped OUT of the vanilla player NBT on
 * save and injected back on load (same slot if free, else next free slot). Vanilla never sees the
 * entries at all, so a vanilla open/save round-trip cannot cull or strip them (vanilla deletes
 * count-0 ghost stacks and drops unknown NBT keys from item compounds — which is exactly how the
 * old in-place {@code retroapi:id} stamps died).
 *
 * <p>Per player: a {@code players} {@link C_79370641} of {@code {name, items}} where {@code items} is
 * a list of {@code {Slot, id (string identifier), Count, Damage}}. Items whose mod is currently
 * missing stay recorded (via the {@code leftover} RAM map, merged back in at the next save) and
 * restore when the mod returns. Root is RAM-cached; persisted through {@link SidecarIo}.
 */
public class PlayerItemSidecar {
	private static final Logger LOGGER = LogManager.getLogger("RetroAPI/PlayerItemSidecar");

	private static C_74087615 cachedRoot;
	private static File cachedFile;

	/**
	 * Items that could not be restored at load time (mod removed, or no free slot). PEEKED — never
	 * removed — by {@link #recordItems} so they survive every subsequent save until restorable.
	 */
	private static final Map<String, C_79370641> leftover = new HashMap<>();

	/** Drop all RAM state (world switch — called from {@code SidecarManager.flush}). */
	public static void reset() {
		cachedRoot = null;
		cachedFile = null;
		leftover.clear();
	}

	private static File file() {
		File worldDir = SidecarManager.getWorldDir();
		return worldDir == null ? null : new File(worldDir, "retroapi/player_items.dat");
	}

	/** Whether the sidecar can be used right now (a RetroAPI world is open). */
	public static boolean isAvailable() {
		return file() != null;
	}

	private static C_74087615 root(File f) {
		if (cachedRoot != null && f.equals(cachedFile)) {
			return cachedRoot;
		}
		C_74087615 root = new C_74087615();
		if (f.exists()) {
			try (FileInputStream fis = new FileInputStream(f)) {
				root = C_08565163.m_38706312(fis);
			} catch (IOException e) {
				LOGGER.error("Failed to read {}", f, e);
			}
		}
		cachedRoot = root;
		cachedFile = f;
		return root;
	}

	/**
	 * Record (replacing any prior record) the modded items stripped from a player's inventory NBT.
	 * Unrestorable leftovers noted at load time are merged in so they are never dropped.
	 */
	public static void recordItems(String name, C_79370641 items) {
		File f = file();
		if (f == null) return;
		C_79370641 pending = leftover.get(name);
		if (pending != null) {
			for (int i = 0; i < pending.m_89439680(); i++) {
				items.m_43125067(pending.m_59132367(i));
			}
		}
		C_74087615 root = root(f);
		C_79370641 players = without(root, name);
		if (items.m_89439680() > 0) {
			C_74087615 entry = new C_74087615();
			entry.m_91017064("name", name);
			entry.m_21770494("items", items);
			players.m_43125067(entry);
		}
		root.m_21770494("players", players);
		persist(f, root);
	}

	/** The recorded modded items for a player, or {@code null} if none. */
	public static C_79370641 getItems(String name) {
		File f = file();
		if (f == null) return null;
		C_74087615 root = root(f);
		if (!root.m_97612750("players")) return null;
		C_79370641 players = root.m_95654166("players");
		for (int i = 0; i < players.m_89439680(); i++) {
			C_74087615 entry = (C_74087615) players.m_59132367(i);
			if (name.equals(entry.m_47517355("name"))) {
				return entry.m_95654166("items");
			}
		}
		return null;
	}

	/** Note items that could not be restored this load; kept until a future load can place them. */
	public static void setLeftover(String name, C_79370641 items) {
		if (items == null || items.m_89439680() == 0) {
			leftover.remove(name);
		} else {
			leftover.put(name, items);
		}
	}

	private static C_79370641 without(C_74087615 root, String excludeName) {
		C_79370641 result = new C_79370641();
		if (root.m_97612750("players")) {
			C_79370641 players = root.m_95654166("players");
			for (int i = 0; i < players.m_89439680(); i++) {
				C_74087615 entry = (C_74087615) players.m_59132367(i);
				if (!excludeName.equals(entry.m_47517355("name"))) {
					result.m_43125067(entry);
				}
			}
		}
		return result;
	}

	private static void persist(File f, C_74087615 root) {
		try {
			SidecarIo.writeAsync(f, SidecarIo.snapshot(root));
		} catch (IOException e) {
			LOGGER.error("Failed to snapshot {}", f, e);
		}
	}
}
