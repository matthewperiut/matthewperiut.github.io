package com.periut.retroapi.biome;

import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_74918097;

/**
 * A modded biome. Extending {@link C_28105876} is the cleanest way to populate it: the base constructor
 * seeds the vanilla default spawns (spider/zombie/sheep/…) into the protected spawn lists, which a
 * modded biome almost never wants — so this clears them and lets {@link BiomeBuilder} add exactly the
 * modded spawns. Subclassing also grants access to the protected spawn lists.
 */
public class RetroBiome extends C_28105876 {
	public RetroBiome() {
		super();
		this.f_40051390.clear();
		this.f_03514753.clear();
		this.f_03244403.clear();
	}

	public void addPassive(Class<? extends C_74425583> entityClass, int weight) {
		this.f_03514753.add(new C_74918097(entityClass, weight));
		com.periut.retroapi.entity.RetroSpawnGroups.assign(entityClass, net.minecraft.unmapped.C_70943525.f_66562489);
	}

	public void addMonster(Class<? extends C_74425583> entityClass, int weight) {
		this.f_40051390.add(new C_74918097(entityClass, weight));
		com.periut.retroapi.entity.RetroSpawnGroups.assign(entityClass, net.minecraft.unmapped.C_70943525.f_16930340);
	}

	public void addWaterCreature(Class<? extends C_74425583> entityClass, int weight) {
		this.f_03244403.add(new C_74918097(entityClass, weight));
		com.periut.retroapi.entity.RetroSpawnGroups.assign(entityClass, net.minecraft.unmapped.C_70943525.f_39257944);
	}
}
