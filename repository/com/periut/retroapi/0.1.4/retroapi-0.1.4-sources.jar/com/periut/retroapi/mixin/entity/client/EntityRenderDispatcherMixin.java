package com.periut.retroapi.mixin.entity.client;

import com.periut.retroapi.entity.client.RetroEntityRenderers;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Collection;
import java.util.Map;
import net.minecraft.unmapped.C_32232284;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_53593123;

/**
 * Wires modded entity renderers into the dispatcher's renderer map. Redirects the single
 * {@code this.renderers.values()} call in {@code <init>} (one call site, so no brittle ordinal like
 * StationAPI's): flush RetroAPI-registered renderers into the map, then return {@code values()} — so
 * vanilla's following {@code setDispatcher(this)} loop iterates and wires vanilla + modded renderers
 * alike. Disabled when StationAPI is present (its EntityRendererRegisterEvent owns this).
 */
@Mixin(C_32232284.class)
public class EntityRenderDispatcherMixin {
	@Redirect(
		method = "<init>",
		at = @At(value = "INVOKE", target = "Ljava/util/Map;values()Ljava/util/Collection;")
	)
	private Collection<C_53593123<? extends C_42232651>> retroapi$registerModdedRenderers(
			Map<Class<? extends C_42232651>, C_53593123<? extends C_42232651>> renderers) {
		RetroEntityRenderers.applyTo(renderers);
		return renderers.values();
	}
}
