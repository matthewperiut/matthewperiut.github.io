package com.periut.retroapi.mixin.register;

import com.periut.retroapi.registry.RetroRegistry;
import com.periut.retroapi.storage.PlayerItemSidecar;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_79370641;
import net.minecraft.unmapped.C_98888256;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Player-inventory leg of the sidecar architecture: modded stacks are stripped OUT of the vanilla
 * {@code Inventory} NBT on save ({@code writeNbt} TAIL — the {@code retroapi:id} stamps that
 * {@code ItemStackMixin} wrote identify them) and injected back INTO the list on load
 * ({@code readNbt} HEAD, before vanilla parses it) — same slot if free, else the next free main
 * slot; items whose mod is missing (or with no free slot) stay in the sidecar for a later load.
 *
 * <p>Same embed-into-loading philosophy as {@code PlayerDimensionMixin}: vanilla's own code paths
 * parse the restored entries, so behavior is exactly as if they had always been in the file. The
 * in-place {@code retroapi:id} stamps alone were not vanilla-proof for player inventories: vanilla
 * play culls count-0 ghost stacks and vanilla saves drop the custom keys, destroying the items.
 * Old saves with in-place stamps still load (ItemStackMixin resolves them) and migrate to the
 * sidecar on their first save here.
 *
 * <p>Disabled under StationAPI (it owns item flattening there).
 */
@Mixin(C_40996800.class)
public class PlayerInventorySidecarMixin {
	private static final int MAIN_SIZE = 36;
	private static final int ARMOR_BASE = 100;
	private static final int ARMOR_SIZE = 4;

	@Inject(method = "writeNbt", at = @At("TAIL"))
	private void retroapi$stripModdedItems(C_74087615 nbt, CallbackInfo ci) {
		if (!PlayerItemSidecar.isAvailable()) return;
		C_40996800 self = (C_40996800) (Object) this;
		C_79370641 inventory = nbt.m_95654166("Inventory");
		if (inventory == null) return;

		C_79370641 kept = new C_79370641();
		C_79370641 modded = new C_79370641();
		for (int i = 0; i < inventory.m_89439680(); i++) {
			C_74087615 entry = (C_74087615) inventory.m_59132367(i);
			if (entry.m_97612750("retroapi:id")) {
				C_74087615 m = new C_74087615();
				m.m_41884431("Slot", entry.m_84056038("Slot"));
				m.m_91017064("id", entry.m_47517355("retroapi:id"));
				m.m_41884431("Count", entry.m_97612750("retroapi:count")
						? entry.m_84056038("retroapi:count") : entry.m_84056038("Count"));
				m.m_98335007("Damage", entry.m_97612750("retroapi:damage")
						? entry.m_03599456("retroapi:damage") : entry.m_03599456("Damage"));
				// Carry the item's data components through the sidecar too.
				if (entry.m_97612750("retroapi:components")) {
					m.m_18682924("retroapi:components", entry.m_81819352("retroapi:components"));
				}
				modded.m_43125067(m);
			} else {
				kept.m_43125067(entry);
			}
		}

		nbt.m_21770494("Inventory", kept);
		// Always record — an empty list clears the player's entry (items were dropped/used up),
		// and recordItems merges in any load-time leftovers so they survive.
		PlayerItemSidecar.recordItems(self.f_59008391, modded);
	}

	@Inject(method = "readNbt", at = @At("HEAD"))
	private void retroapi$injectModdedItems(C_74087615 nbt, CallbackInfo ci) {
		C_40996800 self = (C_40996800) (Object) this;
		C_79370641 recorded = PlayerItemSidecar.getItems(self.f_59008391);
		if (recorded == null || recorded.m_89439680() == 0) return;

		C_79370641 inventory = nbt.m_95654166("Inventory");
		if (inventory == null) {
			inventory = new C_79370641();
		}

		// Occupancy from the entries already in the vanilla list.
		boolean[] mainTaken = new boolean[MAIN_SIZE];
		boolean[] armorTaken = new boolean[ARMOR_SIZE];
		for (int i = 0; i < inventory.m_89439680(); i++) {
			int slot = ((C_74087615) inventory.m_59132367(i)).m_84056038("Slot") & 255;
			if (slot < MAIN_SIZE) {
				mainTaken[slot] = true;
			} else if (slot >= ARMOR_BASE && slot < ARMOR_BASE + ARMOR_SIZE) {
				armorTaken[slot - ARMOR_BASE] = true;
			}
		}

		C_79370641 leftover = new C_79370641();
		for (int i = 0; i < recorded.m_89439680(); i++) {
			C_74087615 m = (C_74087615) recorded.m_59132367(i);
			C_98888256 item = RetroRegistry.getItemByStringId(m.m_47517355("id"));
			if (item == null) {
				// Mod currently missing — keep for a future load.
				leftover.m_43125067(m);
				continue;
			}

			// Original slot if free, else the next free main slot.
			int desired = m.m_84056038("Slot") & 255;
			int target = -1;
			if (desired < MAIN_SIZE && !mainTaken[desired]) {
				target = desired;
			} else if (desired >= ARMOR_BASE && desired < ARMOR_BASE + ARMOR_SIZE && !armorTaken[desired - ARMOR_BASE]) {
				target = desired;
			} else {
				for (int s = 0; s < MAIN_SIZE; s++) {
					if (!mainTaken[s]) {
						target = s;
						break;
					}
				}
			}
			if (target == -1) {
				// Inventory full of vanilla items — keep for a future load.
				leftover.m_43125067(m);
				continue;
			}
			if (target < MAIN_SIZE) {
				mainTaken[target] = true;
			} else {
				armorTaken[target - ARMOR_BASE] = true;
			}

			C_74087615 entry = new C_74087615();
			entry.m_41884431("Slot", (byte) target);
			entry.m_98335007("id", (short) item.f_57562535);
			entry.m_41884431("Count", m.m_84056038("Count"));
			entry.m_98335007("Damage", m.m_03599456("Damage"));
			// Re-attach components so ItemStack.readNbt restores them on load.
			if (m.m_97612750("retroapi:components")) {
				entry.m_18682924("retroapi:components", m.m_81819352("retroapi:components"));
			}
			inventory.m_43125067(entry);
		}

		nbt.m_21770494("Inventory", inventory);
		PlayerItemSidecar.setLeftover(self.f_59008391, leftover);
	}
}
