package com.periut.retroapi.world;

import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_64041439;

/**
 * The block-storage strategy behind {@link RetroWorldGen}: how a custom chunk generator builds a chunk and
 * places blocks in it. Chosen ONCE at class load (RetroAPI's vanilla legacy model, or StationAPI's flattened
 * model) and held in a {@code static final} field, so the generation calls are a single devirtualized +
 * inlined call with no StationAPI branch — mirroring the rendering atlas strategy. Being an interface also
 * keeps the StationAPI-referencing implementation off the verifier's radar until it is actually instantiated.
 */
interface ChunkGenBackend {
	C_14917579 createChunk(C_64041439 world, byte[] vanillaBlocks, int chunkX, int chunkZ);

	void setBlock(C_14917579 chunk, int x, int y, int z, int blockId, int meta);
}
