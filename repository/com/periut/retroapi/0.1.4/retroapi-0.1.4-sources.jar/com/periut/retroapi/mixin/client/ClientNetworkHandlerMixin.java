package com.periut.retroapi.mixin.client;

import com.llamalad7.mixinextras.sugar.Local;
import com.periut.retroapi.component.ComponentWire;
import com.periut.retroapi.component.SpawnComponentCarrier;
import com.periut.retroapi.network.BlocksUpdatePacketAccess;
import com.periut.retroapi.storage.ChunkExtendedBlocks;
import com.periut.retroapi.storage.ExtendedBlocksAccess;
import net.minecraft.unmapped.C_06774341;
import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_34399650;
import net.minecraft.unmapped.C_36877109;
import net.minecraft.unmapped.C_62858513;
import net.minecraft.unmapped.C_88014908;
import net.minecraft.unmapped.C_91508932;
import com.periut.retroapi.network.WorldChunkPacketAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_88014908.class)
public class ClientNetworkHandlerMixin {

	@Shadow private C_34399650 world;

	/**
	 * Apply the dropped item's component blob once the client has rebuilt its stack. The
	 * spawn packet carried the blob (see ItemEntitySpawnComponentMixin); here the freshly
	 * constructed ItemEntity is the local the handler just made, and its stack gets the
	 * components so things like the Mood Gem's texture render correctly on the ground.
	 */
	@Inject(method = "onItemEntitySpawn", at = @At("TAIL"))
	private void retroapi$applyDroppedItemComponents(C_91508932 packet, CallbackInfo ci,
			@Local C_06774341 entity) {
		ComponentWire.applyBlob(entity.f_15367317, ((SpawnComponentCarrier) packet).retroapi$spawnComponents());
	}

	@Inject(method = "onChunkDeltaUpdate", at = @At("HEAD"), cancellable = true)
	private void retroapi$handleBlocksUpdate(C_36877109 packet, CallbackInfo ci) {
		short[] fullBlockIds = ((BlocksUpdatePacketAccess) packet).retroapi$getFullBlockIds();
		if (fullBlockIds == null) return; // fallback to vanilla if no extended data

		C_14917579 chunk = world.m_27928573(packet.f_79481286, packet.f_86949888);
		int baseX = packet.f_79481286 * 16;
		int baseZ = packet.f_86949888 * 16;

		for (int i = 0; i < packet.f_01960917; i++) {
			short pos = packet.f_04903120[i];
			int localX = pos >> 12 & 15;
			int localZ = pos >> 8 & 15;
			int y = pos & 255;
			int blockId = fullBlockIds[i] & 0xFFFF;
			int meta = packet.f_91311726[i];

			chunk.m_09335939(localX, y, localZ, blockId, meta);
			world.m_67579540(
				localX + baseX, y, localZ + baseZ,
				localX + baseX, y, localZ + baseZ
			);
			world.m_76770021(
				localX + baseX, y, localZ + baseZ,
				localX + baseX, y, localZ + baseZ
			);
		}

		ci.cancel();
	}

	@Inject(method = "handleChunkData", at = @At("RETURN"))
	private void retroapi$afterHandleWorldChunk(C_62858513 packet, CallbackInfo ci) {
		WorldChunkPacketAccess access = (WorldChunkPacketAccess) packet;
		int[] xPositions = access.retroapi$getXmetaPositions();
		if (access.retroapi$getExtCount() == 0 && xPositions == null) return;

		int chunkX = packet.f_05662346 >> 4;
		int chunkZ = packet.f_77394700 >> 4;
		C_14917579 chunk = world.m_27928573(chunkX, chunkZ);
		if (chunk == null) return;

		ChunkExtendedBlocks extended = ((ExtendedBlocksAccess) chunk).retroapi$getExtendedBlocks();
		int[] indices = access.retroapi$getExtIndices();
		int[] blockIds = access.retroapi$getExtBlockIds();
		int[] meta = access.retroapi$getExtMeta();

		for (int i = 0; i < access.retroapi$getExtCount(); i++) {
			extended.set(indices[i], blockIds[i], meta[i]);
		}

		// Secondary meta (state index bits 4-11) rides the same packet.
		if (xPositions != null) {
			int[] xValues = access.retroapi$getXmetaValues();
			for (int i = 0; i < xPositions.length; i++) {
				extended.setXmeta(xPositions[i], xValues[i]);
			}
		}

		// Fix the heightmap now that extended blocks are loaded — but ONLY the heightmap.
		// populateHeightMap (full variant) rewrote the sky-light columns from the air-masked raw
		// arrays, clobbering the authoritative light the server sent in the vanilla chunk packet —
		// blocks flashed bright in dark spaces until client-side updates converged them back.
		chunk.m_71750474();

		// Re-render the chunk
		int baseX = chunkX * 16;
		int baseZ = chunkZ * 16;
		world.m_76770021(baseX, 0, baseZ, baseX + 15, 127, baseZ + 15);
	}
}
