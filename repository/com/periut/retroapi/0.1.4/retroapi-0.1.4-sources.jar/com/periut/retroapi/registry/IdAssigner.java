package com.periut.retroapi.registry;

import com.periut.retroapi.dimension.DimensionRegistration;
import com.periut.retroapi.dimension.RetroDimensionRegistry;
import com.periut.retroapi.mixin.register.FireBlockAccessor;
import net.minecraft.unmapped.C_71827890;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_98888256;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;
import net.ornithemc.osl.core.api.util.NamespacedIdentifiers;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import net.ornithemc.osl.networking.api.PacketBuffer;

import java.io.File;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class IdAssigner {
	private static final Logger LOGGER = LogManager.getLogger("RetroAPI/IdAssigner");

	public static void assignIds(File worldDir) {
		File idMapFile = new File(worldDir, "retroapi/id_map.dat");
		IdMap idMap = new IdMap();
		idMap.load(idMapFile);

		// Purge stale entries for blocks/items no longer registered
		idMap.purgeStaleEntries(RetroRegistry.getBlocks(), RetroRegistry.getItems());

		assignBlockIds(idMap);
		assignItemIds(idMap);
		assignDimensionIds(idMap);

		idMap.save(idMapFile);
	}

	public static void saveCurrentIds(File worldDir) {
		File idMapFile = new File(worldDir, "retroapi/id_map.dat");
		// Load first so the existing (stable) dimension serial ids are preserved across reopen — the
		// DIM<n>/ folders and player-NBT ids depend on them. Block/item ids are then refreshed from the
		// current (StationAPI-managed) registry state.
		IdMap idMap = new IdMap();
		idMap.load(idMapFile);

		for (BlockRegistration reg : RetroRegistry.getBlocks()) {
			idMap.putBlockId(reg.getId(), reg.getBlock().f_84602679);
		}
		for (ItemRegistration reg : RetroRegistry.getItems()) {
			idMap.putItemId(reg.getId(), reg.getItem().f_57562535);
		}
		assignDimensionIds(idMap);

		idMap.save(idMapFile);
		LOGGER.info("Saved current ID map for {} blocks, {} items and {} dimensions",
			RetroRegistry.getBlocks().size(), RetroRegistry.getItems().size(), RetroDimensionRegistry.getAll().size());
	}

	/**
	 * Assign each registered modded dimension a STABLE serial id (persisted in the id_map "dimensions"
	 * section, reused across reopen) and write it back onto the {@link DimensionRegistration}. Serial
	 * ids start at 2 (vanilla -1/0/1 reserved). Stale (mod-removed) entries are purged. This runs in
	 * both the StationAPI and non-StationAPI save paths so the dimension identifier->id map always
	 * exists on disk for datafixer world conversions.
	 */
	private static void assignDimensionIds(IdMap idMap) {
		java.util.List<DimensionRegistration> dimensions = RetroDimensionRegistry.getAll();
		if (dimensions.isEmpty()) return;

		Set<NamespacedIdentifier> active = new HashSet<>();
		for (DimensionRegistration reg : dimensions) {
			active.add(reg.getId());
		}
		idMap.getDimensionIds().keySet().removeIf(id -> !active.contains(id));

		Set<Integer> used = new HashSet<>(idMap.getDimensionIds().values());
		for (DimensionRegistration reg : dimensions) {
			Integer existing = idMap.getDimensionId(reg.getId());
			int serialId;
			if (existing != null) {
				serialId = existing;
			} else {
				serialId = findFreeDimensionId(used);
				used.add(serialId);
				idMap.putDimensionId(reg.getId(), serialId);
			}
			reg.setSerialId(serialId);
		}
	}

	private static int findFreeDimensionId(Set<Integer> used) {
		int id = 2;
		while (used.contains(id)) id++;
		return id;
	}

	private static void assignBlockIds(IdMap idMap) {
		C_81592558[] byId = C_81592558.f_44428008;
		Set<Integer> usedIds = new HashSet<>();

		// Collect all currently used vanilla block IDs
		for (int i = 0; i < byId.length; i++) {
			if (byId[i] != null) {
				boolean isRetroBlock = false;
				for (BlockRegistration reg : RetroRegistry.getBlocks()) {
					if (reg.getBlock() == byId[i]) {
						isRetroBlock = true;
						break;
					}
				}
				if (!isRetroBlock) {
					usedIds.add(i);
				}
			}
		}

		// Also mark IDs already assigned in the map as used
		for (int id : idMap.getBlockIds().values()) {
			usedIds.add(id);
		}

		for (BlockRegistration reg : RetroRegistry.getBlocks()) {
			C_81592558 block = reg.getBlock();
			int currentId = block.f_84602679;
			Integer mappedId = idMap.getBlockId(reg.getId());

			int targetId;
			if (mappedId != null) {
				targetId = mappedId;
			} else {
				// Assign new ID
				targetId = findFreeBlockId(usedIds);
				idMap.putBlockId(reg.getId(), targetId);
				usedIds.add(targetId);
			}

			if (currentId != targetId) {
				remapBlock(reg, currentId, targetId);
			}
		}
	}

	private static void assignItemIds(IdMap idMap) {
		C_98888256[] byId = C_98888256.f_38445253;
		Set<Integer> usedIds = new HashSet<>();

		// Collect all currently used vanilla item IDs (raw, including the +256 offset)
		for (int i = 256; i < byId.length; i++) {
			if (byId[i] != null) {
				boolean isRetroItem = false;
				for (ItemRegistration reg : RetroRegistry.getItems()) {
					if (reg.getItem() == byId[i]) {
						isRetroItem = true;
						break;
					}
				}
				if (!isRetroItem) {
					usedIds.add(i);
				}
			}
		}

		for (int id : idMap.getItemIds().values()) {
			usedIds.add(id);
		}

		for (ItemRegistration reg : RetroRegistry.getItems()) {
			C_98888256 item = reg.getItem();
			int currentId = item.f_57562535;
			Integer mappedId = idMap.getItemId(reg.getId());

			int targetId;
			if (mappedId != null) {
				targetId = mappedId;
			} else {
				targetId = findFreeItemId(usedIds);
				idMap.putItemId(reg.getId(), targetId);
				usedIds.add(targetId);
			}

			if (currentId != targetId) {
				remapItem(item, currentId, targetId);
			}

			LOGGER.info("Assigned item {} -> ID {}", reg.getId(), targetId);
		}
	}

	private static int findFreeBlockId(Set<Integer> usedIds) {
		C_98888256[] itemById = C_98888256.f_38445253;
		// Start at 256 to keep all RetroAPI blocks in extended storage range
		for (int i = 256; i < C_81592558.f_44428008.length; i++) {
			if (!usedIds.contains(i) && (i >= itemById.length || itemById[i] == null || itemById[i] instanceof C_71827890)) {
				return i;
			}
		}
		throw new RuntimeException("No free block IDs available");
	}

	private static int findFreeItemId(Set<Integer> usedIds) {
		// Item IDs stored with +256 offset
		for (int i = 2256; i < 32000; i++) {
			if (!usedIds.contains(i)) {
				return i;
			}
		}
		for (int i = 256; i < 2256; i++) {
			if (!usedIds.contains(i)) {
				return i;
			}
		}
		throw new RuntimeException("No free item IDs available");
	}

	public static void growBlockArraysIfNeeded(int minSize) {
		if (minSize < C_81592558.f_44428008.length) return;
		int newSize = C_81592558.f_44428008.length;
		while (newSize <= minSize) newSize *= 2;
		C_81592558.f_44428008 = Arrays.copyOf(C_81592558.f_44428008, newSize);
		C_81592558.f_54870136 = Arrays.copyOf(C_81592558.f_54870136, newSize);
		C_81592558.f_43623251 = Arrays.copyOf(C_81592558.f_43623251, newSize);
		C_81592558.f_64189907 = Arrays.copyOf(C_81592558.f_64189907, newSize);
		C_81592558.f_72646756 = Arrays.copyOf(C_81592558.f_72646756, newSize);
		C_81592558.f_08006312 = Arrays.copyOf(C_81592558.f_08006312, newSize);
		C_81592558.f_31279291 = Arrays.copyOf(C_81592558.f_31279291, newSize);
		C_81592558.f_47406756 = Arrays.copyOf(C_81592558.f_47406756, newSize);
		LOGGER.info("Grew block arrays to size {}", newSize);
	}

	private static void remapBlock(BlockRegistration reg, int oldId, int newId) {
		C_81592558 block = reg.getBlock();
		growBlockArraysIfNeeded(newId);
		C_81592558[] byId = C_81592558.f_44428008;

		// Save values before clearing
		int lightValue = (oldId >= 0 && oldId < C_81592558.f_31279291.length) ? C_81592558.f_31279291[oldId] : 0;
		boolean hasBlockEntity = (oldId >= 0 && oldId < C_81592558.f_72646756.length) && C_81592558.f_72646756[oldId];
		boolean ticksRandomly = (oldId >= 0 && oldId < C_81592558.f_08006312.length) && C_81592558.f_08006312[oldId];
		int[] burnChances = ((FireBlockAccessor) C_81592558.f_48624188).retroapi$getBurnChances();
		int[] spreadChances = ((FireBlockAccessor) C_81592558.f_48624188).retroapi$getSpreadChances();
		int burnChance = (oldId >= 0 && oldId < burnChances.length) ? burnChances[oldId] : 0;
		int spreadChance = (oldId >= 0 && oldId < spreadChances.length) ? spreadChances[oldId] : 0;

		// Clear old slot only if it's actually this block
		if (oldId >= 0 && oldId < byId.length && byId[oldId] == block) {
			byId[oldId] = null;
			C_81592558.f_54870136[oldId] = false;
			C_81592558.f_43623251[oldId] = 0;
			C_81592558.f_64189907[oldId] = false;
			C_81592558.f_72646756[oldId] = false;
			C_81592558.f_08006312[oldId] = false;
			C_81592558.f_31279291[oldId] = 0;
			C_81592558.f_47406756[oldId] = false;
			if (oldId < burnChances.length) burnChances[oldId] = 0;
			if (oldId < spreadChances.length) spreadChances[oldId] = 0;
		}

		// Set new slot
		byId[newId] = block;
		C_81592558.f_54870136[newId] = block.m_57757663();
		C_81592558.f_43623251[newId] = block.m_57757663() ? 255 : 0;
		C_81592558.f_64189907[newId] = !block.f_22724416.m_26110519();
		C_81592558.f_72646756[newId] = hasBlockEntity;
		C_81592558.f_08006312[newId] = ticksRandomly;
		C_81592558.f_31279291[newId] = lightValue;
		// Fire flammability registered via RetroFlammability follows the block to its new id
		if (newId < burnChances.length) burnChances[newId] = burnChance;
		if (newId < spreadChances.length) spreadChances[newId] = spreadChance;

		// Update the block's id field
		block.f_84602679 = newId;

		// Remap the corresponding BlockItem using the registration's stored reference
		C_71827890 blockItem = reg.getBlockItem();
		if (blockItem != null) {
			// Clear old Item.BY_ID slot only if it still points to this block's item
			C_98888256[] itemById = C_98888256.f_38445253;
			if (oldId >= 0 && oldId < itemById.length && itemById[oldId] == blockItem) {
				itemById[oldId] = null;
			}
			itemById[newId] = blockItem;
			blockItem.f_57562535 = newId;
			blockItem.f_03056041 = newId;
		}

		LOGGER.debug("Remapped block {} from {} to {}", reg.getId(), oldId, newId);
	}

	private static void remapItem(C_98888256 item, int oldId, int newId) {
		C_98888256[] byId = C_98888256.f_38445253;

		// Clear old slot
		if (oldId >= 0 && oldId < byId.length && byId[oldId] == item) {
			byId[oldId] = null;
		}

		// Set new slot
		byId[newId] = item;

		// Update the item's id field
		item.f_57562535 = newId;

		LOGGER.debug("Remapped item from {} to {}", oldId, newId);
	}

	public static void applyFromNetwork(PacketBuffer buffer) {
		int blockCount = buffer.readVarInt();
		for (int i = 0; i < blockCount; i++) {
			String identifier = buffer.readString();
			int numericId = buffer.readVarInt();

			String[] parts = identifier.split(":", 2);
			if (parts.length != 2) {
				LOGGER.warn("Invalid block identifier from server: {}", identifier);
				continue;
			}
			NamespacedIdentifier retroId = NamespacedIdentifiers.from(parts[0], parts[1]);
			BlockRegistration reg = RetroRegistry.getBlockById(retroId);
			if (reg == null) {
				LOGGER.warn("Server has unknown block: {} (id {}), skipping", identifier, numericId);
				continue;
			}

			C_81592558 block = reg.getBlock();
			int currentId = block.f_84602679;
			growBlockArraysIfNeeded(numericId);
			if (currentId != numericId) {
				remapBlock(reg, currentId, numericId);
				LOGGER.info("Synced block {} -> ID {} (was {})", identifier, numericId, currentId);
			}
		}

		int itemCount = buffer.readVarInt();
		for (int i = 0; i < itemCount; i++) {
			String identifier = buffer.readString();
			int numericId = buffer.readVarInt();

			String[] parts = identifier.split(":", 2);
			if (parts.length != 2) {
				LOGGER.warn("Invalid item identifier from server: {}", identifier);
				continue;
			}
			NamespacedIdentifier retroId = NamespacedIdentifiers.from(parts[0], parts[1]);
			ItemRegistration reg = RetroRegistry.getItemById(retroId);
			if (reg == null) {
				LOGGER.warn("Server has unknown item: {} (id {}), skipping", identifier, numericId);
				continue;
			}

			C_98888256 item = reg.getItem();
			int currentId = item.f_57562535;
			if (currentId != numericId) {
				remapItem(item, currentId, numericId);
				LOGGER.info("Synced item {} -> ID {} (was {})", identifier, numericId, currentId);
			}
		}
	}
}

