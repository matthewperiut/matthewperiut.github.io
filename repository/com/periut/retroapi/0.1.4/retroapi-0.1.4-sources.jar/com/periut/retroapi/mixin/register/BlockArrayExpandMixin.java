package com.periut.retroapi.mixin.register;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Arrays;
import net.minecraft.unmapped.C_81592558;

@Mixin(C_81592558.class)
public class BlockArrayExpandMixin {
	private static final int EXPANDED_SIZE = 4096;

	@Inject(method = "<clinit>", at = @At("TAIL"))
	private static void retroapi$expandArrays(CallbackInfo ci) {
		if (C_81592558.f_44428008.length < EXPANDED_SIZE) {
			C_81592558.f_44428008 = Arrays.copyOf(C_81592558.f_44428008, EXPANDED_SIZE);
			C_81592558.f_54870136 = Arrays.copyOf(C_81592558.f_54870136, EXPANDED_SIZE);
			C_81592558.f_43623251 = Arrays.copyOf(C_81592558.f_43623251, EXPANDED_SIZE);
			C_81592558.f_64189907 = Arrays.copyOf(C_81592558.f_64189907, EXPANDED_SIZE);
			C_81592558.f_72646756 = Arrays.copyOf(C_81592558.f_72646756, EXPANDED_SIZE);
			C_81592558.f_08006312 = Arrays.copyOf(C_81592558.f_08006312, EXPANDED_SIZE);
			C_81592558.f_31279291 = Arrays.copyOf(C_81592558.f_31279291, EXPANDED_SIZE);
			C_81592558.f_47406756 = Arrays.copyOf(C_81592558.f_47406756, EXPANDED_SIZE);
		}
	}
}

