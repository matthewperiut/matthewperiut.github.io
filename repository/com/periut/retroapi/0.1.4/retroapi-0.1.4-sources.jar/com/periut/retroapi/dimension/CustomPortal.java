package com.periut.retroapi.dimension;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_87391831;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;

/**
 * A portal block that sends a player to a registered modded dimension. Implementors supply the
 * destination identifier, an optional coordinate scale (default 1 — no scaling, unlike vanilla's
 * 8× nether), and the {@link C_87391831} that finds/builds the arrival portal. The default
 * {@link #switchDimension} routes everything through {@link DimensionHelper}. API-compatible with
 * StationAPI's {@code CustomPortal} so a consuming mod (e.g. an Aether portal) barely changes.
 */
public interface CustomPortal extends TeleportationManager {
	NamespacedIdentifier getDimension(C_40996800 player);

	default double getDimensionScale(C_40996800 player) {
		return 1.0;
	}

	C_87391831 getTravelAgent(C_40996800 player);

	@Override
	default void switchDimension(C_40996800 player) {
		DimensionHelper.switchDimension(player, getDimension(player), getDimensionScale(player), getTravelAgent(player));
	}
}
