package com.periut.retroapi.client.dimension;

import com.periut.retroapi.dimension.DimensionTeleporter;
import com.periut.retroapi.dimension.TravelMessageProvider;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_76536438;
import net.minecraft.unmapped.C_87391831;
import net.minecraft.unmapped.C_90532916;

/**
 * Client-side dimension teleport — RetroAPI's own generalisation of vanilla
 * {@code Minecraft.changeDimension} over an arbitrary destination + scale (single-player and the
 * connected-client view). Touches the client-only {@code Minecraft}, so it is only ever
 * referenced/loaded from the client entrypoint ({@code RetroAPIClient}); the dedicated server never
 * loads it.
 */
public final class ClientTeleporter implements DimensionTeleporter {
	@Override
	public void teleport(C_40996800 player, int target, int moddedDim, double coordFactor, C_87391831 agent) {
		Minecraft minecraft = (Minecraft) FabricLoader.getInstance().getGameInstance();
		C_64041439 oldWorld = minecraft.f_26407825;
		player.f_15409937 = target;
		oldWorld.m_28736857(player);
		player.f_42219270 = false;

		double x = player.f_78826675 * coordFactor;
		double z = player.f_97691941 * coordFactor;
		player.m_12877971(x, player.f_31030949, z, player.f_80130373, player.f_03549461);
		if (player.m_48190713()) {
			oldWorld.m_15238577(player, false);
		}

		C_64041439 newWorld = new C_64041439(oldWorld, C_90532916.m_09825512(target));
		minecraft.m_04848709(newWorld, travelMessage(moddedDim, target), player);
		player.f_94306729 = newWorld;

		if (player.m_48190713()) {
			player.m_12877971(x, player.f_31030949, z, player.f_80130373, player.f_03549461);
			newWorld.m_15238577(player, false);
			agent.m_72853764(newWorld, player);
		}
	}

	/** The loading-screen message: the modded dimension supplies a TRANSLATION KEY via {@link TravelMessageProvider}. */
	private static String travelMessage(int moddedDim, int target) {
		C_90532916 modded = C_90532916.m_09825512(moddedDim);
		if (modded instanceof TravelMessageProvider) {
			TravelMessageProvider provider = (TravelMessageProvider) modded;
			boolean entering = (target == moddedDim);
			String key = entering ? provider.getEnteringTranslationKey() : provider.getLeavingTranslationKey();
			// Translate here — setWorld displays the string verbatim. Untranslated keys come back as-is.
			return C_76536438.m_79832914(key);
		}
		return "";
	}
}
