package com.periut.retroapi.compat;

import net.ornithemc.osl.core.api.util.NamespacedIdentifier;
import com.periut.retroapi.registry.BlockRegistration;
import com.periut.retroapi.registry.IdMap;
import com.periut.retroapi.registry.ItemRegistration;
import com.periut.retroapi.registry.RetroRegistry;
import com.periut.retroapi.storage.ChunkExtendedBlocks;
import com.periut.retroapi.storage.RegionSidecar;
import com.periut.retroapi.storage.InventorySidecar;
import net.minecraft.nbt.*;
import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_79370641;
import net.minecraft.unmapped.C_89060550;
import net.modificationstation.stationapi.api.nbt.StationNbtCompound;
import net.modificationstation.stationapi.api.util.collection.PackedIntegerArray;
import net.modificationstation.stationapi.api.vanillafix.datafixer.schema.StationFlatteningItemStackSchema;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.nio.ByteBuffer;
import java.util.*;

/**
 * Second-pass processor that injects RetroAPI sidecar data into StationAPI-converted chunks.
 * Runs after FlattenedWorldStorage.convertChunks() completes.
 */
public class WorldConversionProcessor {
	private static final Logger LOGGER = LogManager.getLogger("RetroAPI/ConversionProcessor");
	private static final String SECTIONS_KEY = "stationapi:sections";
	private static final String STATION_ID = "stationapi:id";

	public static void processSidecars(File worldDir) {
		for (String[] dim : dimensionDirs(worldDir)) processSidecarsForDim(worldDir, dim[0], dim[1]);
	}

	private static void processSidecarsForDim(File worldDir, String regionRel, String sidecarNs) {
		File idMapFile = new File(worldDir, "retroapi/id_map.dat");
		if (!idMapFile.exists()) {
			LOGGER.info("No retroapi/id_map.dat found, skipping sidecar processing");
			return;
		}

		File sidecarChunksDir = new File(worldDir, sidecarNs + "/chunks");
		File sidecarInventoriesDir = new File(worldDir, sidecarNs + "/inventories");
		boolean hasChunkSidecars = sidecarChunksDir.exists() && sidecarChunksDir.isDirectory();
		boolean hasInventorySidecars = sidecarInventoriesDir.exists() && sidecarInventoriesDir.isDirectory();

		if (!hasChunkSidecars && !hasInventorySidecars) {
			LOGGER.info("No sidecar data found, skipping sidecar processing");
			return;
		}

		LOGGER.info("Processing RetroAPI sidecars for {} (region {})", sidecarNs, regionRel);

		// Scan all region files in the world
		File regionDir = new File(worldDir, regionRel);
		if (!regionDir.exists()) {
			LOGGER.warn("No region directory found in {}", worldDir);
			return;
		}

		File[] regionFiles = regionDir.listFiles((dir, name) -> name.endsWith(".mcr"));
		if (regionFiles == null || regionFiles.length == 0) {
			LOGGER.warn("No region files found in {}", regionDir);
			return;
		}

		int processedChunks = 0;
		int modifiedChunks = 0;

		for (File regionFile : regionFiles) {
			// Parse region coordinates from filename: r.X.Z.mcr
			String name = regionFile.getName();
			String[] parts = name.split("\\.");
			if (parts.length != 4) continue;
			int regionX, regionZ;
			try {
				regionX = Integer.parseInt(parts[1]);
				regionZ = Integer.parseInt(parts[2]);
			} catch (NumberFormatException e) {
				continue;
			}

			// Load sidecars for this region
			File chunkSidecarFile = new File(worldDir, sidecarNs + "/chunks/r." + regionX + "." + regionZ + ".dat");
			File invSidecarFile = new File(worldDir, sidecarNs + "/inventories/r." + regionX + "." + regionZ + ".dat");

			C_74087615 chunkSidecarRoot = loadSidecarNbt(chunkSidecarFile);
			C_74087615 invSidecarRoot = loadSidecarNbt(invSidecarFile);

			if (chunkSidecarRoot == null && invSidecarRoot == null) continue;

			C_89060550 region = new C_89060550(regionFile);
			try {
				// Iterate all chunks in the region
				for (int localX = 0; localX < 32; localX++) {
					for (int localZ = 0; localZ < 32; localZ++) {
						int chunkX = regionX * 32 + localX;
						int chunkZ = regionZ * 32 + localZ;

						if (!region.m_06356153(localX, localZ)) continue;

						DataInputStream dis = region.m_88766766(localX, localZ);
						if (dis == null) continue;

						C_74087615 chunkTag;
						try {
							chunkTag = C_08565163.m_07155133(dis);
							dis.close();
						} catch (IOException e) {
							LOGGER.error("Failed to read chunk {},{}", chunkX, chunkZ, e);
							continue;
						}

						processedChunks++;
						boolean modified = false;

						C_74087615 level = chunkTag.m_81819352("Level");
						if (level == null) continue;

						// 1. Inject extended blocks from block sidecar
						if (chunkSidecarRoot != null) {
							modified |= injectExtendedBlocks(level, chunkX, chunkZ, chunkSidecarRoot);
						}

						// 2. Fix retroapi:id items in existing TileEntities and Entities
						modified |= fixRetroApiItems(level);

						// 3. Inject inventory sidecar data
						if (invSidecarRoot != null) {
							modified |= injectInventorySidecar(level, chunkX, chunkZ, invSidecarRoot);
						}

						if (modified) {
							modifiedChunks++;
							try (DataOutputStream dos = region.m_68205534(localX, localZ)) {
								C_08565163.m_94300398(chunkTag, dos);
							} catch (IOException e) {
								LOGGER.error("Failed to write chunk {},{}", chunkX, chunkZ, e);
							}
						}
					}
				}
			} finally {
				try {
					region.m_16177213();
				} catch (IOException e) {
					LOGGER.error("Failed to close region file {}", regionFile, e);
				}
			}
		}

		LOGGER.info("Sidecar processing complete: processed {} chunks, modified {}", processedChunks, modifiedChunks);
	}

	/**
	 * Fix retroapi:id tagged items in level.dat player inventory.
	 */
	public static void fixLevelDat(File worldDir) {
		File levelDat = new File(worldDir, "level.dat");
		if (!levelDat.exists()) return;

		try {
			C_74087615 root = C_08565163.m_38706312(new FileInputStream(levelDat));
			C_74087615 data = root.m_81819352("Data");
			if (data == null) return;

			C_74087615 player = data.m_81819352("Player");
			if (player == null) return;

			boolean modified = false;

			// Fix player inventory
			if (player.m_97612750("Inventory")) {
				C_79370641 inventory = player.m_95654166("Inventory");
				if (inventory != null) {
					modified |= fixItemList(inventory);
				}
			}

			if (modified) {
				LOGGER.info("Fixed retroapi:id items in level.dat player inventory");
				C_08565163.m_39608025(root, new FileOutputStream(levelDat));
			}
		} catch (IOException e) {
			LOGGER.error("Failed to process level.dat", e);
		}
	}

	/**
	 * Copy the v3 xmeta section ({@code xpos}/{@code xval}) for a chunk from the pre-conversion block
	 * sidecar into the rebuilt chunk, so RetroAPI's flattened-state high bits survive un-conversion.
	 */
	private static void carryOverXmeta(C_74087615 oldSidecar, int chunkX, int chunkZ, C_74087615 chunkNbt) {
		if (oldSidecar == null || !oldSidecar.m_97612750("chunks")) return;
		C_74087615 chunks = oldSidecar.m_81819352("chunks");
		String key = chunkX + "," + chunkZ;
		if (!chunks.m_97612750(key)) return;
		C_74087615 old = chunks.m_81819352(key);
		byte[] xpos = old.m_32985640("xpos");
		byte[] xval = old.m_32985640("xval");
		if (xpos.length > 0 && xval.length * 4 == xpos.length) {
			chunkNbt.m_06603839("xpos", xpos);
			chunkNbt.m_06603839("xval", xval);
		}
	}

	/**
	 * The {@code (regionRelativeDir, sidecarNamespace)} pairs the conversion must process: the overworld
	 * plus every {@code DIM<n>} folder StationAPI also flattens. The overworld keeps {@code region/} +
	 * {@code retroapi/}; every other dimension is {@code DIM<n>/region/} + {@code retroapi/DIM<n>/},
	 * matching {@link com.periut.retroapi.storage.SidecarManager}'s on-disk layout exactly so a converted
	 * dimension round-trips like the overworld.
	 */
	private static java.util.List<String[]> dimensionDirs(File worldDir) {
		java.util.List<String[]> dirs = new ArrayList<>();
		dirs.add(new String[]{"region", "retroapi"});
		File[] dimFolders = worldDir.listFiles((dir, name) ->
			name.startsWith("DIM") && new File(dir, name).isDirectory());
		if (dimFolders != null) {
			for (File dim : dimFolders) {
				if (new File(dim, "region").isDirectory()) {
					String n = dim.getName(); // e.g. "DIM2", "DIM-1"
					dirs.add(new String[]{n + "/region", "retroapi/" + n});
				}
			}
		}
		return dirs;
	}

	private static C_74087615 loadSidecarNbt(File file) {
		if (!file.exists()) return null;
		try (FileInputStream fis = new FileInputStream(file)) {
			return C_08565163.m_38706312(fis);
		} catch (IOException e) {
			LOGGER.error("Failed to load sidecar {}", file, e);
			return null;
		}
	}

	/**
	 * Inject extended blocks from the block sidecar into the converted chunk sections.
	 */
	private static boolean injectExtendedBlocks(C_74087615 level, int chunkX, int chunkZ,
												C_74087615 sidecarRoot) {
		if (!sidecarRoot.m_97612750("chunks")) return false;
		C_74087615 chunks = sidecarRoot.m_81819352("chunks");
		String chunkKey = chunkX + "," + chunkZ;
		if (!chunks.m_97612750(chunkKey)) return false;

		C_74087615 chunkNbt = chunks.m_81819352(chunkKey);
		byte[] posBytes = chunkNbt.m_32985640("positions");
		byte[] metadata = chunkNbt.m_32985640("metadata");

		if (posBytes.length == 0) return false;

		int[] positions = bytesToInts(posBytes);
		String[] ids = decodeSidecarIds(chunkNbt, positions.length);
		if (ids.length == 0) return false;
		if (positions.length != ids.length) {
			LOGGER.warn("Mismatched positions/ids for chunk {},{}", chunkX, chunkZ);
			return false;
		}

		// Group blocks by section
		Map<Integer, List<int[]>> blocksBySection = new HashMap<>();
		// int[]: {localX, localY, localZ, idIndex}
		for (int i = 0; i < positions.length; i++) {
			int index = positions[i];
			// ChunkExtendedBlocks index = x << 11 | z << 7 | y (same as vanilla chunk byte[] indexing)
			int worldY = index & 0x7F;
			int z = (index >> 7) & 0xF;
			int x = (index >> 11) & 0xF;
			int sectionY = worldY >> 4;
			int localY = worldY & 0xF;

			blocksBySection.computeIfAbsent(sectionY, k -> new ArrayList<>())
				.add(new int[]{x, localY, z, i});
		}

		if (blocksBySection.isEmpty()) return false;

		// Get or create sections list
		C_79370641 sections;
		if (level.m_97612750(SECTIONS_KEY)) {
			sections = level.m_95654166(SECTIONS_KEY);
		} else {
			sections = new C_79370641();
			level.m_21770494(SECTIONS_KEY, sections);
		}

		// Index existing sections by Y
		Map<Integer, Integer> sectionIndexByY = new HashMap<>();
		for (int i = 0; i < sections.m_89439680(); i++) {
			C_74087615 section = (C_74087615) sections.m_59132367(i);
			int y = section.m_84056038("y");
			sectionIndexByY.put(y, i);
		}

		boolean modified = false;

		for (Map.Entry<Integer, List<int[]>> entry : blocksBySection.entrySet()) {
			int sectionY = entry.getKey();
			List<int[]> blocks = entry.getValue();

			C_74087615 section;
			Integer existingIdx = sectionIndexByY.get(sectionY);

			if (existingIdx != null) {
				section = (C_74087615) sections.m_59132367(existingIdx);
			} else {
				// Create a new section
				section = new C_74087615();
				section.m_41884431("y", (byte) sectionY);
				sections.m_43125067(section);
			}

			// Get or create palette and block data
			C_74087615 blockStates;
			C_79370641 palette;
			long[] packedData;
			int currentBits;

			if (section.m_97612750("block_states")) {
				blockStates = section.m_81819352("block_states");
				palette = blockStates.m_95654166("palette");
				packedData = ((StationNbtCompound) blockStates).getLongArray("data");
				currentBits = Math.max(4, ceilLog2(palette.m_89439680()));
			} else {
				blockStates = new C_74087615();
				palette = new C_79370641();
				// Add air as first palette entry
				C_74087615 air = new C_74087615();
				air.m_91017064("Name", "minecraft:air");
				palette.m_43125067(air);
				packedData = null;
				currentBits = 4;
				section.m_18682924("block_states", blockStates);
			}

			// Build a map of existing palette entries for lookup
			Map<String, Integer> paletteMap = new HashMap<>();
			for (int i = 0; i < palette.m_89439680(); i++) {
				C_74087615 pe = (C_74087615) palette.m_59132367(i);
				paletteMap.put(pe.m_47517355("Name"), i);
			}

			// Decode existing packed data
			PackedIntegerArray array;
			if (packedData != null && packedData.length > 0) {
				array = new PackedIntegerArray(currentBits, 4096, packedData);
			} else {
				array = new PackedIntegerArray(4, 4096);
			}

			// Read current states into an int array so we can re-encode with new bit size
			int[] stateIndices = new int[4096];
			for (int i = 0; i < 4096; i++) {
				stateIndices[i] = array.get(i);
			}

			// Get or create metadata nibble array
			byte[] metaNibble;
			if (section.m_97612750("data")) {
				metaNibble = section.m_32985640("data");
				if (metaNibble.length < 2048) {
					metaNibble = Arrays.copyOf(metaNibble, 2048);
				}
			} else {
				metaNibble = new byte[2048];
			}

			// Insert extended blocks
			for (int[] block : blocks) {
				int x = block[0], localY = block[1], z = block[2], idIdx = block[3];
				String blockId = ids[idIdx];
				int meta = (idIdx < metadata.length) ? (metadata[idIdx] & 0xFF) : 0;

				// Add to palette if not present
				int paletteIdx;
				if (paletteMap.containsKey(blockId)) {
					paletteIdx = paletteMap.get(blockId);
				} else {
					C_74087615 pe = new C_74087615();
					pe.m_91017064("Name", blockId);
					palette.m_43125067(pe);
					paletteIdx = palette.m_89439680() - 1;
					paletteMap.put(blockId, paletteIdx);
				}

				// Section index: (y << 4 | z) << 4 | x
				int sectionIdx = (localY << 4 | z) << 4 | x;
				stateIndices[sectionIdx] = paletteIdx;

				// Metadata nibble: x << 8 | y << 4 | z
				int nibbleIdx = x << 8 | localY << 4 | z;
				int byteIdx = nibbleIdx >> 1;
				if ((nibbleIdx & 1) == 0) {
					metaNibble[byteIdx] = (byte) ((metaNibble[byteIdx] & 0xF0) | (meta & 0x0F));
				} else {
					metaNibble[byteIdx] = (byte) ((metaNibble[byteIdx] & 0x0F) | ((meta & 0x0F) << 4));
				}
			}

			// Re-encode with potentially new bit size
			int newBits = Math.max(4, ceilLog2(palette.m_89439680()));
			PackedIntegerArray newArray = new PackedIntegerArray(newBits, 4096, stateIndices);

			blockStates.m_21770494("palette", palette);
			((StationNbtCompound) blockStates).put("data", newArray.getData());
			section.m_06603839("data", metaNibble);

			modified = true;
		}

		return modified;
	}

	/**
	 * Fix retroapi:id tagged items in TileEntities and Entities within a chunk.
	 */
	private static boolean fixRetroApiItems(C_74087615 level) {
		boolean modified = false;

		// Fix items in TileEntities
		if (level.m_97612750("TileEntities")) {
			C_79370641 tileEntities = level.m_95654166("TileEntities");
			if (tileEntities != null) {
				for (int i = 0; i < tileEntities.m_89439680(); i++) {
					C_74087615 te = (C_74087615) tileEntities.m_59132367(i);
					if (te.m_97612750("Items")) {
						modified |= fixItemList(te.m_95654166("Items"));
					}
				}
			}
		}

		// Fix item entities
		if (level.m_97612750("Entities")) {
			C_79370641 entities = level.m_95654166("Entities");
			if (entities != null) {
				for (int i = 0; i < entities.m_89439680(); i++) {
					C_74087615 entity = (C_74087615) entities.m_59132367(i);
					if ("Item".equals(entity.m_47517355("id")) && entity.m_97612750("Item")) {
						C_74087615 item = entity.m_81819352("Item");
						if (item != null) {
							modified |= fixSingleItem(item);
						}
					}
				}
			}
		}

		return modified;
	}

	/**
	 * Fix all retroapi:id tagged items in an NbtList of item stacks.
	 */
	private static boolean fixItemList(C_79370641 items) {
		boolean modified = false;
		for (int i = 0; i < items.m_89439680(); i++) {
			C_74087615 item = (C_74087615) items.m_59132367(i);
			modified |= fixSingleItem(item);
		}
		return modified;
	}

	/**
	 * Fix a single item stack: convert retroapi:id to stationapi:id and restore count/damage.
	 */
	private static boolean fixSingleItem(C_74087615 item) {
		if (!item.m_97612750("retroapi:id")) return false;

		String retroId = item.m_47517355("retroapi:id");
		// Set stationapi:id to the retroapi identifier
		item.m_91017064(STATION_ID, retroId);

		// Restore count from retroapi:count if present
		if (item.m_97612750("retroapi:count")) {
			item.m_41884431("Count", item.m_84056038("retroapi:count"));
		}

		// Restore damage from retroapi:damage if present
		if (item.m_97612750("retroapi:damage")) {
			item.m_98335007("Damage", item.m_03599456("retroapi:damage"));
		}

		// Note: retroapi:* tags are left in place since NbtCompound has no remove()
		// in b1.7.3. They are harmless dead data as ItemStackMixin is disabled with StationAPI.
		return true;
	}

	/**
	 * Inject inventory sidecar data (block entities, inventory items, item entities) into the chunk.
	 */
	private static boolean injectInventorySidecar(C_74087615 level, int chunkX, int chunkZ,
												  C_74087615 sidecarRoot) {
		if (!sidecarRoot.m_97612750("chunks")) return false;
		C_74087615 chunks = sidecarRoot.m_81819352("chunks");
		String chunkKey = chunkX + "," + chunkZ;
		if (!chunks.m_97612750(chunkKey)) return false;

		C_74087615 chunkData = chunks.m_81819352(chunkKey);
		boolean modified = false;

		// 1. Inject modded block entities
		if (chunkData.m_97612750("blockEntities")) {
			C_79370641 moddedBEs = chunkData.m_95654166("blockEntities");
			C_79370641 tileEntities = level.m_97612750("TileEntities") ? level.m_95654166("TileEntities") : new C_79370641();

			for (int i = 0; i < moddedBEs.m_89439680(); i++) {
				C_74087615 be = (C_74087615) moddedBEs.m_59132367(i);
				// Convert any retroapi:id items within the block entity's inventory
				if (be.m_97612750("Items")) {
					fixItemList(be.m_95654166("Items"));
				}
				tileEntities.m_43125067(be);
			}

			level.m_21770494("TileEntities", tileEntities);
			modified = true;
			LOGGER.debug("Injected {} modded block entities into chunk {},{}", moddedBEs.m_89439680(), chunkX, chunkZ);
		}

		// 2. Inject modded items into existing block entity inventories
		if (chunkData.m_97612750("inventoryItems")) {
			C_79370641 inventoryItems = chunkData.m_95654166("inventoryItems");
			C_79370641 tileEntities = level.m_97612750("TileEntities") ? level.m_95654166("TileEntities") : new C_79370641();

			// Index TileEntities by position
			Map<String, C_74087615> teByPos = new HashMap<>();
			for (int i = 0; i < tileEntities.m_89439680(); i++) {
				C_74087615 te = (C_74087615) tileEntities.m_59132367(i);
				String posKey = te.m_35587574("x") + "," + te.m_35587574("y") + "," + te.m_35587574("z");
				teByPos.put(posKey, te);
			}

			for (int i = 0; i < inventoryItems.m_89439680(); i++) {
				C_74087615 entry = (C_74087615) inventoryItems.m_59132367(i);
				String retroId = entry.m_47517355("retroapi:id");
				int count = entry.m_84056038("Count") & 0xFF;
				int damage = entry.m_03599456("Damage");
				int slot = entry.m_84056038("Slot") & 0xFF;

				// Create the item in stationapi format
				C_74087615 item = new C_74087615();
				item.m_91017064(STATION_ID, retroId);
				item.m_41884431("Count", (byte) count);
				item.m_98335007("Damage", (short) damage);
				item.m_41884431("Slot", (byte) slot);
				// Carry data components into the flattened item so they survive forward conversion.
				if (entry.m_97612750("retroapi:components")) {
					item.m_18682924("retroapi:components", entry.m_81819352("retroapi:components"));
				}

				// Find the target block entity
				String posKey = entry.m_35587574("x") + "," + entry.m_35587574("y") + "," + entry.m_35587574("z");
				C_74087615 targetTE = teByPos.get(posKey);
				if (targetTE != null && targetTE.m_97612750("Items")) {
					targetTE.m_95654166("Items").m_43125067(item);
				} else {
					LOGGER.warn("No block entity found at {} for inventory item {}", posKey, retroId);
				}
			}

			modified = true;
			LOGGER.debug("Injected {} modded inventory items into chunk {},{}", inventoryItems.m_89439680(), chunkX, chunkZ);
		}

		// 3. Inject modded item entities
		if (chunkData.m_97612750("itemEntities")) {
			C_79370641 moddedEntities = chunkData.m_95654166("itemEntities");
			C_79370641 entities = level.m_97612750("Entities") ? level.m_95654166("Entities") : new C_79370641();

			for (int i = 0; i < moddedEntities.m_89439680(); i++) {
				C_74087615 entity = (C_74087615) moddedEntities.m_59132367(i);
				// Fix the Item compound to use stationapi:id
				if (entity.m_97612750("Item")) {
					C_74087615 itemTag = entity.m_81819352("Item");
					if (itemTag != null) {
						fixSingleItem(itemTag);
					}
				}
				entities.m_43125067(entity);
			}

			level.m_21770494("Entities", entities);
			modified = true;
			LOGGER.debug("Injected {} modded item entities into chunk {},{}", moddedEntities.m_89439680(), chunkX, chunkZ);
		}

		// 4. Inject modded full entities (mobs etc.) — they were stripped to the sidecar so vanilla
		//    wouldn't drop them; the flattened world keeps the entity id as a namespaced string verbatim
		//    (StationAPI flattening doesn't renumber entities), so re-add them and flatten any items they carry.
		if (chunkData.m_97612750("fullEntities")) {
			C_79370641 fullEntities = chunkData.m_95654166("fullEntities");
			C_79370641 entities = level.m_97612750("Entities") ? level.m_95654166("Entities") : new C_79370641();

			for (int i = 0; i < fullEntities.m_89439680(); i++) {
				C_74087615 entity = (C_74087615) fullEntities.m_59132367(i);
				fixCarriedItems(entity);
				entities.m_43125067(entity);
			}

			level.m_21770494("Entities", entities);
			modified = true;
			LOGGER.debug("Injected {} modded full entities into chunk {},{}", fullEntities.m_89439680(), chunkX, chunkZ);
		}

		return modified;
	}

	/**
	 * Convert any {@code retroapi:id} item stacks an entity carries (its {@code Items} list, its held
	 * {@code Item}, or nested {@code Inventory}/{@code Equipment} lists) to {@code stationapi:id}, so a
	 * modded mob with modded gear round-trips. Best-effort over the common item-bearing keys.
	 */
	private static void fixCarriedItems(C_74087615 entity) {
		for (String key : new String[]{"Items", "Inventory", "Equipment", "ArmorItems", "HandItems"}) {
			if (entity.m_97612750(key)) fixItemList(entity.m_95654166(key));
		}
		if (entity.m_97612750("Item")) fixSingleItem(entity.m_81819352("Item"));
	}

	/**
	 * Reconstruct block sidecars from StationAPI's flattened section format.
	 * Must run BEFORE the damager converts sections to byte[], so we can read palette entries.
	 */
	public static void reconstructBlockSidecarsFromFlattened(File worldDir) {
		for (String[] dim : dimensionDirs(worldDir)) reconstructBlockSidecarsForDim(worldDir, dim[0], dim[1]);
	}

	private static void reconstructBlockSidecarsForDim(File worldDir, String regionRel, String sidecarNs) {
		IdMap idMap = new IdMap();
		File idMapFile = new File(worldDir, "retroapi/id_map.dat");
		if (!idMapFile.exists()) {
			LOGGER.warn("No id_map.dat found, cannot reconstruct block sidecars");
			return;
		}
		idMap.load(idMapFile);

		// Build set of RetroAPI block identifiers
		Set<String> retroBlockIds = new HashSet<>();
		for (NamespacedIdentifier id : idMap.getBlockIds().keySet()) {
			retroBlockIds.add(id.toString());
		}

		if (retroBlockIds.isEmpty()) {
			LOGGER.info("No RetroAPI blocks in id_map, skipping block sidecar reconstruction");
			return;
		}

		LOGGER.info("Reconstructing block sidecars from flattened world (known blocks: {}) for {}", retroBlockIds.size(), sidecarNs);

		File regionDir = new File(worldDir, regionRel);
		if (!regionDir.exists()) return;

		File[] regionFiles = regionDir.listFiles((dir, name) -> name.endsWith(".mcr"));
		if (regionFiles == null) return;

		for (File regionFile : regionFiles) {
			String name = regionFile.getName();
			String[] parts = name.split("\\.");
			if (parts.length != 4) continue;
			int regionX, regionZ;
			try {
				regionX = Integer.parseInt(parts[1]);
				regionZ = Integer.parseInt(parts[2]);
			} catch (NumberFormatException e) {
				continue;
			}

			C_74087615 sidecarRoot = new C_74087615();
			sidecarRoot.m_20318863("version", 1);
			C_74087615 sidecarChunks = new C_74087615();
			boolean hasData = false;

			// The pre-conversion block sidecar (additive, never deleted by forward conversion) still holds
			// RetroAPI's xmeta — the flattened-state high bits that have no home in StationAPI's format.
			// Reconstruct overwrites this file from the flattened block ids, so read the old xmeta first
			// and carry it into the rebuilt chunks; otherwise states > 15 silently collapse to 4 bits.
			C_74087615 oldBlockSidecar = loadSidecarNbt(
				new File(worldDir, sidecarNs + "/chunks/r." + regionX + "." + regionZ + ".dat"));

			C_89060550 region = new C_89060550(regionFile);
			try {
				for (int localX = 0; localX < 32; localX++) {
					for (int localZ = 0; localZ < 32; localZ++) {
						if (!region.m_06356153(localX, localZ)) continue;

						DataInputStream dis = region.m_88766766(localX, localZ);
						if (dis == null) continue;

						C_74087615 chunkTag;
						try {
							chunkTag = C_08565163.m_07155133(dis);
							dis.close();
						} catch (IOException e) {
							continue;
						}

						C_74087615 level = chunkTag.m_81819352("Level");
						if (level == null || !level.m_97612750(SECTIONS_KEY)) continue;

						int chunkX = level.m_35587574("xPos");
						int chunkZ = level.m_35587574("zPos");

						List<Integer> positions = new ArrayList<>();
						List<String> ids = new ArrayList<>();
						List<Integer> metas = new ArrayList<>();

						C_79370641 sections = level.m_95654166(SECTIONS_KEY);
						for (int s = 0; s < sections.m_89439680(); s++) {
							C_74087615 section = (C_74087615) sections.m_59132367(s);
							int sectionY = section.m_84056038("y");

							if (!section.m_97612750("block_states")) continue;
							C_74087615 blockStates = section.m_81819352("block_states");
							if (!blockStates.m_97612750("palette")) continue;

							C_79370641 palette = blockStates.m_95654166("palette");

							// Check which palette entries are RetroAPI blocks
							Map<Integer, String> retroPaletteIndices = new HashMap<>();
							for (int p = 0; p < palette.m_89439680(); p++) {
								C_74087615 pe = (C_74087615) palette.m_59132367(p);
								String blockName = pe.m_47517355("Name");
								if (retroBlockIds.contains(blockName)) {
									retroPaletteIndices.put(p, blockName);
								}
							}

							if (retroPaletteIndices.isEmpty()) continue;

							// Decode packed data
							long[] packedData = ((StationNbtCompound) blockStates).getLongArray("data");
							if (packedData == null || packedData.length == 0) {
								// Single-entry palette, all 4096 blocks are that entry
								if (palette.m_89439680() == 1 && retroPaletteIndices.containsKey(0)) {
									String blockId = retroPaletteIndices.get(0);
									for (int idx = 0; idx < 4096; idx++) {
										int x = idx & 0xF;
										int z = (idx >> 4) & 0xF;
										int localY = (idx >> 8) & 0xF;
										int worldY = sectionY * 16 + localY;
										int chunkIndex = (x << 11) | (z << 7) | worldY;
										positions.add(chunkIndex);
										ids.add(blockId);
										metas.add(0);
									}
								}
								continue;
							}

							int bits = Math.max(4, ceilLog2(palette.m_89439680()));
							PackedIntegerArray array = new PackedIntegerArray(bits, 4096, packedData);

							// Read metadata nibble array
							byte[] metaNibble = section.m_97612750("data") ? section.m_32985640("data") : null;

							for (int idx = 0; idx < 4096; idx++) {
								int paletteIdx = array.get(idx);
								if (retroPaletteIndices.containsKey(paletteIdx)) {
									String blockId = retroPaletteIndices.get(paletteIdx);
									// Section index: (y << 4 | z) << 4 | x
									int x = idx & 0xF;
									int z = (idx >> 4) & 0xF;
									int localY = (idx >> 8) & 0xF;
									int worldY = sectionY * 16 + localY;
									int chunkIndex = (x << 11) | (z << 7) | worldY;

									// Get metadata from nibble array
									int meta = 0;
									if (metaNibble != null && metaNibble.length >= 2048) {
										int nibbleIdx = x << 8 | localY << 4 | z;
										int byteIdx = nibbleIdx >> 1;
										if ((nibbleIdx & 1) == 0) {
											meta = metaNibble[byteIdx] & 0x0F;
										} else {
											meta = (metaNibble[byteIdx] >> 4) & 0x0F;
										}
									}

									positions.add(chunkIndex);
									ids.add(blockId);
									metas.add(meta);
								}
							}
						}

						if (!positions.isEmpty()) {
							C_74087615 chunkNbt = new C_74087615();
							int[] posArray = new int[positions.size()];
							byte[] metaArray = new byte[positions.size()];
							StringBuilder idsBuilder = new StringBuilder();

							for (int i = 0; i < positions.size(); i++) {
								posArray[i] = positions.get(i);
								if (i > 0) idsBuilder.append('\0');
								idsBuilder.append(ids.get(i));
								metaArray[i] = metas.get(i).byteValue();
							}

							chunkNbt.m_06603839("positions", intsToBytes(posArray));
							chunkNbt.m_91017064("ids", idsBuilder.toString());
							chunkNbt.m_06603839("metadata", metaArray);
							carryOverXmeta(oldBlockSidecar, chunkX, chunkZ, chunkNbt);

							String chunkKey = chunkX + "," + chunkZ;
							sidecarChunks.m_18682924(chunkKey, chunkNbt);
							hasData = true;
						}
					}
				}
			} finally {
				try { region.m_16177213(); } catch (IOException e) { /* ignore */ }
			}

			if (hasData) {
				sidecarRoot.m_18682924("chunks", sidecarChunks);
				File sidecarFile = new File(worldDir, sidecarNs + "/chunks/r." + regionX + "." + regionZ + ".dat");
				sidecarFile.getParentFile().mkdirs();
				try (FileOutputStream fos = new FileOutputStream(sidecarFile)) {
					C_08565163.m_39608025(sidecarRoot, fos);
					LOGGER.info("Reconstructed block sidecar for region {},{}", regionX, regionZ);
				} catch (IOException e) {
					LOGGER.error("Failed to write block sidecar for region {},{}", regionX, regionZ, e);
				}
			}
		}
	}

	/**
	 * Reconstruct inventory sidecars from vanilla-format chunks after the damager has run.
	 * Strips modded block entities, RetroAPI items, and item entities from vanilla chunks.
	 */
	public static void reconstructInventorySidecarsFromVanilla(File worldDir) {
		for (String[] dim : dimensionDirs(worldDir)) reconstructInventorySidecarsForDim(worldDir, dim[0], dim[1]);
	}

	private static void reconstructInventorySidecarsForDim(File worldDir, String regionRel, String sidecarNs) {
		IdMap idMap = new IdMap();
		File idMapFile = new File(worldDir, "retroapi/id_map.dat");
		if (!idMapFile.exists()) {
			LOGGER.warn("No id_map.dat found, cannot reconstruct inventory sidecars");
			return;
		}
		idMap.load(idMapFile);

		// Build reverse maps: numeric ID → string ID
		Map<Integer, String> reverseBlockMap = new HashMap<>();
		for (Map.Entry<NamespacedIdentifier, Integer> entry : idMap.getBlockIds().entrySet()) {
			reverseBlockMap.put(entry.getValue(), entry.getKey().toString());
		}
		Map<Integer, String> reverseItemMap = new HashMap<>();
		for (Map.Entry<NamespacedIdentifier, Integer> entry : idMap.getItemIds().entrySet()) {
			reverseItemMap.put(entry.getValue(), entry.getKey().toString());
		}

		LOGGER.info("Reconstructing inventory sidecars from vanilla chunks (blocks: {}, items: {}) for {}",
			reverseBlockMap.size(), reverseItemMap.size(), sidecarNs);

		File regionDir = new File(worldDir, regionRel);
		if (!regionDir.exists()) return;

		File[] regionFiles = regionDir.listFiles((dir, name) -> name.endsWith(".mcr"));
		if (regionFiles == null) return;

		for (File regionFile : regionFiles) {
			String name = regionFile.getName();
			String[] parts = name.split("\\.");
			if (parts.length != 4) continue;
			int regionX, regionZ;
			try {
				regionX = Integer.parseInt(parts[1]);
				regionZ = Integer.parseInt(parts[2]);
			} catch (NumberFormatException e) {
				continue;
			}

			// Load block sidecar to identify modded block positions
			File blockSidecarFile = new File(worldDir, sidecarNs + "/chunks/r." + regionX + "." + regionZ + ".dat");
			C_74087615 blockSidecarRoot = loadSidecarNbt(blockSidecarFile);

			C_74087615 invSidecarRoot = new C_74087615();
			invSidecarRoot.m_20318863("version", 1);
			C_74087615 invSidecarChunks = new C_74087615();
			boolean hasData = false;

			C_89060550 region = new C_89060550(regionFile);
			try {
				for (int localX = 0; localX < 32; localX++) {
					for (int localZ = 0; localZ < 32; localZ++) {
						if (!region.m_06356153(localX, localZ)) continue;

						DataInputStream dis = region.m_88766766(localX, localZ);
						if (dis == null) continue;

						C_74087615 chunkTag;
						try {
							chunkTag = C_08565163.m_07155133(dis);
							dis.close();
						} catch (IOException e) {
							continue;
						}

						C_74087615 level = chunkTag.m_81819352("Level");
						if (level == null) continue;

						int chunkX = level.m_35587574("xPos");
						int chunkZ = level.m_35587574("zPos");
						String chunkKey = chunkX + "," + chunkZ;

						// Get modded block positions from block sidecar to identify modded BEs
						Set<String> moddedPositions = new HashSet<>();
						if (blockSidecarRoot != null && blockSidecarRoot.m_97612750("chunks")) {
							C_74087615 bsChunks = blockSidecarRoot.m_81819352("chunks");
							if (bsChunks.m_97612750(chunkKey)) {
								C_74087615 bsChunk = bsChunks.m_81819352(chunkKey);
								byte[] posBytes = bsChunk.m_32985640("positions");
								int[] blockPositions = bytesToInts(posBytes);
								for (int pos : blockPositions) {
									int x = ChunkExtendedBlocks.indexToX(pos);
									int y = ChunkExtendedBlocks.indexToY(pos);
									int z = ChunkExtendedBlocks.indexToZ(pos);
									int worldX = chunkX * 16 + x;
									int worldZ = chunkZ * 16 + z;
									moddedPositions.add(worldX + "," + y + "," + worldZ);
								}
							}
						}

						C_74087615 chunkData = new C_74087615();
						boolean chunkModified = false;

						// 1. Filter TileEntities
						if (level.m_97612750("TileEntities")) {
							C_79370641 tileEntities = level.m_95654166("TileEntities");
							C_79370641 filteredTEs = new C_79370641();
							C_79370641 moddedBEs = new C_79370641();
							C_79370641 inventoryItems = new C_79370641();

							for (int i = 0; i < tileEntities.m_89439680(); i++) {
								C_74087615 be = (C_74087615) tileEntities.m_59132367(i);
								int bx = be.m_35587574("x");
								int by = be.m_35587574("y");
								int bz = be.m_35587574("z");
								String posKey = bx + "," + by + "," + bz;

								if (moddedPositions.contains(posKey)) {
									// Modded block entity - convert vanilla stationapi:id items to
									// numeric IDs, then tag RetroAPI items with retroapi:id, and strip
									if (be.m_97612750("Items")) {
										convertStationApiItemsToNumeric(be.m_95654166("Items"));
										tagItemsWithRetroId(be.m_95654166("Items"), reverseBlockMap, reverseItemMap);
									}
									moddedBEs.m_43125067(be);
								} else {
									// Vanilla block entity - check for RetroAPI items in inventory
									if (be.m_97612750("Items")) {
										C_79370641 items = be.m_95654166("Items");
										C_79370641 filteredItems = new C_79370641();

										for (int j = 0; j < items.m_89439680(); j++) {
											C_74087615 item = (C_74087615) items.m_59132367(j);
											String retroId = resolveRetroId(item, reverseBlockMap, reverseItemMap);
											if (retroId != null) {
												C_74087615 invEntry = new C_74087615();
												invEntry.m_20318863("x", bx);
												invEntry.m_20318863("y", by);
												invEntry.m_20318863("z", bz);
												invEntry.m_41884431("Slot", item.m_84056038("Slot"));
												invEntry.m_91017064("retroapi:id", retroId);
												invEntry.m_41884431("Count", item.m_84056038("Count"));
												invEntry.m_98335007("Damage", item.m_03599456("Damage"));
												// Preserve data components the forward pass attached to the item.
												if (item.m_97612750("retroapi:components")) {
													invEntry.m_18682924("retroapi:components", item.m_81819352("retroapi:components"));
												}
												inventoryItems.m_43125067(invEntry);
											} else {
												filteredItems.m_43125067(item);
											}
										}

										be.m_21770494("Items", filteredItems);
									}
									filteredTEs.m_43125067(be);
								}
							}

							if (moddedBEs.m_89439680() > 0 || inventoryItems.m_89439680() > 0) {
								level.m_21770494("TileEntities", filteredTEs);
								if (moddedBEs.m_89439680() > 0) chunkData.m_21770494("blockEntities", moddedBEs);
								if (inventoryItems.m_89439680() > 0) chunkData.m_21770494("inventoryItems", inventoryItems);
								chunkModified = true;
							}
						}

						// 2. Filter Entities - strip item entities carrying RetroAPI items, and strip modded
						//    full entities (namespaced id, e.g. "aether:moa") to the fullEntities sidecar.
						//    Vanilla entities keep short names with no colon; StationAPI flattening never
						//    renumbers entities, so a colon in the id marks a modded entity the same way the
						//    runtime sidecar (InventorySidecar) classifies them.
						if (level.m_97612750("Entities")) {
							C_79370641 entities = level.m_95654166("Entities");
							C_79370641 filteredEntities = new C_79370641();
							C_79370641 moddedItemEntities = new C_79370641();
							C_79370641 moddedFullEntities = new C_79370641();

							for (int i = 0; i < entities.m_89439680(); i++) {
								C_74087615 entity = (C_74087615) entities.m_59132367(i);
								String entityId = entity.m_47517355("id");
								if ("Item".equals(entityId)) {
									C_74087615 itemTag = entity.m_81819352("Item");
									if (itemTag != null) {
										String retroId = resolveRetroId(itemTag, reverseBlockMap, reverseItemMap);
										if (retroId != null) {
											// Tag the item for sidecar
											itemTag.m_91017064("retroapi:id", retroId);
											itemTag.m_41884431("retroapi:count", itemTag.m_84056038("Count"));
											itemTag.m_98335007("retroapi:damage", itemTag.m_03599456("Damage"));
											itemTag.m_98335007("id", (short) 0);
											itemTag.m_41884431("Count", (byte) 0);
											moddedItemEntities.m_43125067(entity);
											continue;
										}
									}
								} else if (entityId != null && entityId.indexOf(':') >= 0) {
									// Modded full entity - tag any RetroAPI items it carries, then strip whole.
									tagCarriedItems(entity, reverseBlockMap, reverseItemMap);
									moddedFullEntities.m_43125067(entity);
									continue;
								}
								filteredEntities.m_43125067(entity);
							}

							if (moddedItemEntities.m_89439680() > 0 || moddedFullEntities.m_89439680() > 0) {
								level.m_21770494("Entities", filteredEntities);
								if (moddedItemEntities.m_89439680() > 0) chunkData.m_21770494("itemEntities", moddedItemEntities);
								if (moddedFullEntities.m_89439680() > 0) chunkData.m_21770494("fullEntities", moddedFullEntities);
								chunkModified = true;
							}
						}

						if (chunkModified) {
							invSidecarChunks.m_18682924(chunkKey, chunkData);
							hasData = true;

							// Write modified chunk back
							try (DataOutputStream dos = region.m_68205534(localX, localZ)) {
								C_08565163.m_94300398(chunkTag, dos);
							} catch (IOException e) {
								LOGGER.error("Failed to write chunk {},{}", chunkX, chunkZ, e);
							}
						}
					}
				}
			} finally {
				try { region.m_16177213(); } catch (IOException e) { /* ignore */ }
			}

			if (hasData) {
				invSidecarRoot.m_18682924("chunks", invSidecarChunks);
				File invSidecarFile = new File(worldDir, sidecarNs + "/inventories/r." + regionX + "." + regionZ + ".dat");
				invSidecarFile.getParentFile().mkdirs();
				try (FileOutputStream fos = new FileOutputStream(invSidecarFile)) {
					C_08565163.m_39608025(invSidecarRoot, fos);
					LOGGER.info("Reconstructed inventory sidecar for region {},{}", regionX, regionZ);
				} catch (IOException e) {
					LOGGER.error("Failed to write inventory sidecar for region {},{}", regionX, regionZ, e);
				}
			}
		}
	}

	/**
	 * Fix player inventory in level.dat for RetroAPI format after un-conversion.
	 * Tags RetroAPI items with retroapi:id and clamps their vanilla fields.
	 */
	public static void fixLevelDatForRetroApi(File worldDir) {
		File levelDat = new File(worldDir, "level.dat");
		if (!levelDat.exists()) return;

		IdMap idMap = new IdMap();
		File idMapFile = new File(worldDir, "retroapi/id_map.dat");
		if (!idMapFile.exists()) return;
		idMap.load(idMapFile);

		Map<Integer, String> reverseBlockMap = new HashMap<>();
		for (Map.Entry<NamespacedIdentifier, Integer> entry : idMap.getBlockIds().entrySet()) {
			reverseBlockMap.put(entry.getValue(), entry.getKey().toString());
		}
		Map<Integer, String> reverseItemMap = new HashMap<>();
		for (Map.Entry<NamespacedIdentifier, Integer> entry : idMap.getItemIds().entrySet()) {
			reverseItemMap.put(entry.getValue(), entry.getKey().toString());
		}

		try {
			C_74087615 root = C_08565163.m_38706312(new FileInputStream(levelDat));
			C_74087615 data = root.m_81819352("Data");
			if (data == null) return;

			C_74087615 player = data.m_81819352("Player");
			if (player == null) return;

			boolean modified = false;

			if (player.m_97612750("Inventory")) {
				C_79370641 inventory = player.m_95654166("Inventory");
				if (inventory != null) {
					modified |= tagItemsWithRetroId(inventory, reverseBlockMap, reverseItemMap);
				}
			}

			if (modified) {
				LOGGER.info("Fixed player inventory in level.dat for RetroAPI");
				C_08565163.m_39608025(root, new FileOutputStream(levelDat));
			}
		} catch (IOException e) {
			LOGGER.error("Failed to process level.dat for RetroAPI", e);
		}
	}

	/**
	 * Resolve a RetroAPI string ID from an item's NBT, checking stationapi:id first,
	 * then falling back to numeric ID lookup via the reverse map.
	 */
	private static String resolveRetroId(C_74087615 item, Map<Integer, String> reverseBlockMap,
										  Map<Integer, String> reverseItemMap) {
		// Check stationapi:id first (damager may have left it)
		if (item.m_97612750(STATION_ID)) {
			String stationId = item.m_47517355(STATION_ID);
			if (!stationId.isEmpty() && !stationId.startsWith("minecraft:")) {
				return stationId;
			}
		}
		// Check retroapi:id (already tagged)
		if (item.m_97612750("retroapi:id")) {
			return item.m_47517355("retroapi:id");
		}
		// Fall back to numeric ID lookup
		int numericId = item.m_03599456("id");
		String retroId = reverseBlockMap.get(numericId);
		if (retroId != null) return retroId;
		return reverseItemMap.get(numericId);
	}

	/**
	 * Tag all RetroAPI items in a list with retroapi:id and clamp vanilla fields.
	 * Returns true if any items were tagged.
	 */
	private static boolean tagItemsWithRetroId(C_79370641 items, Map<Integer, String> reverseBlockMap,
												Map<Integer, String> reverseItemMap) {
		boolean modified = false;
		for (int i = 0; i < items.m_89439680(); i++) {
			C_74087615 item = (C_74087615) items.m_59132367(i);
			String retroId = resolveRetroId(item, reverseBlockMap, reverseItemMap);
			if (retroId != null) {
				item.m_91017064("retroapi:id", retroId);
				item.m_41884431("retroapi:count", item.m_84056038("Count"));
				item.m_98335007("retroapi:damage", item.m_03599456("Damage"));
				item.m_98335007("id", (short) 0);
				item.m_41884431("Count", (byte) 0);
				modified = true;
			}
		}
		return modified;
	}

	/** Tag any RetroAPI items a modded full entity carries (its inventory lists + a held {@code Item}). */
	private static void tagCarriedItems(C_74087615 entity, Map<Integer, String> reverseBlockMap,
										Map<Integer, String> reverseItemMap) {
		for (String key : new String[]{"Items", "Inventory", "Equipment", "ArmorItems", "HandItems"}) {
			if (entity.m_97612750(key)) tagItemsWithRetroId(entity.m_95654166(key), reverseBlockMap, reverseItemMap);
		}
		if (entity.m_97612750("Item")) {
			C_74087615 item = entity.m_81819352("Item");
			String retroId = resolveRetroId(item, reverseBlockMap, reverseItemMap);
			if (retroId != null) {
				item.m_91017064("retroapi:id", retroId);
				item.m_41884431("retroapi:count", item.m_84056038("Count"));
				item.m_98335007("retroapi:damage", item.m_03599456("Damage"));
				item.m_98335007("id", (short) 0);
				item.m_41884431("Count", (byte) 0);
			}
		}
	}

	/**
	 * Convert stationapi:id items back to numeric IDs using StationAPI's reverse lookup.
	 * This is needed for vanilla items inside modded BEs (e.g. water bucket in a freezer)
	 * that the damager didn't process. Without this, they'd have id=0 causing NPE.
	 */
	private static void convertStationApiItemsToNumeric(C_79370641 items) {
		for (int i = 0; i < items.m_89439680(); i++) {
			C_74087615 item = (C_74087615) items.m_59132367(i);
			if (item.m_97612750(STATION_ID)) {
				String stationId = item.m_47517355(STATION_ID);
				if (stationId.startsWith("minecraft:")) {
					int numericId = StationFlatteningItemStackSchema.lookupOldItemId(stationId);
					if (numericId != 0) {
						item.m_98335007("id", (short) numericId);
					}
				}
			}
		}
	}

	/**
	 * Decode the per-position string ids of a block-sidecar chunk, understanding both formats
	 * {@link com.periut.retroapi.storage.RegionSidecar} can write: the v2 palette form
	 * ({@code palette} = {@code \0}-joined unique ids + a {@code paletteIdx} byte per position) and the
	 * legacy v1 form ({@code ids} = one {@code \0}-joined string per position). The runtime sidecar
	 * writes v2, so reading only v1 here silently dropped every modded block during conversion.
	 */
	private static String[] decodeSidecarIds(C_74087615 chunkNbt, int posCount) {
		if (chunkNbt.m_97612750("palette")) {
			String[] palette = chunkNbt.m_47517355("palette").split("\0");
			byte[] idx = chunkNbt.m_32985640("paletteIdx");
			String[] ids = new String[idx.length];
			for (int i = 0; i < idx.length; i++) {
				int pi = idx[i] & 0xFF;
				ids[i] = pi < palette.length ? palette[pi] : "unknown:0";
			}
			return ids;
		}
		String idsJoined = chunkNbt.m_47517355("ids");
		if (idsJoined.isEmpty()) return new String[0];
		return idsJoined.split("\0");
	}

	private static int ceilLog2(int n) {
		if (n <= 1) return 0;
		return 32 - Integer.numberOfLeadingZeros(n - 1);
	}

	private static int[] bytesToInts(byte[] bytes) {
		ByteBuffer buf = ByteBuffer.wrap(bytes);
		int[] ints = new int[bytes.length / 4];
		for (int i = 0; i < ints.length; i++) {
			ints[i] = buf.getInt();
		}
		return ints;
	}

	private static byte[] intsToBytes(int[] ints) {
		ByteBuffer buf = ByteBuffer.allocate(ints.length * 4);
		for (int v : ints) {
			buf.putInt(v);
		}
		return buf.array();
	}
}
