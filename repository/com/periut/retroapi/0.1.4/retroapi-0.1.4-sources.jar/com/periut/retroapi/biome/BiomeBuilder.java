package com.periut.retroapi.biome;

import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_74425583;

/**
 * Fluent builder for a modded {@link C_28105876} (tint colours, weather flags, per-biome spawn weights),
 * used inside a {@link com.periut.retroapi.biome.event.BiomeRegistrationCallback} listener:
 *
 * <pre>{@code
 * Biome aether = BiomeBuilder.start("aether")
 *     .grassAndLeavesColor(353825)
 *     .precipitation(false)
 *     .snow(false)
 *     .passiveEntity(EntityMoa.class, 10)
 *     .hostileEntity(EntityCockatrice.class, 3)
 *     .build();
 * }</pre>
 *
 * <p>API-compatible with StationAPI's {@code BiomeBuilder} so a consuming mod barely changes. The
 * built biome is a plain vanilla {@link C_28105876} — a custom dimension hands it back from its
 * {@code BiomeSource}, so no global biome registration is required.
 */
public final class BiomeBuilder {
	private final RetroBiome biome = new RetroBiome();

	private BiomeBuilder(String name) {
		this.biome.f_53376351 = name;
	}

	public static BiomeBuilder start(String name) {
		return new BiomeBuilder(name);
	}

	/** Sets both the grass tint and the foliage (leaves) tint to the same colour. */
	public BiomeBuilder grassAndLeavesColor(int color) {
		this.biome.f_41126416 = color;
		this.biome.f_52464089 = color;
		return this;
	}

	public BiomeBuilder grassColor(int color) {
		this.biome.f_41126416 = color;
		return this;
	}

	public BiomeBuilder leavesColor(int color) {
		this.biome.f_52464089 = color;
		return this;
	}

	/** {@code false} disables rain in this biome (access-widened {@code hasRain}). */
	public BiomeBuilder precipitation(boolean hasRain) {
		this.biome.f_82006901 = hasRain;
		return this;
	}

	/** {@code true} enables snowfall in this biome (access-widened {@code hasSnow}). */
	public BiomeBuilder snow(boolean hasSnow) {
		this.biome.f_10922062 = hasSnow;
		return this;
	}

	public BiomeBuilder passiveEntity(Class<? extends C_74425583> entityClass, int rarity) {
		this.biome.addPassive(entityClass, rarity);
		return this;
	}

	public BiomeBuilder hostileEntity(Class<? extends C_74425583> entityClass, int rarity) {
		this.biome.addMonster(entityClass, rarity);
		return this;
	}

	public BiomeBuilder waterCreature(Class<? extends C_74425583> entityClass, int rarity) {
		this.biome.addWaterCreature(entityClass, rarity);
		return this;
	}

	public C_28105876 build() {
		return this.biome;
	}
}
