package com.periut.retroapi.mixin.network;

import net.minecraft.unmapped.C_14230742;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(C_14230742.class)
public class ServerPlayerInteractionManagerMixin {
	@ModifyConstant(method = "tryBreakBlock", constant = @Constant(intValue = 256))
	private int retroapi$widenBlockIdPacking(int original) {
		return 4096;
	}
}
