package com.periut.retroapi.register.item;

import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_98888256;

/**
 * Which ids name something a player can actually hold.
 *
 * <p>Beta's block list is full of forms that exist only as world states: the lit copy of a furnace,
 * the powered copy of a repeater, the unlit redstone torch, farmland, wheat, fire, flowing water, the
 * two halves of a piston mid-push. None of them is an item, and offering them where an ITEM is wanted
 * - {@code /give}, the creative search tab - is offering something that cannot be given.
 *
 * <p>Separate from "does this id exist", which is what a BLOCK argument wants: {@code /setblock
 * minecraft:fire} is a perfectly reasonable thing to type, and this list must not shrink it.
 *
 * <p>One list, used by both the creative screen and the command suggestions, so the two cannot drift
 * apart into "the tab hides it but the command offers it".
 */
public final class ObtainableItems {
    private ObtainableItems() {
    }

    /**
     * Blocks that exist only as world states: fluids, fire, the piston's moving parts, the lit variants
     * a block switches to itself, the double slab two slabs become. Modern has no items for any of them
     * either, and a creative tab full of them is how a backport looks unfinished.
     */
    public static boolean isTechnicalBlock(final int blockId) {
        return blockId == C_81592558.f_12152349.f_84602679 || blockId == C_81592558.f_91830957.f_84602679
            || blockId == C_81592558.f_42662644.f_84602679 || blockId == C_81592558.f_63585395.f_84602679
            || blockId == C_81592558.f_48624188.f_84602679 || blockId == C_81592558.f_18320492.f_84602679
            || blockId == C_81592558.f_95852348.f_84602679 || blockId == C_81592558.f_89678708.f_84602679
            || blockId == C_81592558.f_39350323.f_84602679
            || blockId == C_81592558.f_78357199.f_84602679 || blockId == C_81592558.f_88434840.f_84602679
            || blockId == C_81592558.f_19964067.f_84602679
            || blockId == C_81592558.f_13293967.f_84602679 || blockId == C_81592558.f_69293475.f_84602679
            || blockId == C_81592558.f_95757196.f_84602679 || blockId == C_81592558.f_09380838.f_84602679
            || blockId == C_81592558.f_81695559.f_84602679
            || blockId == C_81592558.f_02852022.f_84602679;
    }

    /**
     * Blocks whose item is a different id entirely - a door block is placed by a door item, a repeater
     * block by a repeater item. The block id is not the thing to hand out; the item id is, and it is in
     * the list on its own.
     */
    public static boolean hasSeparateItem(final int blockId) {
        return blockId == C_81592558.f_10487872.f_84602679 || blockId == C_81592558.f_84644959.f_84602679 || blockId == C_81592558.f_91546482.f_84602679
            || blockId == C_81592558.f_30518711.f_84602679 || blockId == C_81592558.f_98529173.f_84602679
            || blockId == C_81592558.f_77070700.f_84602679 || blockId == C_81592558.f_35874681.f_84602679
            || blockId == C_81592558.f_08141062.f_84602679;
    }

    /**
     * The item id a block hands over when it is picked, or {@code -1} for a block with no held form
     * at all.
     *
     * <p>{@link #isObtainable} answers whether an id may be handed over; this answers what to hand over
     * INSTEAD, which is the half pick-block needs. Both halves of a lit/unlit pair give the form that
     * can be placed, a block whose item is a separate id gives that item, and the fluids and piston
     * innards give nothing, because nothing is what a player could hold.
     *
     * <p>Metadata is the caller's business: a double slab picks as the slab it is made of, so the meta
     * carries across unchanged.
     */
    public static int pickedItemId(final int blockId) {
        if (blockId == C_81592558.f_78357199.f_84602679) {
            return C_81592558.f_19785413.f_84602679;
        }
        if (blockId == C_81592558.f_88434840.f_84602679) {
            return C_81592558.f_68803305.f_84602679;
        }
        if (blockId == C_81592558.f_19964067.f_84602679) {
            return C_81592558.f_78503403.f_84602679;   // the unlit copy is the state; the lit one is the item
        }
        if (blockId == C_81592558.f_39350323.f_84602679) {
            return C_81592558.f_66929948.f_84602679;
        }
        if (blockId == C_81592558.f_95757196.f_84602679) {
            return C_81592558.f_05581995.f_84602679;
        }
        if (blockId == C_81592558.f_08141062.f_84602679) {
            return C_98888256.f_52656331.f_57562535;
        }
        if (blockId == C_81592558.f_84644959.f_84602679) {
            return C_98888256.f_92303073.f_57562535;
        }
        if (blockId == C_81592558.f_91546482.f_84602679) {
            return C_98888256.f_40777991.f_57562535;
        }
        if (blockId == C_81592558.f_10487872.f_84602679) {
            return C_98888256.f_08856223.f_57562535;
        }
        if (blockId == C_81592558.f_30518711.f_84602679 || blockId == C_81592558.f_13293967.f_84602679) {
            return C_98888256.f_97502738.f_57562535;
        }
        if (blockId == C_81592558.f_98529173.f_84602679) {
            return C_98888256.f_59726285.f_57562535;
        }
        if (blockId == C_81592558.f_35874681.f_84602679) {
            return C_98888256.f_55275152.f_57562535;
        }
        if (blockId == C_81592558.f_77070700.f_84602679 || blockId == C_81592558.f_02852022.f_84602679) {
            return C_98888256.f_98054602.f_57562535;
        }
        if (blockId == C_81592558.f_09380838.f_84602679) {
            return C_98888256.f_84974010 == null ? -1 : C_98888256.f_84974010.f_57562535;   // a crop picks as what plants it
        }

        return isObtainable(blockId) ? blockId : -1;
    }

    /** Whether this id can be given to a player: an item, or a block that has one. */
    public static boolean isObtainable(final int id) {
        if (id <= 0 || id >= C_98888256.f_38445253.length || C_98888256.f_38445253[id] == null) {
            return false;
        }
        if (id < C_81592558.f_44428008.length && C_81592558.f_44428008[id] != null) {
            return !isTechnicalBlock(id) && !hasSeparateItem(id);
        }
        return true;
    }
}
