package com.periut.retroapi.commands;

import com.periut.retroapi.text.Texts;
import net.minecraft.unmapped.C_23078083;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_64041439;
import com.periut.retroapi.commands.util.ServerUtil;

/**
 * Builds command sources on the server side.
 *
 * <p>Feedback goes out as {@code §}-coded text for now; the rich-component channel upgrades that for
 * clients running the mod (see {@code com.periut.retroapi.commands.network}).
 */
public final class ServerCommandSources {
    private ServerCommandSources() {
    }

    public static RetroCommandSource forPlayer(final C_49202226 player) {
        final int level = ServerUtil.isOp(player.f_59008391) ? RetroCommandSource.LEVEL_OWNER : RetroCommandSource.LEVEL_ALL;

        return new RetroCommandSource(
            message -> ServerFeedback.send(player, message),
            player,
            player.f_94306729,
            new Position(player.f_78826675, player.f_31030949, player.f_97691941),
            player.f_80130373,
            player.f_03549461,
            player.f_59008391,
            level,
            ServerUtil.getServer(),
            false);
    }

    /** The console, or anything else beta hands to its command handler. Always fully privileged. */
    public static RetroCommandSource forConsole(final C_23078083 output) {
        final C_64041439 world = ServerUtil.getServer().f_58488472.length > 0 ? ServerUtil.getServer().f_58488472[0] : null;
        final Position position = world == null
            ? Position.ORIGIN
            : new Position(world.m_84569052().f_39781383, world.m_84569052().f_62514677, world.m_84569052().f_38078371);

        return new RetroCommandSource(
            message -> output.m_28323918(Texts.toLegacy(message)),
            null,
            world,
            position,
            0.0f,
            0.0f,
            output.m_64276922(),
            RetroCommandSource.LEVEL_OWNER,
            ServerUtil.getServer(),
            false);
    }

    /** Split out so the rich-message path has one place to hook into. */
    static final class ServerFeedback {
        private ServerFeedback() {
        }

        static void send(final C_49202226 player, final com.periut.retroapi.text.Text message) {
            com.periut.retroapi.commands.network.RichMessages.send(player, message);
        }
    }
}
