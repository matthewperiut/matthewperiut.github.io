package com.periut.retroapi.commands.argument;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.periut.retroapi.text.Text;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;

/** A parsed item reference: which item, and which subtype of it. */
public record ItemStackArgument(int itemId, int meta) {
    public static final DynamicCommandExceptionType UNKNOWN_ITEM = new DynamicCommandExceptionType(
        id -> Text.literal("Unknown item '" + id + "'"));

    public C_98888256 getItem() throws CommandSyntaxException {
        if (itemId < 0 || itemId >= C_98888256.f_38445253.length || C_98888256.f_38445253[itemId] == null) {
            throw UNKNOWN_ITEM.create(itemId);
        }
        return C_98888256.f_38445253[itemId];
    }

    public C_88708284 createStack(final int count) throws CommandSyntaxException {
        return new C_88708284(getItem(), count, meta);
    }

    public int getMaxCount() throws CommandSyntaxException {
        return getItem().m_03156313();
    }

    public String getName() {
        return ItemIds.nameOf(itemId);
    }
}
