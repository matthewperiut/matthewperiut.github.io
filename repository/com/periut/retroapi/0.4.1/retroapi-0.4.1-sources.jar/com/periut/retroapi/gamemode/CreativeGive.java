package com.periut.retroapi.gamemode;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_88708284;

/**
 * Handing a creative player the stack they clicked in the creative screen.
 *
 * <p>Beta's creative-less inventory has no notion of an infinite item source, so this is a plain
 * "put it in their inventory, or drop it at their feet if there is no room" - and it is the single
 * place that does it, so the mode check lives here rather than at each caller.
 */
public final class CreativeGive {
    private CreativeGive() {
    }

    /** @return false when the player is not entitled to it */
    public static boolean give(final C_40996800 player, final C_88708284 stack) {
        if (player == null || stack == null || stack.f_60602012 <= 0) {
            return false;
        }
        if (RetroGameModes.get(player) != RetroGameMode.CREATIVE) {
            return false;
        }

        final C_88708284 copy = stack.m_73216943();
        if (!player.f_29439708.m_21544200(copy)) {
            player.m_90783905(copy, false);
        }
        player.f_29439708.f_61641499 = true;
        return true;
    }

    /**
     * Sets one of the player's own slots outright - what the creative screen does when a stack is
     * dragged into the hotbar. Same permission check: a client saying it is in creative is not
     * evidence that it is.
     */
    public static boolean setSlot(final C_40996800 player, final int slot, final C_88708284 stack) {
        if (player == null || RetroGameModes.get(player) != RetroGameMode.CREATIVE) {
            return false;
        }
        if (slot < 0 || slot >= player.f_29439708.f_35249023.length) {
            return false;
        }

        player.f_29439708.f_35249023[slot] = stack;
        player.f_29439708.f_61641499 = true;
        return true;
    }
}
