package com.periut.retroapi.commands.dimension;

import java.util.Random;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_87391831;

public class BareTravelAgent extends C_87391831 {

    private final Random random = new Random();

    @Override
    public boolean m_80083400(C_64041439 level, C_42232651 entity) {
        return true;
    }

    @Override
    public boolean m_97885468(C_64041439 level, C_42232651 entity) {
        return true;
    }

    public boolean blockIsGood(int block, int meta) {
        return true;
    }
}
