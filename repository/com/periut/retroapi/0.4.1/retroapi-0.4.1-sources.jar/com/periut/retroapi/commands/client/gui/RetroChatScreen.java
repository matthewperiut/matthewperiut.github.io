package com.periut.retroapi.commands.client.gui;

import com.periut.retroapi.client.gui.RetroTextDrawer;
import com.periut.retroapi.client.gui.RetroClipboard;
import com.periut.retroapi.client.gui.RetroKeys;
import com.periut.retroapi.commands.client.ClientCommands;
import com.periut.retroapi.text.ClickEvent;
import com.periut.retroapi.text.HoverEvent;
import com.periut.retroapi.text.Style;
import com.periut.retroapi.client.gui.RetroTextField;
import com.periut.retroapi.text.Text;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.unmapped.C_85740840;

/**
 * The chat screen, opened with the chat key.
 *
 * <p>Written from scratch rather than grafted onto beta's {@code ChatScreen}, which is a single
 * string with a cursor pinned to its end. This one has modern Minecraft's behaviour: a real text
 * field with selection and clipboard support, live command colouring, a completion window, sent
 * message history on the arrow keys, a scrollable chat window behind it, and clickable, hoverable
 * chat lines.
 */
public class RetroChatScreen extends C_85740840 {
    /** Sent messages, newest last, kept for the session as modern's history is. */
    private static final List<String> HISTORY = new ArrayList<>();
    private static final int MAX_HISTORY = 100;

    private final String initialText;

    private RetroTextField input;
    private CommandSuggestor suggestor;
    private int historyIndex = -1;
    private String draft = "";
    /** Set while a left-drag that began in the input box is still going. */
    private boolean selecting;

    public RetroChatScreen() {
        this("");
    }

    public RetroChatScreen(final String initialText) {
        this.initialText = initialText;
    }

    @Override
    public void m_41805697() {
        // Beta only reports the first press of a held key unless repeats are asked for.
        Keyboard.enableRepeatEvents(true);

        historyIndex = -1;
        draft = "";

        input = new RetroTextField(f_11884601, f_05230747 - 8);
        input.setMaxLength(256);
        suggestor = new CommandSuggestor(this, input, f_11884601);
        input.setRenderTextProvider(suggestor::highlight);
        input.setChangedListener(text -> suggestor.refresh());
        input.setText(initialText);

        RetroChatHud.getInstance().reflow(Math.min(320, f_05230747 - 10));
    }

    @Override
    public void m_47002234() {
        Keyboard.enableRepeatEvents(false);
        RetroChatHud.getInstance().resetScroll();
    }

    @Override
    public void m_53520780() {
        input.tick();
    }

    @Override
    public boolean m_47190451() {
        return false;
    }

    @Override
    protected void m_29116903(final char typed, final int keyCode) {
        if (suggestor.keyPressed(typed, keyCode)) {
            return;
        }

        switch (keyCode) {
            case RetroKeys.ESCAPE -> f_78495264.m_52715402(null);
            case RetroKeys.RETURN, RetroKeys.NUMPAD_ENTER -> send();
            case RetroKeys.UP -> browseHistory(1);
            case RetroKeys.DOWN -> browseHistory(-1);
            case RetroKeys.PAGE_UP -> RetroChatHud.getInstance().scroll(RetroChatHud.PAGE_LINES);
            case RetroKeys.PAGE_DOWN -> RetroChatHud.getInstance().scroll(-RetroChatHud.PAGE_LINES);
            default -> {
                if (input.keyPressed(typed, keyCode)) {
                    // Typing invalidates where the player was in their history.
                    historyIndex = -1;
                }
            }
        }
    }

    private void send() {
        final String text = input.getText().trim();
        if (!text.isEmpty()) {
            remember(text);
            dispatch(text);
        }
        f_78495264.m_52715402(null);
    }

    private void dispatch(final String text) {
        if (!text.startsWith("/")) {
            f_78495264.f_28396371.m_52386447(text);
            return;
        }

        // On a server the server decides; in singleplayer this client is the only authority there is.
        if (ClientCommands.isRemote()) {
            f_78495264.f_28396371.m_52386447(text);
        } else {
            ClientCommands.execute(text.substring(1));
        }
    }

    private static void remember(final String message) {
        HISTORY.remove(message);
        HISTORY.add(message);
        while (HISTORY.size() > MAX_HISTORY) {
            HISTORY.remove(0);
        }
    }

    /** @param direction 1 for older, -1 for newer */
    private void browseHistory(final int direction) {
        if (HISTORY.isEmpty()) {
            return;
        }

        if (historyIndex == -1) {
            if (direction < 0) {
                return;
            }
            draft = input.getText();
        }

        final int next = historyIndex + direction;
        if (next < -1 || next >= HISTORY.size()) {
            return;
        }

        historyIndex = next;
        input.setText(historyIndex == -1 ? draft : HISTORY.get(HISTORY.size() - 1 - historyIndex));
    }

    @Override
    protected void m_23755539(final int mouseX, final int mouseY, final int button) {
        if (suggestor.mouseClicked(mouseX, mouseY, button)) {
            return;
        }

        if (button == 0) {
            final Style style = RetroChatHud.getInstance().getStyleAt(mouseX, mouseY);
            if (style != null && handleClick(style)) {
                return;
            }

            if (mouseY >= f_07021018 - 14) {
                input.click(mouseX - 4, RetroKeys.isShiftDown());
                selecting = true;
                return;
            }
        }

        super.m_23755539(mouseX, mouseY, button);
    }

    /** @return whether the click was consumed by a chat component */
    private boolean handleClick(final Style style) {
        final ClickEvent event = style.getClickEvent();
        if (event == null) {
            return false;
        }

        switch (event.getAction()) {
            case RUN_COMMAND -> {
                final String command = event.getValue();
                remember(command);
                dispatch(command);
                f_78495264.m_52715402(null);
            }
            case SUGGEST_COMMAND -> input.setText(event.getValue());
            case COPY_TO_CLIPBOARD -> RetroClipboard.write(event.getValue());
            case OPEN_URL -> openUrl(event.getValue());
            default -> {
                return false;
            }
        }

        return true;
    }

    private void openUrl(final String url) {
        try {
            java.awt.Desktop.getDesktop().browse(new java.net.URI(url));
        } catch (final Exception ignored) {
            // No browser, no desktop, or a malformed link - none of it worth a crash.
        }
    }

    /**
     * Beta routes every mouse event through here, wheel included, and the wheel is the only way to
     * reach chat scrollback.
     */
    @Override
    public void m_29921564() {
        super.m_29921564();

        final int wheel = Mouse.getEventDWheel();
        if (wheel == 0) {
            return;
        }

        final int lines = wheel > 0 ? 1 : -1;
        if (!suggestor.mouseScrolled(lines)) {
            RetroChatHud.getInstance().scroll(lines * (RetroKeys.isControlDown() ? RetroChatHud.PAGE_LINES : 1));
        }
    }

    @Override
    public void m_93956703(final int mouseX, final int mouseY, final float delta) {
        // Beta reports presses and releases and nothing in between, so dragging the cursor across
        // the text to select it means following the held button ourselves, frame by frame.
        if (selecting) {
            if (Mouse.isButtonDown(0)) {
                // Selecting, so the anchor the press dropped stays where it is.
                input.click(mouseX - 4, true);
            } else {
                selecting = false;
            }
        }

        // The chat window itself is drawn by the HUD, which runs before any screen; drawing it
        // again here would stack its translucent backgrounds.
        m_57734177(2, f_07021018 - 14, f_05230747 - 2, f_07021018 - 2, 0x80000000);
        input.render(4, f_07021018 - 12);

        suggestor.render(mouseX, mouseY);

        final Style style = RetroChatHud.getInstance().getStyleAt(mouseX, mouseY);
        if (style != null && style.getHoverEvent() != null) {
            renderTooltip(style.getHoverEvent(), mouseX, mouseY);
        }

        super.m_93956703(mouseX, mouseY, delta);
    }

    private void renderTooltip(final HoverEvent hover, final int mouseX, final int mouseY) {
        if (hover.getAction() != HoverEvent.Action.SHOW_TEXT || hover.getValue() == null) {
            return;
        }

        final RetroTextDrawer.Line line = RetroTextDrawer.flatten(hover.getValue());
        final int textWidth = RetroTextDrawer.INSTANCE.width(f_11884601, line);
        final int x = Math.min(mouseX + 6, f_05230747 - textWidth - 6);
        final int y = Math.max(mouseY - 12, 2);

        m_57734177(x - 3, y - 3, x + textWidth + 3, y + 9, 0xF0100010);
        RetroTextDrawer.INSTANCE.draw(f_11884601, line, x, y, 255);
    }

    /** So other code can open chat with something already typed, e.g. a command suggestion. */
    public static RetroChatScreen withText(final Text text) {
        return new RetroChatScreen(text.getString());
    }
}
