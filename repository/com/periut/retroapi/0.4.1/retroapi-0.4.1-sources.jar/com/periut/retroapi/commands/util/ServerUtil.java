package com.periut.retroapi.commands.util;

import com.periut.retroapi.commands.RetroCommands;
import com.periut.retroapi.commands.RetroCommandsNetworking;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.unmapped.C_29639016;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_49202226;
import net.ornithemc.osl.networking.api.server.ServerPlayNetworking;

import java.util.logging.Logger;

/** Server-side odds and ends the commands and the networking code share. */
public class ServerUtil {
    public static Logger LOGGER = Logger.getLogger("Minecraft");

    public static MinecraftServer getServer() {
        return (MinecraftServer) FabricLoader.getInstance().getGameInstance();
    }

    public static C_29639016 getConnectionManager() {
        return getServer().f_65897993;
    }

    /** Announces an operator's action to everyone and writes it to the log, as vanilla does. */
    public static void sendFeedbackAndLog(String user, String message) {
        String str = user + ": " + message;
        getConnectionManager().m_27308858("§7(" + str + ")");
        LOGGER.info(str);
    }

    public static boolean isOp(String name) {
        return getServer().f_65897993.m_55622692(name);
    }

    /** Moving a server player has to go through their connection, or only the server believes it. */
    public static void serverTeleport(C_40996800 p, double x, double y, double z) {
        C_49202226 sp = (C_49202226) p;
        sp.f_70275341.m_40197477(x, y, z, p.f_80130373, p.f_03549461);
    }

    /** Tells a client whether it is op, so its own command tree matches what the server allows. */
    public static void informPlayerOpStatus(String playerName) {
        C_49202226 player = getConnectionManager().m_77290284(playerName);
        if (player == null) return;
        ServerPlayNetworking.send(player, RetroCommandsNetworking.OP_CHANNEL, buffer -> {
            buffer.writeBoolean(isOp(playerName));
        });
    }

    public static void informPlayerDisabledCommands(String playerName) {
        C_49202226 player = getConnectionManager().m_77290284(playerName);
        if (player == null) return;
        ServerPlayNetworking.send(player, RetroCommandsNetworking.DISABLED_CHANNEL, buffer -> {
            if (!RetroCommands.cryConfig) {
                buffer.writeString("");
            } else {
                buffer.writeString(String.join(",", RetroCommands.disabled_commands));
            }
        });
    }
}
