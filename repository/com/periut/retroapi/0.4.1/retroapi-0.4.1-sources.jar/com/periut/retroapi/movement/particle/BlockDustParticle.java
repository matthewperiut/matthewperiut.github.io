package com.periut.retroapi.movement.particle;

import net.minecraft.unmapped.C_47540058;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_96603444;

public class BlockDustParticle
        extends C_47540058 {
    protected C_81592558 block;
    private int colorMultiplier = 0xFFFFFF;

    public BlockDustParticle(C_64041439 world, double x, double y, double z, double g, double h, double i, C_81592558 arg2, int j, int k) {
        super(world, x, y, z, g, h, i);
        this.block = arg2;
        //this.setMiscTexture(arg2.method_396(0, k));
        // set misc texture as 0
        // textureId
        this.f_63348640 = arg2.m_07414817(0, k);
        // note: should reference a variable in block for particle's gravity, but in newer versions not used.
        // gravityStrength
        this.f_38664157 = 1.0F;
        this.f_07440167 = 0.6f;
        this.f_10605225 = 0.6f;
        this.f_45507822 = 0.6f;
        this.f_11203543 /= 2.0f;

        if (block != C_81592558.f_41096518)
            colorMultiplier = this.block.m_42775736(this.f_94306729, (int)x, (int)y, (int)z);

        method_1301();
    }


    public void method_1301() {

        this.f_45507822 *= (float) (colorMultiplier >> 16 & 0xFF) / 255.0f;
        this.f_10605225 *= (float) (colorMultiplier >> 8 & 0xFF) / 255.0f;
        this.f_07440167 *= (float) (colorMultiplier & 0xFF) / 255.0f;
    }

    // getLayer
    @Override
    public int m_89634559() {
        return 1;
    }

    @Override
    public void m_32469004(C_96603444 arg, float f, float g, float h, float i, float j, float k) {
        // Check if the block is grass and apply a green tint
        if (this.block == C_81592558.f_00276986) {
            this.f_45507822 = 0.0f;   // No red
            this.f_10605225 = 1.0f; // Full green
            this.f_07440167 = 0.0f;  // No blue
        }

        // Get texture coordinates for the particle
        float f2 = ((float) (this.f_63348640 % 16) + this.f_76706888 / 4.0f) / 16.0f;
        float f3 = f2 + 0.015609375f;
        float f4 = ((float) (this.f_63348640 / 16) + this.f_34520038 / 4.0f) / 16.0f;
        float f5 = f4 + 0.015609375f;

        // Set particle scale (size)
        float f6 = 0.1f * this.f_11203543;

        // Particle position adjustments
        float f7 = (float) (this.f_59999765 + (this.f_78826675 - this.f_59999765) * (double) f - f_37914722);
        float f8 = (float) (this.f_90348373 + (this.f_31030949 - this.f_90348373) * (double) f - f_59479165);
        float f9 = (float) (this.f_88346412 + (this.f_97691941 - this.f_88346412) * (double) f - f_68501249);

        // Set the color using the red, green, and blue values
        float f10 = 1.0f;
        arg.m_73671468(f10 * this.f_45507822, f10 * this.f_10605225, f10 * this.f_07440167);

        // Render the particle
        arg.m_75942980(f7 - g * f6 - j * f6, f8 - h * f6, f9 - i * f6 - k * f6, f2, f5);
        arg.m_75942980(f7 - g * f6 + j * f6, f8 + h * f6, f9 - i * f6 + k * f6, f2, f4);
        arg.m_75942980(f7 + g * f6 + j * f6, f8 + h * f6, f9 + i * f6 + k * f6, f3, f4);
        arg.m_75942980(f7 + g * f6 - j * f6, f8 - h * f6, f9 + i * f6 - k * f6, f3, f5);
    }

}