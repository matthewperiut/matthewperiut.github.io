package com.periut.retroapi.mixin.movement.client;

import com.periut.retroapi.movement.client.SwimRenderState;
import com.periut.retroapi.movement.util.MathUtil;
import net.minecraft.unmapped.C_36076665;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_82280655;
import net.minecraft.unmapped.C_94760802;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * HumanoidModel.setupAnim's swimming branch, ported one to one. Modern names map onto beta's as
 * xRot/yRot/zRot -> pitch/yaw/roll, walkAnimationPos -> limbAngle and swimAmount -> the blend
 * that fades the whole thing in as the body tips over.
 */
@Mixin(C_82280655.class)
public abstract class BipedEntityModelMixin extends C_36076665 {
    @Shadow
    public C_94760802 head;

    @Shadow
    public C_94760802 hat;

    @Shadow
    public C_94760802 rightArm;

    @Shadow
    public C_94760802 leftArm;

    @Shadow
    public C_94760802 rightLeg;

    @Shadow
    public C_94760802 leftLeg;

    @Inject(method = "setAngles", at = @At("TAIL"))
    private void retroapi$swimAnimation(float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch, float scale, CallbackInfo ci) {
        float swimAmount = SwimRenderState.swimAmount();
        if (swimAmount <= 0.0F) {
            return;
        }

        // The head tips up towards the direction of travel as the body goes flat.
        this.head.f_15806199 = MathUtil.rotLerpRad(swimAmount, this.head.f_15806199, (float) (-Math.PI / 4));
        this.hat.f_15806199 = this.head.f_15806199;

        // Beta only ever swings the right arm, so that is the one an attack takes over from the
        // stroke; modern skips whichever arm is mid-swing the same way.
        float rightArmSwimAmount = this.f_48140049 > 0.0F ? 0.0F : swimAmount;
        float leftArmSwimAmount = swimAmount;

        float swimPos = limbAngle % 26.0F;
        if (swimPos < 14.0F) {
            this.leftArm.f_15806199 = MathUtil.rotLerpRad(leftArmSwimAmount, this.leftArm.f_15806199, 0.0F);
            this.rightArm.f_15806199 = MathUtil.lerp(rightArmSwimAmount, this.rightArm.f_15806199, 0.0F);
            this.leftArm.f_79014262 = MathUtil.rotLerpRad(leftArmSwimAmount, this.leftArm.f_79014262, (float) Math.PI);
            this.rightArm.f_79014262 = MathUtil.lerp(rightArmSwimAmount, this.rightArm.f_79014262, (float) Math.PI);
            this.leftArm.f_52640217 = MathUtil.rotLerpRad(
                    leftArmSwimAmount, this.leftArm.f_52640217,
                    (float) Math.PI + 1.8707964F * this.retroapi$quadraticArmUpdate(swimPos) / this.retroapi$quadraticArmUpdate(14.0F)
            );
            this.rightArm.f_52640217 = MathUtil.lerp(
                    rightArmSwimAmount, this.rightArm.f_52640217,
                    (float) Math.PI - 1.8707964F * this.retroapi$quadraticArmUpdate(swimPos) / this.retroapi$quadraticArmUpdate(14.0F)
            );
        } else if (swimPos < 22.0F) {
            float internalSwimPos = (swimPos - 14.0F) / 8.0F;
            this.leftArm.f_15806199 = MathUtil.rotLerpRad(leftArmSwimAmount, this.leftArm.f_15806199, (float) (Math.PI / 2) * internalSwimPos);
            this.rightArm.f_15806199 = MathUtil.lerp(rightArmSwimAmount, this.rightArm.f_15806199, (float) (Math.PI / 2) * internalSwimPos);
            this.leftArm.f_79014262 = MathUtil.rotLerpRad(leftArmSwimAmount, this.leftArm.f_79014262, (float) Math.PI);
            this.rightArm.f_79014262 = MathUtil.lerp(rightArmSwimAmount, this.rightArm.f_79014262, (float) Math.PI);
            this.leftArm.f_52640217 = MathUtil.rotLerpRad(leftArmSwimAmount, this.leftArm.f_52640217, 5.012389F - 1.8707964F * internalSwimPos);
            this.rightArm.f_52640217 = MathUtil.lerp(rightArmSwimAmount, this.rightArm.f_52640217, 1.2707963F + 1.8707964F * internalSwimPos);
        } else if (swimPos < 26.0F) {
            float internalSwimPos = (swimPos - 22.0F) / 4.0F;
            this.leftArm.f_15806199 = MathUtil.rotLerpRad(leftArmSwimAmount, this.leftArm.f_15806199, (float) (Math.PI / 2) - (float) (Math.PI / 2) * internalSwimPos);
            this.rightArm.f_15806199 = MathUtil.lerp(rightArmSwimAmount, this.rightArm.f_15806199, (float) (Math.PI / 2) - (float) (Math.PI / 2) * internalSwimPos);
            this.leftArm.f_79014262 = MathUtil.rotLerpRad(leftArmSwimAmount, this.leftArm.f_79014262, (float) Math.PI);
            this.rightArm.f_79014262 = MathUtil.lerp(rightArmSwimAmount, this.rightArm.f_79014262, (float) Math.PI);
            this.leftArm.f_52640217 = MathUtil.rotLerpRad(leftArmSwimAmount, this.leftArm.f_52640217, (float) Math.PI);
            this.rightArm.f_52640217 = MathUtil.lerp(rightArmSwimAmount, this.rightArm.f_52640217, (float) Math.PI);
        }

        // Legs flutter-kick, out of phase with each other and slower than the arm stroke.
        this.leftLeg.f_15806199 = MathUtil.lerp(swimAmount, this.leftLeg.f_15806199, 0.3F * C_45510667.m_64246150(limbAngle * 0.33333334F + (float) Math.PI));
        this.rightLeg.f_15806199 = MathUtil.lerp(swimAmount, this.rightLeg.f_15806199, 0.3F * C_45510667.m_64246150(limbAngle * 0.33333334F));
    }

    @Unique
    private float retroapi$quadraticArmUpdate(float x) {
        return -65.0F * x + x * x;
    }
}
