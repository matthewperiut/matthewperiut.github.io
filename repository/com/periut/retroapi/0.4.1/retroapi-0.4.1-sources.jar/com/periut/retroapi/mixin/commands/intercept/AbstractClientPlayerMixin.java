package com.periut.retroapi.mixin.commands.intercept;

import com.periut.retroapi.commands.client.ClientCommands;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_57778754;
import net.fabricmc.loader.api.FabricLoader;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Runs singleplayer commands.
 *
 * <p>Beta has no integrated server, so there is nowhere to send a command to: the client executes it
 * against its own world. Anything else typed becomes a local chat line, because there is no server
 * to echo it back either.
 */
@Mixin(C_57778754.class)
public class AbstractClientPlayerMixin {
    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    public void retroapi$runLocally(final String message, final CallbackInfo ci) {
        final Minecraft minecraft = (Minecraft) FabricLoader.getInstance().getGameInstance();
        if (minecraft.m_38583715()) {
            return;
        }

        if (message.startsWith("/")) {
            ClientCommands.execute(message.substring(1));
        } else {
            final C_40996800 player = (C_40996800) (Object) this;
            minecraft.f_28235293.m_81906308("<" + player.f_59008391 + "> " + message);
        }

        ci.cancel();
    }
}
