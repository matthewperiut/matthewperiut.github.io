package com.periut.retroapi.commandblock;

import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.unmapped.C_40735137;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_73452336;
import net.minecraft.unmapped.C_89604096;
import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.FabricLoader;

/**
 * The command block itself.
 *
 * <p>Everything that decides <em>when</em> it runs lives in {@link CommandBlockExecutor}; this is the
 * block: it holds a {@link CommandBlockEntity}, it opens the editing screen when an operator uses it,
 * and it reacts to redstone.
 */
public class CommandBlock extends C_73452336 {

    public CommandBlock(final int id) {
        super(id, C_89604096.f_64385500);
    }

    @Override
    protected C_40735137 m_22794655() {
        return new CommandBlockEntity();
    }

    @Override
    public void m_91032811(final C_64041439 world, final int x, final int y, final int z, final int neighborId) {
        CommandBlockExecutor.onNeighborUpdate(world, x, y, z);
    }

    @Override
    public boolean m_39069644(final C_64041439 world, final int x, final int y, final int z, final C_40996800 player) {
        // Modern gates this on canUseGameMasterBlocks(): creative only, which is also the only way to
        // get one of these in the first place.
        if (player == null
            || com.periut.retroapi.gamemode.RetroGameModes.get(player)
                != com.periut.retroapi.gamemode.RetroGameMode.CREATIVE) {
            return false;
        }
        // Two separate reasons for this shape.
        //
        // NOT gated on world.isRemote: in beta singleplayer the client's own world is not remote, so
        // that check opened the editor on a server and nowhere else.
        //
        // Gated on the ENVIRONMENT, and reaching the screen through a class this one never names:
        // CommandBlockScreens touches Minecraft, whose fields name ClientPlayerEntity, and a dedicated
        // server refuses to load that class at all. A static call here would resolve it while verifying
        // onUse and take the server down with "Cannot load class ... in environment type SERVER".
        if (FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT) {
            openEditor(player, x, y, z);
        }
        return true;
    }

    @Override
    public void m_93454127(final C_64041439 world, final int x, final int y, final int z,
            final net.minecraft.unmapped.C_74425583 placer) {
        super.m_93454127(world, x, y, z, placer);
        CommandBlockExecutor.onPlaced(world, x, y, z);
    }

    /**
     * Reflective on purpose: naming {@code CommandBlockScreens} here would put a client-only class in
     * this class's constant pool, and this class is loaded on every dedicated server.
     */
    private static void openEditor(final C_40996800 player, final int x, final int y, final int z) {
        try {
            Class.forName("com.periut.retroapi.client.screen.CommandBlockScreens")
                .getMethod("openFor", C_40996800.class, int.class, int.class, int.class)
                .invoke(null, player, x, y, z);
        } catch (final ReflectiveOperationException | LinkageError ignored) {
            // No screen in this environment; the block still works, it just cannot be edited here.
        }
    }

    /** Repeat blocks need a tick of their own; the executor decides whether this one does anything. */
    @Override
    public void m_56075420(final C_64041439 world, final int x, final int y, final int z, final java.util.Random random) {
        CommandBlockExecutor.onScheduledTick(world, x, y, z);
    }

    @Override
    public boolean m_57757663() {
        return true;
    }
}
