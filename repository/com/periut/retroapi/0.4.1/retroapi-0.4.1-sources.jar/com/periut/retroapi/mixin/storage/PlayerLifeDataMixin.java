package com.periut.retroapi.mixin.storage;

import com.periut.retroapi.storage.RetroData;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_74425583;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Ends a player's "life" for {@link RetroData#life}.
 *
 * <p>Hung on the death itself rather than on the respawn because {@code PlayerEntity.respawn()} is a
 * CLIENT-only method in b1.7.3 - it does not exist on a dedicated server, where most of this data
 * lives. {@code LivingEntity.onKilledBy} exists on both sides and is the one place every death goes
 * through, so one mixin covers singleplayer and servers alike.
 */
@Mixin(C_74425583.class)
public class PlayerLifeDataMixin {

	@Inject(method = "onKilledBy", at = @At("HEAD"))
	private void retroapi$clearLifeData(C_42232651 killer, CallbackInfo ci) {
		if ((Object) this instanceof C_40996800 player) {
			RetroData.clearLife(player.f_59008391);
		}
	}
}
