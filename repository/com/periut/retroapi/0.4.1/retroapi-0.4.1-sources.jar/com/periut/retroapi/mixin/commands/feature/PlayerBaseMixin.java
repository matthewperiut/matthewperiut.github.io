package com.periut.retroapi.mixin.commands.feature;

import com.periut.retroapi.commands.api.PlayerWarps;
import com.periut.retroapi.commands.builtin.GodCommand;
import com.periut.retroapi.gamemode.RetroFlight;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_74087615;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// Priority 999 to cancel fire even when in creative, because creative also cancels here.
// BHCreative uses priority 1000
@Mixin(value = C_40996800.class, priority = 999)
public class PlayerBaseMixin implements PlayerWarps {
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    public void onGod(C_42232651 i, int par2, CallbackInfoReturnable<Boolean> cir) {
        C_40996800 player = (C_40996800) (Object) this;

        if (GodCommand.isInvincible(player.f_59008391)) {
            if (player.f_56993461 > 0) {
                player.f_56993461 = 0;
            }
            cir.cancel();
        }
    }

    /**
     * A player who passes through terrain is never inside a wall, however far inside one they are.
     *
     * <p>One override for two symptoms, because beta asks this same question for both: {@code LivingEntity}'s
     * base tick suffocates anyone it returns true for, and {@code HeldItemRenderer.renderScreenOverlays} plasters
     * the block's texture over the whole screen. Flying through rock does neither if the answer is no.
     */
    @Inject(method = "isInsideWall", at = @At("HEAD"), cancellable = true)
    private void retroapi$noclipIgnoresWalls(CallbackInfoReturnable<Boolean> cir) {
        if (RetroFlight.ignoresBlocks(((C_40996800) (Object) this).f_59008391)) {
            cir.setReturnValue(false);
        }
    }

    @Unique
    String warpStr = "";

    @Override
    public void spc$setWarpString(String warp) {
        warpStr = warp;
    }

    @Override
    public String spc$getWarpString() {
        return warpStr;
    }

    @Inject(method = "readNbt", at = @At("TAIL"))
    private void readFromTag(C_74087615 tag, CallbackInfo ci) {
        if (tag.m_97612750("warps")) warpStr = tag.m_47517355("warps");
    }

    @Inject(method = "writeNbt", at = @At("TAIL"))
    private void writeToTag(C_74087615 tag, CallbackInfo ci) {
        if (!warpStr.isEmpty()) tag.m_91017064("warps", warpStr);
    }
}
