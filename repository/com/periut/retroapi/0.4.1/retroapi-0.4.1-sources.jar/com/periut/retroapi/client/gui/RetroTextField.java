package com.periut.retroapi.client.gui;

import com.periut.retroapi.client.gui.RetroClipboard;
import com.periut.retroapi.client.gui.RetroKeys;
import com.periut.retroapi.client.gui.RetroTextDrawer;

import com.periut.retroapi.text.Style;
import com.periut.retroapi.text.Texts;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_29058632;
import net.minecraft.unmapped.C_77279411;

/**
 * A text field: RetroAPI's backport of modern Minecraft's {@code EditBox}.
 *
 * <p>Beta's own text field is a single string with a cursor pinned to the end - no selection, no
 * scrolling, no keyboard shortcuts. This one has all of it: a cursor and a selection anchor,
 * {@code Ctrl+A/C/X/V}, word-wise movement and deletion with {@code Ctrl}, {@code Home} and
 * {@code End}, shift-selection, arrows that collapse a selection to its edge, a window that scrolls
 * horizontally when the text outruns the box, and grey ghost text for a suggested completion.
 *
 * <p>Nothing about it is chat-specific, which is why it is here rather than in the chat package: it
 * is the field behind the chat bar, the command block editor and the creative search box alike, and
 * a mod wanting a usable text box in beta should reach for this rather than write a fourth one.
 *
 * <pre>{@code
 * field = new RetroTextField(textRenderer, 200);   // width in pixels
 * field.setMaxLength(64);
 * field.setChangedListener(text -> ...);
 *
 * // in the screen: keyPressed -> field.keyPressed(typed, keyCode)
 * //                mouseClicked -> field.click(mouseX - textX, RetroKeys.isShiftDown())
 * //                tick -> field.tick()      (drives the cursor blink)
 * //                render -> field.render(textX, textY)
 * }</pre>
 */
public class RetroTextField extends C_29058632 {
    private static final int CURSOR_BLINK_TICKS = 6;
    private static final int TEXT_COLOR = 0xE0E0E0;
    private static final int SELECTION_COLOR = 0xFF3030C0;

    private final C_23014920 textRenderer;
    private final int width;

    /** Modern's {@code EditBox.setTextColor}: chat keeps the default, the creative search box is white. */
    private int textColor = TEXT_COLOR;

    private String text = "";
    private int maxLength = 256;
    private int cursor;
    private int selectionAnchor;
    private int firstCharacterIndex;
    private int focusedTicks;
    private String suggestion = "";

    private Consumer<String> changedListener = ignored -> {
    };
    /** Given the visible slice and where it starts, returns how to colour it. */
    private BiFunction<String, Integer, RetroTextDrawer.Line> renderTextProvider =
        (visible, firstIndex) -> new RetroTextDrawer.Line(List.of(new Texts.Segment(visible, Style.EMPTY)));

    public RetroTextField(final C_23014920 textRenderer, final int width) {
        this.textRenderer = textRenderer;
        this.width = width;
    }

    public void setChangedListener(final Consumer<String> listener) {
        this.changedListener = listener;
    }

    public void setRenderTextProvider(final BiFunction<String, Integer, RetroTextDrawer.Line> provider) {
        this.renderTextProvider = provider;
    }

    public void setMaxLength(final int maxLength) {
        this.maxLength = maxLength;
    }

    public void setTextColor(final int textColor) {
        this.textColor = textColor;
    }

    public String getText() {
        return text;
    }

    public void setText(final String text) {
        final String trimmed = text.length() > maxLength ? text.substring(0, maxLength) : text;
        this.text = trimmed;
        setCursor(trimmed.length());
        setSelectionAnchor(cursor);
        onChanged();
    }

    public int getCursor() {
        return cursor;
    }

    public void setCursor(final int position) {
        cursor = Math.max(0, Math.min(text.length(), position));
        clampScroll();
    }

    public void setSelectionAnchor(final int position) {
        selectionAnchor = Math.max(0, Math.min(text.length(), position));
    }

    public String getSelectedText() {
        final int start = Math.min(cursor, selectionAnchor);
        final int end = Math.max(cursor, selectionAnchor);
        return text.substring(start, end);
    }

    /** Grey text drawn after the cursor; the suggestor uses it to preview a completion. */
    public void setSuggestion(final String suggestion) {
        this.suggestion = suggestion == null ? "" : suggestion;
    }

    public void tick() {
        focusedTicks++;
    }

    public void write(final String written) {
        final StringBuilder filtered = new StringBuilder();
        for (int i = 0; i < written.length(); i++) {
            final char c = written.charAt(i);
            if (C_77279411.f_42800273.indexOf(c) >= 0) {
                filtered.append(c);
            }
        }

        final int start = Math.min(cursor, selectionAnchor);
        final int end = Math.max(cursor, selectionAnchor);
        final int room = maxLength - text.length() + (end - start);
        if (room <= 0) {
            return;
        }

        final String insertion = filtered.length() > room ? filtered.substring(0, room) : filtered.toString();
        text = text.substring(0, start) + insertion + text.substring(end);
        setCursor(start + insertion.length());
        setSelectionAnchor(cursor);
        onChanged();
    }

    /**
     * @param keyCode an LWJGL key code, as beta's screens receive them
     * @return whether the field handled it
     */
    public boolean keyPressed(final char typed, final int keyCode) {
        final boolean control = RetroKeys.isControlDown();
        final boolean shift = RetroKeys.isShiftDown();

        if (control) {
            switch (keyCode) {
                case RetroKeys.A -> {
                    setCursor(text.length());
                    setSelectionAnchor(0);
                    return true;
                }
                case RetroKeys.C -> {
                    RetroClipboard.write(getSelectedText());
                    return true;
                }
                case RetroKeys.V -> {
                    write(RetroClipboard.read());
                    return true;
                }
                case RetroKeys.X -> {
                    RetroClipboard.write(getSelectedText());
                    write("");
                    return true;
                }
                default -> {
                    // Fall through to the shared handling below.
                }
            }
        }

        switch (keyCode) {
            case RetroKeys.BACKSPACE -> {
                if (control) {
                    eraseWords(-1);
                } else {
                    erase(-1);
                }
                return true;
            }
            case RetroKeys.DELETE -> {
                if (control) {
                    eraseWords(1);
                } else {
                    erase(1);
                }
                return true;
            }
            case RetroKeys.LEFT -> {
                // With text selected and no shift held, the arrow collapses the selection to its edge
                // rather than stepping one character from wherever the cursor happens to be - which is
                // what every text field does, and what makes "select, then left" put you before the
                // selection instead of somewhere inside it.
                if (!shift && !control && cursor != selectionAnchor) {
                    setCursor(Math.min(cursor, selectionAnchor));
                    setSelectionAnchor(cursor);
                    return true;
                }
                moveCursor(control ? wordSkipPosition(-1) - cursor : -1, shift);
                return true;
            }
            case RetroKeys.RIGHT -> {
                if (!shift && !control && cursor != selectionAnchor) {
                    setCursor(Math.max(cursor, selectionAnchor));
                    setSelectionAnchor(cursor);
                    return true;
                }
                moveCursor(control ? wordSkipPosition(1) - cursor : 1, shift);
                return true;
            }
            case RetroKeys.HOME -> {
                moveCursor(-cursor, shift);
                return true;
            }
            case RetroKeys.END -> {
                moveCursor(text.length() - cursor, shift);
                return true;
            }
            default -> {
                if (C_77279411.f_42800273.indexOf(typed) >= 0) {
                    write(String.valueOf(typed));
                    return true;
                }
                return false;
            }
        }
    }

    private void moveCursor(final int offset, final boolean select) {
        setCursor(cursor + offset);
        if (!select) {
            setSelectionAnchor(cursor);
        }
    }

    /** Removes the selection if there is one, otherwise the character in the given direction. */
    public void erase(final int direction) {
        if (cursor != selectionAnchor) {
            write("");
            return;
        }

        final int target = Math.max(0, Math.min(text.length(), cursor + direction));
        if (target == cursor) {
            return;
        }

        final int start = Math.min(target, cursor);
        final int end = Math.max(target, cursor);
        text = text.substring(0, start) + text.substring(end);
        setCursor(start);
        setSelectionAnchor(cursor);
        onChanged();
    }

    public void eraseWords(final int direction) {
        if (cursor != selectionAnchor) {
            write("");
            return;
        }
        erase(wordSkipPosition(direction) - cursor);
    }

    /** Where the cursor lands after a {@code Ctrl}-arrow: past the run of spaces, then the word. */
    private int wordSkipPosition(final int direction) {
        int position = cursor;

        if (direction < 0) {
            while (position > 0 && text.charAt(position - 1) == ' ') {
                position--;
            }
            while (position > 0 && text.charAt(position - 1) != ' ') {
                position--;
            }
        } else {
            final int length = text.length();
            while (position < length && text.charAt(position) == ' ') {
                position++;
            }
            while (position < length && text.charAt(position) != ' ') {
                position++;
            }
        }

        return position;
    }

    /** @param x the mouse position relative to the left edge of the field's text */
    public void click(final int x, final boolean select) {
        final String visible = visibleText();
        final int index = firstCharacterIndex + charIndexAt(visible, x);
        setCursor(index);
        if (!select) {
            setSelectionAnchor(cursor);
        }
    }

    private int charIndexAt(final String visible, final int x) {
        int accumulated = 0;
        for (int i = 0; i < visible.length(); i++) {
            final int charWidth = textRenderer.m_09235706(String.valueOf(visible.charAt(i)));
            // Past the halfway point of a character means the cursor belongs after it.
            if (x < accumulated + charWidth / 2) {
                return i;
            }
            accumulated += charWidth;
        }
        return visible.length();
    }

    public void render(final int x, final int y) {
        final String visible = visibleText();
        final int cursorOffset = textRenderer.m_09235706(text.substring(firstCharacterIndex, Math.max(firstCharacterIndex, cursor)));

        if (cursor != selectionAnchor) {
            renderSelection(x, y, visible);
        }

        RetroTextDrawer.INSTANCE.draw(textRenderer, renderTextProvider.apply(visible, firstCharacterIndex), x, y, textColor, 255);

        if (!suggestion.isEmpty()) {
            m_62884682(textRenderer, suggestion, x + textRenderer.m_09235706(visible), y, 0x808080);
        }

        if (focusedTicks / CURSOR_BLINK_TICKS % 2 == 0) {
            final int cursorX = x + cursorOffset;
            if (cursor < text.length()) {
                m_57734177(cursorX, y - 1, cursorX + 1, y + 9, 0xFFD0D0D0);
            } else {
                m_62884682(textRenderer, "_", cursorX, y, textColor);
            }
        }
    }

    private void renderSelection(final int x, final int y, final String visible) {
        final int start = Math.max(Math.min(cursor, selectionAnchor), firstCharacterIndex);
        final int end = Math.min(Math.max(cursor, selectionAnchor), firstCharacterIndex + visible.length());
        if (start >= end) {
            return;
        }

        final int startX = x + textRenderer.m_09235706(text.substring(firstCharacterIndex, start));
        final int endX = x + textRenderer.m_09235706(text.substring(firstCharacterIndex, end));
        m_57734177(startX, y - 1, endX, y + 9, SELECTION_COLOR);
    }

    /** The slice of the text that fits in the box, given where the window has scrolled to. */
    public String visibleText() {
        final int available = width;
        int accumulated = 0;
        int index = firstCharacterIndex;

        while (index < text.length()) {
            final int charWidth = textRenderer.m_09235706(String.valueOf(text.charAt(index)));
            if (accumulated + charWidth > available) {
                break;
            }
            accumulated += charWidth;
            index++;
        }

        return text.substring(firstCharacterIndex, index);
    }

    public int getFirstCharacterIndex() {
        return firstCharacterIndex;
    }

    /** Keeps the cursor inside the visible window, scrolling it into view from either side. */
    private void clampScroll() {
        if (firstCharacterIndex > text.length()) {
            firstCharacterIndex = text.length();
        }

        if (cursor < firstCharacterIndex) {
            firstCharacterIndex = cursor;
        } else {
            while (firstCharacterIndex < cursor
                && textRenderer.m_09235706(text.substring(firstCharacterIndex, cursor)) > width) {
                firstCharacterIndex++;
            }
        }

        // Springs back when the text shrinks. Without this the window only ever moves right: delete
        // the tail of a long line and the box sits half empty with the start of the line still
        // scrolled off it. Modern's EditBox pulls its own displayPos back for the same reason.
        while (firstCharacterIndex > 0
            && textRenderer.m_09235706(text.substring(firstCharacterIndex - 1)) <= width) {
            firstCharacterIndex--;
        }
    }

    private void onChanged() {
        suggestion = "";
        changedListener.accept(text);
    }

}
