package com.periut.retroapi.mixin.gamemode;

import com.periut.retroapi.gamemode.RetroGameMode;
import com.periut.retroapi.gamemode.RetroGameModes;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Tools do not wear out in creative, which is modern's rule and beta has no notion of.
 *
 * <p>At {@code ItemStack.damage} rather than at the places that call it: mining, attacking, shearing,
 * flint and steel, a bow drawn, a mod's own tool - all of them arrive here, so stating it once covers
 * every one of them and anything added later.
 *
 * <p>The whole call is skipped, not just the breaking: a creative pickaxe that quietly accumulated
 * damage would be handed back to a player who left creative already half worn out.
 */
@Mixin(C_88708284.class)
public class CreativeNoDurabilityMixin {

	@Inject(method = "damage", at = @At("HEAD"), cancellable = true)
	private void retroapi$creativeSpendsNoDurability(int amount, C_42232651 holder, CallbackInfo ci) {
		if (holder instanceof C_40996800 player
			&& RetroGameModes.get(player) == RetroGameMode.CREATIVE) {
			ci.cancel();
		}
	}
}
