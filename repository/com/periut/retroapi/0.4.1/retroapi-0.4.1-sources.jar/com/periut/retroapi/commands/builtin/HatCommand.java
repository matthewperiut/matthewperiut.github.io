package com.periut.retroapi.commands.builtin;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.periut.retroapi.commands.RegistrationEnvironment;
import com.periut.retroapi.commands.RetroCommandSource;
import com.periut.retroapi.text.Text;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_88708284;

import static com.periut.retroapi.commands.RetroCommandManager.literal;

/** {@code /hat} - swaps the held item with whatever is on your head. */
public final class HatCommand {
    private static final int HELMET_SLOT = 3;

    private HatCommand() {
    }

    public static void register(final CommandDispatcher<RetroCommandSource> dispatcher, final RegistrationEnvironment environment) {
        dispatcher.register(literal("hat")
            .requires(source -> source.hasPermissionLevel(RetroCommandSource.LEVEL_MODERATOR))
            .executes(context -> {
                final RetroCommandSource source = context.getSource();
                final C_40996800 player = source.getPlayerOrThrow();

                final C_88708284 held = player.f_29439708.m_27760697() == null ? null : player.f_29439708.m_27760697().m_73216943();
                final C_88708284 worn = player.f_29439708.f_52412003[HELMET_SLOT] == null ? null : player.f_29439708.f_52412003[HELMET_SLOT].m_73216943();

                player.f_29439708.f_52412003[HELMET_SLOT] = held;
                player.f_29439708.f_35249023[player.f_29439708.f_13682807] = worn;

                source.sendFeedback(Text.literal("Swapped hat with hand"));
                return Command.SINGLE_SUCCESS;
            }));
    }
}
