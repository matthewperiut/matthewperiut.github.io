package com.periut.retroapi.mixin.gamemode;

import com.periut.retroapi.gamemode.RetroGameModes;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Adventure and spectator may not place blocks.
 *
 * <p>Hung on the item's own use rather than on either interaction manager: there is one of those per
 * side and they disagree about method names, while every placement in the game - hand, dispenser,
 * command - funnels through here.
 */
@Mixin(net.minecraft.unmapped.C_71827890.class)
public class ReadOnlyInteractionMixin {

	@Inject(method = "useOnBlock", at = @At("HEAD"), cancellable = true, require = 0)
	private void retroapi$readOnlyPlacement(C_88708284 stack, C_40996800 player, C_64041439 world,
			int x, int y, int z, int face, CallbackInfoReturnable<Boolean> cir) {
		if (player != null && RetroGameModes.get(player).isReadOnly()) {
			cir.setReturnValue(false);
		}
	}
}
