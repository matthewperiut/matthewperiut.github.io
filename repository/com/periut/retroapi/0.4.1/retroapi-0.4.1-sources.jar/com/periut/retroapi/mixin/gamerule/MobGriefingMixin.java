package com.periut.retroapi.mixin.gamerule;

import com.periut.retroapi.gamerule.RetroGameRules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Set;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_84651702;

/**
 * {@code mobGriefing}: a creeper or a ghast still explodes, hurts and makes noise - it just leaves
 * the terrain alone.
 *
 * <p>Emptying the collected block set after the explosion has worked out what it would destroy is
 * the smallest place to intervene: the damage, sound and particles all happen elsewhere and are
 * untouched. TNT and a player-triggered blast are not a mob's doing, so they still break blocks.
 */
@Mixin(C_84651702.class)
public class MobGriefingMixin {
	@Shadow private Set damagedBlocks;
	@Shadow private C_42232651 source;

	@Inject(method = "explode", at = @At("TAIL"))
	private void retroapi$mobGriefing(CallbackInfo ci) {
		if (source instanceof C_74425583 && !(source instanceof C_40996800)
			&& !RetroGameRules.getBoolean(RetroGameRules.MOB_GRIEFING)) {
			damagedBlocks.clear();
		}
	}
}
