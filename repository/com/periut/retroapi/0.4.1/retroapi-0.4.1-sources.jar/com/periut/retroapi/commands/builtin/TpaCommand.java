package com.periut.retroapi.commands.builtin;

import com.mojang.brigadier.Command;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.periut.retroapi.commands.CommandUtil;
import com.periut.retroapi.commands.Position;
import com.periut.retroapi.commands.RegistrationEnvironment;
import com.periut.retroapi.commands.RetroCommandSource;
import com.periut.retroapi.text.ClickEvent;
import com.periut.retroapi.text.Formatting;
import com.periut.retroapi.text.Text;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.unmapped.C_40996800;

import static com.periut.retroapi.commands.RetroCommandManager.argument;
import static com.periut.retroapi.commands.RetroCommandManager.literal;
import static com.periut.retroapi.commands.argument.EntityArgumentType.getPlayer;
import static com.periut.retroapi.commands.argument.EntityArgumentType.player;

/**
 * {@code /tpa <player>} and {@code /tpa accept} - a teleport a player can ask for rather than take.
 *
 * <p>Not a vanilla command in any version, so there is no modern shape to follow; the request
 * message is now clickable, which is the one thing modern chat would have done differently.
 */
public final class TpaCommand {
    private static final long EXPIRY_TICKS = 2400;

    private static final List<Request> REQUESTS = new ArrayList<>();

    private TpaCommand() {
    }

    private record Request(String from, String to, long time) {
    }

    public static void register(final CommandDispatcher<RetroCommandSource> dispatcher, final RegistrationEnvironment environment) {
        if (!environment.isDedicated()) {
            return;
        }

        dispatcher.register(literal("tpa")
            .then(literal("accept").executes(TpaCommand::accept))
            .then(argument("player", player())
                .executes(TpaCommand::request)));
    }

    private static int request(final CommandContext<RetroCommandSource> context) throws CommandSyntaxException {
        final RetroCommandSource source = context.getSource();
        final C_40996800 self = source.getPlayerOrThrow();
        final C_40996800 target = getPlayer(context, "player");

        if (self == target) {
            source.sendError(Text.literal("You are already there"));
            return 0;
        }

        target.m_83523863("§7" + self.f_59008391 + " wants to teleport to you.");
        target.m_83523863("§7Type \"/tpa accept\" to allow it. (expires in 2 minutes)");

        REQUESTS.add(new Request(self.f_59008391, target.f_59008391, self.f_94306729.m_13949261()));
        source.sendFeedback(Text.literal("Sent a teleport request to " + target.f_59008391).formatted(Formatting.GRAY));
        return Command.SINGLE_SUCCESS;
    }

    private static int accept(final CommandContext<RetroCommandSource> context) throws CommandSyntaxException {
        final RetroCommandSource source = context.getSource();
        final C_40996800 self = source.getPlayerOrThrow();
        final long now = self.f_94306729.m_13949261();

        // Newest first, so accepting twice in a row answers the two most recent requests.
        for (int i = REQUESTS.size() - 1; i >= 0; i--) {
            final Request request = REQUESTS.get(i);
            if (!request.to().equals(self.f_59008391)) {
                continue;
            }

            REQUESTS.remove(i);

            if (now - request.time() > EXPIRY_TICKS) {
                source.sendError(Text.literal("That teleport request has expired"));
                return 0;
            }

            final C_40996800 from = findPlayer(source, request.from());
            if (from == null) {
                source.sendError(Text.literal(request.from() + " is no longer online"));
                return 0;
            }

            CommandUtil.teleport(from, new Position(self.f_78826675, self.f_31030949, self.f_97691941));
            from.m_83523863("§7Teleported to " + self.f_59008391);
            source.sendFeedback(Text.literal("Teleported " + from.f_59008391 + " to you"));
            return Command.SINGLE_SUCCESS;
        }

        source.sendError(Text.literal("You have no pending teleport requests"));
        return 0;
    }

    private static C_40996800 findPlayer(final RetroCommandSource source, final String name) {
        for (final C_40996800 player : source.getPlayers()) {
            if (player.f_59008391.equals(name)) {
                return player;
            }
        }
        return null;
    }
}
