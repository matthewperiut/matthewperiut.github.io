package com.periut.retroapi.mixin.movement.client;

import com.periut.retroapi.movement.api.EntitySprinting;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_03140863;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_57778754;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.periut.retroapi.movement.RetroMovement.lastMovementFovMultiplier;
import static com.periut.retroapi.movement.RetroMovement.movementFovMultiplier;

@Mixin(C_03140863.class)
public class GameRendererMixinCaptureVar {
    @Shadow private Minecraft client;
    private float field_1831; // SOMETHING MOVEMENT IDK

    @Inject(method = "updateCamera", at = @At("HEAD"))
    void tick(CallbackInfo ci) {
        updateMovementFovMultiplier();
    }

    @Unique
    public float method_1305(C_40996800 p) {
        if (((EntitySprinting) (Object) p).isSprinting()) {
            return 1.15f;
        }
        return 1.f;
    }

    @Unique
    private void updateMovementFovMultiplier() {
        C_57778754 class_5182 = (C_57778754) client.f_63700667;
        this.field_1831 = method_1305(class_5182);
        lastMovementFovMultiplier = movementFovMultiplier;
        movementFovMultiplier += (field_1831 - movementFovMultiplier) * 0.5f;
    }
}
