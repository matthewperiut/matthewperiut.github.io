package com.periut.retroapi.mixin.movement.client;

import com.periut.retroapi.movement.RetroMovement;
import com.periut.retroapi.movement.api.EntitySwimming;
import net.minecraft.unmapped.C_08381405;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_54206210;
import com.periut.retroapi.compat.StationBridges;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.periut.retroapi.movement.RetroMovement.stapi;

@Mixin(C_08381405.class)
public class KeyboardInputMixin extends C_54206210 {
    @Shadow
    private boolean[] keys;

    @Inject(method = "updateKey", at = @At("TAIL"))
    void extraInput(int i, boolean bl, CallbackInfo ci) {
        // StationAPI has a keybind screen, so the sprint key is a real rebindable binding there and
        // is read back through the compat bridge. Without it there is nowhere to rebind, so the key
        // is the fixed default.
        int sprintKey = stapi ? StationBridges.get().sprintKeyCode() : RetroMovement.runKeyCode;
        if (i == sprintKey) {
            keys[6] = bl;
        }
    }

    @Inject(method = "update", at = @At("TAIL"))
    public void addRunKey(C_40996800 par1, CallbackInfo ci) {
        f_90787744 = keys[6];

        // Sneaking scales movement to 30% in vanilla. Modern turns crouching off entirely while
        // swimming - shift is the dive control there, not a slow walk - so undo the scaling and
        // let the swim keep its full stroke.
        if (f_28813338 && ((EntitySwimming) par1).isSwimming()) {
            f_54482307 = (keys[2] ? 1.0F : 0.0F) - (keys[3] ? 1.0F : 0.0F);
            f_81168741 = (keys[0] ? 1.0F : 0.0F) - (keys[1] ? 1.0F : 0.0F);
        }
    }
}
