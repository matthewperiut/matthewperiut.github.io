package com.periut.retroapi.mixin.movement.client;

import com.periut.retroapi.movement.MovementConstants;
import com.periut.retroapi.movement.api.EntitySprinting;
import net.minecraft.unmapped.C_39385348;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_88014908;
import net.minecraft.unmapped.C_97929192;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_97929192.class)
public class MultiplayerClientPlayerEntityMixin {
    @Shadow
    public C_88014908 networkHandler;
    @Unique
    boolean wasSprinting = false;

    @Inject(method = "sendMovement", at = @At("HEAD"))
    void tick(CallbackInfo ci) {
        boolean sprinting = ((EntitySprinting) (Object) this).isSprinting();
        if (sprinting != wasSprinting) {
            if (sprinting) {
                this.networkHandler.m_43500316(new C_39385348((C_42232651) (Object) this, MovementConstants.START_RUNNING_COMMAND));
            } else {
                this.networkHandler.m_43500316(new C_39385348((C_42232651) (Object) this, MovementConstants.STOP_RUNNING_COMMAND));
            }
        }
        wasSprinting = sprinting;
    }
}
