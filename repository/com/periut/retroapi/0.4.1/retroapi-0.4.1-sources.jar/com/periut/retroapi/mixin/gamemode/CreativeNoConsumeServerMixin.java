package com.periut.retroapi.mixin.gamemode;

import com.periut.retroapi.gamemode.CreativeItemUse;
import net.minecraft.unmapped.C_14230742;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Creative spends nothing it places, eats or empties - server side.
 *
 * <p>The server re-runs the use itself rather than trusting the client, so it spends the stack all over
 * again on its own copy of the inventory. Same snapshot, same restore - see {@link CreativeItemUse}
 * for what is put back, and why a bucket needs more than the count.
 */
@Mixin(C_14230742.class)
public class CreativeNoConsumeServerMixin {

	@Unique private CreativeItemUse.Snapshot retroapi$held;

	@Inject(method = "interactBlock", at = @At("HEAD"))
	private void retroapi$rememberForBlock(C_40996800 player, C_64041439 world, C_88708284 stack,
			int x, int y, int z, int side, CallbackInfoReturnable<Boolean> cir) {
		retroapi$held = CreativeItemUse.before(player);
	}

	@Inject(method = "interactBlock", at = @At("RETURN"))
	private void retroapi$restoreAfterBlock(C_40996800 player, C_64041439 world, C_88708284 stack,
			int x, int y, int z, int side, CallbackInfoReturnable<Boolean> cir) {
		CreativeItemUse.after(player, retroapi$held);
		retroapi$held = null;
	}

	@Inject(method = "interactItem", at = @At("HEAD"))
	private void retroapi$rememberForItem(C_40996800 player, C_64041439 world, C_88708284 stack,
			CallbackInfoReturnable<Boolean> cir) {
		retroapi$held = CreativeItemUse.before(player);
	}

	@Inject(method = "interactItem", at = @At("RETURN"))
	private void retroapi$restoreAfterItem(C_40996800 player, C_64041439 world, C_88708284 stack,
			CallbackInfoReturnable<Boolean> cir) {
		CreativeItemUse.after(player, retroapi$held);
		retroapi$held = null;
	}
}
