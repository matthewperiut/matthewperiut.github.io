package com.periut.retroapi.mixin.movement.server;

import com.periut.retroapi.movement.MovementConstants;
import com.periut.retroapi.movement.api.EntitySprinting;
import net.minecraft.unmapped.C_39385348;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_99660737;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_99660737.class)
public class ServerPlayNetworkHandlerMixin {
    @Shadow
    private C_49202226 player;

    @Inject(method = "handleClientCommand", at = @At(value = "HEAD"), cancellable = true)
    void handleExtendedClientCommands(C_39385348 packet, CallbackInfo ci) {
        if (packet.f_00758356 == MovementConstants.START_RUNNING_COMMAND) {
            ((EntitySprinting) (Object) player).setSprinting(true);
            ci.cancel();
        } else if (packet.f_00758356 == MovementConstants.STOP_RUNNING_COMMAND) {
            ((EntitySprinting) (Object) player).setSprinting(false);
            ci.cancel();
        }
    }
}
