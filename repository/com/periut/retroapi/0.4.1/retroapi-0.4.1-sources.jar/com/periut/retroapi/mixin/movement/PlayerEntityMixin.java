package com.periut.retroapi.mixin.movement;

import com.periut.retroapi.movement.api.EntitySprinting;
import com.periut.retroapi.movement.api.EntitySwimming;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_89604096;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.periut.retroapi.movement.MovementConstants.STANDING_HEIGHT;
import static com.periut.retroapi.movement.MovementConstants.STANDING_WIDTH;
import static com.periut.retroapi.movement.MovementConstants.SWIMMING_EYE_HEIGHT;
import static com.periut.retroapi.movement.MovementConstants.SWIMMING_HEIGHT;
import static com.periut.retroapi.movement.MovementConstants.SWIMMING_WIDTH;
import static com.periut.retroapi.movement.MovementConstants.SWIM_PITCH_PULL;
import static com.periut.retroapi.movement.MovementConstants.SWIM_PITCH_PULL_STEEP;

@Mixin(C_40996800.class)
abstract public class PlayerEntityMixin extends C_74425583 implements EntitySwimming {

    // shove this down here because it is useless and just required by jvm
    public PlayerEntityMixin(C_64041439 world) {
        super(world);
    }

    @Shadow
    public float stepBobbingAmount;

    @Shadow
    public float prevStepBobbingAmount;

    /** True while the 0.6 x 0.6 swimming pose is applied, i.e. Pose.SWIMMING in modern terms. */
    @Unique
    private boolean retroapi$swimPose;

    /**
     * The eye height this player stands with. Always 1.62 for real players, but OtherPlayerEntity
     * pins it to 0 so that network positions land on the feet, and that has to survive a swim.
     */
    @Unique
    private float retroapi$standingEyeHeight = 1.62F;

    @Override
    public boolean isVisuallySwimming() {
        return this.retroapi$swimPose;
    }

    @Inject(method = "attack(Lnet/minecraft/entity/Entity;)V", at = @At("HEAD"))
    public void onAttack(C_42232651 target, CallbackInfo ci) {
        C_40996800 player = (C_40996800) (Object) this;

        // Check if the player is sprinting
        if (((EntitySprinting) (Object) player).isSprinting()) {
            // Apply sprinting effect: Increase knockback
            applyKnockback(player, target);

            // Optionally: Stop sprinting after the attack
            ((EntitySprinting) (Object) player).setSprinting(false);
        }
    }

    @Unique
    private void applyKnockback(C_40996800 player, C_42232651 target) {
        // Basic knockback calculation based on sprinting
        float knockbackStrength = 1.2F; // You can adjust this value for more/less knockback
        double xKnockback = -C_45510667.m_61414107(player.f_80130373 * ((float) Math.PI / 180F)) * knockbackStrength;
        double zKnockback = C_45510667.m_64246150(player.f_80130373 * ((float) Math.PI / 180F)) * knockbackStrength;

        // Apply knockback to the target entity
        target.m_35111817(xKnockback, 0.1, zKnockback);

        // Reduce player's velocity slightly (to simulate loss of momentum after sprinting attack)
        player.f_24826402 *= 0.6;
        player.f_21201587 *= 0.6;
    }

    /**
     * Player.travel: the look direction pulls a swimmer up or down, which is what makes a swim
     * feel steered rather than skimmed. The upward half is held back until the head has water
     * above it so surfacing does not fling the player out of the pool.
     */
    @Inject(method = "travel", at = @At("HEAD"))
    private void retroapi$swimSteering(float sidewaysSpeed, float forwardSpeed, CallbackInfo ci) {
        if (!this.isSwimming()) {
            return;
        }

        double lookY = -C_45510667.m_61414107(this.f_03549461 * ((float) Math.PI / 180.0F));
        double pull = lookY < -0.2 ? SWIM_PITCH_PULL_STEEP : SWIM_PITCH_PULL;
        if (lookY <= 0.0 || this.f_69621501 || this.retroapi$isWaterAbove()) {
            this.f_35148123 += (lookY - this.f_35148123) * pull;
        }
    }

    @Unique
    private boolean retroapi$isWaterAbove() {
        int i = C_45510667.m_80489169(this.f_78826675);
        int j = C_45510667.m_80489169(this.f_00583773.f_80314167 + 1.0 - 0.1);
        int k = C_45510667.m_80489169(this.f_97691941);
        C_89604096 material = this.f_94306729.m_24175966(i, j, k);
        return material == C_89604096.f_99458234 || material == C_89604096.f_70482856;
    }

    /**
     * AbstractClientPlayer.updateBob gates the walk bob on {@code !isSwimming()} in modern - a
     * swimmer hugging the seabed counts as onGround, and bobbing along it like a footstep looks
     * wrong. Beta computes the bob at the end of tickMovement from the same onGround test, so
     * redo the step here with a target of zero: prevStepBobbingAmount is the pre-tick value, and
     * vanilla's update is {@code bob += (target - bob) * 0.4}.
     */
    @Inject(method = "tickMovement", at = @At("TAIL"))
    private void retroapi$noBobWhileSwimming(CallbackInfo ci) {
        if (this.isSwimming()) {
            this.stepBobbingAmount = this.prevStepBobbingAmount * 0.6F;
        }
    }

    /**
     * Player.updatePlayerPose, minus the crouching pose beta does not have. The swim pose is
     * anchored at the feet so shrinking to 0.6 drops the camera rather than lifting the body,
     * and a player who cannot stand back up stays horizontal - modern's crawling.
     */
    @Inject(method = "tick", at = @At("TAIL"))
    private void retroapi$updatePlayerPose(CallbackInfo ci) {
        // Dying and sleeping resize the box themselves (0.2 cubes), so leave those alone.
        if (this.f_05442563 <= 0 || ((C_40996800) (Object) this).m_18110524()) {
            return;
        }

        if (!this.retroapi$fitsWhileSwimming()) {
            return;
        }

        boolean swimPose = this.isSwimming();
        if (!swimPose && !this.retroapi$fitsWhileStanding()) {
            swimPose = true;
        }

        if (swimPose != this.retroapi$swimPose) {
            this.retroapi$setSwimPose(swimPose);
        }

        // Beta dips the camera by up to 0.2 while the sneak key is held. Sneak is the dive control
        // while swimming, and modern has no such dip, so keep the swimming eye where it belongs.
        if (this.retroapi$swimPose && this.f_94591779 != 0.0F) {
            this.f_94591779 = 0.0F;
            this.f_31030949 = this.f_00583773.f_80314167 + this.f_85480687;
        }
    }

    @Unique
    private void retroapi$setSwimPose(boolean swimPose) {
        if (swimPose) {
            this.retroapi$standingEyeHeight = this.f_85480687;
        }

        this.retroapi$swimPose = swimPose;

        float width = swimPose ? SWIMMING_WIDTH : STANDING_WIDTH;
        float height = swimPose ? SWIMMING_HEIGHT : STANDING_HEIGHT;
        // OtherPlayerEntity stands with an eye height of 0; scaling to 0.4 would push its
        // bounding box below its feet, so a player without an eye height keeps it.
        float eyeHeight = swimPose && this.retroapi$standingEyeHeight > 0.0F
                ? SWIMMING_EYE_HEIGHT
                : this.retroapi$standingEyeHeight;

        double feetY = this.f_00583773.f_80314167;
        this.m_99917968(width, height);
        this.f_85480687 = eyeHeight;
        this.f_00583773.m_04078409(this.f_78826675 - width / 2.0F, feetY, this.f_97691941 - width / 2.0F,
                this.f_78826675 + width / 2.0F, feetY + height, this.f_97691941 + width / 2.0F);
        // Entity.move keeps y in step with the box this way; do the same so the eye does not drift.
        this.f_31030949 = this.f_00583773.f_80314167 + this.f_85480687 - this.f_94591779;
    }

    @Unique
    private boolean retroapi$fitsWhileSwimming() {
        return this.retroapi$fits(SWIMMING_WIDTH, SWIMMING_HEIGHT);
    }

    @Unique
    private boolean retroapi$fitsWhileStanding() {
        return this.retroapi$fits(STANDING_WIDTH, STANDING_HEIGHT);
    }

    /** Player.canPlayerFitWithinBlocksAndEntitiesWhen, for a pose of the given size. */
    @Unique
    private boolean retroapi$fits(float width, float height) {
        double feetY = this.f_00583773.f_80314167;
        double half = width / 2.0F;
        C_82690114 box = C_82690114.m_01430010(this.f_78826675 - half, feetY, this.f_97691941 - half,
                this.f_78826675 + half, feetY + height, this.f_97691941 + half).m_06884845(1.0E-7, 1.0E-7, 1.0E-7);
        return this.f_94306729.m_96987242((C_40996800) (Object) this, box).isEmpty();
    }
}
