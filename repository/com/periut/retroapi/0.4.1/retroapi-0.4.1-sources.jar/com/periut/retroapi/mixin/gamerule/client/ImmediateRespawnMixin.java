package com.periut.retroapi.mixin.gamerule.client;

import com.periut.retroapi.gamerule.RetroGameRules;
import net.minecraft.unmapped.C_72377497;
import net.minecraft.unmapped.C_85740840;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * {@code doImmediateRespawn}: no death screen, straight back into the world.
 *
 * <p>Does exactly what pressing the screen's own respawn button does, at the moment the screen is
 * built. The rule is read from the client's synced copy, which is why game rules are sent to clients
 * at all: the death screen is the client's decision and the server never sees it.
 *
 * <p>Declared as extending {@link C_85740840} so {@code minecraft} - which {@code Screen} owns, not
 * {@code DeathScreen} - is simply inherited. A {@code @Shadow} of it fails outright: mixin only
 * resolves shadows against the target class's own fields.
 */
@Mixin(C_72377497.class)
public abstract class ImmediateRespawnMixin extends C_85740840 {

	@Inject(method = "init", at = @At("TAIL"))
	private void retroapi$doImmediateRespawn(CallbackInfo ci) {
		if (!RetroGameRules.getBoolean(RetroGameRules.DO_IMMEDIATE_RESPAWN)) {
			return;
		}
		if (this.f_78495264 != null && this.f_78495264.f_28396371 != null) {
			this.f_78495264.f_28396371.m_74340941();
			this.f_78495264.m_52715402(null);
		}
	}
}
