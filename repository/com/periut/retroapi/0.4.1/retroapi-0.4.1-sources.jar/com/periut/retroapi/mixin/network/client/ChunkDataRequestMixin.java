package com.periut.retroapi.mixin.network.client;

import com.periut.retroapi.register.blockentity.BlockEntitySyncRequest;
import net.minecraft.unmapped.C_62858513;
import net.minecraft.unmapped.C_88014908;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Asks the server what is inside a chunk that just arrived.
 *
 * <p>The other direction - the server volunteering block-entity state as it sends each chunk - cannot
 * be relied on by itself. At join time those sends happen before the client has finished registering
 * its channels and OSL discards them, and even later they can land a moment before the chunk they
 * describe. Both are races about WHEN the client is ready, so the client asks: by the time this runs
 * the chunk is in its world, its channels are up, and there is nothing left to be early for.
 *
 * <p>Cheap by construction - one small request per chunk, answered only for chunks that actually hold
 * a synced block entity, and most hold none.
 */
@Mixin(C_88014908.class)
public class ChunkDataRequestMixin {

	@Inject(method = "handleChunkData", at = @At("TAIL"))
	private void retroapi$askWhatIsInside(C_62858513 packet, CallbackInfo ci) {
		BlockEntitySyncRequest.request(packet.f_05662346 >> 4, packet.f_77394700 >> 4);
	}
}
