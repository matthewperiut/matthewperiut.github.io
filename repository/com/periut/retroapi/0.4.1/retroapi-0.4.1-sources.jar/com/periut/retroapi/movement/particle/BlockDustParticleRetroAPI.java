package com.periut.retroapi.movement.particle;

import com.periut.retroapi.client.texture.AtlasExpander;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_96603444;

/**
 * Only used when RetroAPI is present and StationAPI is not. RetroAPI expands the terrain atlas
 * past vanilla's 256x16 grid, so the column count and sub-sprite size have to scale with it -
 * mirrors the math RetroAPI's own BlockParticleMixin applies to vanilla's BlockParticle. When
 * StationAPI is also present, StationAPI owns the atlas and BlockDustParticleSTAPI is used instead.
 */
public class BlockDustParticleRetroAPI extends BlockDustParticle {

    public BlockDustParticleRetroAPI(C_64041439 world, double x, double y, double z, double g, double h, double i, C_81592558 block, int j, int k) {
        super(world, x, y, z, g, h, i, block, j, k);
    }

    @Override
    public void m_32469004(C_96603444 arg, float f, float g, float h, float i, float j, float k) {
        if (this.block == C_81592558.f_00276986) {
            this.f_45507822 = 0.0f;
            this.f_10605225 = 1.0f;
            this.f_07440167 = 0.0f;
        }

        float columns = AtlasExpander.terrainAtlasSize / 16.0f;
        float subSpriteSize = 0.015609375f * 256.0f / AtlasExpander.terrainAtlasSize;

        float f2 = ((float) (this.f_63348640 % (int) columns) + this.f_76706888 / 4.0f) / columns;
        float f3 = f2 + subSpriteSize;
        float f4 = ((float) (this.f_63348640 / (int) columns) + this.f_34520038 / 4.0f) / columns;
        float f5 = f4 + subSpriteSize;

        float f6 = 0.1f * this.f_11203543;

        float f7 = (float) (this.f_59999765 + (this.f_78826675 - this.f_59999765) * (double) f - f_37914722);
        float f8 = (float) (this.f_90348373 + (this.f_31030949 - this.f_90348373) * (double) f - f_59479165);
        float f9 = (float) (this.f_88346412 + (this.f_97691941 - this.f_88346412) * (double) f - f_68501249);

        // The world's light where the particle is, which is what vanilla's own BlockParticle.render
        // multiplies its colour by. Hardcoding 1.0 here is why these lit correctly at noon and stayed
        // just as bright at sunset and underground, while the breaking particles - still on vanilla's
        // path - darkened with everything else.
        float f10 = this.m_95186532(f);
        arg.m_73671468(f10 * this.f_45507822, f10 * this.f_10605225, f10 * this.f_07440167);

        arg.m_75942980(f7 - g * f6 - j * f6, f8 - h * f6, f9 - i * f6 - k * f6, f2, f5);
        arg.m_75942980(f7 - g * f6 + j * f6, f8 + h * f6, f9 - i * f6 + k * f6, f2, f4);
        arg.m_75942980(f7 + g * f6 + j * f6, f8 + h * f6, f9 + i * f6 + k * f6, f3, f4);
        arg.m_75942980(f7 + g * f6 - j * f6, f8 - h * f6, f9 + i * f6 - k * f6, f3, f5);
    }
}
