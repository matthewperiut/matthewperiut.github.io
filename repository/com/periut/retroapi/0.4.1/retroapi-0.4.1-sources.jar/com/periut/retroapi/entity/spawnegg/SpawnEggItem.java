package com.periut.retroapi.entity.spawnegg;

import com.periut.retroapi.gamemode.RetroGameMode;
import com.periut.retroapi.gamemode.RetroGameModes;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_72103717;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;

/**
 * A spawn egg, ported from modern's {@code SpawnEggItem}.
 *
 * <p>Modern has one item per mob rather than one item with the entity in its damage value, and this
 * follows that: {@link SpawnEggs} registers thirteen of these, each holding the vanilla
 * {@code EntityRegistry} string of the mob it makes. Nothing about the entity is copied here - the egg
 * asks the registry for one, which is how a mod's own mob gets an egg by doing nothing at all.
 *
 * <p>What it does on use is modern's {@code useOn}: place the mob in the block <em>against</em> the
 * face that was clicked, facing a random way, and take one off the stack unless the player is in
 * creative. Everything happens on the server only, as spawning always must.
 */
public class SpawnEggItem extends C_98888256 {

    private final String entityId;

    public SpawnEggItem(final int id, final String entityId) {
        super(id);
        this.entityId = entityId;
    }

    /** The vanilla {@code EntityRegistry} id this egg spawns, e.g. {@code "Pig"}. */
    public String getEntityId() {
        return entityId;
    }

    @Override
    public boolean m_93921076(final C_88708284 stack, final C_40996800 user, final C_64041439 world,
                              int x, int y, int z, final int side) {
        if (world == null || world.f_50876584) {
            // The client says "used" so the swing animation plays; the server does the spawning.
            return true;
        }

        // Modern: an egg used ON a spawner re-points it instead of spawning anything, which is the
        // only way to set one without commands. Spawners tells every client watching.
        if (Spawners.setMob(world, x, y, z, entityId)) {
            if (!RetroGameModes.is(user, RetroGameMode.CREATIVE)) {
                stack.f_60602012--;
            }
            return true;
        }

        // Beta's own face offsets, the ones BlockItem places against.
        switch (side) {
            case 0 -> y--;
            case 1 -> y++;
            case 2 -> z--;
            case 3 -> z++;
            case 4 -> x--;
            case 5 -> x++;
            default -> {
            }
        }

        if (!spawn(world, x + 0.5, y, z + 0.5)) {
            return false;
        }

        if (!RetroGameModes.is(user, RetroGameMode.CREATIVE)) {
            stack.f_60602012--;
        }
        return true;
    }

    /** @return whether a mob was actually made and added to the world */
    public boolean spawn(final C_64041439 world, final double x, final double y, final double z) {
        final C_42232651 entity = C_72103717.m_32428905(entityId, world);
        if (entity == null) {
            return false;
        }

        // The same call beta's own spawner and mob spawner block use, random facing included.
        if (entity instanceof C_74425583 living) {
            living.m_12877971(x, y, z, world.f_33453426.nextFloat() * 360.0F, 0.0F);
        } else {
            entity.m_03000503(x, y, z, world.f_33453426.nextFloat() * 360.0F, 0.0F);
        }
        return world.m_09670988(entity);
    }
}
