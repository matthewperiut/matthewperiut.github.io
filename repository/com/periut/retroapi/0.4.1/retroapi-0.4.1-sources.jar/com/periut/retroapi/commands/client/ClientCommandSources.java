package com.periut.retroapi.commands.client;

import com.periut.retroapi.commands.RetroCommands;
import com.periut.retroapi.commands.client.gui.RetroChatHud;
import com.periut.retroapi.commands.Position;
import com.periut.retroapi.commands.RetroCommandSource;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_25850426;
import net.minecraft.unmapped.C_57778754;

/**
 * Builds the command source a client runs commands as.
 *
 * <p>In singleplayer that is the whole story - beta has no integrated server, so the client is the
 * authority and holds every permission. Connected to a server, this source exists only to parse and
 * suggest; the server builds its own when the command actually arrives.
 */
public final class ClientCommandSources {
    private ClientCommandSources() {
    }

    public static RetroCommandSource create(final Minecraft minecraft) {
        final C_57778754 player = minecraft.f_28396371;

        // Fully privileged, on both sides of the wire, because this source only ever parses, colours and
        // completes - it never runs anything.
        //
        // Filtering here as well as on the server was worse than useless: the tree a server sends has
        // already had everything this player may not use removed, so a second filter can only take away
        // MORE, and it did - a client whose op status had not arrived (or had arrived wrong) parsed
        // /gamerule against a tree it had quietly pruned and reported "Unknown command" for a command
        // the server was cheerfully suggesting. Modern does not second-guess the tree either.
        //
        // Nothing is granted by this: a command still travels to the server, which builds its own source
        // and re-checks the rights before running a thing.
        final int level = RetroCommandSource.LEVEL_OWNER;

        return new RetroCommandSource(
            message -> RetroChatHud.getInstance().addMessage(message),
            player,
            minecraft.f_26407825,
            player == null ? Position.ORIGIN : new Position(player.f_78826675, player.f_31030949, player.f_97691941),
            player == null ? 0.0f : player.f_80130373,
            player == null ? 0.0f : player.f_03549461,
            player == null ? "client" : player.f_59008391,
            level,
            null,
            true).withLookedAtBlock(lookedAtBlock(minecraft));
    }

    /**
     * The block under the crosshair, which is what coordinate arguments complete to. Null unless the
     * player is actually looking at one - an entity under the crosshair is not a position, and
     * neither is thin air, and in both cases the completions fall back to {@code ~ ~ ~}.
     */
    private static Position lookedAtBlock(final Minecraft minecraft) {
        final C_24654288 target = minecraft.f_81460813;
        if (target == null || target.f_92820457 != C_25850426.f_13890456) {
            return null;
        }
        return new Position(target.f_79497105, target.f_09533029, target.f_04223298);
    }
}
