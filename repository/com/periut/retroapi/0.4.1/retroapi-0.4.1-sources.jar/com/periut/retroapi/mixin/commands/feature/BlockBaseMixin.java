package com.periut.retroapi.mixin.commands.feature;

import com.periut.retroapi.commands.api.ItemInstanceStr;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_72103717;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_88708284;

@Mixin(C_81592558.class)
public class BlockBaseMixin {
    /** Beta's monster spawner. Hardcoded because {@code Block.SPAWNER} is not loaded yet here. */
    private static final int SPAWNER_ID = 52;

    /**
     * Carries the mob a spawner was given with into the block that gets placed.
     *
     * <p>The block is identified by its id rather than by its name: reading the name goes through
     * the client-only translation table, which is not merely wasteful on a dedicated server but
     * throws {@link NoClassDefFoundError} there.
     */
    @Inject(method = "onPlaced(Lnet/minecraft/world/World;IIII)V", at = @At("HEAD"))
    public void onBlockPlaced(C_64041439 i, int j, int k, int l, int direction, CallbackInfo ci) {
        if (i.m_33234383(j, k, l) == SPAWNER_ID) {
            try {
                C_82690114 b = C_82690114.m_23878395(j - 5, k - 5, l - 5, j + 5, k + 5, l + 5);
                List<C_40996800> players = i.m_11058721(C_40996800.class, b);
                String mob = null;
                if (players.size() == 1) {
                    if (players.get(0).f_29439708.m_27760697() != null)
                        mob = ((ItemInstanceStr) (Object) players.get(0).f_29439708.m_27760697()).spc$getStr();
                } else {
                    for (C_40996800 p : players) {
                        C_88708284 held = p.f_29439708.m_27760697();
                        if (held != null && held.f_59294634 == SPAWNER_ID) {
                            mob = ((ItemInstanceStr) (Object) held).spc$getStr();
                            break;
                        }
                    }
                }
                if (mob == null)
                    mob = "Pig";

                C_42232651 entity = C_72103717.m_32428905(mob, i);
                if (entity instanceof C_74425583) {
                    // Through Spawners rather than straight at the block entity: same assignment, plus
                    // the dirty mark that gets the mob to every client watching the chunk.
                    com.periut.retroapi.entity.spawnegg.Spawners.setMob(i, j, k, l, entity.m_06252001());
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
