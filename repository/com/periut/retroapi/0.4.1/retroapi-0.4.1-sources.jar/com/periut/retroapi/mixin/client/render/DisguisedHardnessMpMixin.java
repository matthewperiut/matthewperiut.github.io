package com.periut.retroapi.mixin.client.render;

import com.periut.retroapi.mixin.client.InteractionManagerAccessor;
import com.periut.retroapi.register.block.RetroDisguises;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_45175654;
import net.minecraft.unmapped.C_81592558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * How fast a disguised block gives way: the worn block's speed, not the frame's. See
 * {@link com.periut.retroapi.register.block.RetroBlockDisguise}.
 *
 * <p>{@code getHardness(PlayerEntity)} returns the fraction of the block broken this tick, and it folds
 * together the block's own hardness and how well the held tool bites it. Asking the worn block instead of
 * the frame gets both at once: a frame clad in stone takes as long as stone and rewards a pickaxe for it,
 * and one clad in wool comes apart as fast as wool.
 *
 * <p>Its own class, separate from the sound hook in the same method, because StationAPI replaces this call
 * and not that one, so the two have to be switchable independently. It is disabled under StationAPI by
 * {@code RetroAPIMixinPlugin} rather than made optional: an optional injection that silently stops
 * applying is how the break sound went unnoticed for a whole release.
 */
@Mixin(C_45175654.class)
@Environment(EnvType.CLIENT)
public class DisguisedHardnessMpMixin {

	@Redirect(method = "processBlockBreakingAction",
		at = @At(value = "INVOKE", target = "Lnet/minecraft/block/Block;getHardness(Lnet/minecraft/entity/player/PlayerEntity;)F"))
	private float retroapi$disguisedHardness(C_81592558 block, C_40996800 player, int x, int y, int z, int side) {
		Minecraft minecraft = ((InteractionManagerAccessor) this).retroapi$minecraft();
		C_81592558 worn = minecraft == null || minecraft.f_26407825 == null
			? null
			: RetroDisguises.at(minecraft.f_26407825, x, y, z);
		return worn == null ? block.m_04780401(player) : RetroDisguises.breakingDelta(player, block, worn);
	}
}
