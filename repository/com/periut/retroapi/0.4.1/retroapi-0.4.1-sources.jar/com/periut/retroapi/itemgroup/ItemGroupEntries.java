package com.periut.retroapi.itemgroup;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;

/**
 * What a tab is being filled with, handed to every {@code entries} callback.
 *
 * <p>Order is the order things are added, because a creative tab is a curated list and not a set.
 */
public final class ItemGroupEntries {

    private final List<C_88708284> stacks = new ArrayList<>();

    public void add(final C_88708284 stack) {
        if (stack != null) {
            stacks.add(stack);
        }
    }

    public void add(final C_98888256 item) {
        if (item != null) {
            stacks.add(new C_88708284(item.f_57562535, 1, 0));
        }
    }

    public void add(final C_81592558 block) {
        if (block != null) {
            stacks.add(new C_88708284(block.f_84602679, 1, 0));
        }
    }

    /** A specific subtype - the metadata that tells one wool, log or dye from another. */
    public void add(final C_98888256 item, final int meta) {
        if (item != null) {
            stacks.add(new C_88708284(item.f_57562535, 1, meta));
        }
    }

    public void add(final C_81592558 block, final int meta) {
        if (block != null) {
            stacks.add(new C_88708284(block.f_84602679, 1, meta));
        }
    }

    /** Every subtype from {@code first} to {@code last} inclusive, which is how wool and dye are listed. */
    public void addRange(final C_81592558 block, final int first, final int last) {
        for (int meta = first; meta <= last; meta++) {
            add(block, meta);
        }
    }

    public void addRange(final C_98888256 item, final int first, final int last) {
        for (int meta = first; meta <= last; meta++) {
            add(item, meta);
        }
    }

    public List<C_88708284> getStacks() {
        return stacks;
    }
}
