package com.periut.retroapi.itemgroup;

import com.periut.retroapi.text.Text;
import com.periut.retroapi.register.item.ObtainableItems;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;
import net.ornithemc.osl.core.api.util.NamespacedIdentifiers;

/**
 * Beta's own content, sorted into modern Minecraft's creative tabs.
 *
 * <p>The tabs, their order, their icons and the order of items inside them follow modern as closely
 * as beta allows. Where modern has something beta does not - spawn eggs, banners, most of the
 * Functional tab - the entry is simply missing rather than substituted: a gap in a familiar layout
 * is easier to read than a rearrangement of it.
 *
 * <p>Registered lazily on first use so that a mod which registers its own group during init does not
 * have to care whether these exist yet.
 */
public final class VanillaItemGroups {
    private VanillaItemGroups() {
    }

    private static boolean registered;

    public static RetroItemGroup BUILDING_BLOCKS;
    public static RetroItemGroup COLORED_BLOCKS;
    public static RetroItemGroup NATURAL;
    public static RetroItemGroup FUNCTIONAL;
    public static RetroItemGroup REDSTONE;
    public static RetroItemGroup TOOLS;
    public static RetroItemGroup COMBAT;
    public static RetroItemGroup FOOD_AND_DRINKS;
    public static RetroItemGroup INGREDIENTS;
    /** Modern's inventory tab: the player's own armour, storage and hotbar, not a list of items. */
    public static RetroItemGroup INVENTORY;
    /** Modern's Operator Utilities: command blocks, and nothing a survival world can reach. */
    /** Modern's Spawn Eggs tab: the spawner and one egg per mob. See {@code SpawnEggs}. */
    public static RetroItemGroup SPAWN_EGGS;
    public static RetroItemGroup OPERATOR;
    /** Everything beta has, unsorted - modern's search tab, which is also the "did I forget one" tab. */
    public static RetroItemGroup SEARCH;

    /** One number per (id, metadata) pair, so the same stack listed by two tabs is offered once. */
    private static long key(final int id, final int meta) {
        return ((long) id << 32) | (meta & 0xFFFFFFFFL);
    }

    private static NamespacedIdentifier id(final String path) {
        return NamespacedIdentifiers.from("minecraft", path);
    }

    /**
     * Registers the vanilla tabs. Called by RetroAPI before any mod's init runs, and again from
     * {@link RetroItemGroups#all()} as a safety net - a mod that reaches one of these fields must
     * never find it null, because a null group makes {@code modifyEntries} a silent no-op.
     */
    /**
     * Blocks that exist only as world states: fluids, fire, the piston's moving parts, the lit
     * variants a block switches to itself, the double slab two slabs become. Modern has no items for
     * any of them either, and a creative tab full of them is how a backport looks unfinished.
     */
    private static boolean isTechnical(final int blockId) {
        return ObtainableItems.isTechnicalBlock(blockId);
    }

    /**
     * Blocks whose held form is a different item - a bed, a door, a sign, a cake, a repeater, sugar
     * cane, redstone. The block goes in the world; the item goes in your hand, and it is the item
     * that belongs in a creative tab.
     */
    private static boolean hasSeparateItem(final int blockId) {
        return ObtainableItems.hasSeparateItem(blockId);
    }

    public static synchronized void ensureRegistered() {
        if (registered) {
            return;
        }
        registered = true;

        BUILDING_BLOCKS = RetroItemGroup.builder(id("building_blocks"))
            .displayName(Text.literal("Building Blocks"))
            .icon(() -> new C_88708284(C_81592558.f_73573195))
            .entries(entries -> {
                entries.add(C_81592558.f_38442324);
                entries.add(C_81592558.f_17981199);
                entries.add(C_81592558.f_87667057);
                entries.add(C_81592558.f_38259672);
                entries.add(C_81592558.f_73573195);
                entries.add(C_81592558.f_94949418);
                // All four slabs beta has: stone, sandstone, wood, cobblestone. The double-slab block
                // is deliberately absent - it is what two of these become, not something you place.
                entries.addRange(C_81592558.f_66929948, 0, 3);
                entries.add(C_81592558.f_27446762);
                entries.add(C_81592558.f_38177074);
                entries.add(C_81592558.f_05581995);
                entries.add(C_81592558.f_86394960);
                // Wood: the three species beta has, then everything made of them.
                entries.addRange(C_81592558.f_78280144, 0, 2);
                entries.add(C_81592558.f_32493286);
                entries.add(C_81592558.f_31892463);
                entries.add(C_81592558.f_98928673);
                entries.add(C_81592558.f_22197047);
                entries.add(C_81592558.f_32420701);
                entries.add(C_81592558.f_12629815);
                entries.add(C_81592558.f_51102006);
                entries.add(C_81592558.f_28421768);
                entries.add(C_81592558.f_38591135);
                entries.add(C_81592558.f_14995882);
                entries.add(C_81592558.f_84892602);
                entries.add(C_81592558.f_19295217);
                entries.add(C_81592558.f_41428926);
                entries.add(C_81592558.f_54760749);
                entries.add(C_81592558.f_95737061);
                entries.add(C_81592558.f_99851615);
                entries.add(C_81592558.f_35695348);
            })
            .build();

        COLORED_BLOCKS = RetroItemGroup.builder(id("colored_blocks"))
            .displayName(Text.literal("Colored Blocks"))
            .icon(() -> new C_88708284(C_81592558.f_12629815.f_84602679, 1, 14))
            .entries(entries -> entries.addRange(C_81592558.f_12629815, 0, 15))
            .build();

        NATURAL = RetroItemGroup.builder(id("natural"))
            .displayName(Text.literal("Natural Blocks"))
            .icon(() -> new C_88708284(C_81592558.f_41096518))
            .entries(entries -> {
                entries.add(C_81592558.f_41096518);
                entries.add(C_81592558.f_05581995);
                entries.add(C_81592558.f_27446762);
                entries.add(C_81592558.f_38177074);
                entries.add(C_81592558.f_86394960);
                entries.add(C_81592558.f_38442324);
                entries.add(C_81592558.f_81094226);
                entries.add(C_81592558.f_19757556);
                entries.add(C_81592558.f_91577743);
                entries.add(C_81592558.f_35664400);
                entries.add(C_81592558.f_83073694);
                entries.add(C_81592558.f_68803305);
                entries.add(C_81592558.f_38591135);
                entries.addRange(C_81592558.f_78280144, 0, 2);
                entries.addRange(C_81592558.f_00276986, 0, 2);
                entries.addRange(C_81592558.f_77878473, 0, 2);
                entries.add(C_81592558.f_99121891);
                // Tall grass and fern are metadata on the same block; the dead-shrub state (0) is the
                // one you cannot get, so it is not offered.
                entries.addRange(C_81592558.f_83907852, 1, 2);
                entries.add(C_81592558.f_38977206);
                entries.add(C_81592558.f_72900486);
                entries.add(C_81592558.f_55254929);
                entries.add(C_81592558.f_30894038);
                entries.add(C_81592558.f_94556547);
                // The item, not the block: placing sugar cane is what the item does, and the block has
                // no item form of its own.
                entries.add(C_98888256.f_55275152);
                entries.add(C_81592558.f_94091898);
                entries.add(C_81592558.f_51102006);
                entries.add(C_81592558.f_28421768);
                entries.add(C_81592558.f_88550428);
                entries.add(C_81592558.f_36441950);
                entries.add(C_81592558.f_14995882);
                entries.add(C_81592558.f_84892602);
                entries.add(C_81592558.f_19295217);
            })
            .build();

        FUNCTIONAL = RetroItemGroup.builder(id("functional"))
            .displayName(Text.literal("Functional Blocks"))
            .icon(() -> new C_88708284(C_81592558.f_23542568))
            .entries(entries -> {
                entries.add(C_81592558.f_23542568);
                entries.add(C_81592558.f_30918233);
                entries.add(C_81592558.f_19785413);
                entries.add(C_81592558.f_49828421);
                entries.add(C_81592558.f_25017736);
                entries.add(C_81592558.f_82599628);
                entries.add(C_81592558.f_51448992);
                entries.add(C_98888256.f_97502738);
                entries.add(C_98888256.f_92303073);
                entries.add(C_98888256.f_40777991);
                entries.add(C_81592558.f_79966048);
                entries.add(C_81592558.f_98928673);
                entries.add(C_98888256.f_08856223);
                // The item, not the block - same as the bed and the doors around it. The block is what
                // a placed cake IS; the item is what anyone can hold, and Food and Drinks lists it too.
                entries.add(C_98888256.f_59726285);
                entries.add(C_98888256.f_27056679);
                entries.add(C_81592558.f_49218653);
                entries.add(C_81592558.f_69656505);
            })
            .build();

        REDSTONE = RetroItemGroup.builder(id("redstone"))
            .displayName(Text.literal("Redstone Blocks"))
            .icon(() -> new C_88708284(C_98888256.f_52656331))
            .entries(entries -> {
                entries.add(C_98888256.f_52656331);
                // LIT_REDSTONE_TORCH is the one with an item form; REDSTONE_TORCH is the off state a
                // placed torch switches to, and is not something you can hold.
                entries.add(C_81592558.f_78503403);
                entries.add(C_98888256.f_98054602);
                entries.add(C_81592558.f_82613228);
                entries.add(C_81592558.f_40727126);
                entries.add(C_81592558.f_90267132);
                entries.add(C_81592558.f_58356112);
                entries.add(C_81592558.f_58920251);
                entries.add(C_81592558.f_82599628);
                entries.add(C_81592558.f_65735585);
                entries.add(C_81592558.f_85558300);
                entries.add(C_81592558.f_69656505);
                entries.add(C_81592558.f_86544900);
                entries.add(C_81592558.f_27559703);
                entries.add(C_81592558.f_89685822);
                entries.add(C_98888256.f_72559846);
                entries.add(C_98888256.f_20481988);
                entries.add(C_98888256.f_49490949);
            })
            .build();

        TOOLS = RetroItemGroup.builder(id("tools"))
            .displayName(Text.literal("Tools & Utilities"))
            .icon(() -> new C_88708284(C_98888256.f_98306436))
            .entries(entries -> {
                entries.add(C_98888256.f_38813183);
                entries.add(C_98888256.f_50174679);
                entries.add(C_98888256.f_27888996);
                entries.add(C_98888256.f_03688690);
                entries.add(C_98888256.f_18708761);
                entries.add(C_98888256.f_88921834);
                entries.add(C_98888256.f_02912756);
                entries.add(C_98888256.f_98142733);
                entries.add(C_98888256.f_80805461);
                entries.add(C_98888256.f_98306436);
                entries.add(C_98888256.f_89785708);
                entries.add(C_98888256.f_57678723);
                entries.add(C_98888256.f_50429169);
                entries.add(C_98888256.f_68090982);
                entries.add(C_98888256.f_08977302);
                entries.add(C_98888256.f_31038121);
                entries.add(C_98888256.f_04770191);
                entries.add(C_98888256.f_43932574);
                entries.add(C_98888256.f_45386391);
                entries.add(C_98888256.f_35880850);
                entries.add(C_98888256.f_96370468);
                entries.add(C_98888256.f_91599154);
                entries.add(C_98888256.f_94313583);
                entries.add(C_98888256.f_32467447);
                entries.add(C_98888256.f_62954975);
                entries.add(C_98888256.f_57012528);
                // Modern's own order for the two of them: shears just after the fishing rod, and the
                // map at the end of the compass/clock run of things you read rather than swing.
                entries.add(C_98888256.f_18374421);
                entries.add(C_98888256.f_53864758);
                entries.add(C_98888256.f_10956141);
                entries.add(C_98888256.f_69447318);
                entries.add(C_98888256.f_67114151);
                entries.add(C_98888256.f_07293363);
                entries.add(C_98888256.f_30116592);
                entries.add(C_98888256.f_33926157);
            })
            .build();

        COMBAT = RetroItemGroup.builder(id("combat"))
            .displayName(Text.literal("Combat"))
            .icon(() -> new C_88708284(C_98888256.f_32125146))
            .entries(entries -> {
                entries.add(C_98888256.f_96913276);
                entries.add(C_98888256.f_13344738);
                entries.add(C_98888256.f_32125146);
                entries.add(C_98888256.f_56140732);
                entries.add(C_98888256.f_29490209);
                entries.add(C_98888256.f_59992682);
                entries.add(C_98888256.f_67660833);
                entries.add(C_98888256.f_92705060);
                entries.add(C_98888256.f_60255230);
                entries.add(C_98888256.f_78687479);
                entries.add(C_98888256.f_65686175);
                entries.add(C_98888256.f_20484061);
                entries.add(C_98888256.f_92537726);
                entries.add(C_98888256.f_24275834);
                entries.add(C_98888256.f_67341244);
                entries.add(C_98888256.f_84448376);
                entries.add(C_98888256.f_56682976);
                entries.add(C_98888256.f_64671240);
                entries.add(C_98888256.f_96568531);
                entries.add(C_98888256.f_06326883);
                entries.add(C_98888256.f_58467061);
                entries.add(C_98888256.f_20229887);
                entries.add(C_98888256.f_08730706);
                entries.add(C_98888256.f_00953201);
                entries.add(C_98888256.f_54219088);
                entries.add(C_98888256.f_42239243);
                entries.add(C_98888256.f_21328201);
            })
            .build();

        FOOD_AND_DRINKS = RetroItemGroup.builder(id("food_and_drinks"))
            .displayName(Text.literal("Food & Drinks"))
            .icon(() -> new C_88708284(C_98888256.f_18291365))
            .entries(entries -> {
                entries.add(C_98888256.f_57144513);
                entries.add(C_98888256.f_18291365);
                entries.add(C_98888256.f_94155714);
                entries.add(C_98888256.f_91086089);
                entries.add(C_98888256.f_59726285);
                entries.add(C_98888256.f_94828714);
                entries.add(C_98888256.f_70512792);
                entries.add(C_98888256.f_40838509);
                entries.add(C_98888256.f_87025895);
                entries.add(C_98888256.f_87709655);
                entries.add(C_98888256.f_62954975);
            })
            .build();

        INGREDIENTS = RetroItemGroup.builder(id("ingredients"))
            .displayName(Text.literal("Ingredients"))
            .icon(() -> new C_88708284(C_98888256.f_80480869))
            .entries(entries -> {
                entries.add(C_98888256.f_58154723);
                entries.add(C_98888256.f_80480869);
                entries.add(C_98888256.f_73771168);
                entries.add(C_98888256.f_18976102);
                entries.add(C_98888256.f_70868303);
                entries.add(C_98888256.f_21498627);
                entries.add(C_98888256.f_94759491);
                entries.add(C_98888256.f_56704454);
                entries.add(C_98888256.f_08935226);
                entries.add(C_98888256.f_08971169);
                entries.add(C_98888256.f_21279732);
                entries.add(C_98888256.f_39465979);
                entries.add(C_98888256.f_90966147);
                entries.add(C_98888256.f_32576217);
                entries.add(C_98888256.f_46317332);
                entries.add(C_98888256.f_10659101);
                entries.add(C_98888256.f_03970011);
                entries.add(C_98888256.f_84974010);
                entries.add(C_98888256.f_60617725);
                entries.add(C_98888256.f_79588801);
                entries.add(C_98888256.f_55275152);
                entries.add(C_98888256.f_51993064);
                entries.add(C_98888256.f_32150368);
                entries.add(C_98888256.f_88723374);
                entries.add(C_98888256.f_52656331);
                // Dye, all sixteen, the way modern lists them together.
                entries.addRange(C_98888256.f_09260276, 0, 15);
            })
            .build();

        // Modern's tenth paginated tab, bottom row column 4, and the last one on the first page.
        SPAWN_EGGS = RetroItemGroup.builder(id("spawn_eggs"))
            .displayName(Text.literal("Spawn Eggs"))
            .icon(() -> {
                final C_98888256 creeperEgg = com.periut.retroapi.entity.spawnegg.SpawnEggs.icon();
                return creeperEgg == null ? new C_88708284(C_81592558.f_50662990) : new C_88708284(creeperEgg);
            })
            .entries(entries -> {
                // Modern's own contents: the spawner first, then an egg per mob. Registered late
                // (RetroAPI's init), so this reads them when the tab is opened, never at build time.
                entries.add(C_81592558.f_50662990);
                for (final C_98888256 egg : com.periut.retroapi.entity.spawnegg.SpawnEggs.all()) {
                    entries.add(egg);
                }
            })
            .build();

        OPERATOR = RetroItemGroup.builder(id("op_blocks"))
            .displayName(Text.literal("Operator Utilities"))
            .icon(() -> new C_88708284(com.periut.retroapi.commandblock.CommandBlocks.IMPULSE == null
                ? C_81592558.f_58920251 : com.periut.retroapi.commandblock.CommandBlocks.IMPULSE))
            .entries(entries -> {
                // Registered late (RetroAPI's own init) so guard the nulls: a tab that throws would
                // take the whole screen with it.
                entries.add(com.periut.retroapi.commandblock.CommandBlocks.IMPULSE);
                entries.add(com.periut.retroapi.commandblock.CommandBlocks.CHAIN);
                entries.add(com.periut.retroapi.commandblock.CommandBlocks.REPEATING);
                // The spawner is modern's, but it lives on the Spawn Eggs tab there, not this one.
                entries.add(C_81592558.f_35695348);
            })
            .build();

        // Contents come from the player, not from a list: the screen swaps the container's slots for
        // the player's own when this tab is picked, which is what modern does.
        INVENTORY = RetroItemGroup.builder(id("inventory"))
            .displayName(Text.literal("Inventory"))
            .icon(() -> new C_88708284(C_81592558.f_49828421))
            .entries(entries -> {
            })
            .build();

        SEARCH = RetroItemGroup.builder(id("search"))
            .displayName(Text.literal("Search Items"))
            .icon(() -> new C_88708284(C_98888256.f_53864758))
            .entries(entries -> {
                // Everything every OTHER tab lists, then everything no tab lists at all.
                //
                // Built from the tabs rather than by walking the registries alone, because the tabs are
                // where the subtypes are known: beta has no way to ask a block how many kinds of it
                // there are, so "logs 0..2, leaves 0..2, saplings 0..2, wool 0..15" is knowledge that
                // lives in the addRange calls above. Walking the registries listed each block once, at
                // metadata zero, which is why searching for birch, or for a blue wool, found nothing.
                //
                // A mod's own tab is included on the same terms, so its variants are searchable without
                // it registering them twice - and anything with no tab at all is still swept up below,
                // which is what keeps this the "did I forget one" tab.
                final java.util.Set<Long> listed = new java.util.LinkedHashSet<>();

                // A tab this world hides is walked but not listed: its ids still go into `listed`, so
                // the sweep below leaves them alone too. Otherwise hiding Operator Utilities would have
                // moved the command blocks to the end of the search tab rather than out of it, and
                // "hidden behind a gamerule" would have meant nothing at all.
                final boolean operatorHidden =
                    !com.periut.retroapi.gamerule.RetroGameRules.getBoolean(
                        com.periut.retroapi.gamerule.RetroGameRules.OPERATOR_ITEMS_TAB);

                for (final RetroItemGroup group : RetroItemGroups.all()) {
                    if (group == SEARCH || group == INVENTORY) {
                        continue;   // itself, and the tab that shows the player rather than a list
                    }
                    final boolean hidden = group == OPERATOR && operatorHidden;
                    for (final C_88708284 stack : group.collect()) {
                        if (stack != null && listed.add(key(stack.f_59294634, stack.m_21098843())) && !hidden) {
                            entries.add(stack.m_73216943());
                        }
                    }
                }

                // The sweep: every obtainable id NO tab mentioned at all, at metadata zero.
                //
                // "At all" is the important part. Asking only whether metadata zero was listed added a
                // fourth tall grass to the end of the tab - Natural Blocks lists grass 1..2 deliberately,
                // because 0 is the dead shrub nobody can obtain, and the sweep helpfully put it back.
                final java.util.Set<Integer> anyMeta = new java.util.HashSet<>();
                for (final long entry : listed) {
                    anyMeta.add((int) (entry >> 32));
                }

                for (final C_81592558 block : C_81592558.f_44428008) {
                    if (block != null && ObtainableItems.isObtainable(block.f_84602679) && anyMeta.add(block.f_84602679)) {
                        entries.add(block);
                    }
                }
                for (final C_98888256 item : C_98888256.f_38445253) {
                    if (item != null && ObtainableItems.isObtainable(item.f_57562535) && anyMeta.add(item.f_57562535)) {
                        entries.add(item);
                    }
                }
            })
            .build();
    }
}
