package com.periut.retroapi.mixin.gamerule;

import com.periut.retroapi.gamerule.RetroGameRules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;
import net.minecraft.unmapped.C_32290952;
import net.minecraft.unmapped.C_64041439;

/**
 * {@code doFireTick}: fire neither spreads nor burns out.
 *
 * <p>The whole scheduled tick is cancelled, which is what modern does - the flame stays exactly where
 * it was lit until something removes it.
 */
@Mixin(C_32290952.class)
public class FireTickMixin {

	@Inject(method = "onTick", at = @At("HEAD"), cancellable = true)
	private void retroapi$doFireTick(C_64041439 world, int x, int y, int z, Random random, CallbackInfo ci) {
		if (!RetroGameRules.getBoolean(RetroGameRules.DO_FIRE_TICK)) {
			ci.cancel();
		}
	}
}
