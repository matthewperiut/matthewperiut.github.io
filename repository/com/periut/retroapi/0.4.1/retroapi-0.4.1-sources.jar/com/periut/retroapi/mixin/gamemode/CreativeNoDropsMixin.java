package com.periut.retroapi.mixin.gamemode;

import com.periut.retroapi.gamemode.RetroGameMode;
import com.periut.retroapi.gamemode.RetroGameModes;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Breaking a block in creative drops nothing, as in modern.
 *
 * <p>{@code Block.afterBreak} is the one method both sides run after a block is mined and is where
 * beta drops the items, so cancelling it there covers the client's own break path and the server's
 * {@code tryBreakBlock} alike - and leaves every other kind of break (explosions, {@code /setblock
 * destroy}, a piston) dropping normally, because none of them come through here with a player.
 */
@Mixin(C_81592558.class)
public class CreativeNoDropsMixin {

	@Inject(method = "afterBreak", at = @At("HEAD"), cancellable = true)
	private void retroapi$noCreativeDrops(C_64041439 world, C_40996800 player, int x, int y, int z, int meta, CallbackInfo ci) {
		if (player != null && RetroGameModes.get(player) == RetroGameMode.CREATIVE) {
			ci.cancel();
		}
	}
}
