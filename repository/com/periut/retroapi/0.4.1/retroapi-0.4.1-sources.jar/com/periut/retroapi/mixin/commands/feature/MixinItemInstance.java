package com.periut.retroapi.mixin.commands.feature;

import com.periut.retroapi.commands.api.ItemInstanceStr;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_74891195;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_88708284.class)
public abstract class MixinItemInstance implements ItemInstanceStr {
    @Unique
    private String name;

    @Override
    public String spc$getStr() {
        return this.name;
    }

    @Override
    public void spc$setStr(String name) {
        this.name = name;
    }

    @Inject(method = "writeNbt", at = @At("RETURN"))
    private void onToTag(C_74087615 arg, CallbackInfoReturnable<C_74087615> cir) {
        if (this.name != null)
            arg.m_21770494("spcName", new C_74891195(this.name));
    }

    @Inject(method = "readNbt", at = @At("HEAD"))
    private void onFromTag(C_74087615 arg, CallbackInfo ci) {
        if (arg.m_97612750("spcName")) {
            this.name = arg.m_47517355("spcName");
        }
    }


    @Inject(method = "split", at = @At("RETURN"))
    private void onSplit(int i, CallbackInfoReturnable<C_88708284> cir) {
        ItemInstanceStr copyMixin = (ItemInstanceStr) (Object) cir.getReturnValue();
        copyMixin.spc$setStr(this.name);
    }


    /*
    @Inject(method = "copy()Lnet/minecraft/item/ItemInstance;", at = @At("RETURN"))
    private void onCopy(CallbackInfoReturnable<ItemInstance> cir) {
        ItemInstanceStr copyMixin = (ItemInstanceStr) (Object) cir.getReturnValue();
        if (this.name != null && cir.getReturnValue() != null)
            copyMixin.spc$setStr(this.name);
        else
            System.out.println("didn't work");
    }
*/
}
