package com.periut.retroapi.register.blockentity;

import com.periut.retroapi.network.RetroAPINetworking;
import net.minecraft.unmapped.C_40735137;
import net.minecraft.unmapped.C_49202226;
import net.ornithemc.osl.networking.api.server.ServerPlayNetworking;

import java.util.List;

/**
 * Server-only half of block-entity sync. Kept in its own class - the same shape as
 * {@code StateSyncServer} - so a client environment never loads ServerPlayerEntity or
 * ServerPlayNetworking; callers only reach it from SERVER-side mixins.
 */
public final class BlockEntitySyncServer {

	private BlockEntitySyncServer() {}

	/** Answers a client's "what is in this chunk?" with every synced block entity inside it. */
	public static void sendChunk(C_49202226 player, int chunkX, int chunkZ) {
		if (player == null || !(player.f_94306729 instanceof net.minecraft.unmapped.C_70668269 world)) {
			return;
		}
		// Only a chunk the player could actually be watching, so the request cannot be used to read
		// block entities from across the world.
		if (Math.abs(chunkX - ((int) player.f_78826675 >> 4)) > 16 || Math.abs(chunkZ - ((int) player.f_97691941 >> 4)) > 16) {
			return;
		}

		final int x = chunkX << 4;
		final int z = chunkZ << 4;
		for (final Object candidate : world.m_71796348(x, 0, z, x + 15, 128, z + 15)) {
			if (candidate instanceof C_40735137 blockEntity && blockEntity instanceof RetroSyncedBlockEntity) {
				sendTo(player, blockEntity);
			}
		}
	}

	/** Beta's own view distance, in blocks: the furthest a joining player can already be watching. */
	private static final int VIEW_RADIUS = 10 * 16;

	/**
	 * Everything synced within sight of a player who has just become reachable.
	 *
	 * <p>Vanilla sends a chunk's block entities the moment it sends the chunk, and RetroAPI hangs its own
	 * sync off that - but at join time those chunks go out before the client has finished registering its
	 * channels, and OSL <em>drops</em> a send to a player whose channel is not ready yet. Not queues:
	 * drops. So the state that rode along with the first chunks was thrown away, and nothing sent it
	 * again - which is why a spawner set to creepers came back as a pig every time you rejoined, then
	 * corrected itself the moment anything touched it.
	 *
	 * <p>Called from {@code ServerConnectionEvents.PLAY_READY}, which is the first moment a send to this
	 * player actually goes anywhere.
	 */
	public static void sendNearby(C_49202226 player) {
		if (player == null || !(player.f_94306729 instanceof net.minecraft.unmapped.C_70668269 world)) {
			return;
		}

		final int x = (int) player.f_78826675;
		final int z = (int) player.f_97691941;
		final List<?> found = world.m_71796348(
			x - VIEW_RADIUS, 0, z - VIEW_RADIUS, x + VIEW_RADIUS, 128, z + VIEW_RADIUS);

		for (final Object candidate : found) {
			if (candidate instanceof C_40735137 blockEntity && blockEntity instanceof RetroSyncedBlockEntity) {
				sendTo(player, blockEntity);
			}
		}
	}

	/** Sends one block entity's state to a single player. */
	public static void sendTo(C_49202226 player, C_40735137 blockEntity) {
		byte[] data = BlockEntitySyncCodec.encode(blockEntity);
		if (data == null) {
			return;
		}
		send(player, blockEntity, data);
	}

	/** Sends one block entity's state to every player in a list (the chunk's trackers). */
	public static void sendToAll(List<?> players, C_40735137 blockEntity) {
		if (players == null || players.isEmpty()) {
			return;
		}
		byte[] data = BlockEntitySyncCodec.encode(blockEntity);
		if (data == null) {
			return;
		}
		for (Object player : players) {
			if (player instanceof C_49202226) {
				send((C_49202226) player, blockEntity, data);
			}
		}
	}

	private static void send(C_49202226 player, C_40735137 blockEntity, byte[] data) {
		ServerPlayNetworking.send(player, RetroAPINetworking.BLOCK_ENTITY_SYNC_CHANNEL, buf -> {
			buf.writeInt(blockEntity.f_07118142);
			buf.writeInt(blockEntity.f_33969464);
			buf.writeInt(blockEntity.f_77944174);
			buf.writeByteArray(data);
		});
	}
}
