package com.periut.retroapi.mixin.gamerule;

import com.periut.retroapi.gamerule.RetroGameRules;
import net.minecraft.unmapped.C_25501528;
import net.minecraft.unmapped.C_64041439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** {@code doMobSpawning}: the natural spawner does nothing at all. */
@Mixin(C_25501528.class)
public class MobSpawningMixin {

	@Inject(method = "tick", at = @At("HEAD"), cancellable = true)
	private static void retroapi$doMobSpawning(C_64041439 world, boolean spawnMonsters, boolean spawnAnimals,
			CallbackInfoReturnable<Integer> cir) {
		if (!RetroGameRules.getBoolean(RetroGameRules.DO_MOB_SPAWNING)) {
			cir.setReturnValue(0);
		}
	}
}
