package com.periut.retroapi.mixin.voxelshapes;

import com.periut.retroapi.gamemode.RetroFlight;
import com.periut.retroapi.voxelshapes.HasCollisionVoxelShape;
import com.periut.retroapi.voxelshapes.HasVoxelShape;
import com.periut.retroapi.voxelshapes.VoxelShape;
import net.minecraft.server.MinecraftServer;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_70668269;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_93816630;
import net.minecraft.unmapped.C_99660737;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;

@Mixin(C_99660737.class)
public abstract class VoxelMoveCheckMixin {
    @Shadow
    private C_49202226 player;
    @Shadow
    private MinecraftServer server;

    @Redirect(method = "onPlayerMove", at = @At(value = "INVOKE", target = "Lnet/minecraft/server/network/ServerPlayNetworkHandler;teleport(DDDFF)V", ordinal = 0))
    private void retroapi$verifyBlockIntersectionForBlockVoxelShapes(C_99660737 instance, double e, double f, double g, float h, float v) {
        // A player who passes through terrain is INSIDE blocks on purpose. The server re-simulates their move and drags
        // them back out of anything they collide with, and that check is a plain block-box query which
        // never consults the entity's noClip flag - so the one rubber-band correction that has to be
        // suppressed is this one, and only while they are actually flying.
        //
        // This gate lives here rather than in the commands mixin because both are @Redirect on the SAME
        // teleport() call: two redirects on one call site is a hard conflict, and mixin resolves it by
        // silently dropping one of them (which one is load order). One redirect, both concerns.
        if (RetroFlight.ignoresBlocks(this.player.f_59008391)) {
            return;
        }

        C_70668269 world = this.server.m_54705229(this.player.f_15409937);
        C_82690114 originalPlayerBox = player.f_00583773;
        C_82690114 playerBox = C_82690114.m_23878395(originalPlayerBox.f_87518512, originalPlayerBox.f_80314167, originalPlayerBox.f_85940458,
                originalPlayerBox.f_89130367, originalPlayerBox.f_98553650, originalPlayerBox.f_24562106);

        C_93816630 min = new C_93816630((int) Math.floor(playerBox.f_87518512), (int) Math.floor(playerBox.f_80314167), (int) Math.floor(playerBox.f_85940458));
        C_93816630 max = new C_93816630((int) Math.ceil(playerBox.f_89130367), (int) Math.ceil(playerBox.f_98553650), (int) Math.ceil(playerBox.f_24562106));

        boolean collisionVerified = false;

        for (int x = min.f_39781383; x <= max.f_39781383; x++) {
            for (int y = min.f_62514677; y <= max.f_62514677; y++) {
                for (int z = min.f_38078371; z <= max.f_38078371; z++) {
                    int blockId = world.m_33234383(x, y, z);
                    C_81592558 block = (blockId > 0 && blockId < C_81592558.f_44428008.length) ? C_81592558.f_44428008[blockId] : null;
                    if (block == null) continue;
                    List<C_82690114> boxes = null;

                    if (block instanceof HasCollisionVoxelShape hasCollisionVoxelShape) {
                        VoxelShape voxelShape = hasCollisionVoxelShape.getCollisionVoxelShape(world, x, y, z);
                        if (voxelShape != null) {
                            boxes = voxelShape.getOffsetBoxes();
                        }
                    } else if (block instanceof HasVoxelShape hasVoxelShape) {
                        VoxelShape voxelShape = hasVoxelShape.getVoxelShape(world, x, y, z);
                        if (voxelShape != null) {
                            boxes = voxelShape.getOffsetBoxes();
                        }
                    } else {
                        // getCollisionShape is null for non-colliding blocks (flowers, the
                        // pink flower, ...). List.of(null) throws, which kicked the player on
                        // any move near one, so guard it.
                        C_82690114 collisionShape = block.m_03092609(world, x, y, z);
                        boxes = collisionShape != null ? List.of(collisionShape) : null;
                    }

                    if (boxes != null) {
                        for (C_82690114 blockBoxPart : boxes) {
                            if (blockBoxPart == null) continue;
                            if (playerBox.m_39770760(blockBoxPart)) {
                                collisionVerified = true;
                            }
                        }
                    }
                }
            }
        }

        if (collisionVerified) {
            instance.m_40197477(e, f, g, h, v);
        }
    }
}