package com.periut.retroapi.mixin.gamemode.client;

import com.periut.retroapi.client.screen.RetroCreativeScreen;
import com.periut.retroapi.gamemode.RetroGameMode;
import com.periut.retroapi.gamemode.RetroGameModes;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_85589673;
import net.minecraft.unmapped.C_85740840;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/**
 * A creative player's inventory key opens the creative screen instead of the survival one.
 *
 * <p>Swapped on its way into {@code setScreen}, the same trick the chat screen uses, so every route
 * into the inventory - the key, a mod, a block that opens it - ends up in the right place.
 */
@Mixin(Minecraft.class)
public class CreativeInventoryScreenMixin {

	@ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
	private C_85740840 retroapi$creativeInventory(C_85740840 screen) {
		if (screen == null || screen.getClass() != C_85589673.class) {
			return screen;
		}
		Minecraft minecraft = (Minecraft) (Object) this;
		if (minecraft.f_28396371 == null
			|| RetroGameModes.get(minecraft.f_28396371.f_59008391) != RetroGameMode.CREATIVE) {
			return screen;
		}
		return new RetroCreativeScreen(minecraft.f_28396371);
	}
}
