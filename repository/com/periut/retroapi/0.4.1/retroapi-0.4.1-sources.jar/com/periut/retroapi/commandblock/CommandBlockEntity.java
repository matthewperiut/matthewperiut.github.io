package com.periut.retroapi.commandblock;

import com.periut.retroapi.register.blockentity.RetroSyncedBlockEntity;
import net.minecraft.unmapped.C_40735137;
import net.minecraft.unmapped.C_74087615;

/**
 * A command block's command and the state that decides whether it may run.
 *
 * <p>Modern splits this between {@code BaseCommandBlock} (the command, the output, the success
 * count) and {@code CommandBlockEntity} (powered, automatic, conditionMet); beta has no reason for
 * two classes, so the fields are here under modern's names and with modern's meanings.
 *
 * <p>{@code lastExecution} is modern's guard against a block running twice in one tick, which is
 * what stops a chain that loops back on itself from executing forever inside a single tick.
 */
public class CommandBlockEntity extends C_40735137 implements RetroSyncedBlockEntity {

    private String command = "";
    private String lastOutput = "";
    private int successCount;
    private boolean trackOutput = true;

    private boolean powered;
    private boolean automatic;
    private boolean conditionMet;

    private long lastExecution = -1L;

    public String getCommand() {
        return command;
    }

    /** Setting a new command clears the success count, exactly as {@code BaseCommandBlock} does. */
    public void setCommand(final String command) {
        this.command = command == null ? "" : command;
        this.successCount = 0;
        m_38999452();
    }

    public String getLastOutput() {
        return lastOutput;
    }

    public void setLastOutput(final String lastOutput) {
        this.lastOutput = lastOutput == null ? "" : lastOutput;
        m_38999452();
    }

    public int getSuccessCount() {
        return successCount;
    }

    public void setSuccessCount(final int successCount) {
        this.successCount = successCount;
        m_38999452();
    }

    public boolean isTrackOutput() {
        return trackOutput;
    }

    public void setTrackOutput(final boolean trackOutput) {
        this.trackOutput = trackOutput;
        m_38999452();
    }

    public boolean isPowered() {
        return powered;
    }

    public void setPowered(final boolean powered) {
        this.powered = powered;
        m_38999452();
    }

    public boolean isAutomatic() {
        return automatic;
    }

    public void setAutomatic(final boolean automatic) {
        this.automatic = automatic;
        m_38999452();
    }

    public boolean wasConditionMet() {
        return conditionMet;
    }

    /**
     * Works out whether the block may run, and remembers the answer.
     *
     * <p>Modern's rule: an unconditional block always may; a conditional one may only when the block
     * <em>behind</em> it - opposite the way it faces - is a command block that succeeded.
     *
     * @return the same value {@link #wasConditionMet()} will now report
     */
    public boolean markConditionMet() {
        conditionMet = true;

        if (CommandBlocks.isConditional(f_18133822, f_07118142, f_33969464, f_77944174)) {
            final int[] behind = CommandBlockFacing.behind(f_18133822, f_07118142, f_33969464, f_77944174);
            conditionMet = behind != null
                && f_18133822.m_40611090(behind[0], behind[1], behind[2]) instanceof CommandBlockEntity previous
                && previous.getSuccessCount() > 0;
        }

        return conditionMet;
    }

    /** @return false when this block has already run on this game tick */
    boolean beginExecution(final long gameTime) {
        if (lastExecution == gameTime) {
            return false;
        }
        lastExecution = gameTime;
        return true;
    }

    public CommandBlockMode getMode() {
        return CommandBlocks.modeOf(f_18133822 == null ? 0 : f_18133822.m_33234383(f_07118142, f_33969464, f_77944174));
    }

    @Override
    public void m_08722866(final C_74087615 nbt) {
        super.m_08722866(nbt);
        command = nbt.m_47517355("Command");
        successCount = nbt.m_35587574("SuccessCount");
        trackOutput = !nbt.m_97612750("TrackOutput") || nbt.m_25255788("TrackOutput");
        lastOutput = trackOutput ? nbt.m_47517355("LastOutput") : "";
        powered = nbt.m_25255788("powered");
        automatic = nbt.m_25255788("auto");
        conditionMet = nbt.m_25255788("conditionMet");
    }

    @Override
    public void m_55164141(final C_74087615 nbt) {
        super.m_55164141(nbt);
        nbt.m_91017064("Command", command);
        nbt.m_20318863("SuccessCount", successCount);
        nbt.m_11270099("TrackOutput", trackOutput);
        if (trackOutput) {
            nbt.m_91017064("LastOutput", lastOutput);
        }
        nbt.m_11270099("powered", powered);
        nbt.m_11270099("auto", automatic);
        nbt.m_11270099("conditionMet", conditionMet);
    }
}
