package com.periut.retroapi.compat;

import com.periut.retroapi.dimension.TeleportationManager;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_90931970;
import net.minecraft.unmapped.C_98888256;

/**
 * Default {@link StationBridge} used when the {@code retroapi-stationapi} mod is absent. Every method is a
 * no-op; in practice none are ever called, because core gates every StationAPI delegation on
 * {@code FabricLoader.isModLoaded("stationapi")} and the bridge resolves to the real implementation whenever
 * that gate passes. This exists only so {@link StationBridges#get()} never returns {@code null}.
 */
final class NoopStationBridge implements StationBridge {
	@Override public void registerBlock(String namespace, String path, C_81592558 block,
		java.util.function.IntFunction<net.minecraft.unmapped.C_71827890> itemFactory) {}
	@Override public void registerItem(String namespace, String path, C_98888256 item) {}
	@Override public void registerLangPath() {}
	@Override public void bindAchievement(C_90931970 achievement, String namespace, String path) {}
	@Override public int addTerrainTexture(String namespace, String path) { return -1; }
	@Override public int addItemTexture(String namespace, String path) { return -1; }
	@Override public void setItemTexture(C_98888256 item, String namespace, String path) {}
	@Override public void addShapedRecipe(C_88708284 output, Object... recipe) {}
	@Override public void addShapelessRecipe(C_88708284 output, Object... ingredients) {}
	@Override public void addSmeltingRecipe(int inputId, C_88708284 output) {}
	@Override public void attachPortal(C_40996800 player, TeleportationManager retroManager) {}
	@Override public java.util.List<String> dimensionIds() { return java.util.List.of(); }
	@Override public boolean switchDimension(C_40996800 player, String identifier) { return false; }
	@Override public String dimensionIdentifier(int serialId) { return null; }
	@Override public java.util.List<String> itemIdentifiers() { return java.util.List.of(); }
	@Override public int itemId(String identifier) { return -1; }
	@Override public int blockId(String identifier) { return -1; }
	@Override public String itemIdentifier(C_98888256 item) { return null; }
	@Override public int sprintKeyCode() { return -1; }
}
