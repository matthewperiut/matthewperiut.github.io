package com.periut.retroapi.mixin.movement;

import com.periut.retroapi.movement.api.EntitySprinting;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static com.periut.retroapi.movement.MovementConstants.BASE_SWIM_SPEED;
import static com.periut.retroapi.movement.MovementConstants.SPRINT_WATER_SLOW_DOWN;
import static com.periut.retroapi.movement.MovementConstants.WATER_VERTICAL_SLOW_DOWN;

@Mixin(C_74425583.class)
abstract public class LivingEntityMixin extends C_42232651 {

    @Shadow
    public float walkAnimationSpeed;

    @Shadow
    public float lastWalkAnimationSpeed;

    @Shadow
    public float walkAnimationProgress;

    public LivingEntityMixin(C_64041439 world) {
        super(world);
    }

    @Inject(method = "tickMovement", at = @At("HEAD"))
    private void increaseMovementSpeed(CallbackInfo info) {
        C_74425583 entity = (C_74425583) (Object) this;
        // In water the sprint boost comes out of the reduced drag in retroapi$travelInWater
        // instead, the way modern Minecraft does it - stacking this on top would overshoot.
        if (((EntitySprinting) (Object) entity).isSprinting() && !this.m_26067036()) {

            if (Math.sqrt(Math.pow(f_24826402, 2) + Math.pow(f_21201587, 2)) < 0.25) {
                float f = f_80130373 * ((float) Math.PI / 180);
                this.f_24826402 -= (double) (C_45510667.m_61414107(f) * 0.035f);
                this.f_21201587 += (double) (C_45510667.m_64246150(f) * 0.035f);
            }
        }
    }

    /**
     * LivingEntity.travelInWater, for the sprinting case only. Modern differs from b1.7.3 in
     * exactly two places while sprinting: horizontal drag relaxes from 0.8 to 0.9, and the
     * gravity term is skipped entirely (getFluidFallingAdjustedMovement returns early when
     * sprinting), which is why a sprint-swimmer holds their depth instead of sinking.
     * Everything else - the 0.02 base speed, the 0.8 vertical drag, the ledge hop - is the same
     * in both versions, so ordinary swimming keeps vanilla b1.7.3 behaviour untouched.
     */
    @Inject(method = "travel", at = @At("HEAD"), cancellable = true)
    private void retroapi$travelInWater(float sidewaysSpeed, float forwardSpeed, CallbackInfo ci) {
        if (!this.m_26067036() || !((EntitySprinting) (Object) this).isSprinting()) {
            return;
        }

        double oldY = this.f_31030949;
        this.m_66390769(sidewaysSpeed, forwardSpeed, BASE_SWIM_SPEED);
        this.m_15512507(this.f_24826402, this.f_35148123, this.f_21201587);
        this.f_24826402 *= SPRINT_WATER_SLOW_DOWN;
        this.f_35148123 *= WATER_VERTICAL_SLOW_DOWN;
        this.f_21201587 *= SPRINT_WATER_SLOW_DOWN;
        if (this.f_76585361 && this.m_96655813(this.f_24826402, this.f_35148123 + 0.6F - this.f_31030949 + oldY, this.f_21201587)) {
            this.f_35148123 = 0.3F;
        }

        this.retroapi$updateWalkAnimation();
        ci.cancel();
    }

    /** The tail of LivingEntity.travel, which the cancelled call would otherwise have reached. */
    @Unique
    private void retroapi$updateWalkAnimation() {
        this.lastWalkAnimationSpeed = this.walkAnimationSpeed;
        double dx = this.f_78826675 - this.f_59999765;
        double dz = this.f_97691941 - this.f_88346412;
        float speed = C_45510667.m_14578936(dx * dx + dz * dz) * 4.0F;
        if (speed > 1.0F) {
            speed = 1.0F;
        }

        this.walkAnimationSpeed = this.walkAnimationSpeed + (speed - this.walkAnimationSpeed) * 0.4F;
        this.walkAnimationProgress = this.walkAnimationProgress + this.walkAnimationSpeed;
    }

    @Inject(method = "jump", at = @At("TAIL"), cancellable = true)
    void addedSpeedOnSprintJump(CallbackInfo ci) {
        if (((EntitySprinting) (Object) this).isSprinting()) {
            float f = f_80130373 * ((float) Math.PI / 180);
            this.f_24826402 -= (double) (C_45510667.m_61414107(f) * 0.2f);
            this.f_21201587 += (double) (C_45510667.m_64246150(f) * 0.2f);
        }
        f_33245636 = true;
    }
}
