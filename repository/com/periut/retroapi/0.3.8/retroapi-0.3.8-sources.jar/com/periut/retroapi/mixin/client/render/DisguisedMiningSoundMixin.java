package com.periut.retroapi.mixin.client.render;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.periut.retroapi.register.block.RetroDisguises;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_03111506;
import net.minecraft.unmapped.C_54765678;
import net.minecraft.unmapped.C_81592558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * The tapping sound while a block is being mined, taken from the disguise. See
 * {@link com.periut.retroapi.register.block.RetroBlockDisguise}.
 *
 * <p>This is a separate sound from the one when the block finally gives way, played from a separate place
 * every four ticks of mining, and it is the one you hear most of: breaking a block by hand is a second of
 * tapping and a single crunch at the end. Fixing only the crunch leaves a stone-clad frame sounding like
 * wood for the entire time you are actually hitting it.
 *
 * <p>Unlike the break sound this needs no snapshot. The block is still standing while it is being mined,
 * so the disguise is simply read from the world.
 */
@Mixin(C_54765678.class)
@Environment(EnvType.CLIENT)
public class DisguisedMiningSoundMixin {

	@WrapOperation(method = "processBlockBreakingAction",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/sound/SoundManager;playSound(Ljava/lang/String;FFFFF)V"),
		require = 1)
	private void retroapi$disguisedMiningSound(C_03111506 sounds, String sound, float sx, float sy, float sz,
			float volume, float pitch, Operation<Void> original, int x, int y, int z, int side) {
		// The world comes through the accessor, not from a break record: the record is written by a
		// different mixin on a different class, and depending on one hook to have run before another is
		// how this ended up playing wooden sounds for a stone-clad block in the first place.
		net.minecraft.client.Minecraft minecraft =
			((com.periut.retroapi.mixin.client.InteractionManagerAccessor) this).retroapi$minecraft();
		C_81592558 worn = minecraft == null || minecraft.f_26407825 == null
			? null
			: RetroDisguises.at(minecraft.f_26407825, x, y, z);
		if (worn == null) {
			original.call(sounds, sound, sx, sy, sz, volume, pitch);
			return;
		}
		// Vanilla's own arithmetic for this sound, on the group it should have come from.
		original.call(sounds, worn.f_13889746.m_48793905(), sx, sy, sz,
			(worn.f_13889746.m_48828997() + 1.0F) / 8.0F, worn.f_13889746.m_35890820() * 0.5F);
	}
}
