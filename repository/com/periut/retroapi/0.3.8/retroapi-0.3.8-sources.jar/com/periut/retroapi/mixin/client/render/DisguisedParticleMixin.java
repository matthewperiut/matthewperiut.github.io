package com.periut.retroapi.mixin.client.render;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.periut.retroapi.register.block.RetroDisguises;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_13986175;
import net.minecraft.unmapped.C_16190149;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Makes a disguised block break into the right coloured dust. See
 * {@link com.periut.retroapi.register.block.RetroBlockDisguise}.
 *
 * <p>{@code BlockParticle} takes a block and reads {@code getTexture(0, meta)} off it, which is the block's
 * static sprite and has no idea where the block was. Both particle calls do know the position, so the
 * block handed to the particle is swapped for the one that position presents as.
 *
 * <p>The two calls need different sources for it. While a block is being chipped away it is still there,
 * so the disguise can simply be read. The cloud thrown out when it finally breaks is produced by a world
 * event that arrives after the block is gone, so that one reads what {@code RetroDisguises} wrote down on
 * the way out.
 */
@Mixin(C_16190149.class)
@Environment(EnvType.CLIENT)
public class DisguisedParticleMixin {

	@WrapOperation(method = "addBlockBreakingParticles",
		at = @At(value = "NEW", target = "(Lnet/minecraft/world/World;DDDDDDLnet/minecraft/block/Block;II)Lnet/minecraft/client/particle/BlockParticle;"),
		require = 1)
	private C_13986175 retroapi$disguiseBreakingParticle(C_64041439 world, double px, double py, double pz,
			double vx, double vy, double vz, C_81592558 block, int side, int meta,
			Operation<C_13986175> original, int x, int y, int z, int face) {
		C_81592558 worn = RetroDisguises.at(world, x, y, z);
		if (worn != null) {
			return original.call(world, px, py, pz, vx, vy, vz, worn, side,
				RetroDisguises.metaAt(world, x, y, z));
		}
		return original.call(world, px, py, pz, vx, vy, vz, block, side, meta);
	}

	@WrapOperation(method = "addBlockBreakParticles",
		at = @At(value = "NEW", target = "(Lnet/minecraft/world/World;DDDDDDLnet/minecraft/block/Block;II)Lnet/minecraft/client/particle/BlockParticle;"),
		require = 1)
	private C_13986175 retroapi$disguiseBreakParticle(C_64041439 world, double px, double py, double pz,
			double vx, double vy, double vz, C_81592558 block, int side, int meta,
			Operation<C_13986175> original, int x, int y, int z, int blockId, int blockMeta) {
		// Same as the sound: the debris cloud rides the same event, which in singleplayer is fired
		// before the block is taken out and from a server may arrive after. Ask the position first.
		C_81592558 worn = RetroDisguises.liveOrRemembered(world, x, y, z);
		if (worn != null) {
			return original.call(world, px, py, pz, vx, vy, vz, worn,
				side, RetroDisguises.at(world, x, y, z) != null
					? RetroDisguises.metaAt(world, x, y, z)
					: RetroDisguises.rememberedMeta(x, y, z));
		}
		return original.call(world, px, py, pz, vx, vy, vz, block, side, meta);
	}
}
