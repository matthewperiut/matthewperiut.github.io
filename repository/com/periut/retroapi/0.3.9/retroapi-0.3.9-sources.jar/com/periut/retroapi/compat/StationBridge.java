package com.periut.retroapi.compat;

import com.periut.retroapi.dimension.TeleportationManager;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_90931970;
import net.minecraft.unmapped.C_98888256;

/**
 * Seam between RetroAPI core and the optional StationAPI compatibility module. Core code calls these methods
 * (always behind a {@code FabricLoader.isModLoaded("stationapi")} gate) through {@link StationBridges#get()};
 * the real implementation lives in the separate {@code retroapi-stationapi} mod and is loaded reflectively, so
 * core itself carries <b>no compile-time or runtime dependency on StationAPI</b>.
 *
 * <p>Every method takes only vanilla / primitive types - no StationAPI type ever crosses this boundary - which
 * is what lets the interface live in core without pulling StationAPI onto the classpath.
 */
public interface StationBridge {

	/**
	 * @param itemFactory the block's own item form, built from the item id. A block that asked for a
	 *                    subclass of {@link net.minecraft.unmapped.C_71827890} needs that subclass here too:
	 *                    placement rules, custom use behaviour and inventory rendering all live on it, and
	 *                    substituting a plain BlockItem silently drops every one of them.
	 */
	void registerBlock(String namespace, String path, C_81592558 block,
		java.util.function.IntFunction<net.minecraft.unmapped.C_71827890> itemFactory);

	void registerItem(String namespace, String path, C_98888256 item);

	void registerLangPath();

	void bindAchievement(C_90931970 achievement, String namespace, String path);

	/** @return sprite index allocated by StationAPI's terrain atlas. */
	int addTerrainTexture(String namespace, String path);

	/** @return sprite index allocated by StationAPI's GUI-items atlas. */
	int addItemTexture(String namespace, String path);

	void setItemTexture(C_98888256 item, String namespace, String path);

	void addShapedRecipe(C_88708284 output, Object... recipe);

	void addShapelessRecipe(C_88708284 output, Object... ingredients);

	void addSmeltingRecipe(int inputId, C_88708284 output);

	/**
	 * Mirror a RetroAPI teleport manager onto the player's StationAPI {@code TeleportationManager} slot so a
	 * RetroAPI portal teleports through StationAPI's dimension system.
	 */
	void attachPortal(C_40996800 player, TeleportationManager retroManager);
}
