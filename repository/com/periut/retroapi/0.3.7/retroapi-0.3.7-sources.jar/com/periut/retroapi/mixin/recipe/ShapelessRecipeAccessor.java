package com.periut.retroapi.mixin.recipe;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.unmapped.C_84171032;
import net.minecraft.unmapped.C_88708284;

/** Vanilla shapeless-recipe stacks, for {@link com.periut.retroapi.registry.IdRemap}. See {@link ShapedRecipeAccessor}. */
@Mixin(C_84171032.class)
public interface ShapelessRecipeAccessor {

	@Accessor("input")
	List<C_88708284> retroapi$getInput();

	@Accessor("output")
	C_88708284 retroapi$getOutput();
}
