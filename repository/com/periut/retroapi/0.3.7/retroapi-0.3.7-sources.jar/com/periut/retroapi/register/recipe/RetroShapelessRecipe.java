package com.periut.retroapi.register.recipe;

import java.util.BitSet;
import net.minecraft.unmapped.C_11727459;
import net.minecraft.unmapped.C_30892219;
import net.minecraft.unmapped.C_88708284;

/**
 * A shapeless crafting recipe with metadata-aware ingredient matching.
 *
 * <p>Each ingredient is an {@link C_88708284}; an ingredient whose damage value is {@code -1}
 * is a <b>WILDCARD</b> matching any metadata, otherwise it matches <b>exactly</b>. Each
 * grid stack must consume exactly one (distinct) ingredient, tracked via a {@link BitSet},
 * mirroring StationAPI's {@code StationShapelessRecipe}.</p>
 */
public final class RetroShapelessRecipe implements C_30892219 {
	private final C_88708284[] ingredients;
	public final C_88708284 output;
	private final BitSet matchedIngredients;

	public RetroShapelessRecipe(C_88708284 output, C_88708284[] ingredients) {
		this.ingredients = ingredients;
		this.output = output;
		this.matchedIngredients = new BitSet(ingredients.length);
	}

	/**
	 * The raw ingredients. Exposed for {@link com.periut.retroapi.registry.IdRemap}, which repoints
	 * modded ingredients when a world assigns different ids than registration used.
	 */
	public C_88708284[] getIngredients() {
		return this.ingredients;
	}

	@Override
	public boolean m_52363298(C_11727459 inv) {
		this.matchedIngredients.clear();
		for (int y = 0; y < 3; ++y) {
			for (int x = 0; x < 3; ++x) {
				C_88708284 itemToTest = inv.m_50913241(x, y);
				if (itemToTest == null) continue;
				boolean noMatch = true;
				for (int i = 0; i < this.ingredients.length; i++) {
					if (this.matchedIngredients.get(i)) continue;
					C_88708284 ingredient = this.ingredients[i];
					if (ingredient == null) continue;
					// WILDCARD: damage == -1 matches any metadata (see RetroShapedRecipe).
					boolean ignoreDamage = ingredient.m_21098843() == -1;
					if (ignoreDamage) ingredient.m_88755881(itemToTest.m_21098843());
					boolean equals = ingredient.m_52048659(itemToTest);
					if (ignoreDamage) ingredient.m_88755881(-1);
					if (equals) {
						this.matchedIngredients.set(i);
						noMatch = false;
						break;
					}
				}
				if (noMatch) return false;
			}
		}
		return this.matchedIngredients.nextClearBit(0) >= this.ingredients.length;
	}

	@Override
	public C_88708284 m_10985002(C_11727459 inv) {
		return this.output.m_73216943();
	}

	@Override
	public int m_36691583() {
		return this.ingredients.length;
	}

	@Override
	public C_88708284 m_66362834() {
		return this.output.m_73216943();
	}
}
