package com.periut.retroapi.register.blockentity;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_40735137;
import net.minecraft.unmapped.C_74087615;

/**
 * Turns a {@link RetroSyncedBlockEntity}'s state into the bytes that ride the
 * {@code retroapi:block_entity_sync} channel, and back. Common to both sides so the two halves can't
 * disagree about the format.
 */
public final class BlockEntitySyncCodec {

	private BlockEntitySyncCodec() {}

	/** Serialises a block entity's sync NBT, or null if it produced nothing writable. */
	public static byte[] encode(C_40735137 blockEntity) {
		if (!(blockEntity instanceof RetroSyncedBlockEntity)) {
			return null;
		}
		try {
			C_74087615 nbt = new C_74087615();
			((RetroSyncedBlockEntity) blockEntity).writeSyncNbt(nbt);
			ByteArrayOutputStream bytes = new ByteArrayOutputStream();
			try (DataOutputStream out = new DataOutputStream(bytes)) {
				C_08565163.m_94300398(nbt, out);
			}
			return bytes.toByteArray();
		} catch (IOException e) {
			// A dropped sync is non-fatal: the block entity still works server-side, the client just
			// shows stale data until the next update.
			return null;
		}
	}

	/** Applies bytes from {@link #encode} to a block entity on the receiving side. */
	public static void decode(C_40735137 blockEntity, byte[] data) {
		if (!(blockEntity instanceof RetroSyncedBlockEntity) || data == null) {
			return;
		}
		try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(data))) {
			C_74087615 nbt = C_08565163.m_07155133(in);
			RetroSyncedBlockEntity synced = (RetroSyncedBlockEntity) blockEntity;
			synced.readSyncNbt(nbt);
			synced.onSynced();
		} catch (IOException e) {
			// see encode()
		}
	}
}
