package com.periut.retroapi.register.blockentity;

import com.periut.retroapi.network.RetroAPINetworking;
import net.minecraft.unmapped.C_40735137;
import net.minecraft.unmapped.C_49202226;
import net.ornithemc.osl.networking.api.server.ServerPlayNetworking;

import java.util.List;

/**
 * Server-only half of block-entity sync. Kept in its own class - the same shape as
 * {@code StateSyncServer} - so a client environment never loads ServerPlayerEntity or
 * ServerPlayNetworking; callers only reach it from SERVER-side mixins.
 */
public final class BlockEntitySyncServer {

	private BlockEntitySyncServer() {}

	/** Sends one block entity's state to a single player. */
	public static void sendTo(C_49202226 player, C_40735137 blockEntity) {
		byte[] data = BlockEntitySyncCodec.encode(blockEntity);
		if (data == null) {
			return;
		}
		send(player, blockEntity, data);
	}

	/** Sends one block entity's state to every player in a list (the chunk's trackers). */
	public static void sendToAll(List<?> players, C_40735137 blockEntity) {
		if (players == null || players.isEmpty()) {
			return;
		}
		byte[] data = BlockEntitySyncCodec.encode(blockEntity);
		if (data == null) {
			return;
		}
		for (Object player : players) {
			if (player instanceof C_49202226) {
				send((C_49202226) player, blockEntity, data);
			}
		}
	}

	private static void send(C_49202226 player, C_40735137 blockEntity, byte[] data) {
		ServerPlayNetworking.send(player, RetroAPINetworking.BLOCK_ENTITY_SYNC_CHANNEL, buf -> {
			buf.writeInt(blockEntity.f_07118142);
			buf.writeInt(blockEntity.f_33969464);
			buf.writeInt(blockEntity.f_77944174);
			buf.writeByteArray(data);
		});
	}
}
