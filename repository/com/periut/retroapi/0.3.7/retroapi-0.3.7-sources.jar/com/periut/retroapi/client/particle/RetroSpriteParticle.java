package com.periut.retroapi.client.particle;

import com.periut.retroapi.client.model.RetroAtlas;
import com.periut.retroapi.register.block.RetroTexture;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_47540058;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_96603444;

/**
 * A ready-made particle that draws one registered RetroAPI block texture - so "I want my own particle"
 * does not have to mean "I want to write a {@code Particle} subclass".
 *
 * <p>It behaves like vanilla's smoke/flame particles (drifts, ages out, optionally falls), but takes its
 * sprite from RetroAPI's expanded terrain atlas, so any {@code RetroTextures.addBlockTexture(...)} handle
 * works - including one that no block uses. Everything is chainable:
 *
 * <pre>
 * new RetroSpriteParticle(world, x, y, z, vx, vy, vz, MyMod.SPARK_TEXTURE)
 *     .lifetime(24)        // ticks before it disappears (a little randomised)
 *     .scale(0.9F)         // 1.0 is roughly a vanilla smoke puff
 *     .gravity(0.02F)      // 0 floats, positive falls, negative rises
 *     .tint(0xFFD070)      // 0xRRGGBB multiply
 *     .drag(0.96F);        // velocity kept per tick
 * </pre>
 *
 * <p>Unlike vanilla's digging particle it draws the WHOLE sprite, not a random quarter of it, so small
 * pixel art reads correctly.
 */
@Environment(EnvType.CLIENT)
public class RetroSpriteParticle extends C_47540058 {

	/** Terrain-atlas render group; vanilla binds {@code terrain.png} for this one. */
	private static final int TERRAIN_GROUP = 1;

	private final RetroTexture texture;
	private float drag = 0.98F;
	private float baseScale = 1.0F;

	public RetroSpriteParticle(C_64041439 world, double x, double y, double z,
			double velocityX, double velocityY, double velocityZ, RetroTexture texture) {
		super(world, x, y, z, velocityX, velocityY, velocityZ);
		this.texture = texture;
		// Vanilla's Particle constructor adds its own random jitter to the velocity; keep exactly what
		// the caller asked for, since spawn code that wants scatter can ask for it (RetroParticles.spawnCloud).
		this.f_24826402 = velocityX;
		this.f_35148123 = velocityY;
		this.f_21201587 = velocityZ;
		this.f_38664157 = 0.0F;
		this.f_89727493 = 20;
		this.f_45507822 = this.f_10605225 = this.f_07440167 = 1.0F;
		this.f_63348640 = texture != null ? texture.id : 0;
	}

	// --- chainable setup --------------------------------------------------------------------------

	/** Ticks to live, ±25% so a burst does not vanish all at once. */
	public RetroSpriteParticle lifetime(int ticks) {
		int jitter = Math.max(1, ticks / 4);
		this.f_89727493 = Math.max(1, ticks - jitter / 2 + this.f_94306729.f_33453426.nextInt(jitter + 1));
		return this;
	}

	/** Exactly this many ticks, no randomisation. */
	public RetroSpriteParticle exactLifetime(int ticks) {
		this.f_89727493 = Math.max(1, ticks);
		return this;
	}

	public RetroSpriteParticle scale(float scale) {
		this.baseScale = scale;
		this.f_11203543 = scale;
		return this;
	}

	/** Downward acceleration per tick; 0 floats, negative rises. */
	public RetroSpriteParticle gravity(float gravity) {
		this.f_38664157 = gravity;
		return this;
	}

	/** Fraction of velocity kept each tick (1.0 keeps moving forever, 0.9 stops quickly). */
	public RetroSpriteParticle drag(float drag) {
		this.drag = drag;
		return this;
	}

	/** {@code 0xRRGGBB} color multiply. */
	public RetroSpriteParticle tint(int rgb) {
		this.f_45507822 = ((rgb >> 16) & 0xFF) / 255.0F;
		this.f_10605225 = ((rgb >> 8) & 0xFF) / 255.0F;
		this.f_07440167 = (rgb & 0xFF) / 255.0F;
		return this;
	}

	/** Shrinks to nothing over its life instead of vanishing at full size. */
	public RetroSpriteParticle shrink() {
		this.shrinking = true;
		return this;
	}

	private boolean shrinking;

	// --- behavior --------------------------------------------------------------------------------

	@Override
	public void m_24884718() {
		this.f_59999765 = this.f_78826675;
		this.f_90348373 = this.f_31030949;
		this.f_88346412 = this.f_97691941;

		if (this.f_79870834++ >= this.f_89727493) {
			this.m_96197347();
			return;
		}
		this.f_35148123 -= 0.04D * this.f_38664157;
		this.m_15512507(this.f_24826402, this.f_35148123, this.f_21201587);
		this.f_24826402 *= this.drag;
		this.f_35148123 *= this.drag;
		this.f_21201587 *= this.drag;
		if (this.f_47825615) {
			this.f_24826402 *= 0.7D;
			this.f_21201587 *= 0.7D;
		}
		if (this.shrinking) {
			float remaining = 1.0F - (float) this.f_79870834 / this.f_89727493;
			this.f_11203543 = this.baseScale * remaining;
		}
		// The sprite index can move when the atlas is rebuilt (resource pack change); re-read it.
		if (this.texture != null) {
			this.f_63348640 = this.texture.id;
		}
	}

	@Override
	public void m_32469004(C_96603444 tessellator, float tickDelta, float rotX, float rotXZ, float rotZ,
			float rotYZ, float rotXY) {
		// UVs come from RetroAPI's atlas strategy, so this draws correctly on the expanded vanilla atlas
		// AND on StationAPI's dynamically sized one - the whole sprite, not a quarter of it.
		double minU = RetroAtlas.terrainU(this.f_63348640, 0.2);
		double maxU = RetroAtlas.terrainU(this.f_63348640, 15.8);
		double minV = RetroAtlas.terrainV(this.f_63348640, 0.2);
		double maxV = RetroAtlas.terrainV(this.f_63348640, 15.8);
		float size = 0.1F * this.f_11203543;

		float px = (float) (this.f_59999765 + (this.f_78826675 - this.f_59999765) * tickDelta - f_37914722);
		float py = (float) (this.f_90348373 + (this.f_31030949 - this.f_90348373) * tickDelta - f_59479165);
		float pz = (float) (this.f_88346412 + (this.f_97691941 - this.f_88346412) * tickDelta - f_68501249);

		tessellator.m_23684328(this.f_45507822, this.f_10605225, this.f_07440167, 1.0F);
		tessellator.m_75942980(px - rotX * size - rotYZ * size, py - rotXZ * size, pz - rotZ * size - rotXY * size,
			maxU, maxV);
		tessellator.m_75942980(px - rotX * size + rotYZ * size, py + rotXZ * size, pz - rotZ * size + rotXY * size,
			maxU, minV);
		tessellator.m_75942980(px + rotX * size + rotYZ * size, py + rotXZ * size, pz + rotZ * size + rotXY * size,
			minU, minV);
		tessellator.m_75942980(px + rotX * size - rotYZ * size, py - rotXZ * size, pz + rotZ * size - rotXY * size,
			minU, maxV);
	}

	@Override
	public int m_89634559() {
		return TERRAIN_GROUP;
	}
}
