package com.periut.retroapi.mixin.world;

import com.periut.retroapi.world.feature.RetroFeatures;
import net.minecraft.unmapped.C_27018031;
import net.minecraft.unmapped.C_44627882;
import net.minecraft.unmapped.C_70668269;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** The dedicated-server half of {@link ChunkCacheDecorateMixin}. */
@Mixin(C_27018031.class)
public class ServerChunkCacheDecorateMixin {

	@Shadow public C_70668269 world;

	@Inject(method = "decorate", at = @At("RETURN"), require = 0)
	private void retroapi$decorate(C_44627882 source, int chunkX, int chunkZ, CallbackInfo ci) {
		RetroFeatures.decorate(this.world, chunkX, chunkZ);
	}
}
