package com.periut.retroapi.tag;

import net.minecraft.unmapped.C_81592558;

/**
 * The default {@code mineable/<tool>} and {@code needs_<tier>_tool} membership for VANILLA beta blocks,
 * reproducing beta 1.7.3's own {@code MinecraftPickaxe}/{@code MinecraftAxe}/{@code MinecraftShovel}
 * effective-block lists and harvest levels. Registered once at init by {@link com.periut.retroapi.RetroAPI}
 * when StationAPI is <b>absent</b> (StationAPI already ships this exact set as data tags, so RetroAPI stands
 * back and lets it own vanilla harvesting - see the StationAPI compat notes).
 *
 * <p>This is the fix for "custom tools only worked on modded blocks": before, no vanilla block was in any
 * RetroAPI tag, so a {@code .tool(PICKAXE).tier(IRON)} plain item had nothing to bite on vanilla stone or
 * ore. With these defaults, the same harvest hook that serves modded ores now serves vanilla blocks too.</p>
 *
 * <p>Under the decoupled harvest rules, a {@code mineable/<tool>} tag only grants SPEED; a block still needs
 * a tool to DROP only because its material says so (stone/metal) or a {@code needs_<tier>_tool} tag does.
 * So listing hand-harvestable wood/dirt blocks in {@code mineable/axe}/{@code mineable/shovel} makes custom
 * axes and shovels faster on them without ever gating their hand-harvest, matching vanilla exactly.</p>
 */
public final class VanillaToolTags {

	private static boolean registered = false;

	private VanillaToolTags() {}

	/** Idempotent: safe to call more than once. */
	public static void registerDefaults() {
		if (registered) {
			return;
		}
		registered = true;

		// --- mineable/pickaxe: stone- and metal-material blocks (these need a pickaxe to drop) ---
		mineable(RetroTool.PICKAXE,
			C_81592558.f_38442324, C_81592558.f_17981199, C_81592558.f_87667057, C_81592558.f_94949418, C_81592558.f_73573195,
			C_81592558.f_39350323, C_81592558.f_66929948, C_81592558.f_38259672,
			C_81592558.f_81094226, C_81592558.f_19757556, C_81592558.f_91577743, C_81592558.f_35664400, C_81592558.f_83073694,
			C_81592558.f_68803305, C_81592558.f_88434840,
			C_81592558.f_41428926, C_81592558.f_54760749, C_81592558.f_95737061, C_81592558.f_99851615,
			C_81592558.f_28421768, C_81592558.f_14995882, C_81592558.f_38591135,
			C_81592558.f_58920251, C_81592558.f_19785413, C_81592558.f_78357199, C_81592558.f_50662990,
			C_81592558.f_91546482, C_81592558.f_90267132, C_81592558.f_40727126,
			C_81592558.f_86544900, C_81592558.f_27559703, C_81592558.f_89685822);

		// --- mineable/axe: wood-material blocks (hand-harvestable; tag only speeds an axe up) ---
		mineable(RetroTool.AXE,
			C_81592558.f_32493286, C_81592558.f_78280144, C_81592558.f_22197047, C_81592558.f_49828421, C_81592558.f_30918233,
			C_81592558.f_31892463, C_81592558.f_98928673, C_81592558.f_82599628, C_81592558.f_25017736,
			C_81592558.f_58356112, C_81592558.f_94091898, C_81592558.f_49218653, C_81592558.f_79966048);

		// --- mineable/shovel: dirt/sand-material blocks (hand-harvestable; tag only speeds a shovel up) ---
		mineable(RetroTool.SHOVEL,
			C_81592558.f_41096518, C_81592558.f_05581995, C_81592558.f_27446762, C_81592558.f_38177074, C_81592558.f_86394960,
			C_81592558.f_81695559, C_81592558.f_51102006, C_81592558.f_95757196, C_81592558.f_84892602);

		// --- tool tiers, straight from beta MinecraftPickaxe.canHarvestBlock ---
		needs(RetroToolTier.STONE,
			C_81592558.f_19757556, C_81592558.f_41428926, C_81592558.f_83073694, C_81592558.f_99851615);
		needs(RetroToolTier.IRON,
			C_81592558.f_91577743, C_81592558.f_54760749, C_81592558.f_35664400, C_81592558.f_95737061,
			C_81592558.f_68803305, C_81592558.f_88434840);
		needs(RetroToolTier.DIAMOND,
			C_81592558.f_38591135);
	}

	private static void mineable(RetroTool tool, C_81592558... blocks) {
		RetroTags.addToTag(tool.mineableTag(), blocks);
	}

	private static void needs(RetroToolTier tier, C_81592558... blocks) {
		RetroTags.addToTag(tier.needsTag(), blocks);
	}
}
