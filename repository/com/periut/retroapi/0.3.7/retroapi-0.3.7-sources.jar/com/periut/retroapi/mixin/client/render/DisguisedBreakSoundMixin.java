package com.periut.retroapi.mixin.client.render;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.periut.retroapi.register.block.RetroDisguises;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_03111506;
import net.minecraft.unmapped.C_24384787;
import net.minecraft.unmapped.C_81592558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Makes a disguised block break with the sound of what it was wearing. See
 * {@link com.periut.retroapi.register.block.RetroBlockDisguise}.
 *
 * <p>The break sound is world event 2001, which arrives carrying a block id and a position and is handled
 * after the block itself has gone, so the disguise cannot be read from the world any more. It is read
 * from what {@code RetroDisguises} recorded on the way out instead.
 */
@Mixin(C_24384787.class)
@Environment(EnvType.CLIENT)
public class DisguisedBreakSoundMixin {

	@WrapOperation(method = "processWorldEvent",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/sound/SoundManager;playSound(Ljava/lang/String;FFFFF)V"),
		require = 0)
	private void retroapi$disguisedBreakSound(C_03111506 sounds, String sound, float x, float y, float z,
			float volume, float pitch, Operation<Void> original,
			int event, int px, int py, int pz, int data) {
		C_81592558 worn = RetroDisguises.remembered(px, py, pz);
		if (worn == null) {
			original.call(sounds, sound, x, y, z, volume, pitch);
			return;
		}
		// The same arithmetic vanilla applies to a break sound, on the group it should have used.
		original.call(sounds, worn.f_13889746.m_58114629(), x, y, z,
			(worn.f_13889746.m_48828997() + 1.0F) / 2.0F, worn.f_13889746.m_35890820() * 0.8F);
	}
}
