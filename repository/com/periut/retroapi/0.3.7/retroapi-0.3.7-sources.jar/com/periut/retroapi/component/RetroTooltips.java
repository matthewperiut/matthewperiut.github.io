package com.periut.retroapi.component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;

/**
 * The tooltip registry. Two ways to add tooltip lines to an item, mirroring how you can
 * either override a method on a custom item or register a callback for one you do not own:
 *
 * <ul>
 *   <li>have the Item class implement {@link RetroTooltipProvider}, or</li>
 *   <li>register a provider for any item (even vanilla) with {@link #register}.</li>
 * </ul>
 *
 * <p>The client-side tooltip mixin calls {@link #linesFor} for the hovered stack and draws
 * the lines under the name. Lines are plain strings; prefix with section signs for color.</p>
 */
public final class RetroTooltips {

	private static final Map<C_98888256, RetroTooltipProvider> PROVIDERS = new HashMap<>();

	private RetroTooltips() {
	}

	/** Adds a tooltip provider for an item (works for vanilla items too). */
	public static void register(C_98888256 item, RetroTooltipProvider provider) {
		PROVIDERS.put(item, provider);
	}

	/** All extra tooltip lines for a stack: the item's own provider plus any registered one. */
	public static List<String> linesFor(C_88708284 stack) {
		List<String> lines = new ArrayList<>();
		if (stack == null) {
			return lines;
		}
		C_98888256 item = stack.m_23235460();
		if (item instanceof RetroTooltipProvider) {
			((RetroTooltipProvider) item).appendTooltip(stack, lines);
		}
		RetroTooltipProvider registered = PROVIDERS.get(item);
		if (registered != null) {
			registered.appendTooltip(stack, lines);
		}
		return lines;
	}
}
