package com.periut.retroapi.mixin.recipe;

import net.minecraft.unmapped.C_55756098;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Reaches a vanilla shaped recipe's stacks so {@link com.periut.retroapi.registry.IdRemap} can repoint
 * modded ingredients/results at their post-remap ids (a mod may build vanilla {@code ShapedRecipe}s
 * directly instead of going through {@code RetroRecipes}).
 */
@Mixin(C_55756098.class)
public interface ShapedRecipeAccessor {

	@Accessor("input")
	C_88708284[] retroapi$getInput();

	@Accessor("output")
	C_88708284 retroapi$getOutput();

	@Accessor("outputId")
	void retroapi$setOutputId(int id);
}
