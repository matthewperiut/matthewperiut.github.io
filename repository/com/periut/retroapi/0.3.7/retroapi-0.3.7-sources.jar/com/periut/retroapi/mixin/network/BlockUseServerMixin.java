package com.periut.retroapi.mixin.network;

import com.periut.retroapi.register.block.event.BlockUseDispatch;
import net.minecraft.unmapped.C_14230742;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Dedicated-server half of {@link com.periut.retroapi.register.block.event.BlockUseCallback}: the
 * authoritative right-click path in multiplayer. The singleplayer half lives on the client's own
 * InteractionManager (b1.7.3 has no integrated server, so the two never both run).
 *
 * <p>Separate from {@code ServerPlayerInteractionManagerMixin} on purpose - see
 * {@code BlockUseClientMixin} for why sharing that class would have disabled the event under StationAPI.
 */
@Mixin(C_14230742.class)
public class BlockUseServerMixin {

	@Inject(method = "interactBlock", at = @At("HEAD"), cancellable = true)
	private void retroapi$blockUse(C_40996800 player, C_64041439 world, C_88708284 held, int x, int y, int z,
			int face, CallbackInfoReturnable<Boolean> cir) {
		BlockUseDispatch.fire(player, world, held, x, y, z, face, cir);
	}
}
