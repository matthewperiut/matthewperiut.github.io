package com.periut.retroapi.mixin.register;

import com.periut.retroapi.register.block.RetroDisguises;
import net.minecraft.unmapped.C_01306377;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/**
 * Makes a disguised block sound like what it is wearing when you walk on it. See
 * {@link com.periut.retroapi.register.block.RetroBlockDisguise}.
 *
 * <p>{@code Block.soundGroup} is a field on the block type, so beta has exactly one step sound for every
 * position of a block and no hook that is given both the sound and the place it came from.
 *
 * <p>So the sound call itself is redirected and the position recomputed from the entity, with the same
 * arithmetic vanilla used a few lines earlier to find the block it was standing on, including its habit
 * of looking one block lower when that block is a fence. Recomputing rather than capturing vanilla's
 * locals is the point: the locals are unnamed and their slots are a compiler detail, while the entity's
 * own feet are not going to move between one statement and the next.
 */
@Mixin(C_42232651.class)
public class DisguisedStepSoundMixin {

	@Redirect(method = "move",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/world/World;playSound(Lnet/minecraft/entity/Entity;Ljava/lang/String;FF)V"),
		require = 0)
	private void retroapi$disguisedStepSound(C_64041439 world, C_42232651 entity, String sound, float volume, float pitch) {
		C_01306377 worn = retroapi$disguisedGroupUnderfoot(world, entity);
		if (worn == null) {
			world.m_94717335(entity, sound, volume, pitch);
			return;
		}
		// Vanilla scales a step sound to 0.15 of the group's volume; keep that relationship rather than
		// carrying the old group's number over to a group that may be louder or quieter.
		world.m_94717335(entity, worn.m_48793905(), worn.m_48828997() * 0.15F, worn.m_35890820());
	}

	@Unique
	private C_01306377 retroapi$disguisedGroupUnderfoot(C_64041439 world, C_42232651 entity) {
		if (world == null || entity == null) {
			return null;
		}
		int x = C_45510667.m_80489169(entity.f_78826675);
		int y = C_45510667.m_80489169(entity.f_31030949 - 0.2F - entity.f_85480687);
		int z = C_45510667.m_80489169(entity.f_97691941);
		// Vanilla's own fence rule: standing on top of one, the sound comes from the fence below.
		if (world.m_33234383(x, y, z) == 0 || world.m_33234383(x, y - 1, z) == C_81592558.f_98928673.f_84602679) {
			if (world.m_33234383(x, y - 1, z) != 0) {
				y--;
			}
		}
		C_81592558 worn = RetroDisguises.at(world, x, y, z);
		return worn == null ? null : worn.f_13889746;
	}
}
