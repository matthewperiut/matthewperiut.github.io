package com.periut.retroapi.register.recipe;

import net.minecraft.unmapped.C_11727459;
import net.minecraft.unmapped.C_30892219;
import net.minecraft.unmapped.C_88708284;

/**
 * A shaped crafting recipe with metadata-aware ingredient matching.
 *
 * <p>Each cell of {@link #grid} is either {@code null} (empty) or an {@link C_88708284}
 * ingredient. An ingredient {@link C_88708284} whose damage value is {@code -1} is a
 * <b>WILDCARD</b>: it matches the corresponding grid stack regardless of metadata/damage.
 * Any other damage value matches <b>exactly</b>. This mirrors StationAPI's
 * {@code StationShapedRecipe} (the {@code ignoreDamage} dance) without the tag system.</p>
 */
public final class RetroShapedRecipe implements C_30892219 {
	public final int width;
	public final int height;
	// entries may be null; an ItemStack with damage == -1 is a wildcard (matches any metadata)
	final C_88708284[] grid;
	public final C_88708284 output;

	public RetroShapedRecipe(int width, int height, C_88708284[] grid, C_88708284 output) {
		this.width = width;
		this.height = height;
		this.grid = grid;
		this.output = output;
	}

	/**
	 * The raw ingredient cells (nulls = empty). Exposed for {@link com.periut.retroapi.registry.IdRemap},
	 * which repoints modded ingredients when a world assigns different ids than registration used.
	 */
	public C_88708284[] getGrid() {
		return this.grid;
	}

	@Override
	public boolean m_52363298(C_11727459 inv) {
		for (int x = 0; x <= 3 - this.width; ++x) {
			for (int y = 0; y <= 3 - this.height; ++y) {
				if (this.matches(inv, x, y, true)) return true;
				if (this.matches(inv, x, y, false)) return true;
			}
		}
		return false;
	}

	private boolean matches(C_11727459 inv, int startX, int startY, boolean mirror) {
		for (int x = 0; x < 3; ++x) {
			for (int y = 0; y < 3; ++y) {
				int dx = x - startX;
				int dy = y - startY;
				C_88708284 ingredient = null;
				if (dx >= 0 && dy >= 0 && dx < this.width && dy < this.height) {
					ingredient = this.grid[(mirror ? this.width - dx - 1 : dx) + dy * this.width];
				}
				C_88708284 itemToTest = inv.m_50913241(x, y);
				if (itemToTest != null || ingredient != null) {
					if (itemToTest == null || ingredient == null) return false;
					// WILDCARD: damage == -1 means "match any metadata". Temporarily borrow the
					// tested stack's damage so isItemEqual passes, then restore. Crafting is
					// single-threaded in b1.7.3, so this transient mutation is safe.
					boolean ignoreDamage = ingredient.m_21098843() == -1;
					if (ignoreDamage) ingredient.m_88755881(itemToTest.m_21098843());
					boolean equals = ingredient.m_52048659(itemToTest);
					if (ignoreDamage) ingredient.m_88755881(-1);
					if (!equals) return false;
				}
			}
		}
		return true;
	}

	@Override
	public C_88708284 m_10985002(C_11727459 inv) {
		return this.output.m_73216943();
	}

	@Override
	public int m_36691583() {
		return this.width * this.height;
	}

	@Override
	public C_88708284 m_66362834() {
		return this.output.m_73216943();
	}
}
