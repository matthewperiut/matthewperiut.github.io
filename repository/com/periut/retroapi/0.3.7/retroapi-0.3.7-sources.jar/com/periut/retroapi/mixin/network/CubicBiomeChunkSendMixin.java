package com.periut.retroapi.mixin.network;

import com.periut.retroapi.biome.cubic.CubicBiomeSyncServer;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_62858513;
import net.minecraft.unmapped.C_99660737;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Sends a chunk's cubic biome cells alongside the vanilla chunk packet.
 *
 * <p>Unlike {@link ChunkSendMixin} this only <em>observes</em> the chunk packet going out and then
 * pushes RetroAPI's own OSL message; it does not touch the packet. That is what lets it stay enabled
 * under StationAPI, where {@code ChunkSendMixin} and {@code WorldChunkPacketMixin} must be off because
 * StationAPI owns chunk packet contents - the reason cubic biomes ride their own channel in the first
 * place (see {@code RetroAPINetworking.CUBIC_BIOME_CHANNEL}).
 *
 * <p>Dedicated server only. b1.7.3 singleplayer <em>is</em> the client, sharing one World object, so the
 * client already holds every cell the server wrote and there is nothing to send.
 */
@Mixin(C_99660737.class)
public class CubicBiomeChunkSendMixin {

	@Shadow public C_49202226 player;

	@Inject(method = "sendPacket", at = @At("HEAD"), require = 0)
	private void retroapi$sendCubicBiomes(C_03562565 packet, CallbackInfo ci) {
		if (!(packet instanceof C_62858513 chunkPacket)) {
			return;
		}
		C_14917579 chunk = player.f_94306729.m_27928573(chunkPacket.f_05662346 >> 4, chunkPacket.f_77394700 >> 4);
		CubicBiomeSyncServer.sendChunk(player, chunk);
	}
}
