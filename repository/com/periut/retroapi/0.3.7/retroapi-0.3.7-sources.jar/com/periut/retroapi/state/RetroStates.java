package com.periut.retroapi.state;

import com.periut.retroapi.RetroAPI;
import com.periut.retroapi.storage.ChunkExtendedBlocks;
import com.periut.retroapi.storage.ExtendedBlocksAccess;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.UnaryOperator;
import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;

/**
 * The flattened block state platform. Blocks declare properties in code
 * ({@code RetroBlockAccess.states(...)}) or in their blockstate JSON
 * ({@code "properties": {...}}); every combination gets a flattened index whose bits 0-3
 * ride vanilla metadata and bits 4-11 ("secondary meta", xmeta) live in the region
 * sidecar. Blocks that never declare properties get an implicit {@code meta} property
 * (0-15) on first query, so the whole platform (blockstate JSONs, models, variant keys)
 * works uniformly on plain meta blocks.
 */
public final class RetroStates {

	private static final Map<C_81592558, RetroStateDefinition> DEFINITIONS = new HashMap<>();

	private RetroStates() {}

	/** Declares a block's state definition. Called by {@code RetroBlockAccess.states(...)}. */
	public static void define(C_81592558 block, List<RetroProperty<?>> properties, UnaryOperator<RetroBlockState> defaultOp) {
		if (DEFINITIONS.containsKey(block)) {
			RetroAPI.LOGGER.warn("State definition for {} declared twice; keeping the first", block.m_27822537());
			return;
		}
		DEFINITIONS.put(block, new RetroStateDefinition(block, properties, defaultOp));
	}

	/**
	 * Declares a definition from blockstate JSON data. Code declarations win: if the block
	 * already has one, the data declaration is checked for agreement and otherwise ignored.
	 */
	public static void defineFromData(C_81592558 block, List<RetroProperty<?>> properties) {
		RetroStateDefinition existing = DEFINITIONS.get(block);
		if (existing != null) {
			if (existing.properties.size() != properties.size()) {
				RetroAPI.LOGGER.warn("Blockstate JSON for {} declares {} properties but code declared {}; code wins",
					block.m_27822537(), properties.size(), existing.properties.size());
			}
			return;
		}
		DEFINITIONS.put(block, new RetroStateDefinition(block, properties, null));
	}

	/** True if the block declared properties (code or data), false if it only has the implicit meta. */
	public static boolean hasExplicitDefinition(C_81592558 block) {
		return DEFINITIONS.containsKey(block);
	}

	private static RetroStateDefinition definitionOf(C_81592558 block) {
		RetroStateDefinition def = DEFINITIONS.get(block);
		if (def == null) {
			// Implicit definition: the single property "meta" (0-15), states aligned with the nibble.
			def = new RetroStateDefinition(block,
				new ArrayList<>(Arrays.asList(RetroIntProperty.of("meta", 0, 15))), null);
			DEFINITIONS.put(block, def);
		}
		return def;
	}

	/** The block's default state (first value of each property unless overridden). */
	public static RetroBlockState getDefault(C_81592558 block) {
		return definitionOf(block).defaultState;
	}

	/** The state with the given flattened index; out-of-range indices clamp to the default. */
	public static RetroBlockState fromIndex(C_81592558 block, int index) {
		RetroStateDefinition def = definitionOf(block);
		if (index < 0 || index >= def.states.length) {
			return def.defaultState;
		}
		return def.states[index];
	}

	/** Looks up a property by name, from code or data declarations. Null if unknown. */
	public static RetroProperty<?> property(C_81592558 block, String name) {
		return definitionOf(block).byName(name);
	}

	/** The number of states in the block's definition (16 for the implicit meta property). */
	public static int stateCount(C_81592558 block) {
		return definitionOf(block).states.length;
	}

	/**
	 * Reads the state at a position: vanilla meta nibble plus the sidecar's xmeta bits.
	 * Works for any BlockView; xmeta needs a real World (renderers always pass one).
	 */
	public static RetroBlockState get(C_46108969 world, int x, int y, int z) {
		int blockId = world.m_33234383(x, y, z);
		if (blockId <= 0 || blockId >= C_81592558.f_44428008.length || C_81592558.f_44428008[blockId] == null) {
			return null;
		}
		C_81592558 block = C_81592558.f_44428008[blockId];
		int index = world.m_06541281(x, y, z);
		ChunkExtendedBlocks extended = extendedAt(world, x, z);
		if (extended != null) {
			index |= extended.getXmeta(ChunkExtendedBlocks.toIndex(x & 15, y, z & 15)) << 4;
		}
		return fromIndex(block, index);
	}

	/**
	 * Writes a state at a position: the low 4 bits go through {@code world.setBlockMeta}
	 * (block updates, re-render, chunk dirty), the high bits into the chunk's xmeta. On a
	 * dedicated server the full index is also synced to clients over
	 * {@code retroapi:state_sync}.
	 */
	public static void set(C_64041439 world, int x, int y, int z, RetroBlockState state) {
		int index = state.getIndex();
		ChunkExtendedBlocks extended = extendedAt(world, x, z);
		if (extended != null) {
			extended.setXmeta(ChunkExtendedBlocks.toIndex(x & 15, y, z & 15), (index >> 4) & 0xFF);
		}
		world.m_38188749(x, y, z, index & 15);

		// A state change is a block change: re-render the position (and, server-side, flag
		// it for sending) and propagate a block update to neighbors, exactly as a
		// setBlock would. setBlockMeta alone does neither reliably, and xmeta-only
		// changes never touch the nibble at all.
		world.m_05575100(x, y, z);
		world.m_69064650(x, y, z, state.getBlock().f_84602679);

		if (!world.f_50876584
			&& net.fabricmc.loader.api.FabricLoader.getInstance().getEnvironmentType() == net.fabricmc.api.EnvType.SERVER) {
			StateSyncServer.send(world, x, y, z, index);
		}
	}

	/**
	 * Writes a state WITHOUT notifying neighbors - the state equivalent of
	 * {@code World.setBlockWithoutNotifyingNeighbors}, and what world generation must use.
	 *
	 * <p>{@link #set} propagates a block update, which during decoration can cascade back into the chunk
	 * being generated (a falling block, a redstone update, a plant re-checking its support) and, at worst,
	 * re-enter generation for a chunk that is not finished. Placement code that owns its surroundings -
	 * a feature, a structure, a multiblock being assembled in one pass - wants this instead.
	 *
	 * <p>The position is still marked dirty so it re-renders, and a dedicated server still syncs the full
	 * index, because those are not neighbor updates: skipping them would leave the block invisible or
	 * wrongly-rendered rather than merely un-notified.
	 */
	public static void setWithoutNotifyingNeighbors(C_64041439 world, int x, int y, int z, RetroBlockState state) {
		int index = state.getIndex();
		ChunkExtendedBlocks extended = extendedAt(world, x, z);
		if (extended != null) {
			extended.setXmeta(ChunkExtendedBlocks.toIndex(x & 15, y, z & 15), (index >> 4) & 0xFF);
		}
		world.m_20740557(x, y, z, index & 15);
		world.m_05575100(x, y, z);

		if (!world.f_50876584
			&& net.fabricmc.loader.api.FabricLoader.getInstance().getEnvironmentType() == net.fabricmc.api.EnvType.SERVER) {
			StateSyncServer.send(world, x, y, z, index);
		}
	}

	/**
	 * Places a block AND its full state in one call, without notifying neighbors: the generation-safe
	 * counterpart to {@code world.setBlock} followed by {@link #set}. Use it from a
	 * {@link com.periut.retroapi.world.feature.RetroFeature} or any other code placing blocks into a
	 * chunk it is still building.
	 */
	public static void placeWithoutNotifyingNeighbors(C_64041439 world, int x, int y, int z, RetroBlockState state) {
		if (y < 0 || y > 127) {
			return;
		}
		int index = state.getIndex();
		world.m_54008700(x, y, z, state.getBlock().f_84602679, index & 15);
		setWithoutNotifyingNeighbors(world, x, y, z, state);
	}

	/** Internal: applies a synced full index on the client (low bits + xmeta + re-render). */
	public static void applySynced(C_64041439 world, int x, int y, int z, int index) {
		ChunkExtendedBlocks extended = extendedAt(world, x, z);
		if (extended != null) {
			extended.setXmeta(ChunkExtendedBlocks.toIndex(x & 15, y, z & 15), (index >> 4) & 0xFF);
		}
		world.m_38188749(x, y, z, index & 15);
		world.m_76770021(x, y, z, x, y, z);
	}

	private static ChunkExtendedBlocks extendedAt(C_46108969 view, int x, int z) {
		// Chunk rendering passes a WorldRegion wrapper, not the World; unwrap so xmeta
		// reads keep working at render time (states past index 15 would otherwise read
		// their low nibble only and pick the wrong variant).
		C_64041439 world = com.periut.retroapi.world.RetroWorlds.unwrap(view);
		if (world == null) {
			return null;
		}
		C_14917579 chunk = world.m_27928573(x >> 4, z >> 4);
		if (chunk == null) {
			return null;
		}
		return ((ExtendedBlocksAccess) chunk).retroapi$getExtendedBlocks();
	}
}
