package com.periut.retroapi.mixin.register;

import com.periut.retroapi.register.block.RetroBlockAccess;
import com.periut.retroapi.tag.RetroTags;
import com.periut.retroapi.tag.RetroTool;
import net.minecraft.item.*;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_50456764;
import net.minecraft.unmapped.C_53672520;
import net.minecraft.unmapped.C_64104387;
import net.minecraft.unmapped.C_75759956;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_85721786;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Set;

@Mixin(C_40996800.class)
public abstract class PlayerEntityMixin {

	@Shadow public C_87542771 inventory;

	/** The player doing the mining, for contextual tool tiers (which can ask where it is standing). */
	@Unique
	private C_40996800 retroapi$self() {
		return (C_40996800) (Object) this;
	}

	@Inject(method = "canHarvest", at = @At("HEAD"), cancellable = true)
	private void retroapi$alwaysDrops(C_81592558 block, CallbackInfoReturnable<Boolean> cir) {
		if (((RetroBlockAccess) block).isAlwaysDrops()) {
			cir.setReturnValue(true);
		}
	}

	/**
	 * Modern, DECOUPLED harvest semantics:
	 * <ul>
	 *   <li>A {@code mineable/<tool>} tag grants SPEED (in the breaking-speed hook below); on its own it
	 *       does not gate drops, exactly like modern Minecraft.</li>
	 *   <li>Whether a block needs a tool AT ALL comes from its material ({@code !isHandHarvestable()},
	 *       beta's own stone/metal rule) or from membership in a {@code needs_<tier>_tool} tag.</li>
	 * </ul>
	 * When a block does need a tool, the held item must be a matching KIND (one of the block's mineable
	 * tags) and of sufficient TIER. Blocks that need no tool, and blocks in no RetroAPI tag, are left to
	 * vanilla untouched. This is what makes a {@code .tool(PICKAXE).tier(IRON)} plain item work on the
	 * shipped vanilla block tags (stone, ores, ...) the same as on a modded ore.
	 */
	@Inject(method = "canHarvest", at = @At("HEAD"), cancellable = true)
	private void retroapi$mineableHarvest(C_81592558 block, CallbackInfoReturnable<Boolean> cir) {
		if (((RetroBlockAccess) block).isAlwaysDrops()) {
			return; // the alwaysDrops handler already answered true
		}
		Set<RetroTool> requiredKinds = RetroTags.mineableTools(block);
		com.periut.retroapi.tag.RetroToolTier requiredTier = RetroTags.requiredTier(block);
		boolean tagged = !requiredKinds.isEmpty()
			|| requiredTier != com.periut.retroapi.tag.RetroToolTier.WOOD;
		if (!tagged) {
			return; // block not in any RetroAPI tag: vanilla decides entirely
		}
		// Decouple: a mineable tag alone does NOT require a tool. The block needs a tool only if its
		// material says so (stone/metal), or a needs_<tier>_tool tag does. Otherwise it drops by hand
		// and the tag only made it faster; leave that case to vanilla.
		boolean requiresTool = !((C_81592558) block).f_22724416.m_84337147()
			|| requiredTier != com.periut.retroapi.tag.RetroToolTier.WOOD;
		if (!requiresTool) {
			return;
		}
		C_88708284 held = this.inventory.m_27760697();
		C_98888256 heldItem = held != null ? held.m_23235460() : null;

		// Tool KIND: if the block declares mineable kinds, the held tool must be one of them.
		if (!requiredKinds.isEmpty()) {
			Set<RetroTool> heldKinds = RetroTool.kindsOf(heldItem);
			if (java.util.Collections.disjoint(heldKinds, requiredKinds)) {
				cir.setReturnValue(false);
				return;
			}
		}
		// Tool TIER: needs_<tier>_tool demands the material level (declared statically, per stack, or per
		// stack AND block via RetroItemAccess.tier, or inferred from a ToolItem's material).
		if (!com.periut.retroapi.tag.RetroToolTier.of(held, block, retroapi$self()).isAtLeast(requiredTier)) {
			cir.setReturnValue(false);
			return;
		}
		cir.setReturnValue(true);
	}

	@Inject(method = "getBlockBreakingSpeed", at = @At("RETURN"), cancellable = true)
	private void retroapi$effectiveTool(C_81592558 block, CallbackInfoReturnable<Float> cir) {
		RetroBlockAccess access = (RetroBlockAccess) block;
		if (cir.getReturnValue() > 1.0f) return;

		C_88708284 held = this.inventory.m_27760697();
		if (held == null) return;
		C_98888256 item = held.m_23235460();

		// Explicit per-block declarations win ties with the tag system.
		if (access.isAlwaysEffectiveTool()) {
			Float speed = retroapi$getToolSpeed(held);
			if (speed != null) {
				cir.setReturnValue(speed);
				return;
			}
		} else {
			Class<? extends C_98888256> effectiveTool = access.getEffectiveTool();
			if (effectiveTool != null && effectiveTool.isInstance(item)) {
				Float speed = retroapi$getToolSpeed(held);
				if (speed != null) {
					cir.setReturnValue(speed);
					return;
				}
			}
		}

		// Tag path: held tool kind matches a mineable/<tool> tag containing this block.
		Set<RetroTool> tools = RetroTags.mineableTools(block);
		if (!tools.isEmpty() && !java.util.Collections.disjoint(RetroTool.kindsOf(item), tools)) {
			Float speed = retroapi$getToolSpeed(held, block);
			if (speed != null) {
				cir.setReturnValue(speed);
			}
		}
	}

	@Unique
	private Float retroapi$getToolSpeed(C_88708284 held) {
		return retroapi$getToolSpeed(held, null);
	}

	@Unique
	private Float retroapi$getToolSpeed(C_88708284 held, C_81592558 block) {
		C_98888256 item = held.m_23235460();
		// An explicitly declared speed wins: that is the whole point of building a tool from parameters
		// instead of a ToolMaterial (which mods cannot extend - it is an enum).
		float declared = ((com.periut.retroapi.register.item.RetroItemAccess) item).getMiningSpeed();
		if (declared > 0.0F && !RetroTool.kindsOf(item).isEmpty()) {
			return declared;
		}
		// Vanilla tool classes: sample the held item's speed against a reference block of
		// the matching material (gives the tool's material speed: wood 2 .. gold 12).
		if (item instanceof C_50456764) return this.inventory.m_51990427(C_81592558.f_38442324);
		if (item instanceof C_85721786) return this.inventory.m_51990427(C_81592558.f_32493286);
		if (item instanceof C_75759956) return this.inventory.m_51990427(C_81592558.f_05581995);
		if (item instanceof C_64104387) return 1.5f;
		// Custom ToolItem subclasses (declared via RetroItemAccess.tool): raw material speed.
		if (item instanceof C_53672520) return ((ToolItemAccessor) item).retroapi$getMiningSpeed();
		// Declared plain-Item tools: scale with the declared tier, so .tier(IRON) mines like an iron
		// tool (6x) instead of a flat token boost. Honors a dynamic or block-aware tier via the stack.
		if (!RetroTool.kindsOf(item).isEmpty()) {
			return retroapi$tierSpeed(com.periut.retroapi.tag.RetroToolTier.of(held, block, retroapi$self()));
		}
		return null;
	}

	/**
	 * Mining speed for a tier: the vanilla ToolMaterial speeds (wood 2, stone 4, iron 6, diamond 8) come
	 * from the built-in tiers, and a mod-registered tier carries its own, which is why this is a lookup
	 * and not a switch.
	 */
	@Unique
	private static float retroapi$tierSpeed(com.periut.retroapi.tag.RetroToolTier tier) {
		return tier == null ? 2.0f : tier.getMiningSpeed();
	}
}
