package com.periut.retroapi.compat;

import com.periut.retroapi.entity.client.RetroEntityRenderers;
import com.periut.retroapi.register.block.RetroBlockAccess;
import com.periut.retroapi.register.block.RetroTextures;
import com.periut.retroapi.register.recipe.event.RecipeRegistrationCallback;
import com.periut.retroapi.registry.RetroRegistry;
import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.item.*;
import net.minecraft.unmapped.C_50456764;
import net.minecraft.unmapped.C_64104387;
import net.minecraft.unmapped.C_75759956;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_85721786;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.client.event.render.entity.EntityRendererRegisterEvent;
import net.modificationstation.stationapi.api.client.event.texture.TextureRegisterEvent;
import net.modificationstation.stationapi.api.event.entity.player.IsPlayerUsingEffectiveToolEvent;
import net.modificationstation.stationapi.api.event.entity.player.PlayerStrengthOnBlockEvent;
import net.modificationstation.stationapi.api.event.recipe.RecipeRegisterEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.util.Namespace;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * StationAPI event bus entrypoint - handles texture registration and block tool/harvest overrides.
 * Only loaded when StationAPI is present.
 */
@Entrypoint(eventBus = @EventBusPolicy(registerInstance = true))
public class StationAPIRegistryForwarder {
	private static final Logger LOGGER = LogManager.getLogger("RetroAPI/StationAPI");

	@Entrypoint.Namespace
	public Namespace namespace = Namespace.of("retroapi");

	@Entrypoint.Logger
	public Logger logger = LOGGER;

	@EventListener
	public void registerTextures(TextureRegisterEvent event) {
		LOGGER.info("Resolving RetroAPI textures with StationAPI atlas system");
		RetroTextures.resolveStationAPITextures();
	}

	/**
	 * Bridges StationAPI's recipe-register event to RetroAPI's RecipeRegistrationCallback so
	 * a single mod listener works in both worlds. RetroAPI's own recipe mixins are disabled
	 * when StationAPI is present, so the callback would otherwise never fire. We fire it once
	 * (on CRAFTING_SHAPED) — RetroRecipes.addShaped/addShapeless then delegate to StationAPI's
	 * CraftingRegistry. The vanilla type lookup is null for non-vanilla recipe ids; guard it.
	 */
	@EventListener
	public void onRecipeRegister(RecipeRegisterEvent event) {
		if (RecipeRegisterEvent.Vanilla.CRAFTING_SHAPED == RecipeRegisterEvent.Vanilla.fromType(event.recipeId)) {
			LOGGER.info("Bridging StationAPI RecipeRegisterEvent -> RetroAPI RecipeRegistrationCallback");
			RecipeRegistrationCallback.EVENT.invoker().run();
		}
	}

	@EventListener
	public void onIsPlayerUsingEffectiveTool(IsPlayerUsingEffectiveToolEvent event) {
		C_81592558 block = event.blockState.getBlock();
		if (RetroRegistry.getBlockRegistration(block) == null) return;

		RetroBlockAccess access = (RetroBlockAccess) block;
		if (access.isAlwaysDrops()) {
			event.resultProvider = () -> true;
		} else {
			// Fall back to vanilla canMineBlock for RetroAPI blocks
			C_87542771 inventory = event.player.f_29439708;
			event.resultProvider = () -> inventory.m_01253514(block);
		}
	}

	@EventListener
	public void onPlayerStrengthOnBlock(PlayerStrengthOnBlockEvent event) {
		C_81592558 block = event.blockState.getBlock();
		if (RetroRegistry.getBlockRegistration(block) == null) return;

		RetroBlockAccess access = (RetroBlockAccess) block;
		boolean alwaysEffective = access.isAlwaysEffectiveTool();
		Class<? extends C_98888256> effectiveTool = access.getEffectiveTool();

		// Fall back to vanilla getMiningSpeed for RetroAPI blocks, then apply tool overrides
		C_87542771 inventory = event.player.f_29439708;
		event.resultProvider = () -> {
			float speed = inventory.m_51990427(block);

			if (speed > 1.0f) return speed;

			C_88708284 held = inventory.m_27760697();
			if (held == null) return speed;
			C_98888256 item = held.m_23235460();

			if (alwaysEffective || (effectiveTool != null && effectiveTool.isInstance(item))) {
				return getToolSpeed(item, inventory);
			}
			return speed;
		};
	}

	/**
	 * Bridges RetroAPI's modded entity renderers into StationAPI's renderer registration. RetroAPI's own
	 * EntityRenderDispatcher @Redirect is disabled under StationAPI (two configs must not both rewrite the
	 * dispatcher ctor), so renderers registered flat via RetroEntityRenderers are forwarded into the
	 * dispatcher map through StationAPI's EntityRendererRegisterEvent — exactly one renderer redirect stays
	 * live (StationAPI's). Client-only event; never fires on a dedicated server.
	 */
	@EventListener
	public void registerEntityRenderers(EntityRendererRegisterEvent event) {
		RetroEntityRenderers.forEach(event::register);
	}

	private static float getToolSpeed(C_98888256 item, C_87542771 inventory) {
		if (item instanceof C_50456764) return inventory.m_51990427(C_81592558.f_38442324);
		if (item instanceof C_85721786) return inventory.m_51990427(C_81592558.f_32493286);
		if (item instanceof C_75759956) return inventory.m_51990427(C_81592558.f_05581995);
		if (item instanceof C_64104387) return 1.5f;
		return 1.0f;
	}
}
