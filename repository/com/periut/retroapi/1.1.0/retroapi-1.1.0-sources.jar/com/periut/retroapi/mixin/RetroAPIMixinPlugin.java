package com.periut.retroapi.mixin;

import net.fabricmc.loader.api.FabricLoader;
import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import java.util.List;
import java.util.Set;

public class RetroAPIMixinPlugin implements IMixinConfigPlugin {
	private static final Set<String> ATLAS_MIXINS = Set.of(
		"com.periut.retroapi.mixin.client.atlas.AchievementsScreenMixin",
		"com.periut.retroapi.mixin.client.atlas.BlockRendererAtlasMixin",
		"com.periut.retroapi.mixin.client.atlas.BlockParticleMixin",
		"com.periut.retroapi.mixin.client.atlas.EntityRendererAtlasMixin",
		"com.periut.retroapi.mixin.client.atlas.ItemInHandRendererMixin",
		"com.periut.retroapi.mixin.client.atlas.ItemRendererMixin",
		"com.periut.retroapi.mixin.client.atlas.ItemColorMixin",
		"com.periut.retroapi.mixin.client.atlas.LayeredItemRenderMixin",
		"com.periut.retroapi.mixin.client.atlas.LayeredHeldItemMixin",
		"com.periut.retroapi.mixin.client.atlas.TextureManagerMixin",
		"com.periut.retroapi.mixin.client.PlayerArmorTextureMixin"
	);

	private static final Set<String> STATIONAPI_DISABLED_MIXINS = Set.of(
		"com.periut.retroapi.mixin.dimension.DimensionMixin",
		"com.periut.retroapi.mixin.dimension.RegionWorldStorageMixin",
		"com.periut.retroapi.mixin.dimension.PlayerEntityMixin",
		"com.periut.retroapi.mixin.dimension.PlayerDimensionMixin",
		"com.periut.retroapi.mixin.dimension.EntityReadDimensionMixin",
		"com.periut.retroapi.mixin.dimension.server.MinecraftServerMixin",
		"com.periut.retroapi.mixin.dimension.server.PlayerManagerMixin",
		"com.periut.retroapi.mixin.dimension.server.ServerPlayerEntityMixin",
		"com.periut.retroapi.mixin.dimension.client.ClientPlayerEntityMixin",
		"com.periut.retroapi.mixin.client.achievement.AchievementsPageScreenMixin",
		"com.periut.retroapi.mixin.register.ItemStackMixin",
		"com.periut.retroapi.mixin.register.PlayerInventorySidecarMixin",
		"com.periut.retroapi.mixin.network.BlockUpdatePacketMixin",
		"com.periut.retroapi.mixin.network.BlocksUpdatePacketMixin",
		"com.periut.retroapi.mixin.network.WorldChunkPacketMixin",
		"com.periut.retroapi.mixin.network.ChunkSendMixin",
		// Component sync rides the slot/inventory packets; StationAPI owns item serialization there.
		"com.periut.retroapi.mixin.network.SlotUpdateComponentMixin",
		"com.periut.retroapi.mixin.network.InventoryComponentMixin",
		"com.periut.retroapi.mixin.network.ItemEntitySpawnComponentMixin",
		// Sound bridge stays RetroAPI-only when StationAPI is present (its packet layer owns sounds there).
		"com.periut.retroapi.mixin.network.ServerWorldSoundMixin",
		"com.periut.retroapi.mixin.client.ClientNetworkHandlerMixin",
		"com.periut.retroapi.mixin.client.ClientPlayerInteractionManagerMixin",
		"com.periut.retroapi.mixin.recipe.FurnaceBlockEntityMixin",
		"com.periut.retroapi.mixin.client.sound.SoundEngineMixin",
		"com.periut.retroapi.mixin.client.sound.SoundsMixin",
		// Renderer mixin is a @Redirect; to avoid two configs rewriting EntityRenderDispatcher.<init>,
		// it stays disabled under StationAPI and renderers are forwarded through StationAPI's
		// EntityRendererRegisterEvent (see compat/StationAPIRegistryForwarder).
		"com.periut.retroapi.mixin.entity.client.EntityRenderDispatcherMixin"
	);
	// NOTE: entity.server.ServerEntityTrackerMixin and entity.server.TrackedEntityMixin are deliberately
	// NOT disabled under StationAPI. They are @Inject (composable) and guarded on isRetroEntity, while
	// StationAPI's equivalents are guarded on CustomSpawnDataProvider — disjoint entity sets, so RetroAPI's
	// OSL-based entity spawn path coexists orthogonally with StationAPI's MessagePacket path (no interference).

	private boolean stationAPIPresent;

	@Override
	public void onLoad(String mixinPackage) {
		stationAPIPresent = FabricLoader.getInstance().isModLoaded("stationapi");
	}

	@Override
	public String getRefMapperConfig() {
		return null;
	}

	@Override
	public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
		if (ATLAS_MIXINS.contains(mixinClassName) || STATIONAPI_DISABLED_MIXINS.contains(mixinClassName)) {
			return !stationAPIPresent;
		}
		return true;
	}

	@Override
	public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {
	}

	@Override
	public List<String> getMixins() {
		return null;
	}

	@Override
	public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
	}

	@Override
	public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
	}
}
