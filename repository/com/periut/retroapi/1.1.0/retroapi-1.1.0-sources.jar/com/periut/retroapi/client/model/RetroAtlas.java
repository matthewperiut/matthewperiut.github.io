package com.periut.retroapi.client.model;

import com.periut.retroapi.client.texture.AtlasExpander;

/**
 * UV helper for the expanded atlases: maps (slot, pixel coordinate 0-16) to atlas UV.
 * Sprite-size aware (HD packs scale cleanly) and read at RENDER time, so atlas reloads
 * and StationAPI slot reassignment (mutable RetroTexture.id) are always reflected.
 */
public final class RetroAtlas {

	private RetroAtlas() {}

	public static double terrainU(int slot, double uPx) {
		int spriteSize = AtlasExpander.terrainSpriteSize;
		return ((slot % 16) * spriteSize + uPx * spriteSize / 16.0) / AtlasExpander.terrainAtlasSize;
	}

	public static double terrainV(int slot, double vPx) {
		int spriteSize = AtlasExpander.terrainSpriteSize;
		return ((slot / 16) * spriteSize + vPx * spriteSize / 16.0) / AtlasExpander.terrainAtlasSize;
	}
}
