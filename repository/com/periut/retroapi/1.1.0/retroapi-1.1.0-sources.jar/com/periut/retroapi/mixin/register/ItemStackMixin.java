package com.periut.retroapi.mixin.register;

import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;
import net.ornithemc.osl.core.api.util.NamespacedIdentifiers;
import com.periut.retroapi.registry.BlockRegistration;
import com.periut.retroapi.registry.ItemRegistration;
import com.periut.retroapi.registry.RetroRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_88708284.class)
public class ItemStackMixin implements com.periut.retroapi.component.RetroComponentHolder {

	@Shadow public int itemId;
	@Shadow public int count;

	@Shadow public int damage;

	/** This stack's data components (see RetroComponents). Lazily created, never on vanilla saves. */
	@org.spongepowered.asm.mixin.Unique
	private java.util.Map<com.periut.retroapi.component.RetroComponentType<?>, Object> retroapi$components;

	@Override
	public java.util.Map<com.periut.retroapi.component.RetroComponentType<?>, Object> retroapi$components() {
		if (this.retroapi$components == null) {
			this.retroapi$components = new java.util.HashMap<>();
		}
		return this.retroapi$components;
	}

	@Override
	public void retroapi$setComponents(java.util.Map<com.periut.retroapi.component.RetroComponentType<?>, Object> components) {
		this.retroapi$components = components;
	}

	/** copy() makes a fresh stack; deep-copy the components onto it or they would be shared. */
	@Inject(method = "copy", at = @At("RETURN"))
	private void retroapi$copyComponents(CallbackInfoReturnable<C_88708284> cir) {
		retroapi$copyComponentsTo(cir.getReturnValue());
	}

	/**
	 * split() ALSO makes a fresh stack (taking part of this one), and the split-off stack
	 * must carry the same components, or moving an item between slots, dropping part of a
	 * stack, or picking one up loses its data. This was the cause of "moving it between
	 * slots / picking it up clears the component".
	 */
	@Inject(method = "split", at = @At("RETURN"))
	private void retroapi$splitComponents(int amount, CallbackInfoReturnable<C_88708284> cir) {
		retroapi$copyComponentsTo(cir.getReturnValue());
	}

	@org.spongepowered.asm.mixin.Unique
	private void retroapi$copyComponentsTo(C_88708284 target) {
		if (target != null && this.retroapi$components != null && !this.retroapi$components.isEmpty()) {
			((com.periut.retroapi.component.RetroComponentHolder) (Object) target)
				.retroapi$setComponents(new java.util.HashMap<>(this.retroapi$components));
		}
	}

	@Inject(method = "writeNbt", at = @At("RETURN"))
	private void retroapi$writeNbt(C_74087615 nbt, CallbackInfoReturnable<C_74087615> cir) {
		String stringId = resolveStringId(this.itemId);
		if (stringId != null) {
			nbt.m_91017064("retroapi:id", stringId);
			// Save original values so the sidecar can read them after clamping
			nbt.m_41884431("retroapi:count", (byte) this.count);
			nbt.m_98335007("retroapi:damage", (short) this.damage);
			// Clamp to empty so vanilla sees nothing (avoids stone appearing in inventories)
			nbt.m_98335007("id", (short) 0);
			nbt.m_41884431("Count", (byte) 0);
		}
		// Components are independent of the id remap: a vanilla item can carry them too.
		com.periut.retroapi.component.ComponentNbt.write(this, nbt);
	}

	@Inject(method = "readNbt", at = @At("RETURN"))
	private void retroapi$readNbt(C_74087615 nbt, CallbackInfo ci) {
		retroapi$readComponents(nbt);
		// Try retroapi:id first, then fall back to stationapi:id (for worlds un-converted from StationAPI)
		String stringId = null;
		if (nbt.m_97612750("retroapi:id")) {
			stringId = nbt.m_47517355("retroapi:id");
		} else if (nbt.m_97612750("stationapi:id")) {
			stringId = nbt.m_47517355("stationapi:id");
		}

		if (stringId == null || stringId.isEmpty()) return;

		String[] parts = stringId.split(":", 2);
		if (parts.length != 2) return;

		NamespacedIdentifier retroId = NamespacedIdentifiers.from(parts[0], parts[1]);

		BlockRegistration blockReg = RetroRegistry.getBlockById(retroId);
		if (blockReg != null) {
			this.itemId = blockReg.getBlock().f_84602679;
		} else {
			ItemRegistration itemReg = RetroRegistry.getItemById(retroId);
			if (itemReg != null) {
				this.itemId = itemReg.getItem().f_57562535;
			} else {
				// Not a RetroAPI item (could be vanilla stationapi:id like "minecraft:stone") - leave as-is
				return;
			}
		}

		// Restore count and damage from retroapi tags (vanilla readNbt set them to clamped values)
		if (nbt.m_97612750("retroapi:count")) {
			this.count = nbt.m_84056038("retroapi:count") & 0xFF;
		}
		if (nbt.m_97612750("retroapi:damage")) {
			this.damage = nbt.m_03599456("retroapi:damage");
		}
	}

	@org.spongepowered.asm.mixin.Unique
	private void retroapi$readComponents(C_74087615 nbt) {
		com.periut.retroapi.component.ComponentNbt.read(this, nbt);
	}

	private static String resolveStringId(int numericId) {
		if (numericId >= 0 && numericId < C_81592558.f_44428008.length) {
			C_81592558 block = C_81592558.f_44428008[numericId];
			if (block != null) {
				BlockRegistration reg = RetroRegistry.getBlockRegistration(block);
				if (reg != null) return reg.getId().toString();
			}
		}
		if (numericId >= 0 && numericId < C_98888256.f_38445253.length) {
			C_98888256 item = C_98888256.f_38445253[numericId];
			if (item != null) {
				ItemRegistration reg = RetroRegistry.getItemRegistration(item);
				if (reg != null) return reg.getId().toString();
			}
		}
		return null;
	}
}
