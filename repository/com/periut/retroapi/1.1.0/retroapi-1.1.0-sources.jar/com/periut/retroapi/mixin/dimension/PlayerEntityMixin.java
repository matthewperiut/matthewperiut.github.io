package com.periut.retroapi.mixin.dimension;

import com.periut.retroapi.dimension.HasTeleportationManager;
import com.periut.retroapi.dimension.TeleportationManager;
import net.minecraft.unmapped.C_40996800;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

/**
 * Adds a per-player {@link TeleportationManager} slot so a portal can attach the transition it wants
 * the player to run. Read by the server/client dimension-change redirects. Disabled under StationAPI.
 */
@Mixin(C_40996800.class)
public class PlayerEntityMixin implements HasTeleportationManager {
	@Unique private TeleportationManager retroapi$teleportationManager;

	@Override
	public TeleportationManager getTeleportationManager() {
		return retroapi$teleportationManager;
	}

	@Override
	public void setTeleportationManager(TeleportationManager manager) {
		retroapi$teleportationManager = manager;
	}
}
