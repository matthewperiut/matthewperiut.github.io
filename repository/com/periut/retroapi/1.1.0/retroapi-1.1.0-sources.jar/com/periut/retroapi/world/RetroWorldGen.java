package com.periut.retroapi.world;

import com.periut.retroapi.storage.ExtendedBlocksAccess;
import net.minecraft.unmapped.C_14917579;

/**
 * Generation-safe block placement for custom chunk generators.
 *
 * <p>During {@code ChunkSource.getChunk} the chunk is not registered with the world yet, so
 * {@code Chunk.setBlock} must not be used for modded ids: vanilla fires {@code Block.onPlaced},
 * which may touch neighboring world positions and recursively re-generate the same chunk.
 * Vanilla generators avoid this by writing the constructor byte array directly; this is the
 * extended-id (>255) equivalent — it writes RetroAPI's per-chunk overlay with no side effects.</p>
 *
 * <pre>{@code
 * Chunk chunk = new Chunk(world, vanillaBlocks, chunkX, chunkZ);
 * RetroWorldGen.setBlockInChunk(chunk, x, y, z, AetherBlocks.Holystone.id, 0);
 * }</pre>
 */
public final class RetroWorldGen {
	private RetroWorldGen() {}

	/**
	 * Set a block in a freshly generated chunk without triggering placement side effects.
	 * Coordinates are chunk-local (0-15, 0-127, 0-15). Ids &lt; 256 should be written to the
	 * chunk's constructor byte array instead.
	 */
	public static void setBlockInChunk(C_14917579 chunk, int x, int y, int z, int blockId, int meta) {
		int index = (x * 16 + z) * 128 + y;
		((ExtendedBlocksAccess) chunk).retroapi$getExtendedBlocks().set(index, blockId, meta);
	}
}
