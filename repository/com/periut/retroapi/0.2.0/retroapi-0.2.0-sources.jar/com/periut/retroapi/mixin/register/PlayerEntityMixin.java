package com.periut.retroapi.mixin.register;

import com.periut.retroapi.register.block.RetroBlockAccess;
import com.periut.retroapi.tag.RetroTags;
import com.periut.retroapi.tag.RetroTool;
import net.minecraft.item.*;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_50456764;
import net.minecraft.unmapped.C_53672520;
import net.minecraft.unmapped.C_64104387;
import net.minecraft.unmapped.C_75759956;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_85721786;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Set;

@Mixin(C_40996800.class)
public abstract class PlayerEntityMixin {

	@Shadow public C_87542771 inventory;

	@Inject(method = "canHarvest", at = @At("HEAD"), cancellable = true)
	private void retroapi$alwaysDrops(C_81592558 block, CallbackInfoReturnable<Boolean> cir) {
		if (((RetroBlockAccess) block).isAlwaysDrops()) {
			cir.setReturnValue(true);
		}
	}

	/**
	 * Modern mineable semantics: a block in any {@code mineable/<tool>} tag drops only
	 * when a matching tool is held. Blocks in no tag keep vanilla behavior entirely.
	 */
	@Inject(method = "canHarvest", at = @At("HEAD"), cancellable = true)
	private void retroapi$mineableHarvest(C_81592558 block, CallbackInfoReturnable<Boolean> cir) {
		if (((RetroBlockAccess) block).isAlwaysDrops()) {
			return; // the alwaysDrops handler already answered true
		}
		Set<RetroTool> tools = RetroTags.mineableTools(block);
		com.periut.retroapi.tag.RetroToolTier required = RetroTags.requiredTier(block);
		if (tools.isEmpty() && required == com.periut.retroapi.tag.RetroToolTier.WOOD) {
			return; // untagged blocks keep vanilla behavior entirely
		}
		C_88708284 held = this.inventory.m_27760697();
		C_98888256 heldItem = held != null ? held.m_23235460() : null;

		// Tool KIND: a block in a mineable tag drops only for a matching tool kind.
		if (!tools.isEmpty()) {
			RetroTool kind = RetroTool.of(heldItem);
			if (kind == null || !tools.contains(kind)) {
				cir.setReturnValue(false);
				return;
			}
		}
		// Tool TIER: a block in a needs_<tier>_tool tag also demands the material level
		// (declared via RetroItemAccess.tier, or inferred from a ToolItem's material).
		if (!com.periut.retroapi.tag.RetroToolTier.of(heldItem).isAtLeast(required)) {
			cir.setReturnValue(false);
			return;
		}
		cir.setReturnValue(true);
	}

	@Inject(method = "getBlockBreakingSpeed", at = @At("RETURN"), cancellable = true)
	private void retroapi$effectiveTool(C_81592558 block, CallbackInfoReturnable<Float> cir) {
		RetroBlockAccess access = (RetroBlockAccess) block;
		if (cir.getReturnValue() > 1.0f) return;

		C_88708284 held = this.inventory.m_27760697();
		if (held == null) return;
		C_98888256 item = held.m_23235460();

		// Explicit per-block declarations win ties with the tag system.
		if (access.isAlwaysEffectiveTool()) {
			Float speed = retroapi$getToolSpeed(item);
			if (speed != null) {
				cir.setReturnValue(speed);
				return;
			}
		} else {
			Class<? extends C_98888256> effectiveTool = access.getEffectiveTool();
			if (effectiveTool != null && effectiveTool.isInstance(item)) {
				Float speed = retroapi$getToolSpeed(item);
				if (speed != null) {
					cir.setReturnValue(speed);
					return;
				}
			}
		}

		// Tag path: held tool kind matches a mineable/<tool> tag containing this block.
		Set<RetroTool> tools = RetroTags.mineableTools(block);
		if (!tools.isEmpty()) {
			RetroTool kind = RetroTool.of(item);
			if (kind != null && tools.contains(kind)) {
				Float speed = retroapi$getToolSpeed(item);
				if (speed != null) {
					cir.setReturnValue(speed);
				}
			}
		}
	}

	@Unique
	private Float retroapi$getToolSpeed(C_98888256 item) {
		// Vanilla tool classes: sample the held item's speed against a reference block of
		// the matching material (gives the tool's material speed: wood 2 .. gold 12).
		if (item instanceof C_50456764) return this.inventory.m_51990427(C_81592558.f_38442324);
		if (item instanceof C_85721786) return this.inventory.m_51990427(C_81592558.f_32493286);
		if (item instanceof C_75759956) return this.inventory.m_51990427(C_81592558.f_05581995);
		if (item instanceof C_64104387) return 1.5f;
		// Custom ToolItem subclasses (declared via RetroItemAccess.tool): raw material speed.
		if (item instanceof C_53672520) return ((ToolItemAccessor) item).retroapi$getMiningSpeed();
		// Declared tools that are plain Items (incl. hoes, which beta gives no block speeds):
		// a modest boost so tagged blocks still feel responsive.
		if (RetroTool.of(item) != null) return 1.5f;
		return null;
	}
}
