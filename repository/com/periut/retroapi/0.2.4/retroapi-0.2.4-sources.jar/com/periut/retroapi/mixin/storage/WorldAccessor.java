package com.periut.retroapi.mixin.storage;

import net.minecraft.unmapped.C_08489468;
import net.minecraft.unmapped.C_64041439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_64041439.class)
public interface WorldAccessor {
	@Accessor("storage")
	C_08489468 retroapi$getStorage();
}

