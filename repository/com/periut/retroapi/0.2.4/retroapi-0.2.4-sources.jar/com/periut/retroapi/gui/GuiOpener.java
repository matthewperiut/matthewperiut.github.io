package com.periut.retroapi.gui;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_46053237;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;

/**
 * Side-specific GUI opening strategy. The server and client each register their own
 * implementation from their entrypoints (environment-isolation: this common interface
 * references only env-neutral classes).
 */
public interface GuiOpener {
	void open(C_40996800 player, NamespacedIdentifier id, C_43616774 inventory, C_46053237 container);
}
