package com.periut.retroapi.tag;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.unmapped.C_81592558;

/**
 * Maps modern flattening-style names ({@code minecraft:stone}, {@code minecraft:oak_log}, ...)
 * to Beta 1.7.3 blocks, so tag data files copied from modern Minecraft resolve their vanilla
 * entries. Mirrors the flattening schema StationAPI uses for world conversion.
 *
 * <p>Both the modern name and, where it differs, the historical 1.13-flattening name are
 * registered (e.g. {@code grass} and {@code short_grass}; {@code oak_planks} and {@code planks}),
 * so files from any modern version resolve. Names that flatten from metadata (colored wool,
 * wood species) all map to the single beta block.</p>
 */
public final class VanillaBlockNames {

	private static final Map<String, C_81592558> BY_NAME = new HashMap<>();

	private VanillaBlockNames() {}

	static {
		put(C_81592558.f_38442324, "stone");
		put(C_81592558.f_41096518, "grass_block");
		put(C_81592558.f_05581995, "dirt");
		put(C_81592558.f_17981199, "cobblestone");
		put(C_81592558.f_32493286, "oak_planks", "planks");
		put(C_81592558.f_77878473, "oak_sapling", "sapling", "spruce_sapling", "birch_sapling");
		put(C_81592558.f_35695348, "bedrock");
		put(C_81592558.f_12152349, "flowing_water");
		put(C_81592558.f_91830957, "water");
		put(C_81592558.f_42662644, "flowing_lava");
		put(C_81592558.f_63585395, "lava");
		put(C_81592558.f_27446762, "sand");
		put(C_81592558.f_38177074, "gravel");
		put(C_81592558.f_91577743, "gold_ore");
		put(C_81592558.f_19757556, "iron_ore");
		put(C_81592558.f_81094226, "coal_ore");
		put(C_81592558.f_78280144, "oak_log", "log", "spruce_log", "birch_log");
		put(C_81592558.f_00276986, "oak_leaves", "leaves", "spruce_leaves", "birch_leaves");
		put(C_81592558.f_36441950, "sponge");
		put(C_81592558.f_32420701, "glass");
		put(C_81592558.f_83073694, "lapis_ore");
		put(C_81592558.f_99851615, "lapis_block");
		put(C_81592558.f_58920251, "dispenser");
		put(C_81592558.f_94949418, "sandstone");
		put(C_81592558.f_82599628, "note_block");
		put(C_81592558.f_10487872, "red_bed", "bed", "white_bed");
		put(C_81592558.f_27559703, "powered_rail", "golden_rail");
		put(C_81592558.f_89685822, "detector_rail");
		put(C_81592558.f_85558300, "sticky_piston");
		put(C_81592558.f_88550428, "cobweb", "web");
		put(C_81592558.f_83907852, "short_grass", "grass", "tall_grass", "fern");
		put(C_81592558.f_99121891, "dead_bush");
		put(C_81592558.f_65735585, "piston");
		put(C_81592558.f_95852348, "piston_head");
		put(C_81592558.f_12629815, "white_wool", "wool", "orange_wool", "magenta_wool", "light_blue_wool",
			"yellow_wool", "lime_wool", "pink_wool", "gray_wool", "light_gray_wool", "cyan_wool",
			"purple_wool", "blue_wool", "brown_wool", "green_wool", "red_wool", "black_wool");
		put(C_81592558.f_89678708, "moving_piston");
		put(C_81592558.f_38977206, "dandelion");
		put(C_81592558.f_72900486, "poppy", "rose");
		put(C_81592558.f_55254929, "brown_mushroom");
		put(C_81592558.f_30894038, "red_mushroom");
		put(C_81592558.f_54760749, "gold_block");
		put(C_81592558.f_41428926, "iron_block");
		put(C_81592558.f_39350323, "double_stone_slab");
		put(C_81592558.f_66929948, "smooth_stone_slab", "stone_slab");
		put(C_81592558.f_73573195, "bricks", "brick_block");
		put(C_81592558.f_69656505, "tnt");
		put(C_81592558.f_22197047, "bookshelf");
		put(C_81592558.f_87667057, "mossy_cobblestone");
		put(C_81592558.f_38591135, "obsidian");
		put(C_81592558.f_23542568, "torch");
		put(C_81592558.f_48624188, "fire");
		put(C_81592558.f_50662990, "spawner", "mob_spawner");
		put(C_81592558.f_31892463, "oak_stairs");
		put(C_81592558.f_49828421, "chest");
		put(C_81592558.f_08141062, "redstone_wire");
		put(C_81592558.f_35664400, "diamond_ore");
		put(C_81592558.f_95737061, "diamond_block");
		put(C_81592558.f_30918233, "crafting_table");
		put(C_81592558.f_09380838, "wheat");
		put(C_81592558.f_95757196, "farmland");
		put(C_81592558.f_19785413, "furnace");
		put(C_81592558.f_78357199, "lit_furnace");
		put(C_81592558.f_30518711, "oak_sign", "sign", "standing_sign");
		put(C_81592558.f_84644959, "oak_door", "wooden_door");
		put(C_81592558.f_51448992, "ladder");
		put(C_81592558.f_86544900, "rail");
		put(C_81592558.f_38259672, "cobblestone_stairs", "stone_stairs");
		put(C_81592558.f_13293967, "oak_wall_sign", "wall_sign");
		put(C_81592558.f_82613228, "lever");
		put(C_81592558.f_90267132, "stone_pressure_plate");
		put(C_81592558.f_91546482, "iron_door");
		put(C_81592558.f_58356112, "oak_pressure_plate", "wooden_pressure_plate");
		put(C_81592558.f_68803305, "redstone_ore");
		put(C_81592558.f_88434840, "lit_redstone_ore");
		put(C_81592558.f_19964067, "unlit_redstone_torch");
		put(C_81592558.f_78503403, "redstone_torch");
		put(C_81592558.f_40727126, "stone_button");
		put(C_81592558.f_81695559, "snow");
		put(C_81592558.f_28421768, "ice");
		put(C_81592558.f_51102006, "snow_block");
		put(C_81592558.f_94556547, "cactus");
		put(C_81592558.f_86394960, "clay");
		put(C_81592558.f_35874681, "sugar_cane", "reeds");
		put(C_81592558.f_25017736, "jukebox");
		put(C_81592558.f_98928673, "oak_fence", "fence");
		put(C_81592558.f_94091898, "pumpkin", "carved_pumpkin");
		put(C_81592558.f_14995882, "netherrack");
		put(C_81592558.f_84892602, "soul_sand");
		put(C_81592558.f_19295217, "glowstone");
		put(C_81592558.f_18320492, "nether_portal", "portal");
		put(C_81592558.f_49218653, "jack_o_lantern", "lit_pumpkin");
		put(C_81592558.f_98529173, "cake");
		put(C_81592558.f_77070700, "repeater", "unpowered_repeater");
		put(C_81592558.f_02852022, "powered_repeater");
		put(C_81592558.f_79966048, "oak_trapdoor", "trapdoor");
	}

	private static void put(C_81592558 block, String... names) {
		for (String name : names) {
			BY_NAME.put(name, block);
		}
	}

	/**
	 * Resolves a {@code minecraft:<name>} (with or without the namespace) to its beta block,
	 * or null if the name has no beta equivalent (post-beta blocks fall in here, which is
	 * exactly what makes modern tag files copy across safely: unknown entries just skip).
	 */
	public static C_81592558 resolve(String name) {
		int colon = name.indexOf(':');
		if (colon >= 0) {
			name = name.substring(colon + 1);
		}
		return BY_NAME.get(name);
	}
}
