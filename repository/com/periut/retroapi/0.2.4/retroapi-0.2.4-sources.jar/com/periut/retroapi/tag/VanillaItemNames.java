package com.periut.retroapi.tag;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.unmapped.C_98888256;

/**
 * Maps modern flattening-style item names ({@code minecraft:iron_ingot}, {@code minecraft:oak_boat}, ...)
 * to Beta 1.7.3 items, the item-side counterpart of {@link VanillaBlockNames}. This lets item tag data
 * files copied from modern Minecraft (or written in StationAPI's {@code data/{ns}/stationapi/tags/items/}
 * layout) resolve their vanilla entries.
 *
 * <p>Both the modern name and, where it differs, the historical or StationAPI spelling are registered
 * (e.g. {@code cod} and {@code raw_fish}; {@code slime_ball} and {@code slimeball}; {@code golden_pickaxe}
 * and {@code gold_pickaxe}). Names that flatten from item metadata (the dye family, records) map to the
 * single beta item, mirroring how {@link VanillaBlockNames} handles metadata-flattened blocks.</p>
 */
public final class VanillaItemNames {

	private static final Map<String, C_98888256> BY_NAME = new HashMap<>();

	private VanillaItemNames() {}

	static {
		// Tools / weapons (field name lowercased == modern name for these).
		put(C_98888256.f_96913276, "wooden_sword");
		put(C_98888256.f_38813183, "wooden_shovel");
		put(C_98888256.f_50174679, "wooden_pickaxe");
		put(C_98888256.f_27888996, "wooden_axe");
		put(C_98888256.f_03688690, "wooden_hoe");
		put(C_98888256.f_13344738, "stone_sword");
		put(C_98888256.f_18708761, "stone_shovel");
		put(C_98888256.f_88921834, "stone_pickaxe");
		put(C_98888256.f_02912756, "stone_axe");
		put(C_98888256.f_98142733, "stone_hoe");
		put(C_98888256.f_32125146, "iron_sword");
		put(C_98888256.f_80805461, "iron_shovel");
		put(C_98888256.f_98306436, "iron_pickaxe");
		put(C_98888256.f_89785708, "iron_axe");
		put(C_98888256.f_57678723, "iron_hoe");
		put(C_98888256.f_29490209, "diamond_sword");
		put(C_98888256.f_04770191, "diamond_shovel");
		put(C_98888256.f_43932574, "diamond_pickaxe");
		put(C_98888256.f_45386391, "diamond_axe");
		put(C_98888256.f_35880850, "diamond_hoe");
		// Beta "gold" tools flatten to "golden_" in modern; register both.
		put(C_98888256.f_56140732, "golden_sword", "gold_sword");
		put(C_98888256.f_50429169, "golden_shovel", "gold_shovel");
		put(C_98888256.f_68090982, "golden_pickaxe", "gold_pickaxe");
		put(C_98888256.f_08977302, "golden_axe", "gold_axe");
		put(C_98888256.f_31038121, "golden_hoe", "gold_hoe");
		put(C_98888256.f_96370468, "flint_and_steel");
		put(C_98888256.f_59992682, "bow");
		put(C_98888256.f_57012528, "fishing_rod");
		put(C_98888256.f_18374421, "shears");

		// Armor.
		put(C_98888256.f_92705060, "leather_helmet");
		put(C_98888256.f_60255230, "leather_chestplate");
		put(C_98888256.f_78687479, "leather_leggings");
		put(C_98888256.f_65686175, "leather_boots");
		put(C_98888256.f_20484061, "chainmail_helmet", "chain_helmet");
		put(C_98888256.f_92537726, "chainmail_chestplate", "chain_chestplate");
		put(C_98888256.f_24275834, "chainmail_leggings", "chain_leggings");
		put(C_98888256.f_67341244, "chainmail_boots", "chain_boots");
		put(C_98888256.f_84448376, "iron_helmet");
		put(C_98888256.f_56682976, "iron_chestplate");
		put(C_98888256.f_64671240, "iron_leggings");
		put(C_98888256.f_96568531, "iron_boots");
		put(C_98888256.f_00953201, "diamond_helmet");
		put(C_98888256.f_54219088, "diamond_chestplate");
		put(C_98888256.f_42239243, "diamond_leggings");
		put(C_98888256.f_21328201, "diamond_boots");
		put(C_98888256.f_06326883, "golden_helmet", "gold_helmet");
		put(C_98888256.f_58467061, "golden_chestplate", "gold_chestplate");
		put(C_98888256.f_20229887, "golden_leggings", "gold_leggings");
		put(C_98888256.f_08730706, "golden_boots", "gold_boots");

		// Materials / misc.
		put(C_98888256.f_57144513, "apple");
		put(C_98888256.f_67660833, "arrow");
		put(C_98888256.f_58154723, "coal", "charcoal");
		put(C_98888256.f_18976102, "diamond");
		put(C_98888256.f_80480869, "iron_ingot");
		put(C_98888256.f_73771168, "gold_ingot");
		put(C_98888256.f_70868303, "stick");
		put(C_98888256.f_21498627, "bowl");
		put(C_98888256.f_94828714, "mushroom_stew", "suspicious_stew");
		put(C_98888256.f_94759491, "string");
		put(C_98888256.f_56704454, "feather");
		put(C_98888256.f_32150368, "gunpowder");
		put(C_98888256.f_84974010, "wheat_seeds", "seeds");
		put(C_98888256.f_60617725, "wheat");
		put(C_98888256.f_94155714, "bread");
		put(C_98888256.f_08935226, "flint");
		put(C_98888256.f_70512792, "porkchop", "raw_porkchop");
		put(C_98888256.f_40838509, "cooked_porkchop");
		put(C_98888256.f_27056679, "painting");
		put(C_98888256.f_18291365, "golden_apple");
		put(C_98888256.f_97502738, "oak_sign", "sign");
		put(C_98888256.f_92303073, "oak_door", "wooden_door");
		put(C_98888256.f_91599154, "bucket");
		put(C_98888256.f_94313583, "water_bucket");
		put(C_98888256.f_32467447, "lava_bucket");
		put(C_98888256.f_62954975, "milk_bucket");
		put(C_98888256.f_72559846, "minecart");
		put(C_98888256.f_07293363, "saddle");
		put(C_98888256.f_40777991, "iron_door");
		put(C_98888256.f_52656331, "redstone");
		put(C_98888256.f_10659101, "snowball");
		put(C_98888256.f_67114151, "oak_boat", "boat");
		put(C_98888256.f_08971169, "leather");
		put(C_98888256.f_21279732, "brick");
		put(C_98888256.f_39465979, "clay_ball", "clay");
		put(C_98888256.f_55275152, "sugar_cane", "reeds");
		put(C_98888256.f_90966147, "paper");
		put(C_98888256.f_32576217, "book");
		put(C_98888256.f_46317332, "slime_ball", "slimeball");
		put(C_98888256.f_20481988, "chest_minecart", "minecart_chest");
		put(C_98888256.f_49490949, "furnace_minecart", "minecart_furnace");
		put(C_98888256.f_03970011, "egg");
		put(C_98888256.f_53864758, "compass");
		put(C_98888256.f_10956141, "clock");
		put(C_98888256.f_88723374, "glowstone_dust");
		put(C_98888256.f_87025895, "cod", "raw_fish", "fish");
		put(C_98888256.f_87709655, "cooked_cod", "cooked_fish");
		// The dye family flattens per-metadata; every modern split maps to the one beta item.
		put(C_98888256.f_09260276, "dye", "lapis_lazuli", "ink_sac", "cocoa_beans", "bone_meal");
		put(C_98888256.f_51993064, "bone");
		put(C_98888256.f_79588801, "sugar");
		put(C_98888256.f_59726285, "cake");
		put(C_98888256.f_08856223, "red_bed", "bed", "white_bed");
		put(C_98888256.f_98054602, "repeater", "unpowered_repeater");
		put(C_98888256.f_91086089, "cookie");
		put(C_98888256.f_69447318, "filled_map", "map");
		put(C_98888256.f_30116592, "music_disc_13", "record_13", "record_thirteen");
		put(C_98888256.f_33926157, "music_disc_cat", "record_cat");
	}

	private static void put(C_98888256 item, String... names) {
		for (String name : names) {
			BY_NAME.put(name, item);
		}
	}

	/**
	 * Resolves a {@code minecraft:<name>} (with or without the namespace) to its beta item, or null if
	 * the name has no beta equivalent (post-beta items fall in here, which is exactly what makes modern
	 * item tag files copy across safely: unknown entries just skip).
	 */
	public static C_98888256 resolve(String name) {
		int colon = name.indexOf(':');
		if (colon >= 0) {
			name = name.substring(colon + 1);
		}
		return BY_NAME.get(name);
	}
}
