package com.periut.retroapi.gui.client;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_85740840;

/**
 * Client-side GUI handler: the screen factory plus the inventory factory used on remote
 * clients (which have no real block entity instance). Mirrors StationAPI's {@code GuiHandler}.
 */
public record RetroGuiHandler(ScreenFactory screenFactory, InventoryFactory inventoryFactory) {

	@FunctionalInterface
	public interface ScreenFactory {
		C_85740840 create(C_40996800 player, C_43616774 inventory);
	}

	@FunctionalInterface
	public interface InventoryFactory {
		C_43616774 create();
	}
}
