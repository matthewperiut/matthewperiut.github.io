package com.periut.retroapi.mixin.recipe;

import net.minecraft.unmapped.C_53504297;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Exposes vanilla's private {@code FurnaceBlockEntity.getFuelTime(ItemStack)} so
 * {@link com.periut.retroapi.register.recipe.RetroRecipes#getTotalFuelTime(C_88708284)} can answer
 * "how long does this item burn?" for ANY fuel, vanilla's table plus whatever has been injected
 * into it ({@code FurnaceBlockEntityMixin} on the RetroAPI path, StationAPI's own mixin when it is
 * present). Always applied (it adds no behavior, unlike {@code FurnaceBlockEntityMixin}).
 */
@Mixin(C_53504297.class)
public interface FurnaceFuelAccessor {

	@Invoker("getFuelTime")
	int retroapi$getFuelTime(C_88708284 stack);
}
