package com.periut.retroapi.entity.spawn;

import net.minecraft.unmapped.C_42232651;

/**
 * A modded entity with an owner (e.g. projectiles), whose owner id + velocity are sent at spawn so the
 * client can resolve the owner and reproduce the trajectory. Mirrors StationAPI's {@code HasOwner}.
 */
public interface RetroHasOwner {
	C_42232651 getOwner();

	void setOwner(C_42232651 owner);
}
