package com.periut.retroapi.mixin.register;

import net.minecraft.unmapped.C_40735137;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_40735137.class)
public interface BlockEntityAccessor {

	@Invoker("create")
	static void retroapi$create(Class<? extends C_40735137> blockEntityClass, String id) {
		throw new AssertionError();
	}
}
