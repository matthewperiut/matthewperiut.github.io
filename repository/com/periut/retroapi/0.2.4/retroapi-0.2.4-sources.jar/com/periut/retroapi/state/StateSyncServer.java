package com.periut.retroapi.state;

import com.periut.retroapi.network.RetroAPINetworking;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_64041439;
import net.ornithemc.osl.networking.api.server.ServerPlayNetworking;

/**
 * Server-only half of single-block state sync: broadcasts a full flattened index to every
 * player in the world over {@code retroapi:state_sync}. Kept in its own class so client
 * environments never load ServerPlayerEntity/ServerPlayNetworking (RetroStates only calls
 * in here when the environment type is SERVER).
 */
final class StateSyncServer {

	private StateSyncServer() {}

	static void send(C_64041439 world, int x, int y, int z, int index) {
		for (Object player : world.f_51003174) {
			if (player instanceof C_49202226) {
				ServerPlayNetworking.send((C_49202226) player, RetroAPINetworking.STATE_SYNC_CHANNEL, buf -> {
					buf.writeInt(x);
					buf.writeInt(y);
					buf.writeInt(z);
					buf.writeVarInt(index);
				});
			}
		}
	}
}
