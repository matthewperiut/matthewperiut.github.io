package com.periut.retroapi.mixin.client;

import com.periut.retroapi.registry.RetroIds;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_24384787;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(C_24384787.class)
public class WorldRendererMixin {
	@Shadow
	private Minecraft client;

	@Shadow
	private C_64041439 world;

	@Inject(method = "worldEvent", at = @At("HEAD"), cancellable = true, require = 0)
	private void retroapi$handleExtendedBlockBreak(C_40996800 player, int event, int x, int y, int z, int data, CallbackInfo ci) {
		if (event == 2001) {
			// Decode the block-break packing. Must match the encode side (Client/Server
			// PlayerInteractionManager mixins) AND StationAPI's flattening layout: blockId in the low
			// 28 bits, metadata in bits 28+. Using a 12-bit layout here against StationAPI's 28-bit
			// encode silently dropped metadata, breaking particles for metadata-driven blocks (tall
			// grass / ferns / cross plants). See RetroIds.
			int blockId = data & RetroIds.BREAK_EVENT_ID_MASK;
			int metadata = (data >> RetroIds.BREAK_EVENT_META_SHIFT) & 0xF;

			if (blockId > 0) {
				C_81592558 block = C_81592558.f_44428008[blockId];
				if (block != null) {
					client.f_52467463.m_03593803(
						block.f_13889746.m_58114629(),
						x + 0.5f, y + 0.5f, z + 0.5f,
						(block.f_13889746.m_48828997() + 1.0f) / 2.0f,
						block.f_13889746.m_35890820() * 0.8f
					);
				}
			}

			client.f_49464910.m_80935546(x, y, z, blockId, metadata);
			ci.cancel();
		}
	}
}

