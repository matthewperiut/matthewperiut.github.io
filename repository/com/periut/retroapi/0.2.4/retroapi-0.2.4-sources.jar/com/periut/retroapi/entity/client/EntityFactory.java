package com.periut.retroapi.entity.client;

import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;

/**
 * Client-side factory for a non-living modded entity. Mirrors StationAPI's
 * {@code EntityWorldAndPosFactory} so an Aether port is a near-mechanical swap.
 */
@FunctionalInterface
public interface EntityFactory {
	C_42232651 create(C_64041439 world, double x, double y, double z);
}
