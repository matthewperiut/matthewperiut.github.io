package com.periut.retroapi.mixin.client.atlas;

import com.periut.retroapi.client.texture.AtlasExpander;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import javax.imageio.ImageIO;
import net.minecraft.unmapped.C_18996072;
import net.minecraft.unmapped.C_74530968;
import net.minecraft.unmapped.C_82920792;
import java.awt.image.BufferedImage;
import java.io.InputStream;

@Mixin(C_82920792.class)
public abstract class TextureManagerMixin {
	@Shadow
	private C_18996072 texturePacks;

	@Shadow
	public abstract void load(BufferedImage image, int id);

	@Unique
	private int retroapi$terrainTextureId = -1;
	@Unique
	private int retroapi$itemsTextureId = -1;

	@Inject(method = "getTextureId(Ljava/lang/String;)I", at = @At("RETURN"))
	private void retroapi$onLoadTexture(String path, CallbackInfoReturnable<Integer> cir) {
		int textureId = cir.getReturnValueI();

		if ("/terrain.png".equals(path) && retroapi$terrainTextureId == -1) {
			retroapi$terrainTextureId = textureId;
			retroapi$compositeAtlas("/terrain.png", textureId, true);
		} else if ("/gui/items.png".equals(path) && retroapi$itemsTextureId == -1) {
			retroapi$itemsTextureId = textureId;
			retroapi$compositeAtlas("/gui/items.png", textureId, false);
		}
	}

	@Inject(method = "reload", at = @At("RETURN"))
	private void retroapi$onReload(CallbackInfo ci) {
		if (retroapi$terrainTextureId != -1) {
			retroapi$compositeAtlas("/terrain.png", retroapi$terrainTextureId, true);
		}
		if (retroapi$itemsTextureId != -1) {
			retroapi$compositeAtlas("/gui/items.png", retroapi$itemsTextureId, false);
		}
	}

	/**
	 * Drives RetroAPI's atlas animators alongside vanilla's dynamic textures. RetroAPI
	 * uploads its animated sprites itself (exact slot offsets, sprite-size aware) instead
	 * of riding vanilla's DynamicTexture loop, whose upload math hardcodes 16px sprites
	 * and the 256px atlas. See RetroAnimatedTexture for the full reasoning.
	 */
	@Inject(method = "tick", at = @At("RETURN"))
	private void retroapi$tickAnimations(CallbackInfo ci) {
		if (retroapi$terrainTextureId != -1 && !AtlasExpander.terrainAnimators.isEmpty()) {
			org.lwjgl.opengl.GL11.glBindTexture(org.lwjgl.opengl.GL11.GL_TEXTURE_2D, retroapi$terrainTextureId);
			for (com.periut.retroapi.client.texture.RetroAnimatedTexture animator : AtlasExpander.terrainAnimators) {
				animator.tick();
				animator.upload();
			}
		}
		if (retroapi$itemsTextureId != -1 && !AtlasExpander.itemAnimators.isEmpty()) {
			org.lwjgl.opengl.GL11.glBindTexture(org.lwjgl.opengl.GL11.GL_TEXTURE_2D, retroapi$itemsTextureId);
			for (com.periut.retroapi.client.texture.RetroAnimatedTexture animator : AtlasExpander.itemAnimators) {
				animator.tick();
				animator.upload();
			}
		}
	}

	@Unique
	private void retroapi$compositeAtlas(String path, int textureId, boolean isTerrain) {
		try {
			C_74530968 pack = texturePacks.f_25140974;
			InputStream is = pack.m_26802260(path);
			if (is != null) {
				BufferedImage original = ImageIO.read(is);
				is.close();
				BufferedImage modified = isTerrain
					? AtlasExpander.expandTerrainAtlas(original)
					: AtlasExpander.expandItemAtlas(original);
				load(modified, textureId);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
