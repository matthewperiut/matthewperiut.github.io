package com.periut.retroapi.gui.client;

import com.periut.retroapi.gui.GuiOpener;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_46053237;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;

/**
 * Singleplayer GUI opener: opens the registered screen directly against the real inventory
 * (block entity). Mirrors StationAPI's {@code GuiHelperClientImpl} behavior.
 */
public class ClientGuiOpener implements GuiOpener {

	@Override
	public void open(C_40996800 player, NamespacedIdentifier id, C_43616774 inventory, C_46053237 container) {
		RetroGuiHandler handler = RetroGuiRegistry.get(id.toString());
		if (handler != null) {
			Minecraft minecraft = (Minecraft) FabricLoader.getInstance().getGameInstance();
			minecraft.m_52715402(handler.screenFactory().create(player, inventory));
		}
	}
}
