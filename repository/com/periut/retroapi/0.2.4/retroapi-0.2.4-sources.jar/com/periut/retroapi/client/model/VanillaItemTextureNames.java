package com.periut.retroapi.client.model;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.unmapped.C_98888256;

/**
 * Maps modern item texture ids ({@code minecraft:item/apple}, ...) to vanilla items.png
 * sprite indices, the items.png counterpart of {@link VanillaTextureNames}: item model
 * layers reference vanilla item textures by name and resolve straight off the vanilla
 * atlas, nobody re-ships apple.png.
 *
 * <p>Both the modern (post-flattening) name and, where it differs, the historical name
 * are registered. Dyes map per-subtype (bone_meal, lapis_lazuli, ...). Unknown names
 * fall through to the normal mod-file path, so coverage gaps warn rather than vanish.</p>
 */
final class VanillaItemTextureNames {

	private static Map<String, Integer> sprites = null;

	private VanillaItemTextureNames() {}

	/**
	 * The items.png sprite for a path like {@code item/apple}, or null when unknown.
	 * Item sprite ids come from {@code Item.getTextureId}, which is a CLIENT-only method,
	 * so this returns null on the server (where item sprites are never needed anyway, and
	 * the caller falls back to a normal extended slot).
	 */
	static Integer itemSprite(String path) {
		if (net.fabricmc.loader.api.FabricLoader.getInstance().getEnvironmentType()
				!= net.fabricmc.api.EnvType.CLIENT) {
			return null;
		}
		if (path.startsWith("item/")) {
			path = path.substring("item/".length());
		} else if (path.startsWith("items/")) {
			path = path.substring("items/".length());
		}
		return table().get(path);
	}

	private static synchronized Map<String, Integer> table() {
		if (sprites != null) {
			return sprites;
		}
		Map<String, Integer> t = new HashMap<>();

		put(t, C_98888256.f_80805461, "iron_shovel");
		put(t, C_98888256.f_98306436, "iron_pickaxe");
		put(t, C_98888256.f_89785708, "iron_axe");
		put(t, C_98888256.f_96370468, "flint_and_steel");
		put(t, C_98888256.f_57144513, "apple");
		put(t, C_98888256.f_59992682, "bow");
		put(t, C_98888256.f_67660833, "arrow");
		put(t, C_98888256.f_58154723, "coal");
		put(t, C_98888256.f_18976102, "diamond");
		put(t, C_98888256.f_80480869, "iron_ingot");
		put(t, C_98888256.f_73771168, "gold_ingot");
		put(t, C_98888256.f_32125146, "iron_sword");
		put(t, C_98888256.f_96913276, "wooden_sword");
		put(t, C_98888256.f_38813183, "wooden_shovel");
		put(t, C_98888256.f_50174679, "wooden_pickaxe");
		put(t, C_98888256.f_27888996, "wooden_axe");
		put(t, C_98888256.f_13344738, "stone_sword");
		put(t, C_98888256.f_18708761, "stone_shovel");
		put(t, C_98888256.f_88921834, "stone_pickaxe");
		put(t, C_98888256.f_02912756, "stone_axe");
		put(t, C_98888256.f_29490209, "diamond_sword");
		put(t, C_98888256.f_04770191, "diamond_shovel");
		put(t, C_98888256.f_43932574, "diamond_pickaxe");
		put(t, C_98888256.f_45386391, "diamond_axe");
		put(t, C_98888256.f_70868303, "stick");
		put(t, C_98888256.f_21498627, "bowl");
		put(t, C_98888256.f_94828714, "mushroom_stew");
		put(t, C_98888256.f_56140732, "golden_sword");
		put(t, C_98888256.f_50429169, "golden_shovel");
		put(t, C_98888256.f_68090982, "golden_pickaxe");
		put(t, C_98888256.f_08977302, "golden_axe");
		put(t, C_98888256.f_94759491, "string");
		put(t, C_98888256.f_56704454, "feather");
		put(t, C_98888256.f_32150368, "gunpowder");
		put(t, C_98888256.f_03688690, "wooden_hoe");
		put(t, C_98888256.f_98142733, "stone_hoe");
		put(t, C_98888256.f_57678723, "iron_hoe");
		put(t, C_98888256.f_35880850, "diamond_hoe");
		put(t, C_98888256.f_31038121, "golden_hoe");
		put(t, C_98888256.f_60617725, "wheat");
		put(t, C_98888256.f_94155714, "bread");
		put(t, C_98888256.f_92705060, "leather_helmet");
		put(t, C_98888256.f_60255230, "leather_chestplate");
		put(t, C_98888256.f_78687479, "leather_leggings");
		put(t, C_98888256.f_65686175, "leather_boots");
		put(t, C_98888256.f_84448376, "iron_helmet");
		put(t, C_98888256.f_56682976, "iron_chestplate");
		put(t, C_98888256.f_64671240, "iron_leggings");
		put(t, C_98888256.f_96568531, "iron_boots");
		put(t, C_98888256.f_00953201, "diamond_helmet");
		put(t, C_98888256.f_54219088, "diamond_chestplate");
		put(t, C_98888256.f_42239243, "diamond_leggings");
		put(t, C_98888256.f_21328201, "diamond_boots");
		put(t, C_98888256.f_06326883, "golden_helmet");
		put(t, C_98888256.f_58467061, "golden_chestplate");
		put(t, C_98888256.f_20229887, "golden_leggings");
		put(t, C_98888256.f_08730706, "golden_boots");
		put(t, C_98888256.f_08935226, "flint");
		put(t, C_98888256.f_27056679, "painting");
		put(t, C_98888256.f_18291365, "golden_apple");
		put(t, C_98888256.f_91599154, "bucket");
		put(t, C_98888256.f_94313583, "water_bucket");
		put(t, C_98888256.f_32467447, "lava_bucket");
		put(t, C_98888256.f_72559846, "minecart");
		put(t, C_98888256.f_07293363, "saddle");
		put(t, C_98888256.f_40777991, "iron_door");
		put(t, C_98888256.f_52656331, "redstone");
		put(t, C_98888256.f_10659101, "snowball");
		put(t, C_98888256.f_08971169, "leather");
		put(t, C_98888256.f_62954975, "milk_bucket");
		put(t, C_98888256.f_21279732, "brick");
		put(t, C_98888256.f_55275152, "sugar_cane");
		put(t, C_98888256.f_90966147, "paper");
		put(t, C_98888256.f_32576217, "book");
		put(t, C_98888256.f_03970011, "egg");
		put(t, C_98888256.f_53864758, "compass");
		put(t, C_98888256.f_57012528, "fishing_rod");
		put(t, C_98888256.f_10956141, "clock");
		put(t, C_98888256.f_88723374, "glowstone_dust");
		put(t, C_98888256.f_51993064, "bone");
		put(t, C_98888256.f_79588801, "sugar");
		put(t, C_98888256.f_59726285, "cake");
		put(t, C_98888256.f_98054602, "repeater");
		put(t, C_98888256.f_91086089, "cookie");
		put(t, C_98888256.f_84974010, "wheat_seeds", "seeds");
		put(t, C_98888256.f_20484061, "chainmail_helmet", "chain_helmet");
		put(t, C_98888256.f_92537726, "chainmail_chestplate", "chain_chestplate");
		put(t, C_98888256.f_24275834, "chainmail_leggings", "chain_leggings");
		put(t, C_98888256.f_67341244, "chainmail_boots", "chain_boots");
		put(t, C_98888256.f_70512792, "porkchop", "raw_porkchop");
		put(t, C_98888256.f_40838509, "cooked_porkchop");
		put(t, C_98888256.f_97502738, "oak_sign", "sign");
		put(t, C_98888256.f_92303073, "oak_door", "wooden_door");
		put(t, C_98888256.f_67114151, "oak_boat", "boat");
		put(t, C_98888256.f_39465979, "clay_ball", "clay");
		put(t, C_98888256.f_46317332, "slime_ball", "slimeball");
		put(t, C_98888256.f_20481988, "chest_minecart", "minecart_chest");
		put(t, C_98888256.f_49490949, "furnace_minecart", "minecart_furnace");
		put(t, C_98888256.f_87025895, "cod", "fish", "raw_fish");
		put(t, C_98888256.f_87709655, "cooked_cod", "cooked_fish");
		put(t, C_98888256.f_08856223, "red_bed", "bed");
		put(t, C_98888256.f_30116592, "music_disc_13", "record_13");
		put(t, C_98888256.f_33926157, "music_disc_cat", "record_cat");
		// Dyes carry their subtype in the damage value; modern names map per-meta.
		t.put("ink_sac", C_98888256.f_09260276.m_27460772(0));
		t.put("red_dye", C_98888256.f_09260276.m_27460772(1));
		t.put("green_dye", C_98888256.f_09260276.m_27460772(2));
		t.put("cocoa_beans", C_98888256.f_09260276.m_27460772(3));
		t.put("lapis_lazuli", C_98888256.f_09260276.m_27460772(4));
		t.put("purple_dye", C_98888256.f_09260276.m_27460772(5));
		t.put("cyan_dye", C_98888256.f_09260276.m_27460772(6));
		t.put("light_gray_dye", C_98888256.f_09260276.m_27460772(7));
		t.put("gray_dye", C_98888256.f_09260276.m_27460772(8));
		t.put("pink_dye", C_98888256.f_09260276.m_27460772(9));
		t.put("lime_dye", C_98888256.f_09260276.m_27460772(10));
		t.put("yellow_dye", C_98888256.f_09260276.m_27460772(11));
		t.put("light_blue_dye", C_98888256.f_09260276.m_27460772(12));
		t.put("magenta_dye", C_98888256.f_09260276.m_27460772(13));
		t.put("orange_dye", C_98888256.f_09260276.m_27460772(14));
		t.put("bone_meal", C_98888256.f_09260276.m_27460772(15));

		sprites = t;
		return t;
	}

	/** Registers an item's sprite under one or more names. */
	private static void put(Map<String, Integer> t, C_98888256 item, String... names) {
		for (String name : names) {
			t.put(name, item.m_27460772(0));
		}
	}
}
