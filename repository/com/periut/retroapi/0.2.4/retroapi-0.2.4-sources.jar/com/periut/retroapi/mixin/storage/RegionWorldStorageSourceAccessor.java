package com.periut.retroapi.mixin.storage;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.io.File;
import net.minecraft.unmapped.C_72342472;

@Mixin(C_72342472.class)
public interface RegionWorldStorageSourceAccessor {
	@Accessor("dir")
	File retroapi$getDir();
}

