package com.periut.retroapi.mixin.network;

import com.periut.retroapi.network.BlocksUpdatePacketAccess;
import com.periut.retroapi.storage.ChunkExtendedBlocks;
import com.periut.retroapi.storage.ExtendedBlocksAccess;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_36877109;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_62858513;
import net.minecraft.unmapped.C_99660737;
import com.periut.retroapi.network.WorldChunkPacketAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_99660737.class)
public class ChunkSendMixin {

	@Shadow public C_49202226 player;

	@Inject(method = "sendPacket", at = @At("HEAD"))
	private void retroapi$populateExtendedData(C_03562565 packet, CallbackInfo ci) {
		if (packet instanceof C_62858513 wcp) {
			WorldChunkPacketAccess access = (WorldChunkPacketAccess) wcp;
			if (access.retroapi$getExtCount() > 0) return;

			int chunkX = wcp.f_05662346 >> 4;
			int chunkZ = wcp.f_77394700 >> 4;
			C_14917579 chunk = player.f_94306729.m_27928573(chunkX, chunkZ);
			if (chunk == null) return;

			ChunkExtendedBlocks extended = ((ExtendedBlocksAccess) chunk).retroapi$getExtendedBlocks();
			access.retroapi$populateExtended(extended);
		} else if (packet instanceof C_36877109 bsp) {
			BlocksUpdatePacketAccess access = (BlocksUpdatePacketAccess) bsp;
			if (access.retroapi$getFullBlockIds() != null) return;

			C_14917579 chunk = player.f_94306729.m_27928573(bsp.f_79481286, bsp.f_86949888);
			access.retroapi$populateFullIds(chunk);
		}
	}
}
