package com.periut.retroapi.mixin.biome;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_74918097;

/**
 * Reaches the protected spawn lists of ANY biome (vanilla or modded), so
 * {@link com.periut.retroapi.biome.RetroBiomes} can edit them additively without
 * subclassing. RetroBiome reaches them by being a subclass; this reaches a vanilla
 * Biome instance from outside.
 */
@Mixin(C_28105876.class)
public interface BiomeSpawnAccessor {

	@Accessor("spawnableMonsters")
	List<C_74918097> retroapi$getMonsters();

	@Accessor("spawnablePassive")
	List<C_74918097> retroapi$getPassive();

	@Accessor("spawnableWaterCreatures")
	List<C_74918097> retroapi$getWaterCreatures();
}
