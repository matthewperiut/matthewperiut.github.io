package com.periut.retroapi.mixin.storage;

import com.periut.retroapi.storage.ChunkExtendedBlocks;
import com.periut.retroapi.storage.ExtendedBlocksAccess;
import com.periut.retroapi.storage.InventorySidecar;
import com.periut.retroapi.storage.RegionSidecar;
import com.periut.retroapi.storage.SidecarManager;
import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_72739095;
import net.minecraft.unmapped.C_74087615;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_72739095.class)
public class ChunkStorageMixin {

	@Inject(method = "loadChunkFromNbt", at = @At("RETURN"))
	private static void retroapi$onLoadChunk(C_64041439 world, C_74087615 nbt, CallbackInfoReturnable<C_14917579> cir) {
		C_14917579 chunk = cir.getReturnValue();
		if (chunk == null) return;

		int dimensionId = world.f_00524883.f_09977150;

		// Restore extended blocks from sidecar. loadChunkData owns the full restore contract:
		// block-match + vanilla-displacement checks (vanilla-placed blocks win; displaced modded
		// entries stay deferred in the sidecar), and writes the sidecar's authoritative meta into
		// the vanilla nibble only for the positions it actually restored.
		RegionSidecar sidecar = SidecarManager.getRegion(dimensionId, chunk.f_61945954, chunk.f_46577147);
		if (sidecar != null) {
			ChunkExtendedBlocks extended = ((ExtendedBlocksAccess) chunk).retroapi$getExtendedBlocks();
			sidecar.loadChunkData(chunk, extended);
		}

		// Restore modded block entities, inventory items, and item entities from sidecar
		InventorySidecar invSidecar = SidecarManager.getInventoryRegion(dimensionId, chunk.f_61945954, chunk.f_46577147);
		if (invSidecar != null) {
			invSidecar.restoreChunkContent(chunk, world);
		}
	}

	@Inject(method = "saveChunkToNbt", at = @At("HEAD"))
	private static void retroapi$sanitizeBeforeSave(C_14917579 chunk, C_64041439 world, C_74087615 nbt, CallbackInfo ci) {
		// Set extended block positions to air in the vanilla byte array
		ChunkExtendedBlocks extended = ((ExtendedBlocksAccess) chunk).retroapi$getExtendedBlocks();
		for (int index : extended.getBlockIds().keySet()) {
			int blockId = extended.getBlockId(index);
			if (blockId >= 256 && index >= 0 && index < chunk.f_42859137.length) {
				chunk.f_42859137[index] = 0;
			}
		}
	}

	@Inject(method = "saveChunkToNbt", at = @At("RETURN"))
	private static void retroapi$onSaveChunk(C_14917579 chunk, C_64041439 world, C_74087615 nbt, CallbackInfo ci) {
		ChunkExtendedBlocks extended = ((ExtendedBlocksAccess) chunk).retroapi$getExtendedBlocks();
		int dimensionId = world.f_00524883.f_09977150;

		// Save extended blocks to block sidecar
		RegionSidecar sidecar = SidecarManager.getRegion(dimensionId, chunk.f_61945954, chunk.f_46577147);
		if (sidecar != null) {
			sidecar.saveChunkData(chunk.f_61945954, chunk.f_46577147, extended);
		}

		// Filter the NBT to remove all modded content and save to inventory sidecar
		InventorySidecar invSidecar = SidecarManager.getInventoryRegion(dimensionId, chunk.f_61945954, chunk.f_46577147);
		if (invSidecar != null) {
			invSidecar.filterAndSave(chunk.f_61945954, chunk.f_46577147, nbt, extended);
		}
	}
}
