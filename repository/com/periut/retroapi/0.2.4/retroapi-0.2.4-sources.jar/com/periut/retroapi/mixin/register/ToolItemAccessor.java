package com.periut.retroapi.mixin.register;

import net.minecraft.unmapped.C_53672520;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes a tool's material mining speed (wood 2, stone 4, iron 6, diamond 8, gold 12)
 * so the {@code mineable/<tool>} tag hook can apply tool speed to tagged blocks for ANY
 * {@link C_53672520} subclass, not just the vanilla pickaxe/axe/shovel classes.
 */
@Mixin(C_53672520.class)
public interface ToolItemAccessor {

	@Accessor("miningSpeed")
	float retroapi$getMiningSpeed();

	@Accessor("toolMaterial")
	net.minecraft.unmapped.C_74597326 retroapi$getToolMaterial();
}
