package com.periut.retroapi.mixin.client;

import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_97027864;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Exposes the World behind the render-time {@link C_97027864} BlockView wrapper, so
 * state/xmeta reads and dimension checks keep working during chunk rendering (which never
 * hands renderers the World itself). See {@code RetroWorlds.unwrap}.
 */
@Mixin(C_97027864.class)
public interface WorldRegionAccessor {

	@Accessor("world")
	C_64041439 retroapi$getWorld();
}
