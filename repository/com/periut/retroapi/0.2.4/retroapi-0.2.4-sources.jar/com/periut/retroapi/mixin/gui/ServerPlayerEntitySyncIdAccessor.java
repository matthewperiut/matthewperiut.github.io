package com.periut.retroapi.mixin.gui;

import net.minecraft.unmapped.C_49202226;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_49202226.class)
public interface ServerPlayerEntitySyncIdAccessor {

	@Accessor("screenHandlerSyncId")
	int retroapi$getScreenHandlerSyncId();

	@Invoker("incrementScreenHandlerSyncId")
	void retroapi$incrementScreenHandlerSyncId();
}
