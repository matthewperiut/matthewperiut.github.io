package com.periut.retroapi.registry;

import net.minecraft.unmapped.C_71827890;
import net.minecraft.unmapped.C_81592558;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;

public class BlockRegistration {
	private final NamespacedIdentifier id;
	private final C_81592558 block;
	private final C_71827890 blockItem;
	private final int placeholderId;

	public BlockRegistration(NamespacedIdentifier id, C_81592558 block, C_71827890 blockItem) {
		this.id = id;
		this.block = block;
		this.blockItem = blockItem;
		this.placeholderId = block.f_84602679;
	}

	public NamespacedIdentifier getId() {
		return id;
	}

	public C_81592558 getBlock() {
		return block;
	}

	public C_71827890 getBlockItem() {
		return blockItem;
	}

	public int getPlaceholderId() {
		return placeholderId;
	}
}
