package com.periut.retroapi.network;

import net.minecraft.unmapped.C_14917579;

public interface BlocksUpdatePacketAccess {
	short[] retroapi$getFullBlockIds();
	void retroapi$populateFullIds(C_14917579 chunk);
}
