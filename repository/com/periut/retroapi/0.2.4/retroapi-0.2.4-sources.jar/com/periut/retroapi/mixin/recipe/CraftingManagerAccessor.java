package com.periut.retroapi.mixin.recipe;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.unmapped.C_30892219;
import net.minecraft.unmapped.C_70737137;

@Mixin(C_70737137.class)
public interface CraftingManagerAccessor {
	@Accessor("recipes")
	List<C_30892219> retroapi$getRecipes();
}

