package com.periut.retroapi.mixin.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.periut.retroapi.register.item.RetroArmorTexture;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_34859172;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * Binds a {@link RetroArmorTexture} item's own worn texture in place of beta's fixed
 * {@code /armor/<name>_<layer>.png}, so modded armor sets show their own art on the player.
 * Wraps the one {@code bindTexture(String)} call inside the armor-pass binder; vanilla armor
 * and the rest of the render path are untouched. Uses {@code @WrapOperation} (not
 * {@code @Redirect}) so it composes with any other mod wrapping the same call instead of
 * claiming it exclusively.
 */
@Mixin(C_34859172.class)
@Environment(EnvType.CLIENT)
public class PlayerArmorTextureMixin {

	@WrapOperation(
		method = "bindTexture(Lnet/minecraft/entity/player/PlayerEntity;IF)Z",
		at = @At(value = "INVOKE",
			target = "Lnet/minecraft/client/render/entity/PlayerEntityRenderer;bindTexture(Ljava/lang/String;)V"))
	private void retroapi$customArmorTexture(C_34859172 self, String vanillaPath,
			Operation<Void> original, C_40996800 player, int pass, float delta) {
		C_88708284 stack = player.f_29439708.m_34290324(3 - pass);
		if (stack != null) {
			C_98888256 item = stack.m_23235460();
			if (item instanceof RetroArmorTexture custom) {
				original.call(self, custom.getArmorTexture(pass == 2 ? 2 : 1));
				return;
			}
		}
		original.call(self, vanillaPath);
	}
}
