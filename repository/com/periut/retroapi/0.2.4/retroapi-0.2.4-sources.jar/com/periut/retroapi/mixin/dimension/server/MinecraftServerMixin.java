package com.periut.retroapi.mixin.dimension.server;

import com.periut.retroapi.dimension.DimensionRegistration;
import com.periut.retroapi.dimension.RetroDimensionRegistry;
import net.minecraft.server.MinecraftServer;
import net.minecraft.unmapped.C_08489468;
import net.minecraft.unmapped.C_23459903;
import net.minecraft.unmapped.C_29639016;
import net.minecraft.unmapped.C_42042215;
import net.minecraft.unmapped.C_51404117;
import net.minecraft.unmapped.C_70668269;
import net.minecraft.unmapped.C_93497269;
import net.minecraft.unmapped.C_93816630;
import net.minecraft.unmapped.C_98861173;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.HashMap;
import java.util.Map;

/**
 * Server-side modded-dimension worlds + entity trackers. Vanilla hardcodes length-2 arrays
 * ({@code worlds[0]}=overworld, {@code worlds[1]}=nether) and resolves {@code getWorld}/
 * {@code getEntityTracker} with a ternary on {@code id == -1}. Rather than resize the arrays and
 * binary-search them (StationAPI's fragile approach), we keep the vanilla arrays untouched and store
 * modded dimensions in side maps keyed by serial id. Each modded world is a {@link C_51404117}
 * delegating to the overworld - exactly like the nether - so it shares the overworld's storage handle
 * but gets its own {@code DIM<n>/} folder via {@link com.periut.retroapi.mixin.dimension.RegionWorldStorageMixin}.
 * Disabled under StationAPI (it owns server dimension arrays).
 */
@Mixin(MinecraftServer.class)
public abstract class MinecraftServerMixin {
	@Unique private static final Logger RETRO_LOGGER = LogManager.getLogger("RetroAPI/Dimensions");
	/** Vanilla's spawn-region preload reach in blocks (MinecraftServer.loadWorld uses 196). */
	@Unique private static final int RETRO_PRELOAD_REACH = 196;

	@Shadow public C_70668269[] worlds;
	@Shadow private boolean running;
	@Shadow public C_29639016 playerManager;
	@Shadow int ticks;

	@Unique private final Map<Integer, C_70668269> retroapi$moddedWorlds = new HashMap<>();
	@Unique private final Map<Integer, C_42042215> retroapi$moddedTrackers = new HashMap<>();

	@Inject(method = "loadWorld", at = @At("RETURN"))
	private void retroapi$createModdedWorlds(C_98861173 storageSource, String worldDir, long seed, CallbackInfo ci) {
		if (this.worlds == null || this.worlds.length == 0 || this.worlds[0] == null) return;
		MinecraftServer self = (MinecraftServer) (Object) this;
		C_08489468 storage = this.worlds[0].m_05751350();
		for (DimensionRegistration reg : RetroDimensionRegistry.getAll()) {
			int serialId = reg.getSerialId();
			// ReadOnlyServerWorld(server, sharedStorage, worldDir, dimId, seed, overworldDelegate) - the
			// exact shape vanilla uses for the nether. Its ctor calls Dimension.fromId(serialId) (resolved
			// by DimensionMixin) and storage.getChunkStorage(thatDimension) (routed to DIM<n>/).
			C_70668269 world = new C_51404117(self, storage, worldDir, serialId, seed, this.worlds[0]);
			world.m_08775210(new C_93497269(self, world));
			// Mirror the REST of vanilla's per-world setup too - loadWorld only applies these to
			// the length-2 array, so without them a modded dimension runs at difficulty 0 forever:
			// hostile AI gated on difficulty (e.g. ranged attacks checking `difficulty != 0`)
			// silently never fires, and natural monster spawning stays off.
			world.f_91285239 = self.f_42116803.m_37087607("spawn-monsters", true) ? 1 : 0;
			world.m_56022633(self.f_42116803.m_37087607("spawn-monsters", true), self.f_82963087);
			retroapi$moddedWorlds.put(serialId, world);
			retroapi$moddedTrackers.put(serialId, new C_42042215(self, serialId));

			// Preload the spawn region EXACTLY like vanilla's loadWorld does for the overworld/nether -
			// which is precisely what StationAPI inherits for free by resizing the worlds array so the
			// vanilla spawn-prep loop iterates the modded worlds too. Mirrors that loop byte-for-byte:
			// getSpawnPos-centered, reach 196 in steps of 16, with the lighting-update drain, abortable
			// via `running`. So a modded dimension generates + persists its start region at startup,
			// visible in the log and as DIM<serialId>/region/*.mcr files.
			RETRO_LOGGER.info("Preparing start region for modded dimension {} (serial id {})", reg.getId(), serialId);
			C_93816630 spawn = world.m_84569052();
			long lastLog = System.currentTimeMillis();
			for (int k = -RETRO_PRELOAD_REACH; k <= RETRO_PRELOAD_REACH && this.running; k += 16) {
				for (int l = -RETRO_PRELOAD_REACH; l <= RETRO_PRELOAD_REACH && this.running; l += 16) {
					long now = System.currentTimeMillis();
					if (now < lastLog) lastLog = now;
					if (now > lastLog + 1000L) {
						int total = (RETRO_PRELOAD_REACH * 2 + 1) * (RETRO_PRELOAD_REACH * 2 + 1);
						int done = (k + RETRO_PRELOAD_REACH) * (RETRO_PRELOAD_REACH * 2 + 1) + l + 1;
						RETRO_LOGGER.info("Preparing spawn area ({}): {}%", reg.getId(), done * 100 / total);
						lastLog = now;
					}
					world.f_55499904.m_81172804(spawn.f_39781383 + k >> 4, spawn.f_38078371 + l >> 4);
					while (world.m_42759979() && this.running) {
					}
				}
			}
		}
	}

	/**
	 * Drive the modded worlds + entity trackers every server tick. Vanilla's {@code tick()} only
	 * iterates the fixed length-2 {@code worlds}/{@code entityTrackers} arrays (overworld + nether),
	 * so the side-mapped modded dimensions (created above) were never ticked: entities in them - the
	 * player included - never ran {@code tickEntities()}, so {@code playerTick} never fired (no
	 * inventory/container resync, frozen item entities, no portal cooldown), and the modded
	 * {@link C_42042215} never sent spawn/move/destroy packets (disconnected players left as
	 * un-despawned clones, dropped items/mobs invisible). Mirror vanilla's per-world tick body
	 * verbatim for each modded world, then tick the modded trackers - the exact work the vanilla
	 * loops do for the two hardcoded dimensions. Disabled under StationAPI.
	 */
	@Inject(method = "tick", at = @At("TAIL"))
	private void retroapi$tickModdedWorlds(CallbackInfo ci) {
		for (C_70668269 world : retroapi$moddedWorlds.values()) {
			if (this.ticks % 20 == 0) {
				this.playerManager.m_53832545(new C_23459903(world.m_13949261()), world.f_00524883.f_09977150);
			}
			world.m_77531466();
			while (world.m_42759979()) {
			}
			world.m_57128635();
		}
		for (C_42042215 tracker : retroapi$moddedTrackers.values()) {
			tracker.m_52330167();
		}
	}

	/**
	 * Save the side-mapped modded worlds whenever vanilla saves the overworld/nether. Vanilla's
	 * {@code saveWorlds()} only iterates the fixed length-2 {@code worlds[]} array, so the modded
	 * dimensions (created + ticked above) were never persisted: their chunk changes - placed blocks,
	 * block entities, entities, and the RetroAPI {@code retroapi/DIM<n>/} sidecars they drive - were
	 * silently dropped on autosave and shutdown. Mirror the tick driver: drive their save manually too.
	 * (Same lesson as the tick fix: side-mapped state must be driven by hand - vanilla's loops only see
	 * the arrays.) Disabled under StationAPI.
	 */
	@Inject(method = "saveWorlds", at = @At("TAIL"))
	private void retroapi$saveModdedWorlds(CallbackInfo ci) {
		for (C_70668269 world : retroapi$moddedWorlds.values()) {
			// Mirror vanilla's per-world save exactly: saveWithLoadingDisplay persists the CHUNKS (and
			// thus drives the RetroAPI chunk-save sidecar hook), forceSave flushes level/persistent state.
			// forceSave alone (the obvious-but-wrong call) only flushes storage and never saves chunks.
			world.m_70994780(true, null);
			world.m_83336016();
		}
	}

	@Inject(method = "getWorld", at = @At("HEAD"), cancellable = true)
	private void retroapi$getModdedWorld(int dimensionId, CallbackInfoReturnable<C_70668269> cir) {
		C_70668269 world = retroapi$moddedWorlds.get(dimensionId);
		if (world != null) cir.setReturnValue(world);
	}

	@Inject(method = "getEntityTracker", at = @At("HEAD"), cancellable = true)
	private void retroapi$getModdedTracker(int dimensionId, CallbackInfoReturnable<C_42042215> cir) {
		C_42042215 tracker = retroapi$moddedTrackers.get(dimensionId);
		if (tracker != null) cir.setReturnValue(tracker);
	}
}
