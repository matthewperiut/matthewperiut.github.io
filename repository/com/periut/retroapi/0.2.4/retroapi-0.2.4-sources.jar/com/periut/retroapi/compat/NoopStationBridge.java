package com.periut.retroapi.compat;

import com.periut.retroapi.dimension.TeleportationManager;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_90931970;
import net.minecraft.unmapped.C_98888256;

/**
 * Default {@link StationBridge} used when the {@code retroapi-stationapi} mod is absent. Every method is a
 * no-op; in practice none are ever called, because core gates every StationAPI delegation on
 * {@code FabricLoader.isModLoaded("stationapi")} and the bridge resolves to the real implementation whenever
 * that gate passes. This exists only so {@link StationBridges#get()} never returns {@code null}.
 */
final class NoopStationBridge implements StationBridge {
	@Override public void registerBlock(String namespace, String path, C_81592558 block) {}
	@Override public void registerItem(String namespace, String path, C_98888256 item) {}
	@Override public void registerLangPath() {}
	@Override public void bindAchievement(C_90931970 achievement, String namespace, String path) {}
	@Override public int addTerrainTexture(String namespace, String path) { return -1; }
	@Override public int addItemTexture(String namespace, String path) { return -1; }
	@Override public void setItemTexture(C_98888256 item, String namespace, String path) {}
	@Override public void addShapedRecipe(C_88708284 output, Object... recipe) {}
	@Override public void addShapelessRecipe(C_88708284 output, Object... ingredients) {}
	@Override public void addSmeltingRecipe(int inputId, C_88708284 output) {}
	@Override public void attachPortal(C_40996800 player, TeleportationManager retroManager) {}
}
