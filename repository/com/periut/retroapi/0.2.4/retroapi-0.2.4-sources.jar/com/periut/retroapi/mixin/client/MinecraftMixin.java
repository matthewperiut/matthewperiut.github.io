package com.periut.retroapi.mixin.client;

import com.periut.retroapi.client.screen.StationAPIWorldScreen;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_43588014;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_87007645;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.io.File;
import java.io.FileInputStream;
import java.util.List;

@Mixin(C_43588014.class)
public abstract class MinecraftMixin extends C_85740840 {
	private static final Logger LOGGER = LogManager.getLogger("RetroAPI");

	@Shadow
	private List<C_87007645> saves;

	@Shadow
	protected abstract String getSaveFileNames(int index);

	@Inject(method = "getSaves", at = @At("TAIL"))
	private void retroapi$markStationAPIWorlds(CallbackInfo ci) {
		if (FabricLoader.getInstance().isModLoaded("stationapi")) return;

		File gameDir = ((MinecraftAccessor) this.f_78495264).retroapi$getGameDir();
		File savesDir = new File(gameDir, "saves");

		for (int i = 0; i < this.saves.size(); i++) {
			C_87007645 info = this.saves.get(i);
			File levelDat = new File(new File(savesDir, info.m_07607595()), "level.dat");

			if (levelDat.exists()) {
				try (FileInputStream fis = new FileInputStream(levelDat)) {
					C_74087615 root = C_08565163.m_38706312(fis);
					C_74087615 data = root.m_81819352("Data");
					if (data.m_97612750("stationapi:data_versions") && data.m_81819352("stationapi:data_versions").m_97612750("stationapi")) {
						String name = info.m_59791697();
						if (name == null || name.trim().isEmpty()) {
							name = "World " + (i + 1);
						}
					this.saves.set(i, new C_87007645(
							info.m_07607595(),
							"\u00a7c[StationAPI] \u00a7r" + name,
							info.m_72519233(),
							info.m_38445905(),
							true
						));
					}
				} catch (Exception e) {
					LOGGER.error("Failed to read level.dat for StationAPI detection", e);
				}
			}
		}
	}

	@Inject(method = "selectWorld", at = @At("HEAD"), cancellable = true)
	private void retroapi$checkStationAPIWorld(int worldId, CallbackInfo ci) {
		if (FabricLoader.getInstance().isModLoaded("stationapi")) return;

		String worldFolder = this.getSaveFileNames(worldId);
		if (worldFolder == null) worldFolder = "World" + worldId;

		File gameDir = ((MinecraftAccessor) this.f_78495264).retroapi$getGameDir();
		File worldDir = new File(new File(gameDir, "saves"), worldFolder);
		File levelDat = new File(worldDir, "level.dat");

		if (levelDat.exists()) {
			try (FileInputStream fis = new FileInputStream(levelDat)) {
				C_74087615 root = C_08565163.m_38706312(fis);
				C_74087615 data = root.m_81819352("Data");
				if (data.m_97612750("stationapi:data_versions") && data.m_81819352("stationapi:data_versions").m_97612750("stationapi")) {
					LOGGER.warn("StationAPI world detected without StationAPI: {}", worldDir);
					this.f_78495264.m_52715402(new StationAPIWorldScreen());
					ci.cancel();
				}
			} catch (Exception e) {
				LOGGER.error("Failed to read level.dat for StationAPI detection", e);
			}
		}
	}
}

