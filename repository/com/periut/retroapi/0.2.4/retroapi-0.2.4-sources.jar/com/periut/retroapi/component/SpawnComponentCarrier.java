package com.periut.retroapi.component;

import net.minecraft.unmapped.C_74087615;

/**
 * Duck interface on the dropped-item spawn packet: lets the client network handler read the
 * component blob the packet carried, after it has rebuilt the {@link net.minecraft.unmapped.C_88708284}.
 */
public interface SpawnComponentCarrier {

	C_74087615 retroapi$spawnComponents();
}
