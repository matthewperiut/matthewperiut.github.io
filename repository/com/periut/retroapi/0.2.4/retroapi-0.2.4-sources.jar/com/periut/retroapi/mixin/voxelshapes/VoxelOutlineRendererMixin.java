package com.periut.retroapi.mixin.voxelshapes;

import com.periut.retroapi.voxelshapes.Line;
import com.periut.retroapi.voxelshapes.HasVoxelShape;
import com.periut.retroapi.voxelshapes.VoxelShape;
import com.periut.retroapi.voxelshapes.VoxelVec3d;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.unmapped.C_24384787;
import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_96603444;

@Mixin(C_24384787.class)
public abstract class VoxelOutlineRendererMixin {
    @Shadow
    private C_64041439 world;

    @Inject(method = "renderBlockOutline", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;getBlockId(III)I"), cancellable = true)
    private void retroapi$drawBlockVoxelShapesOutline(C_40996800 playerEntity, C_24654288 hitResult, int i, C_88708284 itemStack, float f, CallbackInfo ci) {
        int id = world.m_33234383(hitResult.f_79497105, hitResult.f_09533029, hitResult.f_04223298);
        C_81592558 block = C_81592558.f_44428008[id];
        if (block instanceof HasVoxelShape hasVoxelShape) {
            if (id > 0) {
                block.m_98737217(this.world, hitResult.f_79497105, hitResult.f_09533029, hitResult.f_04223298);
                double interpolatedX = playerEntity.f_09368719 + (playerEntity.f_78826675 - playerEntity.f_09368719) * (double) f;
                double interpolatedY = playerEntity.f_93723721 + (playerEntity.f_31030949 - playerEntity.f_93723721) * (double) f;
                double interpolatedZ = playerEntity.f_84066837 + (playerEntity.f_97691941 - playerEntity.f_84066837) * (double) f;

                VoxelShape voxelShape = hasVoxelShape.getVoxelShape(world, hitResult.f_79497105, hitResult.f_09533029, hitResult.f_04223298);
                if (voxelShape != null) {
                    List<Line> lines = voxelShape.getLines();
                    VoxelVec3d offset = voxelShape.getVoxelOffset();

                    C_96603444 tessellator = C_96603444.f_99414865;
                    tessellator.m_89066829(1);
                    for (Line line : lines) {
                        tessellator.m_51994127(
                                -interpolatedX + line.start().x() + offset.x(),
                                -interpolatedY + line.start().y() + offset.y(),
                                -interpolatedZ + line.start().z() + offset.z()
                        );
                        tessellator.m_51994127(
                                -interpolatedX + line.end().x() + offset.x(),
                                -interpolatedY + line.end().y() + offset.y(),
                                -interpolatedZ + line.end().z() + offset.z()
                        );
                    }
                    tessellator.m_70070273();
                }
            }

            GL11.glDepthMask(true);
            GL11.glEnable(3553);
            GL11.glDisable(3042);

            ci.cancel();
        }
    }
}
