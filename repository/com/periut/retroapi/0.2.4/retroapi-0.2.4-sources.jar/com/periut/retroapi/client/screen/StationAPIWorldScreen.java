package com.periut.retroapi.client.screen;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_95462098;

public class StationAPIWorldScreen extends C_85740840 {
	private static final String MESSAGE =
		"This is a StationAPI World. It cannot be loaded without StationAPI, " +
		"but it can be turned back into a Vanilla world by loading the game with StationAPI, " +
		"clicking edit, and pressing convert to McRegion. " +
		"RetroAPI mods only will transfer to Vanilla world format, and " +
		"StationAPI-dependent items, blocks, etc will disappear. " +
		"RetroAPI mods will work in StationAPI seamlessly alongside other StationAPI mods.";

	private List<String> messageLines;

	@Override
	public void m_41805697() {
		this.f_78519977.clear();
		this.messageLines = wrapText(MESSAGE, this.f_05230747 - 60);

		int textEndY = this.f_07021018 / 4 + 10 + this.messageLines.size() * 12;
		int buttonY = Math.min(textEndY + 20, this.f_07021018 - 30);

		this.f_78519977.add(new C_85125467(
			0, this.f_05230747 / 2 - 100, buttonY, "Back to Title Screen"
		));
	}

	private List<String> wrapText(String text, int maxWidth) {
		List<String> lines = new ArrayList<>();
		String[] words = text.split(" ");
		StringBuilder currentLine = new StringBuilder();

		for (String word : words) {
			String test = currentLine.length() == 0 ? word : currentLine + " " + word;
			if (this.f_11884601.m_09235706(test) > maxWidth && currentLine.length() > 0) {
				lines.add(currentLine.toString());
				currentLine = new StringBuilder(word);
			} else {
				if (currentLine.length() > 0) currentLine.append(" ");
				currentLine.append(word);
			}
		}
		if (currentLine.length() > 0) {
			lines.add(currentLine.toString());
		}
		return lines;
	}

	@Override
	protected void m_30778170(C_85125467 button) {
		if (button.f_92999450 == 0) {
			this.f_78495264.f_26407825 = null;
			this.f_78495264.m_52715402(new C_95462098());
		}
	}

	@Override
	public void m_93956703(int mouseX, int mouseY, float partialTick) {
		this.m_34695786();

		this.m_50067982(this.f_11884601, "StationAPI World Detected",
			this.f_05230747 / 2, this.f_07021018 / 4 - 10, 0xFF5555);

		int y = this.f_07021018 / 4 + 10;
		for (String line : this.messageLines) {
			this.m_50067982(this.f_11884601, line,
				this.f_05230747 / 2, y, 0xAAAAAA);
			y += 12;
		}

		super.m_93956703(mouseX, mouseY, partialTick);
	}

	@Override
	public boolean m_47190451() {
		return true;
	}
}
