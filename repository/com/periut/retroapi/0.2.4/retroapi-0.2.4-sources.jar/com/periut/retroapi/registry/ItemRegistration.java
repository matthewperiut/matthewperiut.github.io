package com.periut.retroapi.registry;

import net.minecraft.unmapped.C_98888256;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;

public class ItemRegistration {
	private final NamespacedIdentifier id;
	private final C_98888256 item;

	public ItemRegistration(NamespacedIdentifier id, C_98888256 item) {
		this.id = id;
		this.item = item;
	}

	public NamespacedIdentifier getId() {
		return id;
	}

	public C_98888256 getItem() {
		return item;
	}
}
