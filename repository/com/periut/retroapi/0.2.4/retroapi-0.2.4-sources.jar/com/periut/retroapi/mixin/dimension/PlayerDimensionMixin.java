package com.periut.retroapi.mixin.dimension;

import com.periut.retroapi.dimension.RetroDimensionRegistry;
import com.periut.retroapi.storage.PlayerDimensionSidecar;
import net.minecraft.unmapped.C_02949887;
import net.minecraft.unmapped.C_06229858;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_79370641;
import net.minecraft.unmapped.C_93816630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Safe-reset of the player's saved dimension id. Vanilla {@code PlayerEntity.writeNbt} writes
 * {@code Dimension = dimensionId}; for a modded dimension that is a poison value that crashes vanilla
 * on load.
 *
 * <p><b>Save</b> ({@code writeNbt} TAIL): capture the EXACT {@code Pos}/{@code Rotation} values vanilla
 * just wrote into the compound, record them (plus the real dimension id) in the
 * {@link PlayerDimensionSidecar}, then clamp the compound to a vanilla-safe state (Dimension 0,
 * position = overworld spawn).
 *
 * <p><b>Load</b> ({@code readNbt} HEAD): inject the recorded values back INTO the compound before
 * vanilla parses it, so the normal loading path reads them as if they had always been in the file.
 * No post-load {@code setPositionAndAngles} - position, bounding box, prev-coords and rotation all
 * come out of vanilla's own code, byte-exact with what was saved.
 *
 * <p>Disabled under StationAPI (its world dir is never set, so the sidecar no-ops anyway, but
 * disabling keeps the path clean).
 */
@Mixin(C_40996800.class)
public class PlayerDimensionMixin {
	@Inject(method = "writeNbt", at = @At("TAIL"))
	private void retroapi$clampDimension(C_74087615 nbt, CallbackInfo ci) {
		C_40996800 self = (C_40996800) (Object) this;
		int dim = self.f_15409937;
		if (!RetroDimensionRegistry.isVanillaId(dim) && RetroDimensionRegistry.getBySerialId(dim) != null) {
			// Record the exact doubles/floats vanilla wrote - not the live entity fields - so the
			// round trip through the sidecar is bit-identical to a vanilla save/load.
			double px = self.f_78826675, py = self.f_31030949, pz = self.f_97691941;
			C_79370641 posList = nbt.m_95654166("Pos");
			if (posList != null && posList.m_89439680() >= 3) {
				px = ((C_06229858) posList.m_59132367(0)).f_79544156;
				py = ((C_06229858) posList.m_59132367(1)).f_79544156;
				pz = ((C_06229858) posList.m_59132367(2)).f_79544156;
			}
			float yaw = self.f_80130373, pitch = self.f_03549461;
			C_79370641 rotList = nbt.m_95654166("Rotation");
			if (rotList != null && rotList.m_89439680() >= 2) {
				yaw = ((C_02949887) rotList.m_59132367(0)).f_97688492;
				pitch = ((C_02949887) rotList.m_59132367(1)).f_97688492;
			}
			PlayerDimensionSidecar.recordPlayer(self.f_59008391, dim, px, py, pz, yaw, pitch);

			nbt.m_20318863("Dimension", 0);
			// Clamp the vanilla position to the (shared) overworld spawn so a vanilla open puts the
			// player on solid ground at spawn, not in the void at the modded-dimension coordinates.
			if (self.f_94306729 != null) {
				C_93816630 spawn = self.f_94306729.m_84569052();
				C_79370641 pos = new C_79370641();
				pos.m_43125067(new C_06229858(spawn.f_39781383 + 0.5));
				pos.m_43125067(new C_06229858(spawn.f_62514677 + 1.0));
				pos.m_43125067(new C_06229858(spawn.f_38078371 + 0.5));
				nbt.m_21770494("Pos", pos);
			}
		} else {
			PlayerDimensionSidecar.removePlayer(self.f_59008391);
		}
	}

	// NOTE: the LOAD-side injection lives in EntityReadDimensionMixin, NOT here. Vanilla's NBT
	// entry point is Entity.read(NbtCompound): it parses Pos/Rotation FIRST and only then calls
	// the per-class readNbt(nbt) hook - so an injection at PlayerEntity.readNbt HEAD is early
	// enough for "Dimension" (read inside readNbt) but TOO LATE for "Pos"/"Rotation" (already
	// parsed). That asymmetry shipped once: dimension restored, position reset to the clamp.
}
