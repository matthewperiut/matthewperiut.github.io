package com.periut.retroapi.register.recipe;

import com.periut.retroapi.compat.StationBridges;
import com.periut.retroapi.mixin.recipe.CraftingManagerAccessor;
import com.periut.retroapi.mixin.recipe.FurnaceFuelAccessor;
import com.periut.retroapi.mixin.recipe.SmeltingManagerAccessor;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.unmapped.C_13858042;
import net.minecraft.unmapped.C_30892219;
import net.minecraft.unmapped.C_53504297;
import net.minecraft.unmapped.C_55756098;
import net.minecraft.unmapped.C_70737137;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_84171032;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Public crafting/smelting/fuel registration API.
 *
 * <h2>Wildcard (any-metadata) policy</h2>
 * A bare {@link C_81592558} or {@link C_98888256} ingredient is treated as a <b>WILDCARD</b>
 * (damage {@code -1}): it matches an input stack of any metadata/damage. To match a
 * <b>specific</b> metadata, pass a full {@link C_88708284} (e.g.
 * {@code new ItemStack(Block.WOOL, 1, 14)}), which matches exactly. This deliberately
 * standardizes on {@code -1} for both shaped and shapeless (StationAPI inconsistently
 * uses {@code 0} for shapeless bare ingredients); it matches modder intent (most bare
 * ingredients want "any metadata") and is safe because metadata-specific recipes always
 * pass full {@code ItemStack}s.
 */
public final class RetroRecipes {

	private static final Map<Integer, Integer> FUEL_MAP = new HashMap<>();

	private RetroRecipes() {}

	private static boolean hasStationAPI() {
		return FabricLoader.getInstance().isModLoaded("stationapi");
	}

	/**
	 * Resolves an ingredient object to an {@link C_88708284}.
	 * <ul>
	 *   <li>{@link C_88708284} -> used as-is (exact metadata, a copy so callers' stacks aren't mutated)</li>
	 *   <li>bare {@link C_98888256} -> wildcard damage {@code -1} (matches any metadata)</li>
	 *   <li>bare {@link C_81592558} -> wildcard damage {@code -1} (matches any metadata)</li>
	 * </ul>
	 */
	private static C_88708284 resolveIngredient(Object o) {
		if (o instanceof C_88708284 stack) return stack.m_73216943();      // exact metadata
		if (o instanceof C_98888256 item)       return new C_88708284(item, 1, -1);  // WILDCARD damage
		if (o instanceof C_81592558 block)     return new C_88708284(block, 1, -1); // WILDCARD damage
		throw new IllegalArgumentException("Invalid ingredient type: " + (o == null ? "null" : o.getClass()));
	}

	/**
	 * Adds a shaped crafting recipe.
	 *
	 * @param output  the result item stack
	 * @param recipe  alternating pattern strings and char-to-ingredient mappings.
	 *                Ingredients can be {@link C_88708284} (exact metadata), {@link C_98888256}, or {@link C_81592558} (wildcard).
	 */
	public static void addShaped(C_88708284 output, Object... recipe) {
		if (hasStationAPI()) {
			// Delegate to StationAPI's CraftingRegistry so RetroAPI and StationAPI never
			// double-register or use conflicting recipe classes.
			StationBridges.get().addShapedRecipe(output, recipe);
			return;
		}

		// Parse pattern strings
		String pattern = "";
		int idx = 0;
		int width = 0;
		int height = 0;

		while (idx < recipe.length && recipe[idx] instanceof String row) {
			pattern += row;
			width = row.length();
			height++;
			idx++;
		}

		// Parse character-to-ingredient mappings
		Map<Character, C_88708284> charMap = new HashMap<>();
		while (idx < recipe.length) {
			char c = (Character) recipe[idx];
			idx++;
			charMap.put(c, resolveIngredient(recipe[idx]));
			idx++;
		}

		// Build ItemStack ingredient grid (null = empty cell)
		C_88708284[] ingredients = new C_88708284[width * height];
		for (int i = 0; i < pattern.length(); i++) {
			char c = pattern.charAt(i);
			ingredients[i] = (c == ' ') ? null : charMap.get(c);
		}

		getCraftingRecipes().add(new RetroShapedRecipe(width, height, ingredients, output));
	}

	/**
	 * Adds a shapeless crafting recipe.
	 *
	 * @param output      the result item stack
	 * @param ingredients the ingredients ({@link C_88708284} exact, or {@link C_98888256}/{@link C_81592558} wildcard)
	 */
	public static void addShapeless(C_88708284 output, Object... ingredients) {
		if (hasStationAPI()) {
			StationBridges.get().addShapelessRecipe(output, ingredients);
			return;
		}

		C_88708284[] stacks = new C_88708284[ingredients.length];
		for (int i = 0; i < ingredients.length; i++) {
			stacks[i] = resolveIngredient(ingredients[i]);
		}

		getCraftingRecipes().add(new RetroShapelessRecipe(output, stacks));
	}

	/**
	 * Re-sorts the crafting recipe list so shaped recipes take precedence over shapeless
	 * recipes (and larger recipes over smaller), treating RetroAPI's own recipe classes
	 * like their vanilla counterparts.
	 *
	 * <p>Vanilla sorts its recipe list at {@code CraftingRecipeManager.<init>} via an inner
	 * comparator that does {@code instanceof ShapedRecipe}/{@code ShapelessRecipe} checks.
	 * Because {@link RetroShapedRecipe}/{@link RetroShapelessRecipe} are neither, freshly
	 * appended RetroAPI recipes would be mis-ordered. Rather than mixin the brittle
	 * mapping-hash synthetic comparator class (and depend on mixinextras), RetroAPI
	 * re-sorts the list here, after registration, with a RetroAPI-aware comparator that
	 * reproduces vanilla's ordering.</p>
	 */
	public static void sortCraftingRecipes() {
		if (hasStationAPI()) return; // StationAPI owns sorting when present
		List<C_30892219> recipes = getCraftingRecipes();
		recipes.sort(RETRO_RECIPE_COMPARATOR);
	}

	/**
	 * Reproduces vanilla {@code CraftingRecipeManager}'s inner comparator: shaped-like
	 * recipes sort before shapeless-like recipes; otherwise larger size sorts first.
	 * Treats {@link RetroShapedRecipe} like {@link C_55756098} and
	 * {@link RetroShapelessRecipe} like {@link C_84171032}.
	 */
	private static final Comparator<C_30892219> RETRO_RECIPE_COMPARATOR = (a, b) -> {
		boolean aShapeless = isShapeless(a);
		boolean bShapeless = isShapeless(b);
		boolean aShaped = isShaped(a);
		boolean bShaped = isShaped(b);
		if (aShapeless && bShaped) return 1;
		if (bShapeless && aShaped) return -1;
		int sizeA = a.m_36691583();
		int sizeB = b.m_36691583();
		if (sizeB < sizeA) return -1;
		if (sizeB > sizeA) return 1;
		return 0;
	};

	private static boolean isShaped(C_30892219 r) {
		return r instanceof C_55756098 || r instanceof RetroShapedRecipe;
	}

	private static boolean isShapeless(C_30892219 r) {
		return r instanceof C_84171032 || r instanceof RetroShapelessRecipe;
	}

	/**
	 * Removes every crafting recipe whose output is item-equal (same id + metadata) to the
	 * given stack. Optional parity helper; no-op under StationAPI (StationAPI exposes no
	 * removal API beyond direct list access). Returns the number of recipes removed.
	 */
	public static int removeRecipe(C_88708284 output) {
		if (hasStationAPI()) return 0;
		List<C_30892219> recipes = getCraftingRecipes();
		int before = recipes.size();
		recipes.removeIf(r -> {
			C_88708284 result = r.m_66362834();
			return result != null && result.m_52048659(output);
		});
		return before - recipes.size();
	}

	@SuppressWarnings("unchecked")
	private static List<C_30892219> getCraftingRecipes() {
		// Vanilla CraftingRecipeManager.getRecipes() is public, but the accessor keeps the
		// generic type tight and avoids depending on the vanilla method's raw signature.
		C_70737137 manager = C_70737137.m_32081319();
		return ((CraftingManagerAccessor) manager).retroapi$getRecipes();
	}

	/**
	 * Adds a smelting recipe.
	 *
	 * @param inputId the raw block/item ID of the input
	 * @param output  the result item stack
	 */
	public static void addSmelting(int inputId, C_88708284 output) {
		if (hasStationAPI()) {
			StationBridges.get().addSmeltingRecipe(inputId, output);
			return;
		}
		C_13858042 manager = C_13858042.m_49255699();
		((SmeltingManagerAccessor) manager).retroapi$getRecipes().put(inputId, output);
	}

	/**
	 * Registers a fuel item with a burn time in ticks (200 ticks = 1 item smelted).
	 * Wired into the furnace via {@code FurnaceBlockEntityMixin} (non-StationAPI path).
	 *
	 * @param itemId   the item ID
	 * @param burnTime burn time in ticks
	 */
	public static void addFuel(int itemId, int burnTime) {
		FUEL_MAP.put(itemId, burnTime);
	}

	/**
	 * Gets the fuel burn time for an item, or 0 if not a registered fuel.
	 */
	public static int getFuelTime(int itemId) {
		return FUEL_MAP.getOrDefault(itemId, 0);
	}

	/**
	 * Returns true if the given item ID has a registered fuel time.
	 */
	public static boolean isFuel(int itemId) {
		return FUEL_MAP.containsKey(itemId);
	}

	/** Probe instance used only to consult the furnace's (possibly mixin-extended) fuel table. */
	private static C_53504297 fuelProbe;

	/**
	 * Gets the burn time in ticks for a stack from the FULL fuel table, vanilla's fuels plus
	 * anything injected into the furnace ({@link #addFuel} on the RetroAPI path, StationAPI's
	 * registrations when it is present). Returns 0 if the stack is not fuel.
	 *
	 * <p>Use this for custom machines that should "burn whatever a furnace burns"
	 * (e.g. a freezer/grinder with a fuel slot), instead of mixin-ing the furnace yourself.</p>
	 */
	public static int getTotalFuelTime(C_88708284 stack) {
		if (stack == null) {
			return 0;
		}
		if (fuelProbe == null) {
			fuelProbe = new C_53504297();
		}
		int vanilla = ((FurnaceFuelAccessor) fuelProbe).retroapi$getFuelTime(stack);
		// Belt-and-braces: under StationAPI our FurnaceBlockEntityMixin is disabled, so FUEL_MAP
		// entries aren't in the furnace's table, still honor them here.
		return Math.max(vanilla, getFuelTime(stack.m_23235460().f_57562535));
	}
}
