package com.periut.retroapi.mixin.register;

import net.ornithemc.osl.core.api.util.NamespacedIdentifier;
import com.periut.retroapi.register.block.RetroBlockAccess;
import com.periut.retroapi.register.block.RetroTexture;
import com.periut.retroapi.register.block.RetroTextures;
import com.periut.retroapi.register.rendertype.RenderType;
import com.periut.retroapi.compat.StationBridges;
import com.periut.retroapi.registry.BlockRegistration;
import com.periut.retroapi.registry.RetroRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.unmapped.C_01306377;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_71827890;
import net.minecraft.unmapped.C_81592558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_81592558.class)
public abstract class BlockMixin implements RetroBlockAccess {

	@Shadow public int id;
	@Shadow public int textureId;

	@Shadow protected abstract C_81592558 setSoundGroup(C_01306377 sounds);
	@Shadow protected abstract C_81592558 setHardness(float strength);
	@Shadow protected abstract C_81592558 setResistance(float resistance);
	@Shadow protected abstract C_81592558 setLuminance(float light);
	@Shadow protected abstract C_81592558 setOpacity(int opacity);

	@Unique private int retroapi$renderType = -1;
	@Unique private boolean retroapi$solidRenderSet = false;
	@Unique private boolean retroapi$solidRender = true;
	@Unique private float[] retroapi$customBounds = null;
	@Unique private boolean retroapi$alwaysDrops = false;
	@Unique private boolean retroapi$alwaysEffectiveTool = false;
	@Unique private Class<?> retroapi$effectiveTool = null;
	@Unique private java.util.List<com.periut.retroapi.state.RetroProperty<?>> retroapi$pendingStates = null;
	@Unique private java.util.function.UnaryOperator<com.periut.retroapi.state.RetroBlockState> retroapi$pendingDefault = null;
	@Unique private boolean retroapi$autoFacing = false;

	// --- Block property wrappers ---

	@Override
	public RetroBlockAccess sounds(C_01306377 sounds) {
		this.setSoundGroup(sounds);
		return this;
	}

	@Override
	public RetroBlockAccess strength(float strength) {
		this.setHardness(strength);
		this.setResistance(strength);
		return this;
	}

	@Override
	public RetroBlockAccess strength(float strength, float resistance) {
		this.setHardness(strength);
		this.setResistance(resistance);
		return this;
	}

	@Override
	public RetroBlockAccess resistance(float resistance) {
		this.setResistance(resistance);
		return this;
	}

	@Override
	public RetroBlockAccess light(float light) {
		this.setLuminance(light);
		return this;
	}

	@Override
	public RetroBlockAccess opacity(int opacity) {
		this.setOpacity(opacity);
		return this;
	}

	// --- RetroAPI extensions ---

	@Override
	public RetroBlockAccess alwaysDrops() {
		this.retroapi$alwaysDrops = true;
		return this;
	}

	@Override
	public RetroBlockAccess alwaysEffectiveTool() {
		this.retroapi$alwaysEffectiveTool = true;
		return this;
	}

	@Override
	public RetroBlockAccess states(com.periut.retroapi.state.RetroProperty<?>... properties) {
		this.retroapi$pendingStates = new java.util.ArrayList<>(java.util.Arrays.asList(properties));
		return this;
	}

	@Override
	public RetroBlockAccess defaultState(java.util.function.UnaryOperator<com.periut.retroapi.state.RetroBlockState> transformer) {
		this.retroapi$pendingDefault = transformer;
		return this;
	}

	@Override
	public RetroBlockAccess facing() {
		this.retroapi$autoFacing = true;
		if (this.retroapi$pendingStates == null) {
			this.retroapi$pendingStates = new java.util.ArrayList<>();
		}
		if (!this.retroapi$pendingStates.contains(com.periut.retroapi.state.RetroFacing.PROPERTY)) {
			this.retroapi$pendingStates.add(com.periut.retroapi.state.RetroFacing.PROPERTY);
		}
		// Aim the inventory icon's default south (front on a visible iso face), unless the caller set one.
		if (this.retroapi$pendingDefault == null) {
			this.retroapi$pendingDefault = s -> s.with(
				com.periut.retroapi.state.RetroFacing.PROPERTY, com.periut.retroapi.state.RetroFacing.SOUTH);
		}
		return this;
	}

	@Override
	public boolean isAutoFacing() {
		return this.retroapi$autoFacing;
	}

	@Override
	public RetroBlockAccess mineable(com.periut.retroapi.tag.RetroTool... tools) {
		for (com.periut.retroapi.tag.RetroTool tool : tools) {
			com.periut.retroapi.tag.RetroTags.addToTag(tool.mineableTag(), (C_81592558) (Object) this);
		}
		return this;
	}

	@Override
	public boolean isAlwaysDrops() {
		return this.retroapi$alwaysDrops;
	}

	@Override
	public boolean isAlwaysEffectiveTool() {
		return this.retroapi$alwaysEffectiveTool;
	}

	@Override
	public RetroBlockAccess effectiveTool(Class<? extends net.minecraft.unmapped.C_98888256> toolClass) {
		this.retroapi$effectiveTool = toolClass;
		return this;
	}

	@Override
	@SuppressWarnings("unchecked")
	public Class<? extends net.minecraft.unmapped.C_98888256> getEffectiveTool() {
		return (Class<? extends net.minecraft.unmapped.C_98888256>) this.retroapi$effectiveTool;
	}

	@Override
	public RetroBlockAccess nonOpaque() {
		this.retroapi$solidRenderSet = true;
		this.retroapi$solidRender = false;
		C_81592558.f_54870136[this.id] = false;
		C_81592558.f_43623251[this.id] = 0;
		return this;
	}

	@Override
	public RetroBlockAccess bounds(float minX, float minY, float minZ, float maxX, float maxY, float maxZ) {
		this.retroapi$customBounds = new float[]{minX, minY, minZ, maxX, maxY, maxZ};
		((C_81592558) (Object) this).m_86422250(minX, minY, minZ, maxX, maxY, maxZ);
		return this;
	}

	@Override
	public RetroBlockAccess renderType(NamespacedIdentifier renderTypeId) {
		this.retroapi$renderType = RenderType.resolve(renderTypeId);
		return this;
	}

	@Override
	public RetroBlockAccess sprite(int spriteId) {
		this.textureId = spriteId;
		return this;
	}

	@Override
	public RetroBlockAccess texture(NamespacedIdentifier textureId) {
		RetroTexture tex = RetroTextures.addBlockTexture(textureId);
		this.textureId = tex.id;
		RetroTextures.trackBlock((C_81592558) (Object) this, tex);
		return this;
	}

	@Override
	public C_81592558 register(NamespacedIdentifier id) {
		return register(id, C_71827890::new);
	}

	@Override
	public C_81592558 register(NamespacedIdentifier id, java.util.function.IntFunction<C_71827890> itemFactory) {
		C_81592558 self = (C_81592558) (Object) this;
		self.m_73501903(id.namespace() + "." + id.identifier());

		if (this.retroapi$pendingStates != null) {
			com.periut.retroapi.state.RetroStates.define(self, this.retroapi$pendingStates, this.retroapi$pendingDefault);
			this.retroapi$pendingStates = null;
			this.retroapi$pendingDefault = null;
		}

		// Blockstate JSON auto-wiring: data-declared properties, render layer, the model
		// table, the MODEL render type (unless one was set explicitly) and the particle
		// sprite from the model's particle texture.
		com.periut.retroapi.client.model.BlockstateLoader.BlockModelTable table =
			com.periut.retroapi.client.model.BlockstateLoader.tryLoad(self, id);
		if (table != null) {
			if (this.retroapi$renderType == -1) {
				this.retroapi$renderType = RenderType.resolve(com.periut.retroapi.register.rendertype.RenderTypes.MODEL);
			}
			com.periut.retroapi.client.model.RetroModel firstModel = table.firstModel();
			RetroTexture particle = firstModel != null ? firstModel.particle() : null;
			if (particle != null) {
				this.textureId = particle.id;
				RetroTextures.trackBlock(self, particle);
			}
		}

		boolean hasStationAPI = FabricLoader.getInstance().isModLoaded("stationapi");

		C_71827890 blockItem = null;
		if (!hasStationAPI) {
			blockItem = itemFactory.apply(this.id - 256);
		}

		RetroRegistry.registerBlock(new BlockRegistration(id, self, blockItem));

		if (hasStationAPI) {
			StationBridges.get().registerBlock(id.namespace(), id.identifier(), self);
		}

		return self;
	}

	// --- Mixin injections ---

	@Inject(method = "isOpaque", at = @At("HEAD"), cancellable = true, require = 0)
	private void retroapi$isSolidRender(CallbackInfoReturnable<Boolean> cir) {
		if (this.retroapi$solidRenderSet) {
			cir.setReturnValue(this.retroapi$solidRender);
		}
	}

	@Inject(method = "isFullCube", at = @At("HEAD"), cancellable = true)
	private void retroapi$isCube(CallbackInfoReturnable<Boolean> cir) {
		if (this.retroapi$solidRenderSet) {
			cir.setReturnValue(this.retroapi$solidRender);
		}
	}

	@Inject(method = "updateBoundingBox", at = @At("HEAD"), cancellable = true)
	private void retroapi$updateShape(C_46108969 world, int x, int y, int z, CallbackInfo ci) {
		if (this.retroapi$customBounds != null) {
			((C_81592558) (Object) this).m_86422250(
				retroapi$customBounds[0], retroapi$customBounds[1], retroapi$customBounds[2],
				retroapi$customBounds[3], retroapi$customBounds[4], retroapi$customBounds[5]
			);
			ci.cancel();
		}
	}

	@Inject(method = "getRenderType", at = @At("HEAD"), cancellable = true, require = 0)
	private void retroapi$getRenderType(CallbackInfoReturnable<Integer> cir) {
		if (this.retroapi$renderType != -1) {
			cir.setReturnValue(this.retroapi$renderType);
		}
	}

	/**
	 * Furnace-like facing for {@code .facing()} blocks: write the placer-facing direction into state on
	 * placement, so the block orients itself with no per-block {@code onPlaced}. Targets the same
	 * {@code onPlaced(World,x,y,z,LivingEntity)} overload the freezer overrides by hand.
	 */
	@Inject(method = "onPlaced(Lnet/minecraft/world/World;IIILnet/minecraft/entity/LivingEntity;)V",
		at = @At("TAIL"), require = 0)
	private void retroapi$autoFace(net.minecraft.unmapped.C_64041439 world, int x, int y, int z,
			net.minecraft.unmapped.C_74425583 placer, CallbackInfo ci) {
		if (this.retroapi$autoFacing) {
			C_81592558 self = (C_81592558) (Object) this;
			com.periut.retroapi.state.RetroStates.set(world, x, y, z,
				com.periut.retroapi.state.RetroStates.getDefault(self).with(
					com.periut.retroapi.state.RetroFacing.PROPERTY,
					com.periut.retroapi.state.RetroFacing.fromYaw(placer.f_80130373)));
		}
	}

	@Inject(method = "getRenderLayer", at = @At("HEAD"), cancellable = true, require = 0)
	private void retroapi$getRenderLayer(CallbackInfoReturnable<Integer> cir) {
		com.periut.retroapi.client.render.RetroRenderLayer layer =
			com.periut.retroapi.client.render.RetroRenderLayers.get((C_81592558) (Object) this);
		if (layer != null) {
			cir.setReturnValue(layer.getPass());
		}
	}

}

