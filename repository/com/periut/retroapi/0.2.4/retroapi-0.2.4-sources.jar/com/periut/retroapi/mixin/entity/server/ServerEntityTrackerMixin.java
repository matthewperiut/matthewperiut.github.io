package com.periut.retroapi.mixin.entity.server;

import com.periut.retroapi.entity.EntityRegistration;
import com.periut.retroapi.registry.RetroRegistry;
import net.minecraft.unmapped.C_31402669;
import net.minecraft.unmapped.C_42042215;
import net.minecraft.unmapped.C_42232651;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Starts tracking modded entities using their {@link EntityRegistration} params, after vanilla has had its
 * chance in {@code onEntityAdded}. Collapses StationAPI's TrackEntityEvent + HasTrackingParameters +
 * TrackingParametersProvider + CustomTracking machinery (5 files) into one mixin reading the registration.
 */
@Mixin(C_42042215.class)
public abstract class ServerEntityTrackerMixin {

	@Shadow private C_31402669 entriesById;

	@Shadow public abstract void startTracking(C_42232651 entity, int trackingDistance, int updatePeriod);

	@Shadow public abstract void startTracking(C_42232651 entity, int trackingDistance, int updatePeriod, boolean sendVelocity);

	@Shadow public abstract void onEntityRemoved(C_42232651 entity);

	@Inject(method = "onEntityAdded", at = @At("RETURN"))
	private void retroapi$trackModded(C_42232651 entity, CallbackInfo ci) {
		EntityRegistration reg = RetroRegistry.getEntityRegistration(entity.getClass());
		if (reg == null) {
			return; // not a RetroAPI entity; vanilla already handled (or ignored) it
		}
		if (this.entriesById.m_25200119(entity.f_11112215)) {
			this.onEntityRemoved(entity); // re-track guard, mirrors StationAPI TrackingParametersImpl
		}
		if (reg.getSendVelocity() == EntityRegistration.SEND_VELOCITY_UNSET) {
			this.startTracking(entity, reg.getTrackingDistance(), reg.getUpdatePeriod());
		} else {
			this.startTracking(entity, reg.getTrackingDistance(), reg.getUpdatePeriod(),
				reg.getSendVelocity() == EntityRegistration.SEND_VELOCITY_TRUE);
		}
	}
}
