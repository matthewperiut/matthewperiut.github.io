package com.periut.retroapi.mixin.client.atlas;

import com.periut.retroapi.client.texture.AtlasExpander;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_15891356;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_96603444;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_15891356.class)
@Environment(EnvType.CLIENT)
public abstract class AchievementsScreenMixin extends C_85740840 {

	@Redirect(
		method = "renderIcons",
		at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screen/AchievementsScreen;drawTexture(IIIIII)V", ordinal = 0)
	)
	private void retroapi$fixTerrainDrawTexture(C_15891356 self, int x, int y, int u, int v, int width, int height) {
		float scale = 1.0F / AtlasExpander.terrainAtlasSize;
		C_96603444 tesselator = C_96603444.f_99414865;
		tesselator.m_35940071();
		tesselator.m_75942980(x, y + height, this.f_02657644, u * scale, (v + height) * scale);
		tesselator.m_75942980(x + width, y + height, this.f_02657644, (u + width) * scale, (v + height) * scale);
		tesselator.m_75942980(x + width, y, this.f_02657644, (u + width) * scale, v * scale);
		tesselator.m_75942980(x, y, this.f_02657644, u * scale, v * scale);
		tesselator.m_70070273();
	}
}

