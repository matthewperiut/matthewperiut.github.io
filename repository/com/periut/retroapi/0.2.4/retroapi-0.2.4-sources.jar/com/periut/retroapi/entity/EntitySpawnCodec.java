package com.periut.retroapi.entity;

import com.periut.retroapi.entity.spawn.RetroEntitySpawnData;
import com.periut.retroapi.entity.spawn.RetroHasOwner;
import com.periut.retroapi.entity.spawn.RetroMobSpawnData;
import com.periut.retroapi.network.RetroAPINetworking;
import net.ornithemc.osl.networking.api.PacketBuffer;
import net.ornithemc.osl.networking.api.server.ServerPlayNetworking;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_74425583;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * Server-side: writes a modded entity's spawn payload onto an OSL {@link PacketBuffer} and sends it to one
 * player, replacing the vanilla spawn packet (which throws for unknown entity types). The wire format is a
 * faithful, sequential mirror of StationAPI's {@code EntitySpawnDataProvider}/{@code MobSpawnDataProvider}
 * (positions are {@code floor(coord*32)}, rotations are {@code angle*256/360} bytes, the DataTracker blob is
 * {@code writeAllEntries}). The client side ({@code entity.client.EntitySpawnClient}) reads it back in order.
 */
public final class EntitySpawnCodec {
	private EntitySpawnCodec() {}

	private static final double MAX_VELOCITY = 3.9D;

	/**
	 * Spawn sends attempted before the player's OSL channel handshake completes, queued for re-send at
	 * {@code PLAY_READY}. OSL's {@code ServerPlayNetworking.send(player, ...)} SILENTLY DROPS packets
	 * until {@code isPlayReady(player, channel)} - and the entity tracker sends spawns on the joining
	 * player's very first ticks (vanilla {@code EntityTracker.onEntityAdded(ServerPlayerEntity)} pushes
	 * every existing tracked entity through {@code updateListener} immediately), which is before the
	 * handshake. Vanilla then marks the player as a listener and never re-sends, so without this queue
	 * every modded entity is permanently invisible to a joining client. (StationAPI doesn't need this:
	 * its MessagePacket is a vanilla-registered packet with no readiness gate.) Weak keys so entries
	 * vanish with disconnected players (e.g. vanilla clients whose handshake never completes).
	 */
	private static final Map<C_49202226, Set<C_42232651>> PENDING = new WeakHashMap<>();

	/** Send the appropriate spawn packet for a RetroAPI entity to one player. */
	public static void sendSpawn(C_49202226 player, C_42232651 entity) {
		NamespacedIdentifier channel;
		if (entity instanceof RetroMobSpawnData) {
			channel = RetroAPINetworking.ENTITY_SPAWN_MOB_CHANNEL;
		} else if (entity instanceof RetroEntitySpawnData) {
			channel = RetroAPINetworking.ENTITY_SPAWN_CHANNEL;
		} else {
			// Registered-but-no-spawn-data entities track but don't network-spawn (mod author must implement a
			// RetroEntitySpawnData/RetroMobSpawnData interface) - they simply won't render client-side.
			return;
		}

		if (!ServerPlayNetworking.isPlayReady(player, channel)) {
			synchronized (PENDING) {
				PENDING.computeIfAbsent(player, p -> new LinkedHashSet<>()).add(entity);
			}
			return;
		}

		if (entity instanceof RetroMobSpawnData) {
			ServerPlayNetworking.send(player, channel, buf -> writeMob(buf, (C_74425583) entity));
		} else {
			ServerPlayNetworking.send(player, channel, buf -> writeEntity(buf, entity));
		}
	}

	/**
	 * Re-send the spawns that were attempted before this player's channel handshake completed. Called
	 * from the {@code PLAY_READY} listener in {@code RetroAPIServer} (registered unconditionally - the
	 * RetroAPI entity spawn path stays active under StationAPI too). Skips entities that died or changed
	 * worlds while queued; the client handler spawns into its current world, so a cross-dimension send
	 * would materialize the entity in the wrong world.
	 */
	public static void flushPending(C_49202226 player) {
		Set<C_42232651> queued;
		synchronized (PENDING) {
			queued = PENDING.remove(player);
		}
		if (queued == null) return;
		for (C_42232651 entity : queued) {
			if (entity.f_42219270 || entity.f_94306729 != player.f_94306729) continue;
			sendSpawn(player, entity);
		}
	}

	private static void writeEntity(PacketBuffer buf, C_42232651 entity) throws IOException {
		RetroEntitySpawnData p = (RetroEntitySpawnData) entity;
		buf.writeString(p.getHandlerId().toString());
		buf.writeVarInt(entity.f_11112215);
		buf.writeInt(C_45510667.m_80489169(entity.f_78826675 * 32.0D));
		buf.writeInt(C_45510667.m_80489169(entity.f_31030949 * 32.0D));
		buf.writeInt(C_45510667.m_80489169(entity.f_97691941 * 32.0D));

		int ownerId = 0;
		if (entity instanceof RetroHasOwner owned) {
			C_42232651 owner = owned.getOwner();
			ownerId = (owner == null ? entity : owner).f_11112215;
		}
		buf.writeVarInt(ownerId);
		if (ownerId > 0) {
			buf.writeShort((int) (clamp(entity.f_24826402) * 8000));
			buf.writeShort((int) (clamp(entity.f_35148123) * 8000));
			buf.writeShort((int) (clamp(entity.f_21201587) * 8000));
		}

		boolean sync = p.syncTrackerAtSpawn();
		buf.writeBoolean(sync);
		if (sync) {
			buf.writeByteArray(dataTrackerBytes(entity));
		}
		p.writeExtra(buf);
	}

	private static void writeMob(PacketBuffer buf, C_74425583 mob) throws IOException {
		RetroMobSpawnData p = (RetroMobSpawnData) mob;
		buf.writeString(p.getHandlerId().toString());
		buf.writeVarInt(mob.f_11112215);
		buf.writeInt(C_45510667.m_80489169(mob.f_78826675 * 32.0D));
		buf.writeInt(C_45510667.m_80489169(mob.f_31030949 * 32.0D));
		buf.writeInt(C_45510667.m_80489169(mob.f_97691941 * 32.0D));
		buf.writeByte((int) (mob.f_80130373 * 256.0F / 360.0F));
		buf.writeByte((int) (mob.f_03549461 * 256.0F / 360.0F));
		buf.writeByteArray(dataTrackerBytes(mob)); // mobs always sync the tracker at spawn
		p.writeExtra(buf);
	}

	private static byte[] dataTrackerBytes(C_42232651 entity) throws IOException {
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		entity.m_82885919().m_08569472(new DataOutputStream(out));
		return out.toByteArray();
	}

	private static double clamp(double v) {
		return Math.max(-MAX_VELOCITY, Math.min(MAX_VELOCITY, v));
	}
}
