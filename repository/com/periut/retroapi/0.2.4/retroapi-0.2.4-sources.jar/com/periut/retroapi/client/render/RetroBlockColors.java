package com.periut.retroapi.client.render;

import com.periut.retroapi.state.RetroBlockState;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_81592558;

/**
 * Tint providers for model faces with {@code tintindex >= 0}: the model renderer
 * multiplies the face color by the provider's 0xRRGGBB result.
 *
 * <pre>
 * RetroBlockColors.register(block, (state, world, x, y, z, tintIndex) -> 0x91BD59);
 * RetroBlockColors.register(block, RetroBlockColors.GRASS);   // biome grass color
 * </pre>
 */
public final class RetroBlockColors {

	@FunctionalInterface
	public interface Provider {
		/** world may be null (item form); return 0xRRGGBB. */
		int getColor(RetroBlockState state, C_46108969 world, int x, int y, int z, int tintIndex);
	}

	/** Biome grass colormap sampling, the way GrassBlock does it. */
	public static final Provider GRASS = (state, world, x, y, z, tintIndex) ->
		sampleColormap(world, x, z, true);

	/** Biome foliage colormap sampling, the way leaves do it. */
	public static final Provider FOLIAGE = (state, world, x, y, z, tintIndex) ->
		sampleColormap(world, x, z, false);

	private static final Map<C_81592558, Provider> PROVIDERS = new HashMap<>();

	private RetroBlockColors() {}

	public static void register(C_81592558 block, Provider provider) {
		PROVIDERS.put(block, provider);
	}

	public static Provider get(C_81592558 block) {
		return PROVIDERS.get(block);
	}

	private static int sampleColormap(C_46108969 world, int x, int z, boolean grass) {
		if (world == null) {
			return grass ? 0x48B518 : 0x48B518;
		}
		net.minecraft.unmapped.C_28112798 source = world.m_72354999();
		source.m_19075238(x, z, 1, 1);
		double temperature = source.f_57821734[0];
		double downfall = source.f_84133265[0];
		return grass
			? net.minecraft.unmapped.C_19632932.m_60771122(temperature, downfall)
			: net.minecraft.unmapped.C_82336779.m_31566293(temperature, downfall);
	}
}
