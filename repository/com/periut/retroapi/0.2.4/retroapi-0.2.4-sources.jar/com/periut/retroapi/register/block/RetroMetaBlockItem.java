package com.periut.retroapi.register.block;

import net.minecraft.unmapped.C_71827890;
import net.minecraft.unmapped.C_88708284;

/**
 * A BlockItem whose damage value carries the block metadata, with per-meta translation keys.
 * Mirrors vanilla {@code WoolBlockItem} (and StationAPI's {@code MetaNamedBlockItemProvider} item):
 * placing keeps the stack's damage as block meta, and the display name resolves
 * {@code <blockTranslationKey><meta>.name} (e.g. {@code tile.aether.holystone0.name}).
 *
 * <p>Register via {@link RetroBlockAccess#register(net.ornithemc.osl.core.api.util.NamespacedIdentifier, java.util.function.IntFunction)}:
 * <pre>
 * RetroBlockAccess.of(new Holystone()).register(id("holystone"), RetroMetaBlockItem::new);
 * </pre>
 */
public class RetroMetaBlockItem extends C_71827890 {

	public RetroMetaBlockItem(int id) {
		super(id);
		this.m_56494446(true);
		this.m_83617391(0);
	}

	@Override
	public int m_65403122(int damage) {
		return damage;
	}

	@Override
	public String m_81802680(C_88708284 stack) {
		return super.m_27822537() + stack.m_21098843();
	}
}
