package com.periut.retroapi.voxelshapes;

import com.periut.retroapi.voxelshapes.impl.BoxToLinesConverter;
import java.util.List;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_94584382;

public class VoxelData {
    private final VoxelVec3d center;
    private final VoxelBox[] boxes;
    private Line[] lines = null;

    public VoxelData(C_82690114... boxes) {
        this(VoxelBox.voxelify(boxes));
    }

    public VoxelData(VoxelBox... boxes) {
        this(new VoxelVec3d(0.5, 0.5, 0.5), boxes);
    }

    public VoxelData(C_94584382 center, C_82690114[] boxes) {
        this(VoxelVec3d.voxelify(center), VoxelBox.voxelify(boxes));
    }

    public VoxelData(VoxelVec3d center, VoxelBox[] boxes) {
        this.center = center;
        this.boxes = boxes;
    }

    public VoxelData withBox(VoxelBox voxelBox) {
        VoxelBox[] newBoxes = new VoxelBox[boxes.length + 1];
        System.arraycopy(boxes, 0, newBoxes, 0, boxes.length);
        newBoxes[boxes.length] = voxelBox;
        return new VoxelData(center, newBoxes);
    }

    public VoxelData withBox(C_82690114 box) {
        return withBox(VoxelBox.voxelify(box));
    }

    public VoxelData preCache() {
        computeLines();
        return this;
    }

    public VoxelShape withOffset(VoxelVec3d offset) {
        return new VoxelShape(this, offset);
    }

    public VoxelShape withOffset(C_94584382 offset) {
        return withOffset(VoxelVec3d.voxelify(offset));
    }

    public VoxelShape withOffset(int x, int y, int z) {
        return withOffset(new VoxelVec3d(x, y, z));
    }

    public List<VoxelBox> getVoxelBoxes() {
        return List.of(boxes);
    }

    public List<C_82690114> getBoxes() {
        return List.of(VoxelBox.devoxelify(boxes));
    }

    protected void computeLines() {
        lines = BoxToLinesConverter.convertBoxesToLines(boxes, center).toArray(Line[]::new);
    }

    public List<Line> getLines() {
        if (lines == null) {
            computeLines();
        }
        return List.of(lines);
    }
}
