package com.periut.retroapi.mixin.entity;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_72103717;

/**
 * Exposes vanilla {@code EntityRegistry}'s private static string&lt;-&gt;class maps so RetroAPI can insert
 * modded entities keyed by their namespaced {@code id.toString()} (the same maps StationAPI populates).
 * This is the minimum-code path: no {@code <clinit>} timing puzzle, because {@code EntityRegistry} is
 * already class-loaded by the time any mod's {@code init()} runs.
 */
@Mixin(C_72103717.class)
public interface EntityRegistryAccessor {
	@Accessor("idToClass")
	static Map<String, Class<? extends C_42232651>> retroapi$getIdToClass() {
		throw new AssertionError();
	}

	@Accessor("classToId")
	static Map<Class<? extends C_42232651>, String> retroapi$getClassToId() {
		throw new AssertionError();
	}
}
