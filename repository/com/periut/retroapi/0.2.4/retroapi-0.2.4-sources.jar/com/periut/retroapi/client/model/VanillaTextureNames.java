package com.periut.retroapi.client.model;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.unmapped.C_81592558;

/**
 * Maps modern texture ids ({@code minecraft:block/cobblestone}, ...) to vanilla terrain
 * atlas sprite indices, so model JSONs copied from modern packs (or StationAPI mods)
 * reference vanilla textures by name and just work; nobody re-ships cobblestone.png.
 *
 * <p>Sprites are sampled from the blocks' own {@code getTexture(face)} (0 = bottom,
 * 1 = top, 2+ = sides), evaluated once on first use. Both the modern name and, where it
 * differs, the historical flattening name are registered. Unknown names fall through to
 * the normal mod-file path and warn there, so coverage gaps are loud, not invisible.</p>
 */
final class VanillaTextureNames {

	private static Map<String, Integer> sprites = null;

	private VanillaTextureNames() {}

	/** The terrain sprite for a path like {@code block/cobblestone}, or null when unknown. */
	static Integer blockSprite(String path) {
		if (path.startsWith("block/")) {
			path = path.substring("block/".length());
		} else if (path.startsWith("blocks/")) {
			path = path.substring("blocks/".length());
		}
		return table().get(path);
	}

	private static synchronized Map<String, Integer> table() {
		if (sprites != null) {
			return sprites;
		}
		Map<String, Integer> t = new HashMap<>();

		all(t, C_81592558.f_38442324, "stone");
		put(t, C_81592558.f_41096518.m_79262324(1), "grass_block_top");
		put(t, C_81592558.f_41096518.m_79262324(2), "grass_block_side");
		all(t, C_81592558.f_05581995, "dirt");
		all(t, C_81592558.f_17981199, "cobblestone");
		all(t, C_81592558.f_32493286, "oak_planks", "planks");
		all(t, C_81592558.f_35695348, "bedrock");
		all(t, C_81592558.f_27446762, "sand");
		all(t, C_81592558.f_38177074, "gravel");
		all(t, C_81592558.f_91577743, "gold_ore");
		all(t, C_81592558.f_19757556, "iron_ore");
		all(t, C_81592558.f_81094226, "coal_ore");
		put(t, C_81592558.f_78280144.m_79262324(2), "oak_log", "log_oak", "log");
		put(t, C_81592558.f_78280144.m_79262324(1), "oak_log_top", "log_oak_top", "log_top");
		all(t, C_81592558.f_00276986, "oak_leaves", "leaves");
		all(t, C_81592558.f_36441950, "sponge");
		all(t, C_81592558.f_32420701, "glass");
		all(t, C_81592558.f_83073694, "lapis_ore");
		all(t, C_81592558.f_99851615, "lapis_block");
		put(t, C_81592558.f_94949418.m_79262324(2), "sandstone", "sandstone_side");
		put(t, C_81592558.f_94949418.m_79262324(1), "sandstone_top");
		put(t, C_81592558.f_94949418.m_79262324(0), "sandstone_bottom");
		all(t, C_81592558.f_82599628, "note_block", "noteblock");
		all(t, C_81592558.f_88550428, "cobweb", "web");
		all(t, C_81592558.f_12629815, "white_wool", "wool", "wool_colored_white");
		all(t, C_81592558.f_54760749, "gold_block");
		all(t, C_81592558.f_41428926, "iron_block");
		all(t, C_81592558.f_73573195, "bricks", "brick");
		put(t, C_81592558.f_69656505.m_79262324(2), "tnt_side");
		put(t, C_81592558.f_69656505.m_79262324(1), "tnt_top");
		put(t, C_81592558.f_69656505.m_79262324(0), "tnt_bottom");
		put(t, C_81592558.f_22197047.m_79262324(2), "bookshelf");
		all(t, C_81592558.f_87667057, "mossy_cobblestone", "cobblestone_mossy");
		all(t, C_81592558.f_38591135, "obsidian");
		all(t, C_81592558.f_35664400, "diamond_ore");
		all(t, C_81592558.f_95737061, "diamond_block");
		put(t, C_81592558.f_30918233.m_79262324(1), "crafting_table_top");
		put(t, C_81592558.f_30918233.m_79262324(2), "crafting_table_front");
		put(t, C_81592558.f_30918233.m_79262324(4), "crafting_table_side");
		put(t, C_81592558.f_19785413.m_79262324(2), "furnace_front");
		put(t, C_81592558.f_19785413.m_79262324(4), "furnace_side");
		put(t, C_81592558.f_19785413.m_79262324(1), "furnace_top");
		all(t, C_81592558.f_68803305, "redstone_ore");
		all(t, C_81592558.f_51102006, "snow", "snow_block");
		all(t, C_81592558.f_28421768, "ice");
		all(t, C_81592558.f_86394960, "clay");
		all(t, C_81592558.f_25017736, "jukebox_side");
		put(t, C_81592558.f_25017736.m_79262324(1), "jukebox_top");
		put(t, C_81592558.f_94091898.m_79262324(2), "pumpkin_side");
		put(t, C_81592558.f_94091898.m_79262324(1), "pumpkin_top");
		all(t, C_81592558.f_14995882, "netherrack");
		all(t, C_81592558.f_84892602, "soul_sand");
		all(t, C_81592558.f_19295217, "glowstone");

		sprites = t;
		return t;
	}

	/** Registers one sprite under several names. */
	private static void put(Map<String, Integer> t, int sprite, String... names) {
		for (String name : names) {
			t.put(name, sprite);
		}
	}

	/** Registers a block's face-0 sprite (blocks that look the same on every face). */
	private static void all(Map<String, Integer> t, C_81592558 block, String... names) {
		put(t, block.m_79262324(0), names);
	}
}
