package com.periut.retroapi.mixin.network;

import net.minecraft.unmapped.C_49202226;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_49202226.class)
public interface ServerPlayerEntityAccessor {
	@Invoker("incrementScreenHandlerSyncId")
	void invokeIncrementSyncId();

	@Accessor("screenHandlerSyncId")
	int getMenuId();
}
