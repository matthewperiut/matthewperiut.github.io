package com.periut.retroapi.mixin.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Properties;
import net.minecraft.unmapped.C_16154270;

@Mixin(C_16154270.class)
public interface LanguageAccessor {
	@Accessor("translations")
	Properties retroapi$getTranslations();
}
