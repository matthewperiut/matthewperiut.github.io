package com.periut.retroapi.mixin.client;

import com.periut.retroapi.register.rendertype.BlockRenderContext;
import com.periut.retroapi.register.rendertype.CustomBlockRenderer;
import com.periut.retroapi.register.rendertype.RetroBlockRendererAccess;
import com.periut.retroapi.register.rendertype.RenderType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_96603444;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_03670941.class)
@Environment(EnvType.CLIENT)
public class BlockRendererMixin implements RetroBlockRendererAccess {
	@Shadow private C_46108969 blockView;
	@Shadow private boolean useAo;
	@Shadow private float firstVertexRed;
	@Shadow private float firstVertexGreen;
	@Shadow private float firstVertexBlue;
	@Shadow private float secondVertexRed;
	@Shadow private float secondVertexGreen;
	@Shadow private float secondVertexBlue;
	@Shadow private float thirdVertexRed;
	@Shadow private float thirdVertexGreen;
	@Shadow private float thirdVertexBlue;
	@Shadow private float fourthVertexRed;
	@Shadow private float fourthVertexGreen;
	@Shadow private float fourthVertexBlue;

	@Override
	public void retroapi$setupSmoothFace(float v1, float v2, float v3, float v4, float shade) {
		this.useAo = true;
		this.firstVertexRed = this.firstVertexGreen = this.firstVertexBlue = shade * v1;
		this.secondVertexRed = this.secondVertexGreen = this.secondVertexBlue = shade * v2;
		this.thirdVertexRed = this.thirdVertexGreen = this.thirdVertexBlue = shade * v3;
		this.fourthVertexRed = this.fourthVertexGreen = this.fourthVertexBlue = shade * v4;
	}

	@Override
	public void retroapi$cleanupSmoothFace() {
		this.useAo = false;
	}

	// --- Custom render type handling ---

	@Inject(method = "render(Lnet/minecraft/block/Block;III)Z", at = @At("HEAD"), cancellable = true)
	private void retroapi$handleCustomRenderType(C_81592558 block, int x, int y, int z, CallbackInfoReturnable<Boolean> cir) {
		int type = block.m_43136364();
		if (RenderType.isCustom(type)) {
			CustomBlockRenderer renderer = RenderType.getRenderer(type);
			if (renderer != null) {
				block.m_98737217(this.blockView, x, y, z);
				BlockRenderContext ctx = new BlockRenderContext(
					(C_03670941) (Object) this, block, x, y, z, this.blockView
				);
				cir.setReturnValue(renderer.render(ctx));
			}
		}
	}

	@Inject(method = "render(Lnet/minecraft/block/Block;IF)V", at = @At("HEAD"), cancellable = true)
	private void retroapi$handleCustomRenderAsItem(C_81592558 block, int metadata, float brightness, CallbackInfo ci) {
		int type = block.m_43136364();
		if (RenderType.isCustom(type)) {
			// Model blocks render their baked model in inventory/hand instead of a plain cube.
			if (com.periut.retroapi.client.model.BlockstateLoader.tableFor(block) != null) {
				GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
				com.periut.retroapi.client.model.ModelBlockRenderer.renderInventory(block, metadata);
				GL11.glTranslatef(0.5F, 0.5F, 0.5F);
				ci.cancel();
				return;
			}
			block.m_25081207();
			GL11.glTranslatef(-0.5F, -0.5F, -0.5F);
			C_96603444 tesselator = C_96603444.f_99414865;
			C_03670941 self = (C_03670941) (Object) this;

			tesselator.m_35940071();
			tesselator.m_86080397(0.0F, -1.0F, 0.0F);
			self.m_52572467(block, 0.0, 0.0, 0.0, block.m_07414817(0, metadata));
			tesselator.m_70070273();

			tesselator.m_35940071();
			tesselator.m_86080397(0.0F, 1.0F, 0.0F);
			self.m_53051530(block, 0.0, 0.0, 0.0, block.m_07414817(1, metadata));
			tesselator.m_70070273();

			tesselator.m_35940071();
			tesselator.m_86080397(0.0F, 0.0F, -1.0F);
			self.m_01007294(block, 0.0, 0.0, 0.0, block.m_07414817(2, metadata));
			tesselator.m_70070273();

			tesselator.m_35940071();
			tesselator.m_86080397(0.0F, 0.0F, 1.0F);
			self.m_11750528(block, 0.0, 0.0, 0.0, block.m_07414817(3, metadata));
			tesselator.m_70070273();

			tesselator.m_35940071();
			tesselator.m_86080397(-1.0F, 0.0F, 0.0F);
			self.m_46310987(block, 0.0, 0.0, 0.0, block.m_07414817(4, metadata));
			tesselator.m_70070273();

			tesselator.m_35940071();
			tesselator.m_86080397(1.0F, 0.0F, 0.0F);
			self.m_13161429(block, 0.0, 0.0, 0.0, block.m_07414817(5, metadata));
			tesselator.m_70070273();

			GL11.glTranslatef(0.5F, 0.5F, 0.5F);
			ci.cancel();
		}
	}

	@Inject(method = "isSideLit", at = @At("HEAD"), cancellable = true)
	private static void retroapi$customIsItem3d(int type, CallbackInfoReturnable<Boolean> cir) {
		if (RenderType.isCustom(type)) {
			cir.setReturnValue(true);
		}
	}
}

