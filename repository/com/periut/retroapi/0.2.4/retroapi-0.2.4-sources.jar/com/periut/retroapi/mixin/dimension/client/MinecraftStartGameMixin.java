package com.periut.retroapi.mixin.dimension.client;

import com.periut.retroapi.RetroAPI;
import com.periut.retroapi.dimension.DimensionRegistration;
import com.periut.retroapi.dimension.RetroDimensionRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_57778754;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_90532916;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Singleplayer world-object hops for modded dimensions.
 *
 * <p><b>World load:</b> vanilla's {@code World(WorldStorage, ...)} constructor only special-cases
 * dimension id -1 (the nether) from level.dat, so the world always loads as the overworld for a
 * modded id. The player NBT restore ({@code PlayerDimensionMixin.readNbt}) then sets
 * {@code dimensionId} back to the modded serial id - leaving the player physically in the
 * overworld while their data says otherwise, which inverts portal direction logic. After
 * {@code startGame}, if the restored id is a registered modded dimension, hop into it.</p>
 *
 * <p><b>Respawn:</b> vanilla {@code respawnPlayer} calls {@code changeDimension()} when the
 * current dimension has no world spawn, and that method TOGGLES: {@code dim == -1 ? 0 : -1}.
 * Dying in a modded dimension would therefore respawn the player in the nether. Route a
 * modded-dimension player to the overworld instead.</p>
 *
 * <p>Both hops mirror vanilla {@code changeDimension()}'s full sequence (remove from old world,
 * reposition, setWorld, re-bind {@code player.world}, reposition + updateEntity) without the 8x
 * coordinate scaling. Skipping the re-bind leaves the player entity attached to the OLD world
 * object: rendering follows {@code Minecraft.world} while physics still query
 * {@code player.world} - invisible-terrain collisions.</p>
 */
@Mixin(Minecraft.class)
public abstract class MinecraftStartGameMixin {

	@Shadow public C_64041439 world;
	@Shadow public C_57778754 player;

	@Shadow public abstract void setWorld(C_64041439 world, String message, net.minecraft.unmapped.C_40996800 player);

	@Inject(method = "startGame", at = @At("TAIL"))
	private void retroapi$restoreModdedDimension(String worldDir, String worldName, long seed, CallbackInfo ci) {
		if (this.world == null || this.player == null || this.world.f_50876584) {
			return;
		}
		int dim = this.player.f_15409937;
		if (RetroDimensionRegistry.isVanillaId(dim)) {
			return;
		}
		DimensionRegistration reg = RetroDimensionRegistry.getBySerialId(dim);
		if (reg == null || this.world.f_00524883.f_09977150 == dim) {
			return;
		}

		RetroAPI.LOGGER.info("Restoring player into modded dimension {} (serial id {})", reg.getId(), dim);
		retroapi$hop(dim, "Loading " + reg.getId().identifier());
	}

	/**
	 * Vanilla changeDimension() toggles -1 <-> 0; for a player in a modded dimension that sends
	 * them to the nether. Replace the whole method with an overworld hop in that case (respawn
	 * repositions to the spawn point afterwards).
	 */
	@Inject(method = "changeDimension", at = @At("HEAD"), cancellable = true)
	private void retroapi$leaveModdedDimension(CallbackInfo ci) {
		if (this.world == null || this.player == null || this.world.f_50876584) {
			return;
		}
		int dim = this.player.f_15409937;
		if (RetroDimensionRegistry.isVanillaId(dim) || RetroDimensionRegistry.getBySerialId(dim) == null) {
			return;
		}
		RetroAPI.LOGGER.info("Leaving modded dimension (serial id {}) -> overworld", dim);
		retroapi$hop(0, "Leaving dimension");
		ci.cancel();
	}

	@Unique
	private void retroapi$hop(int dim, String message) {
		double x = this.player.f_78826675;
		double y = this.player.f_31030949;
		double z = this.player.f_97691941;

		this.player.f_15409937 = dim;
		this.world.m_28736857(this.player);
		this.player.f_42219270 = false;
		this.player.m_12877971(x, y, z, this.player.f_80130373, this.player.f_03549461);
		if (this.player.m_48190713()) {
			this.world.m_15238577(this.player, false);
		}

		C_64041439 newWorld = new C_64041439(this.world, C_90532916.m_09825512(dim));
		this.setWorld(newWorld, message, this.player);

		this.player.f_94306729 = this.world;
		if (this.player.m_48190713()) {
			this.player.m_03000503(x, y, z, this.player.f_80130373, this.player.f_03549461);
			this.world.m_15238577(this.player, false);
		}
	}
}
