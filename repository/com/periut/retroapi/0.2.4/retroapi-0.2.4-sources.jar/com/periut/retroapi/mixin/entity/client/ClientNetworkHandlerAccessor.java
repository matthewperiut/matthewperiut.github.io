package com.periut.retroapi.mixin.entity.client;

import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_88014908;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/**
 * Exposes the client network handler's private {@code getEntity(int)} so the entity spawn listener can
 * resolve an owner entity by id (for {@link com.periut.retroapi.entity.spawn.RetroHasOwner} projectiles).
 */
@Mixin(C_88014908.class)
public interface ClientNetworkHandlerAccessor {
	@Invoker("getEntity")
	C_42232651 retroapi$getEntity(int id);
}
