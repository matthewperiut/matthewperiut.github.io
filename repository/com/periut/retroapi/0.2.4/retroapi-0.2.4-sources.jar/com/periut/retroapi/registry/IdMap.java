package com.periut.retroapi.registry;

import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_74087615;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;
import net.ornithemc.osl.core.api.util.NamespacedIdentifiers;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.util.*;

public class IdMap {
	private static final Logger LOGGER = LogManager.getLogger("RetroAPI/IdMap");

	private final Map<NamespacedIdentifier, Integer> blockIds = new HashMap<>();
	private final Map<NamespacedIdentifier, Integer> itemIds = new HashMap<>();
	private final Map<NamespacedIdentifier, Integer> dimensionIds = new HashMap<>();

	public void load(File file) {
		if (!file.exists()) {
			return;
		}
		try (FileInputStream fis = new FileInputStream(file)) {
			C_74087615 root = C_08565163.m_38706312(fis);

			// NbtCompound has no key iteration API in b1.7.3, so use manual NBT key extraction
			loadFromNbt(root);

			LOGGER.info("Loaded ID map with {} blocks and {} items", blockIds.size(), itemIds.size());
		} catch (IOException e) {
			LOGGER.error("Failed to load ID map", e);
		}
	}

	private void loadFromNbt(C_74087615 root) {
		if (root.m_97612750("blocks")) {
			C_74087615 blocks = root.m_81819352("blocks");
			for (String key : getKeys(blocks)) {
				int id = blocks.m_35587574(key);
				String[] parts = key.split(":", 2);
				if (parts.length == 2) {
					blockIds.put(NamespacedIdentifiers.from(parts[0], parts[1]), id);
				}
			}
		}
		if (root.m_97612750("items")) {
			C_74087615 items = root.m_81819352("items");
			for (String key : getKeys(items)) {
				int id = items.m_35587574(key);
				String[] parts = key.split(":", 2);
				if (parts.length == 2) {
					itemIds.put(NamespacedIdentifiers.from(parts[0], parts[1]), id);
				}
			}
		}
		if (root.m_97612750("dimensions")) {
			C_74087615 dimensions = root.m_81819352("dimensions");
			for (String key : getKeys(dimensions)) {
				int id = dimensions.m_35587574(key);
				String[] parts = key.split(":", 2);
				if (parts.length == 2) {
					dimensionIds.put(NamespacedIdentifiers.from(parts[0], parts[1]), id);
				}
			}
		}
	}

	@SuppressWarnings("unchecked")
	private static java.util.Set<String> getKeys(C_74087615 compound) {
		// NbtCompound.getValues() returns Collection<NbtElement>, but the internal map
		// has String keys. We need to write and re-read to get keys, or use reflection.
		// For simplicity, write to byte array and re-read with key tracking.
		java.util.Set<String> keys = new java.util.HashSet<>();
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			DataOutputStream dos = new DataOutputStream(baos);
			C_74087615 wrapper = new C_74087615();
			wrapper.m_18682924("d", compound);
			C_08565163.m_94300398(wrapper, dos);
			dos.flush();

			DataInputStream dis = new DataInputStream(new ByteArrayInputStream(baos.toByteArray()));
			// Read root compound tag
			byte rootType = dis.readByte(); // 10 = compound
			dis.readUTF(); // root name

			// Read inner compound "d"
			byte innerType = dis.readByte(); // 10 = compound
			dis.readUTF(); // "d"

			// Now read all entries in the inner compound
			while (true) {
				byte type = dis.readByte();
				if (type == 0) break; // end tag
				String name = dis.readUTF();
				keys.add(name);
				skipNbtValue(dis, type);
			}
		} catch (IOException e) {
			// Should not happen with byte arrays
		}
		return keys;
	}

	private static void skipNbtValue(DataInputStream dis, byte type) throws IOException {
		switch (type) {
			case 1 -> dis.readByte();
			case 2 -> dis.readShort();
			case 3 -> dis.readInt();
			case 4 -> dis.readLong();
			case 5 -> dis.readFloat();
			case 6 -> dis.readDouble();
			case 7 -> { int len = dis.readInt(); dis.skipBytes(len); }
			case 8 -> dis.readUTF();
			case 9 -> {
				byte listType = dis.readByte();
				int count = dis.readInt();
				for (int i = 0; i < count; i++) {
					skipNbtValue(dis, listType);
				}
			}
			case 10 -> {
				while (true) {
					byte t = dis.readByte();
					if (t == 0) break;
					dis.readUTF(); // key
					skipNbtValue(dis, t);
				}
			}
		}
	}

	public void save(File file) {
		C_74087615 root = new C_74087615();

		C_74087615 blocks = new C_74087615();
		for (Map.Entry<NamespacedIdentifier, Integer> entry : blockIds.entrySet()) {
			blocks.m_20318863(entry.getKey().toString(), entry.getValue());
		}
		root.m_18682924("blocks", blocks);

		C_74087615 items = new C_74087615();
		for (Map.Entry<NamespacedIdentifier, Integer> entry : itemIds.entrySet()) {
			items.m_20318863(entry.getKey().toString(), entry.getValue());
		}
		root.m_18682924("items", items);

		C_74087615 dimensions = new C_74087615();
		for (Map.Entry<NamespacedIdentifier, Integer> entry : dimensionIds.entrySet()) {
			dimensions.m_20318863(entry.getKey().toString(), entry.getValue());
		}
		root.m_18682924("dimensions", dimensions);

		// Synchronous but ATOMIC (tmp+rename): a torn id_map.dat would scramble every modded id
		// in the world on the next load, so this file must never be truncate-overwritten in place.
		try {
			com.periut.retroapi.storage.SidecarIo.writeNow(file, com.periut.retroapi.storage.SidecarIo.snapshot(root));
			LOGGER.info("Saved ID map with {} blocks and {} items", blockIds.size(), itemIds.size());
		} catch (IOException e) {
			LOGGER.error("Failed to save ID map", e);
		}
	}

	public Integer getBlockId(NamespacedIdentifier id) {
		return blockIds.get(id);
	}

	public Integer getItemId(NamespacedIdentifier id) {
		return itemIds.get(id);
	}

	public void putBlockId(NamespacedIdentifier id, int numericId) {
		blockIds.put(id, numericId);
	}

	public void putItemId(NamespacedIdentifier id, int numericId) {
		itemIds.put(id, numericId);
	}

	public Integer getDimensionId(NamespacedIdentifier id) {
		return dimensionIds.get(id);
	}

	public void putDimensionId(NamespacedIdentifier id, int serialId) {
		dimensionIds.put(id, serialId);
	}

	public Map<NamespacedIdentifier, Integer> getDimensionIds() {
		return dimensionIds;
	}

	public Map<NamespacedIdentifier, Integer> getBlockIds() {
		return blockIds;
	}

	public Map<NamespacedIdentifier, Integer> getItemIds() {
		return itemIds;
	}

	public void purgeStaleEntries(List<BlockRegistration> blocks, List<ItemRegistration> items) {
		Set<NamespacedIdentifier> activeBlocks = new HashSet<>();
		for (BlockRegistration reg : blocks) {
			activeBlocks.add(reg.getId());
		}
		Set<NamespacedIdentifier> activeItems = new HashSet<>();
		for (ItemRegistration reg : items) {
			activeItems.add(reg.getId());
		}

		int removedBlocks = 0, removedItems = 0;
		Iterator<NamespacedIdentifier> it = blockIds.keySet().iterator();
		while (it.hasNext()) {
			if (!activeBlocks.contains(it.next())) {
				it.remove();
				removedBlocks++;
			}
		}
		it = itemIds.keySet().iterator();
		while (it.hasNext()) {
			if (!activeItems.contains(it.next())) {
				it.remove();
				removedItems++;
			}
		}

		if (removedBlocks > 0 || removedItems > 0) {
			LOGGER.info("Purged {} stale block and {} stale item entries from ID map", removedBlocks, removedItems);
		}
	}
}
