package com.periut.retroapi.mixin.storage;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.io.File;
import net.minecraft.unmapped.C_68019318;

@Mixin(C_68019318.class)
public interface WorldStorageAccessor {
	@Accessor("dir")
	File retroapi$getDir();
}

