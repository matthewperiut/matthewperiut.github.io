package com.periut.retroapi.register.item;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;

/**
 * A tiny food system, the beta-friendly take on modern's {@code .food(FoodComponent)}. Any
 * item becomes edible by being registered here (the builder does it for you via
 * {@code RetroItemAccess.food(...)}); no FoodItem subclass needed. Beta 1.7.3 predates the
 * hunger bar AND status effects, so a food restores HEALTH (hearts*2 points), and anything
 * fancier, a buff, a hit of damage, a teleport, rides an {@link OnEaten} callback that fires
 * right after the heal. That callback is the whole point: it lets a food do something other
 * than heal.
 */
public final class RetroFood {

	/** Runs the instant a food is eaten, after the heal. Use it for effects beyond healing. */
	@FunctionalInterface
	public interface OnEaten {
		void onEaten(C_88708284 stack, C_64041439 world, C_40996800 player);
	}

	private record Props(int health, boolean meat, OnEaten onEaten) {
	}

	private static final Map<C_98888256, Props> FOODS = new HashMap<>();

	private RetroFood() {
	}

	/** Registers an item as food restoring {@code health} points, with an optional eat effect. */
	public static void register(C_98888256 item, int health, boolean meat, OnEaten onEaten) {
		FOODS.put(item, new Props(health, meat, onEaten));
	}

	public static boolean isFood(C_98888256 item) {
		return FOODS.containsKey(item);
	}

	public static boolean isMeat(C_98888256 item) {
		Props p = FOODS.get(item);
		return p != null && p.meat;
	}

	/** Eats one from the stack: heal, then run the effect. Called by the use hook in ItemMixin. */
	public static C_88708284 eat(C_88708284 stack, C_64041439 world, C_40996800 player) {
		Props props = FOODS.get(stack.m_23235460());
		if (props == null) {
			return stack;
		}
		stack.f_60602012--;
		player.m_36201314(props.health);
		if (props.onEaten != null) {
			props.onEaten.onEaten(stack, world, player);
		}
		return stack;
	}
}
