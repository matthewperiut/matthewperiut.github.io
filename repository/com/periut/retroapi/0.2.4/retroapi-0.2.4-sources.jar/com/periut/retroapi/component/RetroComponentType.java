package com.periut.retroapi.component;

import net.minecraft.unmapped.C_74087615;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;

/**
 * A typed, persistent piece of data that can live on an ItemStack, the beta port of
 * modern Minecraft's {@code DataComponentType}.
 *
 * <p>Beta ItemStacks have NO nbt of their own, just id/count/damage, so "extra data on
 * an item" did not exist before. This (with {@link RetroComponents}) adds it the modern
 * way: instead of poking raw nbt tags, you declare a typed component once and then
 * {@code get}/{@code set} it on any stack. The {@link Serializer} is the equivalent of
 * the modern {@code persistent(codec)} call; it says how the value is written to and read
 * from nbt for saving (and, on a dedicated server, the network).</p>
 *
 * @param <T> the value type this component holds
 */
public final class RetroComponentType<T> {

	/** Reads/writes a component value to nbt under a key. The beta-era stand-in for a Codec. */
	public interface Serializer<T> {
		void write(C_74087615 nbt, String key, T value);

		T read(C_74087615 nbt, String key);
	}

	private final NamespacedIdentifier id;
	private final T defaultValue;
	private final Serializer<T> serializer;

	RetroComponentType(NamespacedIdentifier id, T defaultValue, Serializer<T> serializer) {
		this.id = id;
		this.defaultValue = defaultValue;
		this.serializer = serializer;
	}

	public NamespacedIdentifier getId() {
		return this.id;
	}

	public T getDefault() {
		return this.defaultValue;
	}

	public Serializer<T> getSerializer() {
		return this.serializer;
	}

	@Override
	public String toString() {
		return "RetroComponentType[" + this.id + "]";
	}

	// ------------------------------------------------------- built-in serializers --

	public static final Serializer<Integer> INT = new Serializer<Integer>() {
		public void write(C_74087615 nbt, String key, Integer value) {
			nbt.m_20318863(key, value);
		}

		public Integer read(C_74087615 nbt, String key) {
			return nbt.m_35587574(key);
		}
	};

	public static final Serializer<Float> FLOAT = new Serializer<Float>() {
		public void write(C_74087615 nbt, String key, Float value) {
			nbt.m_72136054(key, value);
		}

		public Float read(C_74087615 nbt, String key) {
			return nbt.m_93225250(key);
		}
	};

	public static final Serializer<Boolean> BOOL = new Serializer<Boolean>() {
		public void write(C_74087615 nbt, String key, Boolean value) {
			nbt.m_11270099(key, value);
		}

		public Boolean read(C_74087615 nbt, String key) {
			return nbt.m_25255788(key);
		}
	};

	public static final Serializer<String> STRING = new Serializer<String>() {
		public void write(C_74087615 nbt, String key, String value) {
			nbt.m_91017064(key, value);
		}

		public String read(C_74087615 nbt, String key) {
			return nbt.m_47517355(key);
		}
	};

	public static final Serializer<Long> LONG = new Serializer<Long>() {
		public void write(C_74087615 nbt, String key, Long value) {
			nbt.m_94086206(key, value);
		}

		public Long read(C_74087615 nbt, String key) {
			return nbt.m_76179339(key);
		}
	};

	public static final Serializer<Double> DOUBLE = new Serializer<Double>() {
		public void write(C_74087615 nbt, String key, Double value) {
			nbt.m_66750483(key, value);
		}

		public Double read(C_74087615 nbt, String key) {
			return nbt.m_61702839(key);
		}
	};

	/** An item reference (the id string), the beta stand-in for modern's item-holder components. */
	public static final Serializer<net.minecraft.unmapped.C_98888256> ITEM = new Serializer<net.minecraft.unmapped.C_98888256>() {
		public void write(C_74087615 nbt, String key, net.minecraft.unmapped.C_98888256 value) {
			nbt.m_20318863(key, value == null ? -1 : value.f_57562535);
		}

		public net.minecraft.unmapped.C_98888256 read(C_74087615 nbt, String key) {
			int id = nbt.m_35587574(key);
			return id >= 0 && id < net.minecraft.unmapped.C_98888256.f_38445253.length ? net.minecraft.unmapped.C_98888256.f_38445253[id] : null;
		}
	};

	/**
	 * A raw {@link C_74087615}: store any structured nbt straight in a component, the escape
	 * hatch when no typed serializer fits. (Prefer a typed {@link #compound} for real data, but
	 * this is here for free-form or pre-built nbt.)
	 */
	public static final Serializer<C_74087615> NBT = new Serializer<C_74087615>() {
		public void write(C_74087615 nbt, String key, C_74087615 value) {
			nbt.m_18682924(key, value == null ? new C_74087615() : value);
		}

		public C_74087615 read(C_74087615 nbt, String key) {
			return nbt.m_81819352(key);
		}
	};

	/**
	 * A whole {@link net.minecraft.unmapped.C_88708284}: id, count, damage, AND the stack's own
	 * components. So a component can hold an item that itself carries components. Combine with
	 * {@link #listOf} to keep a full INVENTORY in one component:
	 * {@code RetroComponentType.listOf(RetroComponentType.ITEM_STACK)} is a {@code List<ItemStack>}.
	 */
	public static final Serializer<net.minecraft.unmapped.C_88708284> ITEM_STACK = new Serializer<net.minecraft.unmapped.C_88708284>() {
		public void write(C_74087615 nbt, String key, net.minecraft.unmapped.C_88708284 value) {
			C_74087615 sub = new C_74087615();
			if (value != null) {
				sub.m_20318863("id", value.f_59294634);
				sub.m_20318863("count", value.f_60602012);
				sub.m_20318863("damage", value.m_21098843());
				ComponentNbt.write((RetroComponentHolder) (Object) value, sub);
			}
			nbt.m_18682924(key, sub);
		}

		public net.minecraft.unmapped.C_88708284 read(C_74087615 nbt, String key) {
			C_74087615 sub = nbt.m_81819352(key);
			if (sub == null || !sub.m_97612750("id")) {
				return null;
			}
			net.minecraft.unmapped.C_88708284 stack = new net.minecraft.unmapped.C_88708284(
				sub.m_35587574("id"), sub.m_35587574("count"), sub.m_35587574("damage"));
			ComponentNbt.read((RetroComponentHolder) (Object) stack, sub);
			return stack;
		}
	};

	/**
	 * Builds a serializer for a composite value (a record, say) from a pair of functions
	 * that read/write the value into its own sub-compound, the beta-era equivalent of a
	 * {@code RecordCodecBuilder}. This is how you store multi-field component data, the
	 * fabric-docs "advanced" component (temperature + burnt) is exactly this shape.
	 */
	public static <T> Serializer<T> compound(java.util.function.BiConsumer<C_74087615, T> writer,
			java.util.function.Function<C_74087615, T> reader) {
		return new Serializer<T>() {
			public void write(C_74087615 nbt, String key, T value) {
				C_74087615 sub = new C_74087615();
				writer.accept(sub, value);
				nbt.m_18682924(key, sub);
			}

			public T read(C_74087615 nbt, String key) {
				return reader.apply(nbt.m_81819352(key));
			}
		};
	}

	/**
	 * Builds a serializer for a {@code List<E>} from an element serializer, the beta-era
	 * equivalent of {@code Codec.list(...)}. The list rides as an nbt list of compounds,
	 * each element written under the fixed key {@code "v"}.
	 */
	public static <E> Serializer<java.util.List<E>> listOf(Serializer<E> element) {
		return new Serializer<java.util.List<E>>() {
			public void write(C_74087615 nbt, String key, java.util.List<E> value) {
				net.minecraft.unmapped.C_79370641 list = new net.minecraft.unmapped.C_79370641();
				for (E item : value) {
					C_74087615 entry = new C_74087615();
					element.write(entry, "v", item);
					list.m_43125067(entry);
				}
				nbt.m_21770494(key, list);
			}

			public java.util.List<E> read(C_74087615 nbt, String key) {
				java.util.List<E> result = new java.util.ArrayList<>();
				net.minecraft.unmapped.C_79370641 list = nbt.m_95654166(key);
				if (list != null) {
					for (int i = 0; i < list.m_89439680(); i++) {
						result.add(element.read((C_74087615) list.m_59132367(i), "v"));
					}
				}
				return result;
			}
		};
	}
}
