package com.periut.retroapi.voxelshapes;

import java.util.Arrays;
import net.minecraft.unmapped.C_82690114;

/**
 * One immutable box of a {@link VoxelShape}, coordinates in block space (0-1, values
 * outside are allowed). Ported from matthewperiut/voxelshapes.
 */
public record VoxelBox(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {

	public static VoxelBox voxelify(C_82690114 box) {
		return new VoxelBox(box.f_87518512, box.f_80314167, box.f_85940458, box.f_89130367, box.f_98553650, box.f_24562106);
	}

	public static VoxelBox[] voxelify(C_82690114[] boxes) {
		return Arrays.stream(boxes).map(VoxelBox::voxelify).toArray(VoxelBox[]::new);
	}

	public static C_82690114 devoxelify(VoxelBox voxelBox) {
		return C_82690114.m_23878395(voxelBox.minX, voxelBox.minY, voxelBox.minZ, voxelBox.maxX, voxelBox.maxY, voxelBox.maxZ);
	}

	public static C_82690114[] devoxelify(VoxelBox[] voxelBoxes) {
		return Arrays.stream(voxelBoxes).map(VoxelBox::devoxelify).toArray(C_82690114[]::new);
	}

	public VoxelBox add(double minX, double minY, double minZ, double maxX, double maxY, double maxZ) {
		return new VoxelBox(this.minX + minX, this.minY + minY, this.minZ + minZ,
			this.maxX + maxX, this.maxY + maxY, this.maxZ + maxZ);
	}

	public VoxelBox add(VoxelBox other) {
		return new VoxelBox(this.minX + other.minX, this.minY + other.minY, this.minZ + other.minZ,
			this.maxX + other.maxX, this.maxY + other.maxY, this.maxZ + other.maxZ);
	}
}
