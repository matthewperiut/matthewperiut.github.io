package com.periut.retroapi.mixin.client;

import com.periut.retroapi.RetroAPI;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_34859172;
import net.minecraft.unmapped.C_40996800;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_34859172.class)
@Environment(EnvType.CLIENT)
public class PlayerRendererMixin {

	@Unique
	private int retroapi$helmetItemId = 0;

	@Unique
	private int retroapi$heldItemId = 0;

	@Inject(
		method = "renderMore(Lnet/minecraft/entity/player/PlayerEntity;F)V",
		at = @At("HEAD")
	)
	private void retroapi$captureItemIds(C_40996800 player, float tickDelta, CallbackInfo ci) {
		// Capture helmet item id (armor slot 3 = head)
		if (player.f_29439708.f_52412003[3] != null) {
			retroapi$helmetItemId = player.f_29439708.f_52412003[3].m_23235460().f_57562535;
		} else {
			retroapi$helmetItemId = 0;
		}
		// Capture held item id
		if (player.f_29439708.m_27760697() != null) {
			retroapi$heldItemId = player.f_29439708.m_27760697().f_59294634;
		} else {
			retroapi$heldItemId = 0;
		}
	}

	@ModifyConstant(
		method = "renderMore(Lnet/minecraft/entity/player/PlayerEntity;F)V",
		constant = @Constant(intValue = 256, ordinal = 0)
	)
	private int retroapi$fixHelmetBlockCheck(int original) {
		if (RetroAPI.isBlock(retroapi$helmetItemId)) {
			return retroapi$helmetItemId + 1;
		}
		return original;
	}

	@ModifyConstant(
		method = "renderMore(Lnet/minecraft/entity/player/PlayerEntity;F)V",
		constant = @Constant(intValue = 256, ordinal = 1)
	)
	private int retroapi$fixHeldBlockCheck(int original) {
		if (RetroAPI.isBlock(retroapi$heldItemId)) {
			return retroapi$heldItemId + 1;
		}
		return original;
	}
}
