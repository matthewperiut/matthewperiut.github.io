package com.periut.retroapi.dimension.server;

import com.periut.retroapi.dimension.DimensionTeleporter;
import net.minecraft.server.MinecraftServer;
import net.minecraft.unmapped.C_04694721;
import net.minecraft.unmapped.C_29639016;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_70668269;
import net.minecraft.unmapped.C_87391831;

/**
 * Server-side dimension teleport - RetroAPI's own generalisation of vanilla
 * {@code PlayerManager.changePlayerDimension} over an arbitrary destination + scale. Touches
 * server-only classes ({@code ServerPlayerEntity}, {@code MinecraftServer}, {@code PlayerManager},
 * {@code ServerWorld}), so it is only ever referenced/loaded from the server entrypoint
 * ({@code RetroAPIServer}); the client never loads it.
 */
public final class ServerTeleporter implements DimensionTeleporter {
	@Override
	public void teleport(C_40996800 playerEntity, int target, int moddedDim, double coordFactor, C_87391831 agent) {
		C_49202226 player = (C_49202226) playerEntity;
		MinecraftServer server = player.f_69312484;
		C_29639016 playerManager = server.f_65897993;
		C_70668269 oldWorld = server.m_54705229(player.f_15409937);
		player.f_15409937 = target;
		C_70668269 newWorld = server.m_54705229(target);

		player.f_70275341.m_61088315(new C_04694721((byte) target));
		oldWorld.m_31627685(player);
		player.f_42219270 = false;

		double x = player.f_78826675 * coordFactor;
		double z = player.f_97691941 * coordFactor;
		player.m_12877971(x, player.f_31030949, z, player.f_80130373, player.f_03549461);
		if (player.m_48190713()) {
			oldWorld.m_15238577(player, false);
		}

		if (player.m_48190713()) {
			newWorld.m_09670988(player);
			player.m_12877971(x, player.f_31030949, z, player.f_80130373, player.f_03549461);
			newWorld.m_15238577(player, false);
			newWorld.f_55499904.f_95421973 = true;
			agent.m_72853764(newWorld, player);
			newWorld.f_55499904.f_95421973 = false;
		}

		playerManager.m_31698239(player);
		player.f_70275341.m_40197477(player.f_78826675, player.f_31030949, player.f_97691941, player.f_80130373, player.f_03549461);
		player.m_67289058(newWorld);
		playerManager.m_18431033(player, newWorld);
		playerManager.m_44114554(player);
	}
}
