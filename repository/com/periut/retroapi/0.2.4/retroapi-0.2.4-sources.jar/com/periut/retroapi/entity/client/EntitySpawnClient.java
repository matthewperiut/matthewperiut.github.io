package com.periut.retroapi.entity.client;

import com.periut.retroapi.RetroAPI;
import com.periut.retroapi.entity.EntityRegistration;
import com.periut.retroapi.entity.spawn.RetroEntitySpawnData;
import com.periut.retroapi.entity.spawn.RetroHasOwner;
import com.periut.retroapi.entity.spawn.RetroMobSpawnData;
import com.periut.retroapi.mixin.entity.client.ClientNetworkHandlerAccessor;
import com.periut.retroapi.registry.RetroRegistry;
import net.minecraft.unmapped.C_34399650;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_61027059;
import net.minecraft.unmapped.C_74425583;
import net.ornithemc.osl.networking.api.PacketBuffer;
import net.ornithemc.osl.networking.api.client.ClientPacketListener;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;

/**
 * Client-side spawn handlers for {@link com.periut.retroapi.network.RetroAPINetworking#ENTITY_SPAWN_CHANNEL}
 * and {@code ENTITY_SPAWN_MOB_CHANNEL}. Reconstructs the modded entity and registers it under the server's id
 * via {@link C_34399650#m_34714727}, so subsequent vanilla position/velocity/despawn packets drive it.
 * Reads fields in the exact order {@link com.periut.retroapi.entity.EntitySpawnCodec} writes them. Mirrors
 * StationAPI's {@code EntityClientNetworkHandler}.
 */
public final class EntitySpawnClient {
	private EntitySpawnClient() {}

	public static void handleEntitySpawn(ClientPacketListener.Context ctx, PacketBuffer buf) throws IOException {
		ctx.ensureOnMainThread(); // reschedules onto the main thread, then re-runs here

		String handler = buf.readString();
		int id = buf.readVarInt();
		int tx = buf.readInt(), ty = buf.readInt(), tz = buf.readInt();
		int ownerId = buf.readVarInt();
		double vx = 0, vy = 0, vz = 0;
		if (ownerId > 0) {
			vx = buf.readShort() / 8000.0D;
			vy = buf.readShort() / 8000.0D;
			vz = buf.readShort() / 8000.0D;
		}
		boolean sync = buf.readBoolean();
		byte[] trackerBytes = sync ? buf.readByteArray() : null;

		EntityRegistration reg = RetroRegistry.getEntityByStringId(handler);
		if (reg == null || (reg.getEntityFactory() == null && reg.getSimpleEntityFactory() == null)) {
			RetroAPI.LOGGER.warn("No entity factory for spawn handler {}", handler);
			return;
		}
		C_34399650 world = (C_34399650) ctx.minecraft().f_26407825;
		if (world == null) return;

		C_42232651 e;
		if (reg.getEntityFactory() != null) {
			// Constructor takes the spawn coordinates.
			e = reg.getEntityFactory().create(world, tx / 32.0D, ty / 32.0D, tz / 32.0D);
		} else {
			// World-only constructor: apply the position from the packet after construction.
			e = reg.getSimpleEntityFactory().create(world);
			if (e != null) e.m_03000503(tx / 32.0D, ty / 32.0D, tz / 32.0D, 0.0F, 0.0F);
		}
		if (e == null) return;
		e.f_16319839 = tx;
		e.f_59722398 = ty;
		e.f_79826809 = tz;
		e.f_80130373 = 0.0F;
		e.f_03549461 = 0.0F;
		e.f_11112215 = id;
		world.m_34714727(id, e);

		if (ownerId > 0) {
			if (e instanceof RetroHasOwner owned) {
				owned.setOwner(((ClientNetworkHandlerAccessor) ctx.networkHandler()).retroapi$getEntity(ownerId));
			}
			e.m_04637244(vx, vy, vz);
		}
		if (trackerBytes != null) {
			e.m_82885919().m_47989627(C_61027059.m_63048531(toStream(trackerBytes)));
		}
		if (e instanceof RetroEntitySpawnData provider) {
			provider.readExtra(buf);
		}
	}

	public static void handleMobSpawn(ClientPacketListener.Context ctx, PacketBuffer buf) throws IOException {
		ctx.ensureOnMainThread();

		String handler = buf.readString();
		int id = buf.readVarInt();
		int tx = buf.readInt(), ty = buf.readInt(), tz = buf.readInt();
		float yaw = buf.readByte() * 360 / 256.0F;
		float pitch = buf.readByte() * 360 / 256.0F;
		byte[] trackerBytes = buf.readByteArray();

		EntityRegistration reg = RetroRegistry.getEntityByStringId(handler);
		if (reg == null || reg.getMobFactory() == null) {
			RetroAPI.LOGGER.warn("No mob factory for spawn handler {}", handler);
			return;
		}
		C_34399650 world = (C_34399650) ctx.minecraft().f_26407825;
		if (world == null) return;

		C_74425583 mob = reg.getMobFactory().create(world);
		if (mob == null) return;
		mob.f_16319839 = tx;
		mob.f_59722398 = ty;
		mob.f_79826809 = tz;
		mob.f_11112215 = id;
		mob.m_03000503(tx / 32.0D, ty / 32.0D, tz / 32.0D, yaw, pitch);
		mob.f_08305162 = true;
		world.m_34714727(id, mob);
		mob.m_82885919().m_47989627(C_61027059.m_63048531(toStream(trackerBytes)));

		if (mob instanceof RetroMobSpawnData provider) {
			provider.readExtra(buf);
		}
	}

	private static DataInputStream toStream(byte[] bytes) {
		return new DataInputStream(new ByteArrayInputStream(bytes));
	}
}
