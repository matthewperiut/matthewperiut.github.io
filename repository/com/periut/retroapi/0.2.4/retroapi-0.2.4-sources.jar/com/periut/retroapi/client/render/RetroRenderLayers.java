package com.periut.retroapi.client.render;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.unmapped.C_81592558;

/**
 * Per-block render layer assignment, read by the {@code Block.getRenderLayer()} mixin.
 * Code-side: {@code RetroRenderLayers.set(block, RetroRenderLayer.TRANSLUCENT)};
 * data-side: {@code "render_layer": "translucent"} in the blockstate JSON.
 *
 * <p>Environment-neutral on purpose (no client imports), so blockstate JSON parsing can
 * run in common init on a dedicated server too.</p>
 */
public final class RetroRenderLayers {

	private static final Map<C_81592558, RetroRenderLayer> LAYERS = new HashMap<>();

	private RetroRenderLayers() {}

	public static void set(C_81592558 block, RetroRenderLayer layer) {
		LAYERS.put(block, layer);
	}

	/** The assigned layer, or null when the block uses vanilla's own getRenderLayer. */
	public static RetroRenderLayer get(C_81592558 block) {
		return LAYERS.get(block);
	}
}
