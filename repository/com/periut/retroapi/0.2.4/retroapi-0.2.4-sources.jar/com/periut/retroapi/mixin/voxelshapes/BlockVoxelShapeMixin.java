package com.periut.retroapi.mixin.voxelshapes;

import com.periut.retroapi.voxelshapes.HasCollisionVoxelShape;
import com.periut.retroapi.voxelshapes.HasVoxelShape;
import com.periut.retroapi.voxelshapes.VoxelShape;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_94584382;

@Mixin(C_81592558.class)
public class BlockVoxelShapeMixin {
    @Inject(method = "addIntersectingBoundingBox(Lnet/minecraft/world/World;IIILnet/minecraft/util/math/Box;Ljava/util/ArrayList;)V", at = @At("HEAD"), cancellable = true)
    private void retroapi$addVoxelShapesToCollision(C_64041439 world, int x, int y, int z, C_82690114 box, ArrayList<C_82690114> boxes, CallbackInfo ci) {
        if (this instanceof HasCollisionVoxelShape hasCollisionVoxelShape) {
            VoxelShape collisionVoxelShape = hasCollisionVoxelShape.getCollisionVoxelShape(world, x, y, z);
            if (collisionVoxelShape != null) boxes.addAll(collisionVoxelShape.getOffsetBoxes());
            ci.cancel();
        } else if (this instanceof HasVoxelShape hasVoxelShape) {
            VoxelShape voxelShape = hasVoxelShape.getVoxelShape(world, x, y, z);
            if (voxelShape != null) boxes.addAll(voxelShape.getOffsetBoxes());
            ci.cancel();
        }
    }

    @Inject(method = "raycast(Lnet/minecraft/world/World;IIILnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/hit/HitResult;", at = @At("HEAD"), cancellable = true)
    private void retroapi$allowMineThroughBlock(C_64041439 world, int x, int y, int z, C_94584382 startPos, C_94584382 endPos, CallbackInfoReturnable<C_24654288> cir) {
        if (this instanceof HasVoxelShape hasVoxelShape) {
            startPos = startPos.m_88858529(-x, -y, -z);
            endPos = endPos.m_88858529(-x, -y, -z);
            VoxelShape voxelShape = hasVoxelShape.getVoxelShape(world, x, y, z);
            if (voxelShape == null) return;
            for (C_82690114 box : voxelShape.getBoxes()) {
                C_94584382 northVec = startPos.m_36803764(endPos, box.f_87518512);
                C_94584382 southVec = startPos.m_36803764(endPos, box.f_89130367);
                C_94584382 downVec = startPos.m_68053983(endPos, box.f_80314167);
                C_94584382 upVec = startPos.m_68053983(endPos, box.f_98553650);
                C_94584382 eastVec = startPos.m_90042859(endPos, box.f_85940458);
                C_94584382 westVec = startPos.m_90042859(endPos, box.f_24562106);

                if (!retroapi$containsInYZPlane(box, northVec)) northVec = null;
                if (!retroapi$containsInYZPlane(box, southVec)) southVec = null;
                if (!retroapi$containsInXZPlane(box, downVec)) downVec = null;
                if (!retroapi$containsInXZPlane(box, upVec)) upVec = null;
                if (!retroapi$containsInXYPlane(box, eastVec)) eastVec = null;
                if (!retroapi$containsInXYPlane(box, westVec)) westVec = null;


                C_94584382 hitPos = null;
                if (northVec != null && (hitPos == null || startPos.m_74339345(northVec) < startPos.m_74339345(hitPos))) {
                    hitPos = northVec;
                }

                if (southVec != null && (hitPos == null || startPos.m_74339345(southVec) < startPos.m_74339345(hitPos))) {
                    hitPos = southVec;
                }

                if (downVec != null && (hitPos == null || startPos.m_74339345(downVec) < startPos.m_74339345(hitPos))) {
                    hitPos = downVec;
                }

                if (upVec != null && (hitPos == null || startPos.m_74339345(upVec) < startPos.m_74339345(hitPos))) {
                    hitPos = upVec;
                }

                if (eastVec != null && (hitPos == null || startPos.m_74339345(eastVec) < startPos.m_74339345(hitPos))) {
                    hitPos = eastVec;
                }

                if (westVec != null && (hitPos == null || startPos.m_74339345(westVec) < startPos.m_74339345(hitPos))) {
                    hitPos = westVec;
                }

                if (hitPos != null) {
                    byte side = -1;
                    if (hitPos == northVec) side = 4;
                    if (hitPos == southVec) side = 5;
                    if (hitPos == downVec) side = 0;
                    if (hitPos == upVec) side = 1;
                    if (hitPos == eastVec) side = 2;
                    if (hitPos == westVec) side = 3;

                    cir.setReturnValue(new C_24654288(x, y, z, side, hitPos.m_88858529(x, y, z)));
                    return;
                }
            }
            cir.setReturnValue(null);
        }
    }

    @Unique
    private boolean retroapi$containsInYZPlane(C_82690114 box, C_94584382 vec3d) {
        if (vec3d == null) {
            return false;
        } else {
            return vec3d.f_95060918 >= box.f_80314167 && vec3d.f_95060918 <= box.f_98553650 && vec3d.f_88390642 >= box.f_85940458 && vec3d.f_88390642 <= box.f_24562106;
        }
    }

    @Unique
    private boolean retroapi$containsInXZPlane(C_82690114 box, C_94584382 vec3d) {
        if (vec3d == null) {
            return false;
        } else {
            return vec3d.f_96140729 >= box.f_87518512 && vec3d.f_96140729 <= box.f_89130367 && vec3d.f_88390642 >= box.f_85940458 && vec3d.f_88390642 <= box.f_24562106;
        }
    }

    @Unique
    private boolean retroapi$containsInXYPlane(C_82690114 box, C_94584382 vec3d) {
        if (vec3d == null) {
            return false;
        } else {
            return vec3d.f_96140729 >= box.f_87518512 && vec3d.f_96140729 <= box.f_89130367 && vec3d.f_95060918 >= box.f_80314167 && vec3d.f_95060918 <= box.f_98553650;
        }
    }
}
