package com.periut.retroapi.mixin.recipe;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.unmapped.C_13858042;
import net.minecraft.unmapped.C_88708284;

@Mixin(C_13858042.class)
public interface SmeltingManagerAccessor {
	@Accessor("recipes")
	Map<Integer, C_88708284> retroapi$getRecipes();
}

