package com.periut.retroapi.storage;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_79370641;

/**
 * Safe-reset persistence for a player's current dimension.
 *
 * <p>b1.7.3 saves {@code player.dimensionId} (and position) as raw values in player NBT; a modded
 * {@code Dimension} (&ge; 2) would crash vanilla's {@code Dimension.fromId} on load, and the modded
 * coordinates would drop the player into the void of the overworld. So on save we clamp the vanilla
 * NBT to a safe overworld state - {@code Dimension = 0} and position = the world spawn - and record the
 * real modded dimension + the EXACT position/rotation doubles vanilla wrote, here in
 * {@code retroapi/dimensions.dat}. On a RetroAPI load, {@code PlayerDimensionMixin} injects these values
 * back into the NBT compound at {@code readNbt} HEAD, so vanilla's own loading path parses them as if
 * they had always been in the file - no post-load repositioning.
 *
 * <p>Entries are stored as a {@code players} {@link C_79370641} of {@code {name, dim, x, y, z, yaw, pitch}}
 * compounds - avoids b1.7.3's lack of an NBT-compound key-iteration/removal API. The root compound is
 * cached in RAM (one disk read per world) and persisted through {@link SidecarIo} (atomic + async).
 */
public class PlayerDimensionSidecar {
	private static final Logger LOGGER = LogManager.getLogger("RetroAPI/DimensionSidecar");

	private static C_74087615 cachedRoot;
	private static File cachedFile;

	/** A player's recorded modded dimension and real position/rotation. */
	public static final class Entry {
		public final int dimensionId;
		public final double x;
		public final double y;
		public final double z;
		public final boolean hasRotation;
		public final float yaw;
		public final float pitch;

		public Entry(int dimensionId, double x, double y, double z, boolean hasRotation, float yaw, float pitch) {
			this.dimensionId = dimensionId;
			this.x = x;
			this.y = y;
			this.z = z;
			this.hasRotation = hasRotation;
			this.yaw = yaw;
			this.pitch = pitch;
		}
	}

	/** Drop the RAM cache (world switch - called from {@code SidecarManager.flush}). */
	public static void reset() {
		cachedRoot = null;
		cachedFile = null;
	}

	private static File file() {
		File worldDir = SidecarManager.getWorldDir();
		return worldDir == null ? null : new File(worldDir, "retroapi/dimensions.dat");
	}

	private static C_74087615 root(File f) {
		if (cachedRoot != null && f.equals(cachedFile)) {
			return cachedRoot;
		}
		C_74087615 root = new C_74087615();
		if (f.exists()) {
			try (FileInputStream fis = new FileInputStream(f)) {
				root = C_08565163.m_38706312(fis);
			} catch (IOException e) {
				LOGGER.error("Failed to read {}", f, e);
			}
		}
		cachedRoot = root;
		cachedFile = f;
		return root;
	}

	/** Record (replacing any prior entry) the real modded dimension + exact saved position/rotation. */
	public static void recordPlayer(String name, int dimensionId, double x, double y, double z, float yaw, float pitch) {
		File f = file();
		if (f == null) return;
		C_74087615 root = root(f);
		C_79370641 players = without(root, name);
		C_74087615 entry = new C_74087615();
		entry.m_91017064("name", name);
		entry.m_20318863("dim", dimensionId);
		entry.m_66750483("x", x);
		entry.m_66750483("y", y);
		entry.m_66750483("z", z);
		entry.m_72136054("yaw", yaw);
		entry.m_72136054("pitch", pitch);
		players.m_43125067(entry);
		root.m_21770494("players", players);
		persist(f, root);
	}

	/** Drop any recorded modded dimension for a player (they are back in a vanilla dimension). */
	public static void removePlayer(String name) {
		File f = file();
		if (f == null) return;
		C_74087615 root = root(f);
		if (!root.m_97612750("players")) return;
		root.m_21770494("players", without(root, name));
		persist(f, root);
	}

	/** The recorded modded dimension + position for a player, or {@code null} if none. */
	public static Entry getPlayer(String name) {
		File f = file();
		if (f == null) return null;
		C_74087615 root = root(f);
		if (!root.m_97612750("players")) return null;
		C_79370641 players = root.m_95654166("players");
		for (int i = 0; i < players.m_89439680(); i++) {
			C_74087615 entry = (C_74087615) players.m_59132367(i);
			if (name.equals(entry.m_47517355("name"))) {
				// Rotation was added later; entries from older saves fall back to "leave NBT as-is".
				boolean hasRotation = entry.m_97612750("yaw");
				return new Entry(entry.m_35587574("dim"), entry.m_61702839("x"), entry.m_61702839("y"), entry.m_61702839("z"),
						hasRotation, entry.m_93225250("yaw"), entry.m_93225250("pitch"));
			}
		}
		return null;
	}

	private static C_79370641 without(C_74087615 root, String excludeName) {
		C_79370641 result = new C_79370641();
		if (root.m_97612750("players")) {
			C_79370641 players = root.m_95654166("players");
			for (int i = 0; i < players.m_89439680(); i++) {
				C_74087615 entry = (C_74087615) players.m_59132367(i);
				if (!excludeName.equals(entry.m_47517355("name"))) {
					result.m_43125067(entry);
				}
			}
		}
		return result;
	}

	private static void persist(File f, C_74087615 root) {
		try {
			SidecarIo.writeAsync(f, SidecarIo.snapshot(root));
		} catch (IOException e) {
			LOGGER.error("Failed to snapshot {}", f, e);
		}
	}
}
