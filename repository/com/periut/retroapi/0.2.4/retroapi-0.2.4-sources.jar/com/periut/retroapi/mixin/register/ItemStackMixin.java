package com.periut.retroapi.mixin.register;

import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;
import net.ornithemc.osl.core.api.util.NamespacedIdentifiers;
import com.periut.retroapi.registry.BlockRegistration;
import com.periut.retroapi.registry.ItemRegistration;
import com.periut.retroapi.registry.RetroRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * The numeric-id flattening half of the ItemStack mixin: persists a RetroAPI item/block stack as a string
 * id ({@code retroapi:id} + original count/damage) and clamps the vanilla {@code id}/{@code Count} to empty
 * so a vanilla save never sees a bogus stack, resolving it back on read. This is the half that CLASHES with
 * StationAPI (which owns id flattening via {@code stationapi:id}), so it is in
 * {@code RetroAPIMixinPlugin}'s StationAPI-disabled set. Data components were split out to
 * {@link com.periut.retroapi.mixin.component.ItemStackComponentMixin}, which stays active under StationAPI.
 */
@Mixin(C_88708284.class)
public class ItemStackMixin {

	@Shadow public int itemId;
	@Shadow public int count;
	@Shadow public int damage;

	@Inject(method = "writeNbt", at = @At("RETURN"))
	private void retroapi$writeNbt(C_74087615 nbt, CallbackInfoReturnable<C_74087615> cir) {
		String stringId = resolveStringId(this.itemId);
		if (stringId != null) {
			nbt.m_91017064("retroapi:id", stringId);
			// Save original values so the sidecar can read them after clamping
			nbt.m_41884431("retroapi:count", (byte) this.count);
			nbt.m_98335007("retroapi:damage", (short) this.damage);
			// Clamp to empty so vanilla sees nothing (avoids stone appearing in inventories)
			nbt.m_98335007("id", (short) 0);
			nbt.m_41884431("Count", (byte) 0);
		}
	}

	@Inject(method = "readNbt", at = @At("RETURN"))
	private void retroapi$readNbt(C_74087615 nbt, CallbackInfo ci) {
		// Try retroapi:id first, then fall back to stationapi:id (for worlds un-converted from StationAPI)
		String stringId = null;
		if (nbt.m_97612750("retroapi:id")) {
			stringId = nbt.m_47517355("retroapi:id");
		} else if (nbt.m_97612750("stationapi:id")) {
			stringId = nbt.m_47517355("stationapi:id");
		}

		if (stringId == null || stringId.isEmpty()) return;

		String[] parts = stringId.split(":", 2);
		if (parts.length != 2) return;

		NamespacedIdentifier retroId = NamespacedIdentifiers.from(parts[0], parts[1]);

		BlockRegistration blockReg = RetroRegistry.getBlockById(retroId);
		if (blockReg != null) {
			this.itemId = blockReg.getBlock().f_84602679;
		} else {
			ItemRegistration itemReg = RetroRegistry.getItemById(retroId);
			if (itemReg != null) {
				this.itemId = itemReg.getItem().f_57562535;
			} else {
				// Not a RetroAPI item (could be vanilla stationapi:id like "minecraft:stone") - leave as-is
				return;
			}
		}

		// Restore count and damage from retroapi tags (vanilla readNbt set them to clamped values)
		if (nbt.m_97612750("retroapi:count")) {
			this.count = nbt.m_84056038("retroapi:count") & 0xFF;
		}
		if (nbt.m_97612750("retroapi:damage")) {
			this.damage = nbt.m_03599456("retroapi:damage");
		}
	}

	private static String resolveStringId(int numericId) {
		if (numericId >= 0 && numericId < C_81592558.f_44428008.length) {
			C_81592558 block = C_81592558.f_44428008[numericId];
			if (block != null) {
				BlockRegistration reg = RetroRegistry.getBlockRegistration(block);
				if (reg != null) return reg.getId().toString();
			}
		}
		if (numericId >= 0 && numericId < C_98888256.f_38445253.length) {
			C_98888256 item = C_98888256.f_38445253[numericId];
			if (item != null) {
				ItemRegistration reg = RetroRegistry.getItemRegistration(item);
				if (reg != null) return reg.getId().toString();
			}
		}
		return null;
	}
}
