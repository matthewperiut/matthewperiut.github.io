package com.periut.retroapi.voxelshapes;

import java.util.List;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_94584382;

public class VoxelShape {
    private final VoxelData voxelData;
    private final VoxelVec3d offset;

    protected VoxelShape(VoxelData voxelData, VoxelVec3d offset) {
        this.voxelData = voxelData;
        this.offset = offset;
    }

    public List<C_82690114> getOffsetBoxes() {
        return voxelData.getBoxes().stream().map((box) -> box.m_64578311(offset.x(), offset.y(), offset.z())).toList();
    }

    public List<VoxelBox> getVoxelBoxes() {
        return voxelData.getVoxelBoxes();
    }

    public List<C_82690114> getBoxes() {
        return voxelData.getBoxes();
    }

    public List<Line> getLines() {
        return voxelData.getLines();
    }

    public VoxelVec3d getVoxelOffset() {
        return offset;
    }

    public C_94584382 getOffset() {
        return VoxelVec3d.devoxelify(offset);
    }
}
