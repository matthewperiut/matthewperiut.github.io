package com.periut.retroapi.entity.client;

import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;

/**
 * Client-side factory for a living modded entity (mob). Mirrors StationAPI's
 * {@code Function<World, LivingEntity>} mob handler so an Aether port is a near-mechanical swap.
 */
@FunctionalInterface
public interface MobFactory {
	C_74425583 create(C_64041439 world);
}
