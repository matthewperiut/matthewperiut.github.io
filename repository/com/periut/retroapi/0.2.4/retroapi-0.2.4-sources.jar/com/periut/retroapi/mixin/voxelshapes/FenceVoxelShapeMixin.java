package com.periut.retroapi.mixin.voxelshapes;

import com.periut.retroapi.voxelshapes.HasCollisionVoxelShape;
import com.periut.retroapi.voxelshapes.HasVoxelShape;
import com.periut.retroapi.voxelshapes.VoxelData;
import com.periut.retroapi.voxelshapes.VoxelShape;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_89604096;
import net.minecraft.unmapped.C_89914243;
import com.periut.retroapi.voxelshapes.VoxelBox;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_89914243.class)
public abstract class FenceVoxelShapeMixin extends C_81592558 implements HasVoxelShape, HasCollisionVoxelShape {
    @Unique
    private static final VoxelBox retroapi$BASE_VOXEL_DATA = new VoxelBox(0.375F, 0, 0.375F, 0.625F, 1.F, 0.625F);
    @Unique
    private static final VoxelBox retroapi$BOX_NEG_X = new VoxelBox(0, 0, 0.375F, 0.375F, 1.F, 0.625F);
    @Unique
    private static final VoxelBox retroapi$BOX_POS_X = new VoxelBox(0.625F, 0, 0.375F, 1.F, 1.F, 0.625F);
    @Unique
    private static final VoxelBox retroapi$BOX_NEG_Z = new VoxelBox(0.375F, 0, 0, 0.625F, 1.F, 0.375F);
    @Unique
    private static final VoxelBox retroapi$BOX_POS_Z = new VoxelBox(0.375F, 0, 0.625F, 0.625F, 1.F, 1.F);
    @Unique
    private static final VoxelBox retroapi$COLLISION_MODIFIER = new VoxelBox(0, 0, 0, 0, 0.5, 0);

    @Unique
    private static final VoxelData[] retroapi$VOXEL_DATUM = new VoxelData[16];
    @Unique
    private static final VoxelData[] retroapi$COLLISION_DATUM = new VoxelData[16];

    static {
        for (int i = 0; i < 16; i++) {
            VoxelData voxelData = new VoxelData(retroapi$BASE_VOXEL_DATA);
            VoxelData collisionData = new VoxelData(retroapi$BASE_VOXEL_DATA.add(retroapi$COLLISION_MODIFIER));

            if ((i & 1) != 0) {
                voxelData = voxelData.withBox(retroapi$BOX_POS_Z);
                collisionData = collisionData.withBox(retroapi$BOX_POS_Z.add(retroapi$COLLISION_MODIFIER));
            }
            if ((i & 2) != 0) {
                voxelData = voxelData.withBox(retroapi$BOX_NEG_Z);
                collisionData = collisionData.withBox(retroapi$BOX_NEG_Z.add(retroapi$COLLISION_MODIFIER));
            }
            if ((i & 4) != 0) {
                voxelData = voxelData.withBox(retroapi$BOX_NEG_X);
                collisionData = collisionData.withBox(retroapi$BOX_NEG_X.add(retroapi$COLLISION_MODIFIER));
            }
            if ((i & 8) != 0) {
                voxelData = voxelData.withBox(retroapi$BOX_POS_X);
                collisionData = collisionData.withBox(retroapi$BOX_POS_X.add(retroapi$COLLISION_MODIFIER));
            }

            retroapi$VOXEL_DATUM[i] = voxelData.preCache();
            retroapi$COLLISION_DATUM[i] = collisionData;
        }
    }

    public FenceVoxelShapeMixin(int id, C_89604096 material) {
        super(id, material);
    }

    @Unique
    private int retroapi$getVoxelDatumIndex(C_64041439 world, int x, int y, int z) {
        boolean posX = world.m_33234383(x + 1, y, z) == f_84602679;
        boolean negX = world.m_33234383(x - 1, y, z) == f_84602679;
        boolean posZ = world.m_33234383(x, y, z + 1) == f_84602679;
        boolean negZ = world.m_33234383(x, y, z - 1) == f_84602679;

        int index = 0;
        if (posZ) index |= 1;
        if (negZ) index |= 2;
        if (negX) index |= 4;
        if (posX) index |= 8;

        return index;
    }

    @Override
    public VoxelShape getVoxelShape(C_64041439 world, int x, int y, int z) {
        return retroapi$VOXEL_DATUM[retroapi$getVoxelDatumIndex(world, x, y, z)].withOffset(x, y, z);
    }

    @Override
    public VoxelShape getCollisionVoxelShape(C_64041439 world, int x, int y, int z) {
        return retroapi$COLLISION_DATUM[retroapi$getVoxelDatumIndex(world, x, y, z)].withOffset(x, y, z);
    }
}
