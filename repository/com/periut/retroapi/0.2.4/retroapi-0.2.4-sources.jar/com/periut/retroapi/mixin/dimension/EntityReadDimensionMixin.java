package com.periut.retroapi.mixin.dimension;

import com.periut.retroapi.dimension.RetroDimensionRegistry;
import com.periut.retroapi.storage.PlayerDimensionSidecar;
import net.minecraft.unmapped.C_02949887;
import net.minecraft.unmapped.C_06229858;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_79370641;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Load side of the player dimension sidecar ({@code PlayerDimensionMixin} is the save side).
 *
 * <p>This MUST hook {@code Entity.read(NbtCompound)} - the public NBT entry point - and not
 * {@code PlayerEntity.readNbt}: {@code read} parses {@code Pos}/{@code Rotation} FIRST and only
 * then calls the per-class {@code readNbt} hook (where {@code Dimension} is read). Injecting the
 * sidecar values into the compound here, before ANY parsing, means vanilla's own loading path
 * places the player - position, bounding box, prev-coords, rotation, dimension - exactly as if
 * the values had always been in the file. No post-load repositioning.
 */
@Mixin(C_42232651.class)
public class EntityReadDimensionMixin {
	@Inject(method = "read", at = @At("HEAD"))
	private void retroapi$injectRealDimension(C_74087615 nbt, CallbackInfo ci) {
		if (!((Object) this instanceof C_40996800 self)) return;
		PlayerDimensionSidecar.Entry entry = PlayerDimensionSidecar.getPlayer(self.f_59008391);
		if (entry == null) return;
		// Only inject while the dimension is actually registered; if its mod was removed, the
		// clamped vanilla state (overworld spawn) is the correct, safe fallback and the sidecar
		// entry survives untouched for when the mod returns.
		if (RetroDimensionRegistry.getBySerialId(entry.dimensionId) == null) return;

		nbt.m_20318863("Dimension", entry.dimensionId);
		C_79370641 pos = new C_79370641();
		pos.m_43125067(new C_06229858(entry.x));
		pos.m_43125067(new C_06229858(entry.y));
		pos.m_43125067(new C_06229858(entry.z));
		nbt.m_21770494("Pos", pos);
		if (entry.hasRotation) {
			C_79370641 rot = new C_79370641();
			rot.m_43125067(new C_02949887(entry.yaw));
			rot.m_43125067(new C_02949887(entry.pitch));
			nbt.m_21770494("Rotation", rot);
		}
	}
}
