package com.periut.retroapi.gui.server;

import com.periut.retroapi.gui.GuiOpener;
import com.periut.retroapi.mixin.gui.ServerPlayerEntitySyncIdAccessor;
import com.periut.retroapi.network.RetroAPINetworking;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_46053237;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_54028238;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;
import net.ornithemc.osl.networking.api.server.ServerPlayNetworking;

/**
 * Dedicated-server GUI opener: assigns a window sync id, tells the client which registered
 * screen to open via the {@code retroapi:open_gui} channel, and installs the container on the
 * player so vanilla window-item sync packets flow. Mirrors StationAPI's {@code GuiHelperServerImpl}.
 */
public class ServerGuiOpener implements GuiOpener {

	@Override
	public void open(C_40996800 player, NamespacedIdentifier id, C_43616774 inventory, C_46053237 container) {
		C_49202226 serverPlayer = (C_49202226) player;
		ServerPlayerEntitySyncIdAccessor accessor = (ServerPlayerEntitySyncIdAccessor) serverPlayer;
		accessor.retroapi$incrementScreenHandlerSyncId();
		int syncId = accessor.retroapi$getScreenHandlerSyncId();

		ServerPlayNetworking.send(serverPlayer, RetroAPINetworking.OPEN_GUI_CHANNEL, buffer -> {
			buffer.writeString(id.toString());
			buffer.writeVarInt(syncId);
		});

		player.f_25936683 = container;
		container.f_66294390 = syncId;
		container.m_22289062((C_54028238) serverPlayer);
	}
}
