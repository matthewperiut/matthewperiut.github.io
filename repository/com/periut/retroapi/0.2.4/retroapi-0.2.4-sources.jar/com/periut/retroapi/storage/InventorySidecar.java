package com.periut.retroapi.storage;

import net.minecraft.unmapped.C_06774341;
import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40735137;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_72103717;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_79370641;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.ornithemc.osl.core.api.util.NamespacedIdentifier;
import net.ornithemc.osl.core.api.util.NamespacedIdentifiers;
import com.periut.retroapi.registry.BlockRegistration;
import com.periut.retroapi.registry.ItemRegistration;
import com.periut.retroapi.registry.RetroRegistry;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.*;
import java.util.*;

public class InventorySidecar {
	private static final Logger LOGGER = LogManager.getLogger("RetroAPI/InventorySidecar");
	private static final int VERSION = 1;

	/**
	 * Block entities that couldn't be restored because a vanilla block entity
	 * occupied the position. Preserved so they can be re-saved to the sidecar.
	 * Keyed by "chunkX,chunkZ".
	 */
	private static final Map<String, C_79370641> pendingBlockEntities = new HashMap<>();

	/**
	 * Modded full-entities whose id is not registered this session (the providing mod was
	 * removed) so we could not reconstruct them on load. Kept here so {@link #filterAndSave}
	 * re-writes them to the sidecar on every save, surviving repeated autosaves until the mod
	 * returns and they restore. Keyed by "chunkX,chunkZ". Unlike {@link #pendingBlockEntities}
	 * this is PEEKED (not removed) on save - a remove would drop the data on the second
	 * autosave of a still-loaded chunk. Cleared by {@link #restoreChunkContent} once the entity
	 * reconstructs successfully (mod returned).
	 */
	private static final Map<String, C_79370641> pendingFullEntities = new HashMap<>();

	/**
	 * Drop all cross-load deferral state. Called on world change (SidecarManager.flush) so a chunk
	 * "x,z" deferred in one world can never leak its modded content into another world's chunk "x,z"
	 * (chunkKey is world-agnostic, and these maps are static).
	 */
	public static void clearPending() {
		pendingBlockEntities.clear();
		pendingFullEntities.clear();
	}

	private final File file;
	private C_74087615 root;
	private boolean dirty = false;

	public InventorySidecar(File file) {
		this.file = file;
		this.root = new C_74087615();
		load();
	}

	private void load() {
		if (!file.exists()) {
			root.m_20318863("version", VERSION);
			root.m_18682924("chunks", new C_74087615());
			return;
		}
		try (FileInputStream fis = new FileInputStream(file)) {
			root = C_08565163.m_38706312(fis);
		} catch (IOException e) {
			LOGGER.error("Failed to load inventory sidecar {}", file, e);
			root = new C_74087615();
			root.m_20318863("version", VERSION);
			root.m_18682924("chunks", new C_74087615());
		}
	}

	public void save() {
		if (!dirty) return;
		try {
			// Snapshot on this (main) thread, gzip+atomic-write on the SidecarIo background thread.
			byte[] payload = SidecarIo.snapshot(root);
			dirty = false;
			SidecarIo.writeAsync(file, payload);
		} catch (IOException e) {
			LOGGER.error("Failed to snapshot inventory sidecar {}", file, e);
		}
	}

	/**
	 * Filter the chunk NBT to remove all modded content:
	 * - Modded block entities (at positions with extended blocks) -> saved to sidecar
	 * - RetroAPI items in vanilla block entity inventories -> saved to sidecar
	 * - Item entities carrying RetroAPI items -> saved to sidecar
	 */
	public void filterAndSave(int chunkX, int chunkZ, C_74087615 nbt, ChunkExtendedBlocks extended) {
		if (!root.m_97612750("chunks")) {
			root.m_18682924("chunks", new C_74087615());
		}
		C_74087615 chunks = root.m_81819352("chunks");
		String chunkKey = chunkX + "," + chunkZ;
		C_74087615 chunkData = new C_74087615();

		// 1. Filter TileEntities
		C_79370641 tileEntities = nbt.m_95654166("TileEntities");
		if (tileEntities != null) {
			C_79370641 filteredTEs = new C_79370641();
			C_79370641 moddedBEs = new C_79370641();
			C_79370641 inventoryItems = new C_79370641();

			for (int i = 0; i < tileEntities.m_89439680(); i++) {
				C_74087615 be = (C_74087615) tileEntities.m_59132367(i);
				int bx = be.m_35587574("x");
				int by = be.m_35587574("y");
				int bz = be.m_35587574("z");
				int localX = bx & 15;
				int localZ = bz & 15;
				int index = ChunkExtendedBlocks.toIndex(localX, by, localZ);

				if (extended.hasEntry(index)) {
					// Modded block entity - strip entirely
					moddedBEs.m_43125067(be);
				} else {
					// Vanilla block entity - check for RetroAPI items in inventory
					if (be.m_97612750("Items")) {
						C_79370641 items = be.m_95654166("Items");
						C_79370641 filteredItems = new C_79370641();
						boolean hasModdedItems = false;

						for (int j = 0; j < items.m_89439680(); j++) {
							C_74087615 item = (C_74087615) items.m_59132367(j);
							if (item.m_97612750("retroapi:id")) {
								// RetroAPI item - save to sidecar
								C_74087615 invEntry = new C_74087615();
								invEntry.m_20318863("x", bx);
								invEntry.m_20318863("y", by);
								invEntry.m_20318863("z", bz);
								invEntry.m_41884431("Slot", item.m_84056038("Slot"));
								invEntry.m_91017064("retroapi:id", item.m_47517355("retroapi:id"));
								invEntry.m_41884431("Count", item.m_97612750("retroapi:count")
								? item.m_84056038("retroapi:count") : item.m_84056038("Count"));
								invEntry.m_98335007("Damage", item.m_97612750("retroapi:damage")
								? item.m_03599456("retroapi:damage") : item.m_03599456("Damage"));
								// Carry the stack's data components so they survive the strip/restore round-trip
								// (restoreChunkContent reads them back via ComponentNbt.read).
								if (item.m_97612750("retroapi:components")) {
									invEntry.m_18682924("retroapi:components", item.m_81819352("retroapi:components"));
								}
								inventoryItems.m_43125067(invEntry);
								hasModdedItems = true;
							} else {
								filteredItems.m_43125067(item);
							}
						}

						if (hasModdedItems) {
							be.m_21770494("Items", filteredItems);
						}
					}
					filteredTEs.m_43125067(be);
				}
			}

			nbt.m_21770494("TileEntities", filteredTEs);
			// Merge in any pending (deferred) block entities that couldn't be restored
			C_79370641 pending = pendingBlockEntities.remove(chunkKey);
			if (pending != null) {
				for (int i = 0; i < pending.m_89439680(); i++) {
					moddedBEs.m_43125067(pending.m_59132367(i));
				}
			}
			if (moddedBEs.m_89439680() > 0) {
				chunkData.m_21770494("blockEntities", moddedBEs);
			}
			if (inventoryItems.m_89439680() > 0) {
				chunkData.m_21770494("inventoryItems", inventoryItems);
			}
		}

		// 2. Filter Entities - strip RetroAPI modded content so vanilla never silently drops it
		C_79370641 entities = nbt.m_95654166("Entities");
		if (entities != null) {
			C_79370641 filteredEntities = new C_79370641();
			C_79370641 moddedEntities = new C_79370641();   // item-entity carriers of RetroAPI items
			C_79370641 fullEntities = new C_79370641();      // RetroAPI modded full entities (mobs etc.)

			for (int i = 0; i < entities.m_89439680(); i++) {
				C_74087615 entity = (C_74087615) entities.m_59132367(i);
				String entityId = entity.m_47517355("id");

				// (a) Item entities carrying RetroAPI items - strip to itemEntities (existing behavior).
				if ("Item".equals(entityId)) {
					C_74087615 itemTag = entity.m_81819352("Item");
					if (itemTag != null && itemTag.m_97612750("retroapi:id")) {
						moddedEntities.m_43125067(entity);
						continue;
					}
					filteredEntities.m_43125067(entity);
					continue;
				}

				// (b) RetroAPI-registered modded full entity - strip the whole compound verbatim.
				//     Vanilla saveSelfNbt wrote id = registration.getId().toString() (e.g. "aether:moa"),
				//     so this round-trips through RetroRegistry. Non-null lookup => it is ours.
				if (entityId != null && !entityId.isEmpty()
						&& RetroRegistry.getEntityByStringId(entityId) != null) {
					fullEntities.m_43125067(entity);
					continue;
				}

				// (c) Vanilla entity - leave it in the chunk NBT.
				filteredEntities.m_43125067(entity);
			}

			nbt.m_21770494("Entities", filteredEntities);
			// Carry forward modded full-entities we couldn't reconstruct (mod removed) so they
			// survive this save and restore when the mod returns. PEEK, do not remove (see field doc).
			C_79370641 pendingFull = pendingFullEntities.get(chunkKey);
			if (pendingFull != null) {
				for (int i = 0; i < pendingFull.m_89439680(); i++) {
					fullEntities.m_43125067(pendingFull.m_59132367(i));
				}
			}
			if (moddedEntities.m_89439680() > 0) {
				chunkData.m_21770494("itemEntities", moddedEntities);
			}
			if (fullEntities.m_89439680() > 0) {
				chunkData.m_21770494("fullEntities", fullEntities);
			}
		}

		chunks.m_18682924(chunkKey, chunkData);
		dirty = true;
	}

	/**
	 * Restore modded content from sidecar into a loaded chunk:
	 * - Modded block entities (with block placement verification)
	 * - RetroAPI items in vanilla block entity inventories
	 * - Item entities carrying RetroAPI items
	 */
	public void restoreChunkContent(C_14917579 chunk, C_64041439 world) {
		if (!root.m_97612750("chunks")) return;
		C_74087615 chunks = root.m_81819352("chunks");
		String chunkKey = chunk.f_61945954 + "," + chunk.f_46577147;

		if (!chunks.m_97612750(chunkKey)) return;
		C_74087615 chunkData = chunks.m_81819352(chunkKey);

		ChunkExtendedBlocks extended = ((ExtendedBlocksAccess) chunk).retroapi$getExtendedBlocks();

		// 1. Restore modded block entities
		if (chunkData.m_97612750("blockEntities")) {
			C_79370641 moddedBEs = chunkData.m_95654166("blockEntities");
			C_79370641 deferredBEs = new C_79370641();

			for (int i = 0; i < moddedBEs.m_89439680(); i++) {
				C_74087615 beNbt = (C_74087615) moddedBEs.m_59132367(i);
				int bx = beNbt.m_35587574("x");
				int by = beNbt.m_35587574("y");
				int bz = beNbt.m_35587574("z");
				int localX = bx & 15;
				int localZ = bz & 15;
				int index = ChunkExtendedBlocks.toIndex(localX, by, localZ);

				// Check for existing vanilla block entity at this position
				C_32594356 pos = new C_32594356(localX, by, localZ);
				C_40735137 existing = (C_40735137) chunk.f_39463725.get(pos);
				if (existing != null) {
					// Vanilla block entity here - don't overwrite, keep data for next load
					deferredBEs.m_43125067(beNbt);
					// Also remove the extended block entry so vanilla block takes priority
					if (extended.hasEntry(index)) {
						extended.remove(index);
					}
					continue;
				}

				// Ensure the modded block is present at this position
				if (!extended.hasEntry(index)) {
					// Extended block missing - try to restore it from the BE's associated block
					// Skip if we can't determine the block
					deferredBEs.m_43125067(beNbt);
					continue;
				}

				// Verify the block has HAS_BLOCK_ENTITY set
				int blockId = extended.getBlockId(index);
				if (blockId > 0 && blockId < C_81592558.f_44428008.length && C_81592558.f_44428008[blockId] != null) {
					C_81592558.f_72646756[blockId] = true;
				}

				C_40735137 be = C_40735137.m_71831317(beNbt);
				if (be != null) {
					chunk.m_12877624(be);
				}
			}

			if (deferredBEs.m_89439680() > 0) {
				pendingBlockEntities.put(chunkKey, deferredBEs);
			} else {
				pendingBlockEntities.remove(chunkKey);
			}
		}

		// 2. Restore RetroAPI items into vanilla block entity inventories
		if (chunkData.m_97612750("inventoryItems")) {
			C_79370641 inventoryItems = chunkData.m_95654166("inventoryItems");
			for (int i = 0; i < inventoryItems.m_89439680(); i++) {
				C_74087615 entry = (C_74087615) inventoryItems.m_59132367(i);
				int bx = entry.m_35587574("x");
				int by = entry.m_35587574("y");
				int bz = entry.m_35587574("z");
				int slot = entry.m_84056038("Slot") & 0xFF;
				String stringId = entry.m_47517355("retroapi:id");
				int count = entry.m_84056038("Count") & 0xFF;
				int damage = entry.m_03599456("Damage");

				int numericId = resolveNumericId(stringId);
				if (numericId <= 0) continue;

				int localX = bx & 15;
				int localZ = bz & 15;
				C_40735137 be = chunk.m_88099179(localX, by, localZ);
				if (!(be instanceof C_43616774 inv)) continue;

				C_88708284 stack = new C_88708284(numericId, count, damage);
				// Restore data components saved alongside id/count/damage.
				com.periut.retroapi.component.ComponentNbt.read(
					(com.periut.retroapi.component.RetroComponentHolder) (Object) stack, entry);

				// Temporarily null out world to prevent markDirty from triggering
				// recursive chunk loading during restore (b1.8+ markDirty accesses world)
				C_64041439 beWorld = be.f_18133822;
				be.f_18133822 = null;
				try {
					// Try original slot first
					if (slot < inv.m_54518913() && inv.m_87969967(slot) == null) {
						inv.m_33431716(slot, stack);
					} else {
						// Find next free slot
						boolean placed = false;
						for (int s = 0; s < inv.m_54518913(); s++) {
							if (inv.m_87969967(s) == null) {
								inv.m_33431716(s, stack);
								placed = true;
								break;
							}
						}
						if (!placed) {
							LOGGER.warn("No free slot for {} at {},{},{} - discarding", stringId, bx, by, bz);
						}
					}
				} finally {
					be.f_18133822 = beWorld;
				}
			}
		}

		// 3. Restore item entities by creating them directly (not via NBT deserialization)
		if (chunkData.m_97612750("itemEntities")) {
			C_79370641 itemEntities = chunkData.m_95654166("itemEntities");
			for (int i = 0; i < itemEntities.m_89439680(); i++) {
				C_74087615 entityNbt = (C_74087615) itemEntities.m_59132367(i);

				// Resolve the item from retroapi:id
				if (!entityNbt.m_97612750("Item")) continue;
				C_74087615 itemTag = entityNbt.m_81819352("Item");
				if (!itemTag.m_97612750("retroapi:id")) continue;

				int numericId = resolveNumericId(itemTag.m_47517355("retroapi:id"));
				if (numericId <= 0) continue;

				int count = itemTag.m_97612750("retroapi:count")
					? (itemTag.m_84056038("retroapi:count") & 0xFF)
					: (itemTag.m_84056038("Count") & 0xFF);
				if (count <= 0) count = 1;
				int damage = itemTag.m_97612750("retroapi:damage")
					? itemTag.m_03599456("retroapi:damage")
					: itemTag.m_03599456("Damage");

				C_88708284 stack = new C_88708284(numericId, count, damage);
				// Restore data components saved with the dropped item.
				com.periut.retroapi.component.ComponentNbt.read(
					(com.periut.retroapi.component.RetroComponentHolder) (Object) stack, itemTag);

				// Read position from entity NBT
				C_79370641 posList = entityNbt.m_95654166("Pos");
				double ex = ((net.minecraft.unmapped.C_06229858) posList.m_59132367(0)).f_79544156;
				double ey = ((net.minecraft.unmapped.C_06229858) posList.m_59132367(1)).f_79544156;
				double ez = ((net.minecraft.unmapped.C_06229858) posList.m_59132367(2)).f_79544156;

				C_06774341 itemEntity = new C_06774341(world, ex, ey, ez, stack);

				// Restore motion if present
				if (entityNbt.m_97612750("Motion")) {
					C_79370641 motionList = entityNbt.m_95654166("Motion");
					itemEntity.f_24826402 = ((net.minecraft.unmapped.C_06229858) motionList.m_59132367(0)).f_79544156;
					itemEntity.f_35148123 = ((net.minecraft.unmapped.C_06229858) motionList.m_59132367(1)).f_79544156;
					itemEntity.f_21201587 = ((net.minecraft.unmapped.C_06229858) motionList.m_59132367(2)).f_79544156;
				}

				// Restore age and pickup delay
				if (entityNbt.m_97612750("Age")) {
					itemEntity.f_48081161 = entityNbt.m_03599456("Age");
				}

				chunk.m_11127416(itemEntity);
			}
		}

		// 4. Restore RetroAPI modded full entities via the vanilla NBT reconstructor.
		//    RetroEntities.register inserted the class into EntityRegistry.idToClass keyed by
		//    id.toString(), so getEntityFromNbt resolves it, runs the (World) ctor, and calls
		//    entity.read(nbt) to restore Pos/Motion/Rotation + subclass state.
		if (chunkData.m_97612750("fullEntities")) {
			C_79370641 fullEntities = chunkData.m_95654166("fullEntities");
			C_79370641 deferredEntities = new C_79370641();

			for (int i = 0; i < fullEntities.m_89439680(); i++) {
				C_74087615 entityNbt = (C_74087615) fullEntities.m_59132367(i);
				String entityId = entityNbt.m_47517355("id");

				// Mod absent this session - keep the data in the sidecar so it restores when the
				// mod returns. Never feed an unknown id to getEntityFromNbt (it would just drop it).
				if (entityId == null || entityId.isEmpty()
						|| RetroRegistry.getEntityByStringId(entityId) == null) {
					deferredEntities.m_43125067(entityNbt);
					continue;
				}

				C_42232651 entity = C_72103717.m_23901323(entityNbt, world);
				if (entity == null) {
					// Reconstruction failed (no (World) ctor, ctor threw, or read() failed). Keep it
					// for a future successful load instead of dropping it.
					LOGGER.warn("Failed to reconstruct modded entity {} in chunk {},{} - deferring",
						entityId, chunk.f_61945954, chunk.f_46577147);
					deferredEntities.m_43125067(entityNbt);
					continue;
				}
				chunk.m_11127416(entity);
			}

			if (deferredEntities.m_89439680() > 0) {
				pendingFullEntities.put(chunkKey, deferredEntities);
			} else {
				pendingFullEntities.remove(chunkKey);
			}
		}
	}

	private static int resolveNumericId(String stringId) {
		String[] parts = stringId.split(":", 2);
		if (parts.length != 2) return -1;

		NamespacedIdentifier retroId = NamespacedIdentifiers.from(parts[0], parts[1]);

		BlockRegistration blockReg = RetroRegistry.getBlockById(retroId);
		if (blockReg != null) return blockReg.getBlock().f_84602679;

		ItemRegistration itemReg = RetroRegistry.getItemById(retroId);
		if (itemReg != null) return itemReg.getItem().f_57562535;

		return -1;
	}
}
