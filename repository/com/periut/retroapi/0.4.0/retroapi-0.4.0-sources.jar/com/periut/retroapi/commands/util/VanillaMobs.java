package com.periut.retroapi.commands.util;

import com.periut.retroapi.commands.api.SummonRegistry;
import com.periut.retroapi.mixin.commands.access.EntityAccessor;
import net.minecraft.unmapped.C_09140510;
import net.minecraft.unmapped.C_22077616;
import net.minecraft.unmapped.C_43112843;
import net.minecraft.unmapped.C_87105418;
import net.minecraft.unmapped.C_99730074;

/**
 * Summon-time options for the vanilla mobs that have any.
 *
 * <p>Every argument is optional: {@code /summon Sheep} spawns a plain white sheep, and the extra
 * words only refine that.
 */
public class VanillaMobs {
    public static void setupSummons() {
        SummonRegistry.add(C_43112843.class, (world, pos, args) -> {
            final C_43112843 creeper = new C_43112843(world);
            if (flag(args, 0)) {
                ((EntityAccessor) creeper).getDataTracker().m_52395024(17, (byte) 1);
            }
            return creeper;
        }, "[charged (0 or 1)]");

        SummonRegistry.add(C_99730074.class, (world, pos, args) -> {
            final C_99730074 sheep = new C_99730074(world);
            sheep.m_60335413(number(args, 0, 0));
            sheep.m_71024489(args.length > 1 && !flag(args, 1));
            return sheep;
        }, "[colour] [has wool (0 or 1)]");

        SummonRegistry.add(C_87105418.class, (world, pos, args) -> {
            final C_87105418 pig = new C_87105418(world);
            if (flag(args, 0)) {
                ((EntityAccessor) pig).getDataTracker().m_52395024(16, (byte) 1);
            }
            return pig;
        }, "[saddle (0 or 1)]");

        SummonRegistry.add(C_22077616.class, (world, pos, args) -> {
            final C_22077616 slime = new C_22077616(world);
            final int size = number(args, 0, 0);
            if (size > 0) {
                ((EntityAccessor) slime).getDataTracker().m_52395024(16, (byte) size);
            }
            return slime;
        }, "[size]");

        SummonRegistry.add(C_09140510.class, (world, pos, args) -> {
            final C_09140510 tnt = new C_09140510(world);
            final int fuse = number(args, 0, 0);
            if (fuse > 0) {
                tnt.f_25392235 = fuse;
            }
            return tnt;
        }, "[fuse ticks]");
    }

    private static int number(final String[] args, final int index, final int fallback) {
        if (index >= args.length) {
            return fallback;
        }
        try {
            return Integer.parseInt(args[index]);
        } catch (final NumberFormatException ignored) {
            return fallback;
        }
    }

    /** Treats anything that is not zero or absent as set, which is how the old syntax behaved. */
    private static boolean flag(final String[] args, final int index) {
        return index < args.length && !args[index].isEmpty() && args[index].charAt(0) != '0';
    }
}
