package com.periut.retroapi.commands.api;

import com.periut.retroapi.commands.Position;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;

/**
 * Entity types with summon-time options, keyed by class.
 *
 * <p>Anything not registered here is still summonable - {@code /summon} falls back to beta's own
 * entity registry - so a factory is only needed for types that take arguments.
 */
public class SummonRegistry {
    private static final Map<Class<? extends C_42232651>, SummonFactory> FACTORIES = new HashMap<>();
    private static final Map<Class<? extends C_42232651>, String> USAGE = new LinkedHashMap<>();

    /**
     * @param usage how the arguments read in help, e.g. {@code "<charged (0 or 1)>"}
     */
    public static void add(final Class<? extends C_42232651> type, final SummonFactory factory, final String usage) {
        final SummonFactory previous = FACTORIES.put(type, factory);
        if (previous != null) {
            System.out.println("[retroapi] Overwrote " + previous + " with " + factory + " for summoning " + type);
        }
        USAGE.put(type, usage);
    }

    public static C_42232651 create(final Class<? extends C_42232651> type, final C_64041439 world, final Position position, final String[] arguments) {
        final SummonFactory factory = FACTORIES.get(type);
        return factory == null ? null : factory.create(world, position, arguments);
    }

    public static boolean hasFactory(final Class<? extends C_42232651> type) {
        return FACTORIES.containsKey(type);
    }

    public static String usageFor(final Class<? extends C_42232651> type) {
        return USAGE.get(type);
    }

    public static Map<Class<? extends C_42232651>, String> usages() {
        return USAGE;
    }
}
