package com.periut.retroapi.tag;

import net.minecraft.unmapped.C_53672520;
import net.minecraft.unmapped.C_74597326;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;

/**
 * Tool material tiers, mirroring modern Minecraft's {@code needs_<tier>_tool} tag family.
 * A block in {@code needs_iron_tool} only drops when the breaking tool's tier is at least
 * IRON (and the tool KIND still has to match a {@code mineable/<tool>} tag, exactly like
 * modern). Vanilla gold tools mine at wood tier, also like modern.
 *
 * <p>Item side: vanilla {@link C_53672520} subclasses infer their tier from their material's
 * mining level automatically; custom items declare one with
 * {@code RetroItemAccess.tier(RetroToolTier.IRON)} (chainable at registration or from a
 * constructor via {@code RetroItemAccess.of(this).tier(...)}).</p>
 *
 * <p>Block side: data files at {@code data/{ns}/tags/block/needs_stone_tool.json} (and
 * {@code needs_iron_tool}, {@code needs_diamond_tool}) in the modern format, or from code:
 * {@code RetroTags.addToTag(RetroToolTier.IRON.needsTag(), block)}.</p>
 */
public enum RetroToolTier {
	WOOD(0, null),
	STONE(1, "needs_stone_tool"),
	IRON(2, "needs_iron_tool"),
	DIAMOND(3, "needs_diamond_tool");

	private final int level;
	private final String tagName;

	RetroToolTier(int level, String tagName) {
		this.level = level;
		this.tagName = tagName;
	}

	/**
	 * Computes a tool's tier from the actual stack, for tools whose tier is not fixed: e.g. a
	 * multi-tool that levels up with use, or one whose tier rides its damage/NBT. Declare one with
	 * {@code RetroItemAccess.tier(stack -> ...)}; it is consulted per-harvest, so the answer can change
	 * at runtime. Return any {@link RetroToolTier}. This is the "dynamically picking the tier" hook.
	 */
	@FunctionalInterface
	public interface Dynamic {
		RetroToolTier tierFor(C_88708284 stack);
	}

	/**
	 * A tier that also sees WHAT is being mined and WHO is mining it - the missing half of {@link Dynamic},
	 * which only got the stack and so could not express "diamond-tier on stone, wood-tier on everything
	 * else", a drill bit that only bites certain ores, or a tool that is weaker in the nether. Declared
	 * with {@code RetroItemAccess.tier((stack, block, player) -> ...)} and consulted per harvest, ahead of
	 * the stack-only and static forms.
	 *
	 * <pre>
	 * RetroItemAccess.of(this).tier((stack, block, player) -&gt; {
	 *     if (player != null &amp;&amp; player.world.dimension.isNether) return RetroToolTier.WOOD;
	 *     return block == Block.STONE ? RetroToolTier.DIAMOND : RetroToolTier.WOOD;
	 * });
	 * </pre>
	 *
	 * <p>The player is the one breaking the block, and is null only when something asks for a tier outside
	 * a harvest (a tooltip, another mod's query) - treat it as "no context", not as an error. Beta's
	 * harvest hooks carry the {@link net.minecraft.unmapped.C_81592558} but no position, so block metadata and
	 * coordinates are genuinely not available here; a tier that has to see the state needs its own mixin.
	 */
	@FunctionalInterface
	public interface Contextual {
		RetroToolTier tierFor(C_88708284 stack, net.minecraft.unmapped.C_81592558 block,
			net.minecraft.unmapped.C_40996800 player);
	}

	/** Numeric mining level, comparable to {@link C_74597326#m_73635374()}. */
	public int getLevel() {
		return level;
	}

	/** The {@code needs_<tier>_tool} tag key, or null for WOOD (everything mines wood tier). */
	public RetroTagKey needsTag() {
		return tagName == null ? null : RetroTagKey.block(tagName);
	}

	/** True when a tool of this tier may harvest a block requiring the given tier. */
	public boolean isAtLeast(RetroToolTier required) {
		return level >= required.level;
	}

	/**
	 * The tier of an item, with no stack context: a dynamic tier declaration is ignored here (it needs
	 * a stack), an explicit {@code RetroItemAccess.tier(RetroToolTier)} declaration wins, vanilla tool
	 * items infer from their material's mining level, everything else is WOOD (matching modern, where a
	 * bare hand or a stick is a wood-tier "tool"). Prefer {@link #of(C_88708284)} in harvest code.
	 */
	public static RetroToolTier of(C_98888256 item) {
		if (item == null) {
			return WOOD;
		}
		com.periut.retroapi.register.item.RetroItemAccess access =
			(com.periut.retroapi.register.item.RetroItemAccess) item;
		RetroToolTier declared = access.getToolTier();
		if (declared != null) {
			return declared;
		}
		if (item instanceof C_53672520) {
			return fromLevel(((com.periut.retroapi.mixin.register.ToolItemAccessor) item)
				.retroapi$getToolMaterial().m_73635374());
		}
		return WOOD;
	}

	/**
	 * The tier of the tool in this stack. A {@code RetroItemAccess.tier(stack -> ...)} dynamic
	 * declaration wins (letting the tier change at runtime), then a static {@code .tier(...)}, then a
	 * vanilla {@code ToolItem}'s material level, else WOOD. This is the overload the harvest hook uses.
	 */
	public static RetroToolTier of(C_88708284 stack) {
		if (stack == null) {
			return WOOD;
		}
		C_98888256 item = stack.m_23235460();
		if (item == null) {
			return WOOD;
		}
		Dynamic dynamic = ((com.periut.retroapi.register.item.RetroItemAccess) item).getToolTierDynamic();
		if (dynamic != null) {
			RetroToolTier tier = dynamic.tierFor(stack);
			if (tier != null) {
				return tier;
			}
		}
		return of(item);
	}

	/**
	 * The tier of the tool in this stack <em>for a specific block</em>, with no player context. Equivalent
	 * to {@code of(stack, block, null)}; use the three-argument form from anywhere that knows who is
	 * mining, so contextual tiers can see the world they are being asked about.
	 */
	public static RetroToolTier of(C_88708284 stack, net.minecraft.unmapped.C_81592558 block) {
		return of(stack, block, null);
	}

	/**
	 * The tier of the tool in this stack <em>for a specific block, in a specific player's hands</em>. A
	 * {@code RetroItemAccess.tier((stack, block, player) -> ...)} declaration wins, then the stack-only
	 * dynamic form, then a static tier, then a vanilla {@code ToolItem}'s material. This is the overload
	 * the harvest hooks use, so a tool's level can depend on what it is pointed at and on where its
	 * wielder is standing.
	 */
	public static RetroToolTier of(C_88708284 stack, net.minecraft.unmapped.C_81592558 block,
			net.minecraft.unmapped.C_40996800 player) {
		if (stack == null) {
			return WOOD;
		}
		C_98888256 item = stack.m_23235460();
		if (item == null) {
			return WOOD;
		}
		Contextual contextual = ((com.periut.retroapi.register.item.RetroItemAccess) item).getToolTierContextual();
		if (contextual != null) {
			RetroToolTier tier = contextual.tierFor(stack, block, player);
			if (tier != null) {
				return tier;
			}
		}
		return of(stack);
	}

	/** The tier for a numeric mining level, clamped into the known range. */
	public static RetroToolTier fromLevel(int level) {
		if (level >= 3) return DIAMOND;
		if (level == 2) return IRON;
		if (level == 1) return STONE;
		return WOOD;
	}
}
