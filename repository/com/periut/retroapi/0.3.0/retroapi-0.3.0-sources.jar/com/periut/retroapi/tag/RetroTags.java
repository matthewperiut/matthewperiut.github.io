package com.periut.retroapi.tag;

import com.periut.retroapi.RetroAPI;
import com.periut.retroapi.registry.BlockRegistration;
import com.periut.retroapi.registry.ItemRegistration;
import com.periut.retroapi.registry.RetroRegistry;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_98888256;
import net.ornithemc.osl.core.api.util.NamespacedIdentifiers;

import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The tag engine for both blocks and items. Membership comes from two places that union together:
 *
 * <ul>
 *   <li><b>Data</b>: {@code data/{ns}/tags/block(s)/**.json} and {@code tags/item(s)/**.json} files in any
 *       mod (modern schema), plus StationAPI's {@code data/{ns}/stationapi/tags/blocks|items/**.json}
 *       layout (see {@link RetroTagLoader}), resolved lazily on first query so every mod has finished
 *       registering by then.</li>
 *   <li><b>Code</b>: {@link #addToTag(RetroTagKey, C_81592558...)} / {@link #addToTag(RetroTagKey, C_98888256...)},
 *       callable at any time (RetroAPI's code tags are mutable at runtime, unlike StationAPI's, whose
 *       tags are frozen from resources). {@code RetroBlockAccess.mineable(...)} and
 *       {@code RetroItemAccess.tool(...)} sugar down to this.</li>
 * </ul>
 *
 * <p>Tags are namespace-blind: a tag file at {@code data/minecraft/.../mineable/pickaxe.json} and one at
 * {@code data/mymod/.../mineable/pickaxe.json} both feed the same {@code mineable/pickaxe} tag, so vanilla
 * files copied from modern Minecraft and mod additions union with zero ceremony.</p>
 *
 * <p>The flagship consumers are the {@code mineable/{pickaxe,axe,shovel,hoe,sword,shears}} family and the
 * {@code needs_<tier>_tool} tiers, wired into mining speed and drops by {@code PlayerEntityMixin}.</p>
 */
public final class RetroTags {

	/** Code-registered membership, live immediately, keyed by the full tag (category + path). */
	private static final Map<RetroTagKey, Set<Object>> CODE_TAGS = new HashMap<>();
	/** Data-file block membership, resolved on first query. */
	private static Map<String, Set<C_81592558>> dataBlockTags = null;
	/** Data-file item membership, resolved on first query. */
	private static Map<String, Set<C_98888256>> dataItemTags = null;
	/** Block to the set of mineable tools whose tag contains it, cached for the harvest hook. */
	private static Map<C_81592558, Set<RetroTool>> mineableCache = null;
	/** Block to its required tool tier, cached like mineable. */
	private static Map<C_81592558, RetroToolTier> tierCache = null;
	/** Guards the one-time lazy registration of the default vanilla tool-tag membership. */
	private static boolean vanillaDefaultsLoaded = false;

	private RetroTags() {}

	/**
	 * Registers the beta-accurate default {@code mineable}/{@code needs_<tier>_tool} membership for vanilla
	 * blocks on first query, so it is present no matter the mod-init order (an eager call in
	 * {@code RetroAPI.init()} could lose a race with a consumer mod that queries tags from ITS init first).
	 * Skipped under StationAPI, which owns vanilla harvesting itself.
	 */
	private static void ensureVanillaDefaults() {
		if (vanillaDefaultsLoaded) {
			return;
		}
		vanillaDefaultsLoaded = true;
		if (!FabricLoader.getInstance().isModLoaded("stationapi")) {
			VanillaToolTags.registerDefaults();
		}
	}

	// -------------------------------------------------------------- membership --

	/** True if the block is in the tag (data or code membership). */
	public static boolean isIn(C_81592558 block, RetroTagKey tag) {
		if (block == null) {
			return false;
		}
		ensureVanillaDefaults();
		Set<Object> code = CODE_TAGS.get(tag);
		if (code != null && code.contains(block)) {
			return true;
		}
		Set<C_81592558> data = resolvedBlocks().get(tag.getPath());
		return data != null && data.contains(block);
	}

	/** True if the item is in the tag (data or code membership). */
	public static boolean isIn(C_98888256 item, RetroTagKey tag) {
		if (item == null) {
			return false;
		}
		Set<Object> code = CODE_TAGS.get(tag);
		if (code != null && code.contains(item)) {
			return true;
		}
		Set<C_98888256> data = resolvedItems().get(tag.getPath());
		return data != null && data.contains(item);
	}

	/** Every block in the tag (data and code membership unioned). Never null. */
	public static Set<C_81592558> blocksIn(RetroTagKey tag) {
		ensureVanillaDefaults();
		Set<C_81592558> result = new LinkedHashSet<>();
		Set<C_81592558> data = resolvedBlocks().get(tag.getPath());
		if (data != null) {
			result.addAll(data);
		}
		Set<Object> code = CODE_TAGS.get(tag);
		if (code != null) {
			for (Object o : code) {
				if (o instanceof C_81592558 b) {
					result.add(b);
				}
			}
		}
		return Collections.unmodifiableSet(result);
	}

	/** Every item in the tag (data and code membership unioned). Never null. */
	public static Set<C_98888256> itemsIn(RetroTagKey tag) {
		Set<C_98888256> result = new LinkedHashSet<>();
		Set<C_98888256> data = resolvedItems().get(tag.getPath());
		if (data != null) {
			result.addAll(data);
		}
		Set<Object> code = CODE_TAGS.get(tag);
		if (code != null) {
			for (Object o : code) {
				if (o instanceof C_98888256 i) {
					result.add(i);
				}
			}
		}
		return Collections.unmodifiableSet(result);
	}

	/** @deprecated Ambiguous name; use {@link #blocksIn(RetroTagKey)}. */
	@Deprecated
	public static Set<C_81592558> all(RetroTagKey tag) {
		return blocksIn(tag);
	}

	// -------------------------------------------------------- code registration --

	/** Adds blocks to a tag from code. Unions with data files, replaces nothing. Live immediately. */
	public static void addToTag(RetroTagKey tag, C_81592558... blocks) {
		Set<Object> set = CODE_TAGS.computeIfAbsent(tag, k -> new LinkedHashSet<>());
		Collections.addAll(set, blocks);
		invalidateToolCaches();
	}

	/** Adds items to a tag from code. Unions with data files, replaces nothing. Live immediately. */
	public static void addToTag(RetroTagKey tag, C_98888256... items) {
		Set<Object> set = CODE_TAGS.computeIfAbsent(tag, k -> new LinkedHashSet<>());
		Collections.addAll(set, items);
	}

	/** Removes code-registered blocks from a tag (data-file membership is untouched). */
	public static void removeFromTag(RetroTagKey tag, C_81592558... blocks) {
		Set<Object> set = CODE_TAGS.get(tag);
		if (set != null) {
			for (C_81592558 b : blocks) {
				set.remove(b);
			}
			invalidateToolCaches();
		}
	}

	/** Removes code-registered items from a tag (data-file membership is untouched). */
	public static void removeFromTag(RetroTagKey tag, C_98888256... items) {
		Set<Object> set = CODE_TAGS.get(tag);
		if (set != null) {
			for (C_98888256 i : items) {
				set.remove(i);
			}
		}
	}

	private static void invalidateToolCaches() {
		mineableCache = null;
		tierCache = null;
	}

	// ------------------------------------------------------------ tool helpers --

	/**
	 * The mineable tools whose tag contains this block, or an empty set. Cached; this is
	 * the hot path for {@code PlayerEntityMixin.canHarvest}/{@code getBlockBreakingSpeed}.
	 */
	public static Set<RetroTool> mineableTools(C_81592558 block) {
		if (mineableCache == null) {
			Map<C_81592558, Set<RetroTool>> cache = new HashMap<>();
			for (RetroTool tool : RetroTool.values()) {
				for (C_81592558 b : blocksIn(tool.mineableTag())) {
					cache.computeIfAbsent(b, k -> new HashSet<>()).add(tool);
				}
			}
			mineableCache = cache;
		}
		Set<RetroTool> tools = mineableCache.get(block);
		if (tools != null) {
			return tools;
		}
		return defaultMineableTools(block);
	}

	/**
	 * What a block is mineable with when nothing declared it - inferred from its material, the way modern
	 * Minecraft's own tags are laid out (stone/metal -&gt; pickaxe, wood -&gt; axe, soil/sand -&gt; shovel,
	 * leaves -&gt; shears + hoe + sword, wool -&gt; shears).
	 *
	 * <p>This closes the trap behind "my tool can't break my block". Beta decides whether a tool is
	 * effective from hardcoded block LISTS inside each vanilla tool item - lists a modded block obviously
	 * is not in - so a modded stone-material block dropped nothing for ANY tool, vanilla or modded, until
	 * its author found {@code .mineable(...)}. Inferring the obvious default makes a block behave like the
	 * vanilla blocks it is made of, while an explicit {@code .mineable(...)} or a data tag still wins.
	 */
	public static Set<RetroTool> defaultMineableTools(C_81592558 block) {
		if (block == null) {
			return Collections.emptySet();
		}
		net.minecraft.unmapped.C_89604096 material = block.f_22724416;
		if (material == null) {
			return Collections.emptySet();
		}
		if (material == net.minecraft.unmapped.C_89604096.f_64385500
			|| material == net.minecraft.unmapped.C_89604096.f_16486116
			|| material == net.minecraft.unmapped.C_89604096.f_13130403
			|| material == net.minecraft.unmapped.C_89604096.f_95157123) {
			return DEFAULT_PICKAXE;
		}
		if (material == net.minecraft.unmapped.C_89604096.f_60980542
			|| material == net.minecraft.unmapped.C_89604096.f_11404709) {
			return DEFAULT_AXE;
		}
		if (material == net.minecraft.unmapped.C_89604096.f_77812914
			|| material == net.minecraft.unmapped.C_89604096.f_63222177
			|| material == net.minecraft.unmapped.C_89604096.f_35482456
			|| material == net.minecraft.unmapped.C_89604096.f_71726800
			|| material == net.minecraft.unmapped.C_89604096.f_53619813
			|| material == net.minecraft.unmapped.C_89604096.f_66199858) {
			return DEFAULT_SHOVEL;
		}
		if (material == net.minecraft.unmapped.C_89604096.f_85479516) {
			return DEFAULT_LEAVES;
		}
		if (material == net.minecraft.unmapped.C_89604096.f_92747101
			|| material == net.minecraft.unmapped.C_89604096.f_39748349) {
			return DEFAULT_SHEARS;
		}
		return Collections.emptySet();
	}

	private static final Set<RetroTool> DEFAULT_PICKAXE = Collections.unmodifiableSet(EnumSet.of(RetroTool.PICKAXE));
	private static final Set<RetroTool> DEFAULT_AXE = Collections.unmodifiableSet(EnumSet.of(RetroTool.AXE));
	private static final Set<RetroTool> DEFAULT_SHOVEL = Collections.unmodifiableSet(EnumSet.of(RetroTool.SHOVEL));
	private static final Set<RetroTool> DEFAULT_SHEARS = Collections.unmodifiableSet(EnumSet.of(RetroTool.SHEARS));
	/** Leaves: shears cut them cleanly, and a sword or hoe hacks through them faster than a hand. */
	private static final Set<RetroTool> DEFAULT_LEAVES = Collections.unmodifiableSet(
		EnumSet.of(RetroTool.SHEARS, RetroTool.SWORD, RetroTool.HOE));

	/**
	 * The tool tier a block demands ({@code needs_stone_tool} and friends), or WOOD when it
	 * demands none. The highest tier wins if a block somehow sits in several tags.
	 */
	public static RetroToolTier requiredTier(C_81592558 block) {
		if (tierCache == null) {
			Map<C_81592558, RetroToolTier> cache = new HashMap<>();
			for (RetroToolTier tier : RetroToolTier.values()) {
				RetroTagKey tag = tier.needsTag();
				if (tag == null) {
					continue;
				}
				for (C_81592558 b : blocksIn(tag)) {
					RetroToolTier existing = cache.get(b);
					if (existing == null || tier.getLevel() > existing.getLevel()) {
						cache.put(b, tier);
					}
				}
			}
			tierCache = cache;
		}
		RetroToolTier tier = tierCache.get(block);
		return tier != null ? tier : RetroToolTier.WOOD;
	}

	// ------------------------------------------------------------- resolution --

	private static synchronized Map<String, Set<C_81592558>> resolvedBlocks() {
		if (dataBlockTags != null) {
			return dataBlockTags;
		}
		Map<String, List<RetroTagLoader.Entry>> raw = RetroTagLoader.loadBlockTags();
		Map<String, Set<C_81592558>> result = new HashMap<>();
		for (String path : raw.keySet()) {
			resolveBlockTag(path, raw, result, new HashSet<>());
		}
		dataBlockTags = result;
		invalidateToolCaches();
		return result;
	}

	private static synchronized Map<String, Set<C_98888256>> resolvedItems() {
		if (dataItemTags != null) {
			return dataItemTags;
		}
		Map<String, List<RetroTagLoader.Entry>> raw = RetroTagLoader.loadItemTags();
		Map<String, Set<C_98888256>> result = new HashMap<>();
		for (String path : raw.keySet()) {
			resolveItemTag(path, raw, result, new HashSet<>());
		}
		dataItemTags = result;
		return result;
	}

	private static Set<C_81592558> resolveBlockTag(String path, Map<String, List<RetroTagLoader.Entry>> raw,
			Map<String, Set<C_81592558>> result, Set<String> resolving) {
		Set<C_81592558> existing = result.get(path);
		if (existing != null) {
			return existing;
		}
		if (!resolving.add(path)) {
			RetroAPI.LOGGER.warn("Tag reference cycle at #{}; treating as empty", path);
			return Collections.emptySet();
		}
		Set<C_81592558> blocks = new LinkedHashSet<>();
		List<RetroTagLoader.Entry> entries = raw.get(path);
		if (entries != null) {
			for (RetroTagLoader.Entry entry : entries) {
				if (entry.isReference()) {
					String ref = RetroTagKey.normalize(entry.value);
					if (raw.containsKey(ref) || CODE_TAGS.containsKey(RetroTagKey.block(ref))) {
						blocks.addAll(resolveBlockTag(ref, raw, result, resolving));
						for (C_81592558 b : blocksIn(RetroTagKey.block(ref))) {
							blocks.add(b);
						}
					} else if (entry.required) {
						RetroAPI.LOGGER.warn("Tag #{} references unknown tag {}", path, entry.value);
					}
				} else {
					C_81592558 block = resolveBlock(entry.value);
					if (block != null) {
						blocks.add(block);
					} else if (entry.required && !entry.value.startsWith("minecraft:")) {
						RetroAPI.LOGGER.warn("Tag #{} references unknown block {}", path, entry.value);
					}
					// Unknown minecraft: names skip silently: modern tag files are full of
					// post-beta blocks, and skipping them is what makes those files reusable.
				}
			}
		}
		resolving.remove(path);
		result.put(path, blocks);
		return blocks;
	}

	private static Set<C_98888256> resolveItemTag(String path, Map<String, List<RetroTagLoader.Entry>> raw,
			Map<String, Set<C_98888256>> result, Set<String> resolving) {
		Set<C_98888256> existing = result.get(path);
		if (existing != null) {
			return existing;
		}
		if (!resolving.add(path)) {
			RetroAPI.LOGGER.warn("Item tag reference cycle at #{}; treating as empty", path);
			return Collections.emptySet();
		}
		Set<C_98888256> items = new LinkedHashSet<>();
		List<RetroTagLoader.Entry> entries = raw.get(path);
		if (entries != null) {
			for (RetroTagLoader.Entry entry : entries) {
				if (entry.isReference()) {
					String ref = RetroTagKey.normalize(entry.value);
					if (raw.containsKey(ref) || CODE_TAGS.containsKey(RetroTagKey.item(ref))) {
						items.addAll(resolveItemTag(ref, raw, result, resolving));
						for (C_98888256 i : itemsIn(RetroTagKey.item(ref))) {
							items.add(i);
						}
					} else if (entry.required) {
						RetroAPI.LOGGER.warn("Item tag #{} references unknown tag {}", path, entry.value);
					}
				} else {
					C_98888256 item = resolveItem(entry.value);
					if (item != null) {
						items.add(item);
					} else if (entry.required && !entry.value.startsWith("minecraft:")) {
						RetroAPI.LOGGER.warn("Item tag #{} references unknown item {}", path, entry.value);
					}
				}
			}
		}
		resolving.remove(path);
		result.put(path, items);
		return items;
	}

	private static C_81592558 resolveBlock(String name) {
		int colon = name.indexOf(':');
		String ns = colon >= 0 ? name.substring(0, colon) : "minecraft";
		String id = colon >= 0 ? name.substring(colon + 1) : name;
		if ("minecraft".equals(ns)) {
			return VanillaBlockNames.resolve(id);
		}
		BlockRegistration reg = RetroRegistry.getBlockById(NamespacedIdentifiers.from(ns, id));
		return reg != null ? reg.getBlock() : null;
	}

	private static C_98888256 resolveItem(String name) {
		int colon = name.indexOf(':');
		String ns = colon >= 0 ? name.substring(0, colon) : "minecraft";
		String id = colon >= 0 ? name.substring(colon + 1) : name;
		if ("minecraft".equals(ns)) {
			C_98888256 vanilla = VanillaItemNames.resolve(id);
			if (vanilla != null) {
				return vanilla;
			}
			// A vanilla block name in an item tag resolves to that block's item.
			C_81592558 block = VanillaBlockNames.resolve(id);
			return block != null && block.f_84602679 < C_98888256.f_38445253.length ? C_98888256.f_38445253[block.f_84602679] : null;
		}
		ItemRegistration reg = RetroRegistry.getItemById(NamespacedIdentifiers.from(ns, id));
		return reg != null ? reg.getItem() : null;
	}
}
