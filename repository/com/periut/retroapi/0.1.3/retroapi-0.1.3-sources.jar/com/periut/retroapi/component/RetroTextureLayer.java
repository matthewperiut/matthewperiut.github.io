package com.periut.retroapi.component;

/**
 * One layer of a {@link RetroLayeredTexture}: an atlas sprite id and an RGB tint applied to
 * it ({@code 0xRRGGBB}; use {@link #NO_TINT} for none). Layers draw back to front, so the
 * first layer in the list is the base and later layers stack on top. There is no separate
 * "base texture", the base is simply layer 0, which keeps the whole look in one list that
 * an item can rebuild from a stack's components.
 */
public record RetroTextureLayer(int spriteId, int tint) {

	/** White: the sprite draws with its own colors, untinted. */
	public static final int NO_TINT = 0xFFFFFF;

	/** A layer drawn with its own colors. */
	public static RetroTextureLayer plain(int spriteId) {
		return new RetroTextureLayer(spriteId, NO_TINT);
	}

	/** A layer multiplied by an {@code 0xRRGGBB} tint (like a dye color). */
	public static RetroTextureLayer tinted(int spriteId, int tint) {
		return new RetroTextureLayer(spriteId, tint);
	}
}
