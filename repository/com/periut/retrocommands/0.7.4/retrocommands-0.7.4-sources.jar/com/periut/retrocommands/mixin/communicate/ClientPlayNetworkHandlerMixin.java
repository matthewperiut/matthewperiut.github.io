package com.periut.retrocommands.mixin.communicate;
 
 import com.periut.retrocommands.RetroCommands;
import net.minecraft.unmapped.C_47909326;
import net.minecraft.unmapped.C_88014908;
import org.spongepowered.asm.mixin.Mixin;
 import org.spongepowered.asm.mixin.injection.At;
 import org.spongepowered.asm.mixin.injection.Inject;
 import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_88014908.class)
 public abstract class ClientPlayNetworkHandlerMixin {
     @Inject(method = "onHello", at = @At("TAIL"))
     void askIfOp(C_47909326 par1, CallbackInfo ci) {
         RetroCommands.mp_rc = false;
         RetroCommands.mp_op = false;
     }
 }