package com.periut.retrocommands.command.extra;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.SharedCommandSource;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_88708284;


public class Hat implements Command {
    @Override
    public void command(SharedCommandSource commandSource, String[] parameters) {
        C_40996800 player = commandSource.getPlayer();
        if (player == null) {
            return;
        }

        C_88708284 hand = player.f_29439708.m_27760697() == null ? null : player.f_29439708.m_27760697().m_73216943();
        C_88708284 hat = player.f_29439708.f_52412003[3] == null ? null : player.f_29439708.f_52412003[3].m_73216943();

        player.f_29439708.f_52412003[3] = hand;
        player.f_29439708.f_35249023[player.f_29439708.f_13682807] = hat;

        commandSource.sendFeedback("Swapped hat with hand");
    }

    @Override
    public String name() {
        return "hat";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /hat");
        commandSource.sendFeedback("Info: Puts the item in your hand on your head");
    }

    @Override
    public boolean needsPermissions() {
        return false;
    }
}
