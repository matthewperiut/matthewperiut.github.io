package com.periut.retrocommands.mixin.intercept;

import com.periut.retrocommands.RetroCommands;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_97929192;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Arrays;

@Mixin(C_97929192.class)
public class ClientPlayerMixin {
    @Inject(method = "sendChatMessage", at = @At("HEAD"), cancellable = true)
    public void sendFeedbackInMP(String par1, CallbackInfo ci) {
        if (par1.startsWith("/clear")) {
            ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_28235293.m_57675430();
            ci.cancel();
        }
        if (par1.startsWith("/perm")) {
            ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_28235293.m_81906308("mp_op: " + RetroCommands.mp_op);
            ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_28235293.m_81906308("mp_rc: " + RetroCommands.mp_rc);
            ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_28235293.m_81906308("player_names: " + Arrays.toString(RetroCommands.player_names));
            ci.cancel();
        }
    }
}
