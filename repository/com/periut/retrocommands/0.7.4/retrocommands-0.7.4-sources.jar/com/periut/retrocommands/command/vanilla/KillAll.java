package com.periut.retrocommands.command.vanilla;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.SharedCommandSource;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;


public class KillAll implements Command {

    @Override
    public void command(SharedCommandSource commandSource, String[] parameters) {
        C_40996800 player = commandSource.getPlayer();
        if (player == null) {
            return;
        }

        List<C_42232651> entities_to_kill = new ArrayList<>();
        for (int i = 0; i < player.f_94306729.f_97717459.size(); i++) {
            C_42232651 e = (C_42232651) player.f_94306729.f_97717459.get(i);
            if (e instanceof C_40996800) continue;
            entities_to_kill.add(e);
        }

        for (C_42232651 e : entities_to_kill) {
            e.m_40469716(null, 1000);
        }

        commandSource.sendFeedback("Killed " + entities_to_kill.size() + " entities");
    }

    @Override
    public String name() {
        return "killall";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /killall");
        commandSource.sendFeedback("Info: Kills all entities in the world");
    }
}
