package com.periut.retrocommands.optionaldep.bhcreative;

import net.minecraft.unmapped.C_40996800;

public class ChangeGamemode {
    public static void set(C_40996800 player, boolean creative) {
//        ((CreativePlayer) (player)).creative_setCreative(creative);
    }
}
