package com.periut.retrocommands.command.vanilla;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.api.ItemInstanceStr;
import com.periut.retrocommands.optionaldep.retroapi.RetroApiCompat;
import com.periut.retrocommands.util.SharedCommandSource;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_72103717;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.registry.ItemRegistry;
import net.modificationstation.stationapi.api.util.Identifier;

import java.util.Optional;

import static com.periut.retrocommands.util.ParameterSuggestUtil.suggestItemIdentifier;


public class Give implements Command {

    public static boolean givePlayerItemInstance(SharedCommandSource commandSource, C_40996800 player, C_88708284 instance) {
        C_88708284[] inventory = player.f_29439708.f_35249023;
        for (int i = 0; i < inventory.length; i++) {
            if (inventory[i] == null) {
                inventory[i] = instance;
                return true;
            }
        }

        commandSource.sendFeedback("Cannot give " + instance.m_23235460().m_17134118() + " because inventory is full");
        return false;
    }

    public static int nameToItemId(String n) {
        String name = n.replace("_", "");
        for (int i = 0; i < C_98888256.f_38445253.length; i++) {
            if (C_98888256.f_38445253[i] == null)
                continue;
            String translatedName = C_98888256.f_38445253[i].m_17134118().replace(" ", ""); // Remove spaces
            if (translatedName.equalsIgnoreCase(name)) {
                return i;
            }
        }
        return -1;
    }

    public static int identifierToItemId(String n) {
        Optional<C_98888256> item = ItemRegistry.INSTANCE.getOrEmpty(Identifier.of(n));
        return item.map(itemBase -> itemBase.f_57562535).orElse(-1);
    }

    @Override
    public void command(SharedCommandSource commandSource, String[] parameters) {
        if (parameters.length > 1 && !parameters[1].equals("help")) {
            int itemNumber;
            int meta = 0;

            String setSPCStr = "";

            try {
                itemNumber = Integer.parseInt(parameters[1]);
            } catch (NumberFormatException e) {
                itemNumber = -1;
                if (FabricLoader.getInstance().isModLoaded("station-registry-api-v0")) {
                    itemNumber = identifierToItemId(parameters[1]);
                }
                if (itemNumber == -1 && FabricLoader.getInstance().isModLoaded("retroapi")) {
                    itemNumber = RetroApiCompat.identifierToItemId(parameters[1]);
                }
                if (itemNumber == -1) {
                    itemNumber = nameToItemId(parameters[1]);
                }
            }

            if (itemNumber == -1) {
                commandSource.sendFeedback("Item not found");
                return;
            }

            C_98888256 itemType = C_98888256.f_38445253[itemNumber];
            if (itemType == null) {
                commandSource.sendFeedback("Item not found");
                return;
            }
            int stackSize = itemType.m_03156313();


            if (parameters.length > 2) {
                int requestedCount;
                try {
                    requestedCount = Integer.parseInt(parameters[2]);
                } catch (NumberFormatException e) {
                    commandSource.sendFeedback("Requested number of items '" + parameters[2] + "' is not a number");
                    return;
                }
                stackSize = requestedCount;

                if (parameters.length > 3) {
                    if (itemType.m_52352354() || itemType.m_17134118().equals("Monster Spawner")) {
                        try {
                            meta = Integer.parseInt(parameters[3]);
                        } catch (NumberFormatException e) {
                            if (itemType.m_17134118().equals("Monster Spawner")) {
                                C_42232651 entity = C_72103717.m_32428905(parameters[3], commandSource.getPlayer().f_94306729);
                                if (entity instanceof C_74425583 l) {
                                    setSPCStr = l.m_06252001();
                                    commandSource.sendFeedback(l.m_06252001() + " inside");
                                } else if (entity != null) {
                                    commandSource.sendFeedback("Entity must be living in spawners");
                                } else {
                                    commandSource.sendFeedback("Invalid entity parameter");
                                }
                            } else {
                                commandSource.sendFeedback("Metadata not a number");
                            }
                        }
                    } else {
                        commandSource.sendFeedback("Metadata not applicable");
                    }
                }
            }

            C_88708284 item = new C_88708284(itemType, stackSize, meta);

            if (!setSPCStr.isEmpty()) {
                ((ItemInstanceStr) ((Object) item)).spc$setStr(setSPCStr);
            }

            if (givePlayerItemInstance(commandSource, commandSource.getPlayer(), item)) {
                commandSource.sendFeedback("Gave " + item.f_60602012 + " " + itemType.m_17134118());
            }
            return;
        }
        manual(commandSource);
    }

    @Override
    public String name() {
        return "give";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /give {id} {count} {optional:meta/mob_id}");
        commandSource.sendFeedback("Info: gives the player items");
        commandSource.sendFeedback("id: can be number or name");
        commandSource.sendFeedback("count: number of item");
        commandSource.sendFeedback("meta: sub-item selection");
        commandSource.sendFeedback("list mobs with /mobs");
    }

    @Override
    public String[] suggestion(SharedCommandSource source, int parameterNum, String currentInput, String totalInput)
    {
        if (parameterNum == 1)
        {
            // suggestItemIdentifier gates StationAPI/RetroAPI internally
            return suggestItemIdentifier(currentInput);
        }

        if (parameterNum == 2 && currentInput.isEmpty())
        {
            String itemId = totalInput.split(" ")[1];
            boolean hasModId = itemId.contains(":");

            if (hasModId)
            {
                if (FabricLoader.getInstance().isModLoaded("station-registry-api-v0"))
                {
                    Optional<C_98888256> id = ItemRegistry.INSTANCE.getOrEmpty(Identifier.of(itemId));
                    if (id.isPresent())
                    {
                        return new String[]{ String.valueOf(id.get().m_03156313()) };
                    }
                }
                if (FabricLoader.getInstance().isModLoaded("retroapi"))
                {
                    int maxCount = RetroApiCompat.maxCountOf(itemId);
                    if (maxCount != -1)
                    {
                        return new String[]{ String.valueOf(maxCount) };
                    }
                }
            }
        }
        return new String[0];
    }
}
