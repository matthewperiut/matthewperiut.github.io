package com.periut.retrocommands.mixin.feature;

import com.periut.retrocommands.api.ItemInstanceStr;
import com.periut.retrocommands.optionaldep.stapi.block.SpecialMobSpawnerBlock;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_45302099;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_72103717;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_99795455;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(C_81592558.class)
public class BlockBaseMixin {
    @Redirect(method = "<clinit>", at = @At(value = "NEW", target = "(II)Lnet/minecraft/block/SpawnerBlock;"))
    private static C_45302099 staticBlock(int i, int j) {
        if (FabricLoader.getInstance().isModLoaded("station-blockitems-v0"))
            return new SpecialMobSpawnerBlock(i, j);
        else
            return new C_45302099(i, j);
    }

    @Inject(method = "onPlaced(Lnet/minecraft/world/World;IIII)V", at = @At("HEAD"))
    public void onBlockPlaced(C_64041439 i, int j, int k, int l, int direction, CallbackInfo ci) {
        if (C_81592558.f_44428008[i.m_33234383(j, k, l)].m_72526337().startsWith("Mon")) //ster Spawner
        {
            try {
                C_82690114 b = C_82690114.m_23878395(j - 5, k - 5, l - 5, j + 5, k + 5, l + 5);
                List<C_40996800> players = i.m_11058721(C_40996800.class, b);
                String mob = null;
                if (players.size() == 1) {
                    if (players.get(0).f_29439708.m_27760697() != null)
                        mob = ((ItemInstanceStr) (Object) players.get(0).f_29439708.m_27760697()).spc$getStr();
                } else {
                    for (C_40996800 p : players) {
                        if (p.m_01577449().m_23235460().m_17134118().startsWith("Mon")) {
                            if (p.f_29439708.m_27760697() != null)
                                mob = ((ItemInstanceStr) (Object) p.f_29439708.m_27760697()).spc$getStr();
                            break;
                        }
                    }
                }
                if (mob == null)
                    mob = "Pig";

                C_42232651 entity = C_72103717.m_32428905(mob, i);
                if (entity instanceof C_74425583) {
                    ((C_99795455) i.m_40611090(j, k, l)).m_59312260(entity.m_06252001());
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }
}
