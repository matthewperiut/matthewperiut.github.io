package com.periut.retrocommands.command.server;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.ServerUtil;
import com.periut.retrocommands.util.SharedCommandSource;
import net.minecraft.unmapped.C_47185453;

public class Say implements Command {
    @Override
    public void command(SharedCommandSource commandSource, String[] parameters) {
        if (parameters.length < 2) {
            manual(commandSource);
            return;
        }
        String joinedString = ServerUtil.appendEnd(1, parameters);
        ServerUtil.LOGGER.info("[" + commandSource.getName() + "] " + joinedString);
        ServerUtil.getConnectionManager().m_05763283(new C_47185453("§d[Server] " + joinedString));
    }

    @Override
    public String name() {
        return "say";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /say");
        commandSource.sendFeedback("Info: Broadcasts a message to all players");
    }

    @Override
    public boolean disableInSingleplayer() {
        return true;
    }
}
