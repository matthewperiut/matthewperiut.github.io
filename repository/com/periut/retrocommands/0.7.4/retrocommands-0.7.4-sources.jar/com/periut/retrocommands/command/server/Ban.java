package com.periut.retrocommands.command.server;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.ServerUtil;
import com.periut.retrocommands.util.SharedCommandSource;
import net.minecraft.unmapped.C_49202226;

public class Ban implements Command {
    @Override
    public void command(SharedCommandSource commandSource, String[] parameters) {
        if (parameters.length < 2) {
            manual(commandSource);
            return;
        }
        String var13 = parameters[1];
        ServerUtil.getConnectionManager().m_42023880(var13);
        ServerUtil.sendFeedbackAndLog(commandSource.getName(), "Banning " + var13);
        C_49202226 player = ServerUtil.getConnectionManager().m_77290284(var13);
        if (player != null) {
            player.f_70275341.m_85508200("Banned by admin");
        }
    }

    @Override
    public String name() {
        return "ban";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /ban {player}");
        commandSource.sendFeedback("Info: Bans a player from the server");
    }

    @Override
    public boolean disableInSingleplayer() {
        return true;
    }
}
