package com.periut.retrocommands.api;

import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;

@FunctionalInterface
public interface SummonCommand {
    C_42232651 create(C_64041439 level, PosParse pos, String[] parameters); // Modify the parameters as needed
}
