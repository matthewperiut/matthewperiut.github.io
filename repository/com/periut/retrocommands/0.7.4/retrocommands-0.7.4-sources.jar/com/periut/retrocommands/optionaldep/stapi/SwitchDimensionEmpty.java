package com.periut.retrocommands.optionaldep.stapi;

import net.minecraft.unmapped.C_40996800;

public class SwitchDimensionEmpty {
    public static void go(C_40996800 player, String id) {

    }
}
