package com.periut.retrocommands.command.extra;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.SharedCommandSource;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.unmapped.C_40996800;


public class God implements Command {

    public static Map<String, Boolean> isPlayerInvincible = new HashMap<>();

    @Override
    public void command(SharedCommandSource commandSource, String[] parameters) {
        boolean god = false;

        C_40996800 player = commandSource.getPlayer();
        if (player == null) {
            return;
        }

        if (isPlayerInvincible.get(player.f_59008391) != null) {
            god = !isPlayerInvincible.get(player.f_59008391);
            isPlayerInvincible.replace(player.f_59008391, god);
        } else {
            isPlayerInvincible.put(player.f_59008391, true);
            god = true;
        }

        commandSource.sendFeedback("God mode " + (god ? "activated" : "deactivated"));
    }

    @Override
    public String name() {
        return "god";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /god");
        commandSource.sendFeedback("Info: Activates or deactivates invincibility");
    }
}
