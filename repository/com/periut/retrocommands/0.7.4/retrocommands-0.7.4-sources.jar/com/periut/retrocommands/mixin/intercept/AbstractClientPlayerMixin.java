package com.periut.retrocommands.mixin.intercept;

import com.periut.retrocommands.util.RetroChatUtil;
import com.periut.retrocommands.util.SharedCommandSource;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_57778754;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_57778754.class)
public class AbstractClientPlayerMixin {
    @Shadow
    protected Minecraft minecraft;

    @Inject(method = "sendChatMessage", at = @At("HEAD"))
    public void sendFeedbackInSP(String par1, CallbackInfo ci) {
        if (!((Minecraft) FabricLoader.getInstance().getGameInstance()).m_38583715()) // sp check
        {
            C_40996800 player = ((C_40996800) (Object) this);
            if (par1.charAt(0) == '/') {
                // handle commands
                RetroChatUtil.handleCommand(new SharedCommandSource(player), par1.substring(1), true);
            } else {
                ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_28235293.m_81906308("<" + player.f_59008391 + "> " + par1);
            }
        }
    }
}
