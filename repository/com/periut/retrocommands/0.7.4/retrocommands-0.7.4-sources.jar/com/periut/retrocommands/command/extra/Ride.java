package com.periut.retrocommands.command.extra;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.SharedCommandSource;
import java.util.List;
import java.util.TreeMap;
import java.util.stream.Collectors;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_72103717;
import net.minecraft.unmapped.C_82690114;


public class Ride implements Command {


    @Override
    public void command(SharedCommandSource commandSource, String[] parameters) {
        C_40996800 player = commandSource.getPlayer();
        if (player == null) {
            return;
        }

        if (parameters.length < 3) {
            if (player.f_03824457 != null) {
                player.m_41678293(null);
                return;
            }
            manual(commandSource);
            return;
        }

        String rider = parameters[1];
        String vehicle = parameters[2];

        C_42232651 riderEntity = null;
        C_42232651 vehicleEntity = null;

        for (Object o : player.f_94306729.f_51003174) {
            C_40996800 p = (C_40996800) o;
            if (p.f_59008391.equals(rider)) {
                riderEntity = p;
            }
            if (p.f_59008391.equals(vehicle)) {
                vehicleEntity = p;
            }
        }

        int riderId = -1;
        int vehicleId = -1;

        try {
            if (riderEntity == null) riderId = Integer.parseInt(rider);
            if (vehicleEntity == null) vehicleId = Integer.parseInt(vehicle);
        } catch (Exception e) {
            commandSource.sendFeedback("Invalid entity id");
        }

        for (Object o : player.f_94306729.f_97717459) {
            C_42232651 e = (C_42232651) o;

            if (e.f_11112215 == riderId) {
                riderEntity = e;
            }
            if (e.f_11112215 == vehicleId) {
                vehicleEntity = e;
            }
        }

        if (riderEntity == null || vehicleEntity == null) {
            commandSource.sendFeedback("Invalid entity id");
            return;
        }

        riderEntity.m_41678293(vehicleEntity);
        String riderString = riderEntity instanceof C_40996800 ? ((C_40996800) riderEntity).f_59008391 : "The " + (String) C_72103717.f_89671387.get(riderEntity.getClass());
        String vehicleString = vehicleEntity instanceof C_40996800 ? ((C_40996800) vehicleEntity).f_59008391 : "the " + (String) C_72103717.f_89671387.get(vehicleEntity.getClass());
        commandSource.sendFeedback(riderString + " is now on " + vehicleString);
    }

    @Override
    public String name() {
        return "ride";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /ride {rider entity id} {vehicle entity id}");
        commandSource.sendFeedback("Info: Puts an entity on an entity");
        commandSource.sendFeedback("You can find entity id in the F3 menu");
        commandSource.sendFeedback("You can also use player names instead");
    }

    @Override
    public String[] suggestion(SharedCommandSource source, int parameterNum, String currentInput, String totalInput) {
        if (parameterNum == 1 || parameterNum == 2) {
            C_40996800 p = source.getPlayer();
            List<C_42232651> entities = p.f_94306729.m_11058721(C_42232651.class, C_82690114.m_23878395(p.f_78826675-20, p.f_31030949-20, p.f_97691941-20, p.f_78826675+20, p.f_31030949+20, p.f_97691941+20));

            // Use TreeMap to keep entries in order based on the distance
            TreeMap<Double, C_42232651> distanceMap = new TreeMap<>();

            for (C_42232651 entity : entities) {
                double distance = p.m_22973163(entity);
                // Handle potential duplicates (unlikely but possible)
                while (distanceMap.containsKey(distance)) {
                    distance += 0.0001;  // Small offset to handle entities at almost same distance
                }
                distanceMap.put(distance, entity);
            }

            // Extract entity IDs from sorted entities and convert them to String
            // If entity is a PlayerBase, use getName() instead
            List<String> sortedEntityIDs = distanceMap.values().stream()
                    .map(entity -> {
                        if (entity instanceof C_40996800) {
                            return ((C_40996800) entity).f_59008391;
                        } else {
                            return Integer.toString(entity.f_11112215);
                        }
                    })
                    .collect(Collectors.toList());

            // Filter and modify the suggestions based on currentInput
            for (int i = sortedEntityIDs.size() - 1; i >= 0; i--) {  // Change loop condition to i >= 0
                if (!sortedEntityIDs.get(i).startsWith(currentInput)) {
                    sortedEntityIDs.remove(i);
                } else {
                    if (parameterNum == 2)
                    {
                        if (sortedEntityIDs.get(i).equals(totalInput.split(" ")[1]))
                        {
                            sortedEntityIDs.remove(i);
                        }
                        else
                        {
                            sortedEntityIDs.set(i, sortedEntityIDs.get(i).substring(currentInput.length()));
                        }
                    }
                    else
                    {
                        sortedEntityIDs.set(i, sortedEntityIDs.get(i).substring(currentInput.length()));
                    }
                }
            }

            return sortedEntityIDs.toArray(new String[0]);
        }
        return new String[0];
    }

}
