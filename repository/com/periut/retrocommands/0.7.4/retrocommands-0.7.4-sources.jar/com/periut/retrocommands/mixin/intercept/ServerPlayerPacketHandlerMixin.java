package com.periut.retrocommands.mixin.intercept;

import com.periut.retrocommands.util.ServerUtil;
import com.periut.retrocommands.util.RetroChatUtil;
import com.periut.retrocommands.util.SharedCommandSource;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_99660737;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_99660737.class)
public abstract class ServerPlayerPacketHandlerMixin {
    @Shadow private C_49202226 player;

    @Shadow public abstract void sendPacket(C_03562565 arg);

    @Inject(method = "handleCommand", at = @At(value = "HEAD"), cancellable = true)
    private void parseRegularCommand(String string, CallbackInfo ci) {
        if (!ServerUtil.getConnectionManager().m_55622692(player.f_59008391))
            if (RetroChatUtil.handleCommand(new SharedCommandSource(this), string.substring(1), false))
                ci.cancel();
    }
}
