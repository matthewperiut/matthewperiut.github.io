package com.periut.retrocommands.command.extra;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.SharedCommandSource;
import java.util.Map;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_72103717;


public class Mobs implements Command {
    public static Map<String, Class<? extends C_42232651>> getMobSet()
    {
        return C_72103717.f_82260251;
    }

    @Override
    public void command(SharedCommandSource commandSource, String[] parameters) {
        commandSource.sendFeedback("Mobs that can be spawned, Case-Sensitive usage!");
        Map<String, Class<? extends C_42232651>> map = getMobSet();

        String msg = "";
        for (Map.Entry<String, Class<? extends C_42232651>> entry : map.entrySet()) {
            msg += "\"" + entry.getKey() + "\", ";
            if (msg.length() > 50) {
                commandSource.sendFeedback(msg);
                msg = "";
            }
        }
        commandSource.sendFeedback(msg.substring(0, msg.length() - 2)); // removes last comma then sends
    }

    @Override
    public String name() {
        return "mobs";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /mobs");
        commandSource.sendFeedback("Info: gives the list of mobs");
    }

    public boolean needsPermissions() {
        return false;
    }
}
