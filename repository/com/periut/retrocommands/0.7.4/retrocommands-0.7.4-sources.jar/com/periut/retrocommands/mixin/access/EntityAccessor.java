package com.periut.retrocommands.mixin.access;

import net.minecraft.unmapped.C_42232651;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_42232651.class)
public interface EntityAccessor {
    @Accessor("dataTracker")
    net.minecraft.unmapped.C_61027059 getDataTracker();
}
