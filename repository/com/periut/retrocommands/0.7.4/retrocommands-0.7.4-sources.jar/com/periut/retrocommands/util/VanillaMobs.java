package com.periut.retrocommands.util;

import com.periut.retrocommands.api.SummonRegistry;
import com.periut.retrocommands.mixin.access.EntityAccessor;
import net.minecraft.unmapped.C_09140510;
import net.minecraft.unmapped.C_22077616;
import net.minecraft.unmapped.C_43112843;
import net.minecraft.unmapped.C_87105418;
import net.minecraft.unmapped.C_99730074;

public class VanillaMobs {
    public static void setupSummons() {
        SummonRegistry.add(C_43112843.class, (level, pos, param) -> {
            C_43112843 creeper = new C_43112843(level);

            if (param.length > 5)
                if (!param[5].isEmpty())
                    if (param[5].charAt(0) != '0')
                        ((EntityAccessor) creeper).getDataTracker().m_52395024(17, (byte) 1);

            return creeper;
        }, "{charged (0 or 1)}");

        SummonRegistry.add(C_99730074.class, (level, pos, param) -> {
            int color = Integer.parseInt(param[5]);
            int has_wool = 1;
            if (param.length > 6)
                has_wool = Integer.parseInt(param[6]);
            C_99730074 sheep = new C_99730074(level);
            sheep.m_71024489(has_wool == 0);
            sheep.m_60335413(color);
            return sheep;
        }, "{color meta} {has wool (0 or 1)}");

        SummonRegistry.add(C_87105418.class, (level, pos, param) -> {
            int meta = Integer.parseInt(param[5]);
            if (meta != 0)
                meta = 1;

            C_87105418 pig = new C_87105418(level);
            ((EntityAccessor) pig).getDataTracker().m_52395024(16, (byte) meta);
            return pig;
        }, "{saddle (0 or 1)}");

        SummonRegistry.add(C_22077616.class, (level, pos, param) -> {
            int meta = Integer.parseInt(param[5]);
            C_22077616 slime = new C_22077616(level);
            if (meta > 0) {
                ((EntityAccessor) slime).getDataTracker().m_52395024(16, (byte) meta);
            }
            return slime;
        }, "{size (int > 0)}");

        SummonRegistry.add(C_09140510.class, (level, pos, param) -> {
            int fuse = Integer.parseInt(param[5]);
            C_09140510 tnt = new C_09140510(level);
            if (fuse > 0) {
                tnt.f_25392235 = fuse;
            }
            return tnt;
        }, "{fuse ticks (int > 0)}");
    }
}
