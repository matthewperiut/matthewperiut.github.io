package com.periut.retrocommands.util;

import com.periut.retrocommands.mixin.access.ServerPlayerPacketHandlerAccessor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_23078083;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_99660737;

public class SharedCommandSource {
    private final Object actualSource;

    public SharedCommandSource(Object source) {
        this.actualSource = source;
    }

    public void sendFeedback(String feedback) {
        EnvType side = FabricLoader.getInstance().getEnvironmentType();
        switch (side) {
            case CLIENT -> sendClientFeedback("§7" + feedback);
            case SERVER -> sendServerFeedback(feedback);
            default -> throw new IllegalArgumentException("Unknown side " + side + "!");
        }
    }

    public String getName() {
        if (actualSource instanceof C_40996800 player) {
            return player.f_59008391;
        } else {
            EnvType side = FabricLoader.getInstance().getEnvironmentType();
            if (side == EnvType.CLIENT) {
                return getNameClient();
            }
            if (side == EnvType.SERVER) {
                return getNameServer();
            }
        }
        return "unknown";
    }

    public C_40996800 getPlayer() {
        if (actualSource instanceof C_40996800 player) {
            return player;
        } else {
            EnvType side = FabricLoader.getInstance().getEnvironmentType();
            if (side == EnvType.CLIENT) {
                return getPlayerClient();
            }
            if (side == EnvType.SERVER) {
                return getPlayerServer();
            }
        }
        return null;
    }

    @Environment(EnvType.CLIENT)
    private C_40996800 getPlayerClient() {
        return ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_28396371;
    }

    @Environment(EnvType.SERVER)
    private C_40996800 getPlayerServer() {
        if (actualSource instanceof C_99660737 playerPacketHandler) {
            return ((ServerPlayerPacketHandlerAccessor) playerPacketHandler).getServerPlayer();
        } else {
            return null;
        }
    }

    @Environment(EnvType.CLIENT)
    private String getNameClient() {
        return "client";
    }

    @Environment(EnvType.SERVER)
    private String getNameServer() {
        if (actualSource instanceof C_23078083 cmdSrc) {
            return cmdSrc.m_64276922();
        }
        return "unknown";
    }

    @Environment(EnvType.CLIENT)
    private void sendClientFeedback(String feedback) {
        ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_28235293.m_81906308(feedback);
    }

    @Environment(EnvType.SERVER)
    private void sendServerFeedback(String feedback) {
        ((C_23078083) actualSource).m_28323918(feedback);
    }

    public boolean isClient() {
        return FabricLoader.getInstance().getEnvironmentType() == EnvType.CLIENT;
    }
}
