package com.periut.retrocommands.command.server;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.ServerUtil;
import com.periut.retrocommands.util.SharedCommandSource;
import net.minecraft.unmapped.C_29639016;

public class Save implements Command {
    @Override
    public void command(SharedCommandSource commandSource, String[] parameters) {
        if (parameters.length < 2) {
            manual(commandSource);
            return;
        }

        C_29639016 scm = ServerUtil.getConnectionManager();

        switch (parameters[1]) {
            case "all":
                ServerUtil.sendFeedbackAndLog(commandSource.getName(), "Forcing save..");
                if (scm != null) {
                    scm.m_91002909();
                }

                for (int i = 0; i < ServerUtil.getServer().f_58488472.length; ++i) {
                    ServerUtil.getServer().f_58488472[i].m_70994780(true, null);
                }

                ServerUtil.sendFeedbackAndLog(commandSource.getName(), "Save complete.");
                break;
            case "off":
                ServerUtil.sendFeedbackAndLog(commandSource.getName(), "Disabling level saving..");

                for (int i = 0; i < ServerUtil.getServer().f_58488472.length; ++i) {
                    ServerUtil.getServer().f_58488472[i].f_93442927 = true;
                }
                break;
            case "on":
                ServerUtil.sendFeedbackAndLog(commandSource.getName(), "Enabling level saving..");

                for (int i = 0; i < ServerUtil.getServer().f_58488472.length; ++i) {
                    ServerUtil.getServer().f_58488472[i].f_93442927 = false;
                }
                break;
            default:
                break;
        }
    }

    @Override
    public String name() {
        return "save";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /save {all/off/on}");
        commandSource.sendFeedback("Info: save all | forces a server-wide level save");
        commandSource.sendFeedback("      save off | disables terrain saving (useful for backup scripts)");
        commandSource.sendFeedback("      save on  | re-enables terrain saving");
    }

    @Override
    public boolean disableInSingleplayer() {
        return true;
    }
}
