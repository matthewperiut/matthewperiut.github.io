package com.periut.retrocommands.optionaldep.stapi.block;

import com.periut.retrocommands.optionaldep.stapi.item.MobSpawnerBlockItem;
import net.minecraft.unmapped.C_45302099;
import net.modificationstation.stationapi.api.block.HasCustomBlockItemFactory;

@HasCustomBlockItemFactory(MobSpawnerBlockItem.class)
public class SpecialMobSpawnerBlock extends C_45302099 {
    public SpecialMobSpawnerBlock(int i, int j) {
        super(i, j);
    }
}
