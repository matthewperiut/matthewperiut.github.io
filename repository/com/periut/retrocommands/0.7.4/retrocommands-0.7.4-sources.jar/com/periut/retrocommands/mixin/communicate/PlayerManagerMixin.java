package com.periut.retrocommands.mixin.communicate;

import com.periut.retrocommands.RetroCommandsNetworking;
import com.periut.retrocommands.util.ServerUtil;
import net.minecraft.unmapped.C_29639016;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_99660737;
import net.ornithemc.osl.networking.api.server.ServerPlayNetworking;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(C_29639016.class)
public abstract class PlayerManagerMixin {
    @Shadow public List players;

    @Inject(method = "addPlayer", at = @At("TAIL"))
    public void sendPlayersToAll(C_49202226 par1, CallbackInfo ci) {

        C_99660737 serverPlayNetworkHandler = (C_99660737) par1.f_70275341;
        ServerUtil.informPlayerOpStatus(serverPlayNetworkHandler.m_64276922());
        ServerUtil.informPlayerDisabledCommands(serverPlayNetworkHandler.m_64276922());

        String playerNames = "";
        for (Object object : players) {
            C_40996800 player = (C_40996800) object;
            playerNames += player.f_59008391 + ",";
        }

        playerNames = playerNames.substring(0, playerNames.length()-1);

        String finalPlayerNames = playerNames;
        for (Object object : players) {
            C_49202226 player = (C_49202226) object;
            ServerPlayNetworking.send(player, RetroCommandsNetworking.PLAYERS_CHANNEL, buffer -> {
                buffer.writeString(finalPlayerNames);
            });
        }
    }
}
