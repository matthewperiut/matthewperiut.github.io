package com.periut.retrocommands.mixin.client;

import com.periut.retrocommands.RetroCommands;
import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.optionaldep.mojangfix.MJFChatAccess;
import com.periut.retrocommands.util.ConfigUtil;
import com.periut.retrocommands.util.RetroChatUtil;
import com.periut.retrocommands.util.SharedCommandSource;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_63704535;
import net.minecraft.unmapped.C_77279411;
import net.minecraft.unmapped.C_85740840;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

import static com.periut.retrocommands.RetroCommands.*;

@Mixin(value = C_63704535.class, priority = 1100)
public abstract class ChatScreenMixin extends C_85740840 {
    @Shadow protected String text;
    @Shadow private int focusedTicks;

    @Unique private boolean autocomplete = false;
    @Unique private String[] suggestions = new String[0];
    @Unique private int chosen = 0;
    @Unique private int textWidthPixels = 0;
    @Unique private int textWidthPixelsBeforeCurrentWord = 0;
    @Unique private String currentWord = "";

    /* Mixin field initializers are merged by injecting into the target constructor;
     * that merge can silently fail, leaving @Unique fields null. Never rely on it. */
    @Unique
    private void ensureFieldsInitialized() {
        if (suggestions == null) suggestions = new String[0];
        if (currentWord == null) currentWord = "";
    }

    @Unique
    void setText(String s) {
        if (mojangFix) {
            MJFChatAccess.setText(s);
        }

        if (text != null)
            text = s;
    }

    @Unique
    String getText() {
        String result;
        if (mojangFix) {
            result = MJFChatAccess.getText();
        } else {
            result = text;
        }

        if (result == null)
            result = "";

        return result;
    }

    @Unique
    void appendText(String s) {
        setText(text + s);
    }

    @Inject(method = "init", at = @At("HEAD"))
    void init(CallbackInfo ci) {
        ensureFieldsInitialized();
        if (cryConfig && !f_78495264.m_38583715()) {
            ConfigUtil.refreshDisabledCommands();
        }
    }

    @Inject(method = "keyPressed", at = @At("HEAD"), cancellable = true)
    private void keyPressedInit(char i, int par2, CallbackInfo ci) {
        ensureFieldsInitialized();
        if (par2 == 15 && suggestions.length > 0) {
            autocomplete = true;
        }

        if (suggestions.length > 1) {
            if (adjustChosenSuggestion(par2))
                ci.cancel();
        }
    }

    @Inject(method = "keyPressed", at = @At("TAIL"))
    private void processInput(char i, int par2, CallbackInfo ci) {
        resetValues();

        if (getText().isEmpty()) {
            return;
        }

        String[] sections = getText().split(" ");
        if (sections.length == 0) {
            return;
        }

        currentWord = sections[sections.length - 1];
        fetchSuggestionsForCurrentWord(sections);

        if (getText().endsWith(" "))
            currentWord = "";

        if (suggestions.length > 1) {
            calculateTextWidthPixelsBeforeCurrentWord(sections);
        }
    }

    @Unique
    private void resetValues() {
        currentWord = "";
        suggestions = new String[0];
    }

    @Unique
    private static final List<String> vanillaNoOPCommands = Collections.unmodifiableList(
            new ArrayList<String>() {{
                add("me");
                add("kill");
                add("tell");
            }});

    @Unique
    private void fetchSuggestionsForCurrentWord(String[] sections) {
        try {
            Minecraft mc = ((Minecraft) FabricLoader.getInstance().getGameInstance());

            if (getText().startsWith(" ")) {
                return;
            }

            if (sections.length == 1 && currentWord.length() > 1 && getText().charAt(0) == '/' && !getText().endsWith(" ")) {

                if (mc.f_26407825.f_50876584 && !RetroCommands.mp_rc) {
                    suggestions = vanillaNoOPCommands.stream()
                            .filter(s -> s.startsWith(currentWord.substring(1)))
                            .map(s -> s.substring(getText().length() - 1))
                            .toArray(String[]::new);
                } else {
                    suggestions = RetroChatUtil.commands.stream()
                            .filter(c -> c.name().startsWith(currentWord.substring(1)))
                            .filter(c -> !RetroCommands.disabled_commands.contains(c.name()))
                            .filter(c -> (!c.disableInSingleplayer() || mc.f_26407825.f_50876584))
                            .filter(c -> (RetroCommands.mp_op || !c.needsPermissions() || !mc.f_26407825.f_50876584))
                            .map(c -> c.name().substring(getText().length() - 1))
                            .toArray(String[]::new);
                }
            } else {
                Command command = RetroChatUtil.commands.stream()
                        .filter(c -> c.name().equals(sections[0].substring(1)))
                        .filter(c -> (!c.disableInSingleplayer() || mc.f_26407825.f_50876584))
                        .filter(c -> (RetroCommands.mp_op || !c.needsPermissions() || !mc.f_26407825.f_50876584))
                        .findFirst().orElse(null);
                if (command != null && (!command.disableInSingleplayer() || mc.f_26407825.f_50876584)) {
                    C_40996800 player = mc.f_28396371;
                    SharedCommandSource source = new SharedCommandSource(player);
                    suggestions = getText().endsWith(" ") ? command.suggestion(source, sections.length, "", getText()) : command.suggestion(source, sections.length - 1, currentWord, getText());
                }
            }

            textWidthPixels = this.f_11884601.m_09235706("> " + this.getText());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    @Unique
    private boolean adjustChosenSuggestion(int par2) {
        int initial = chosen;
        if (par2 == 200) { chosen++; }
        if (par2 == 208) { chosen--; }
        if (chosen < 0) { chosen = suggestions.length - 1; }
        if (chosen >= suggestions.length) { chosen = 0; }
        return initial != chosen;
    }

    @Unique
    private void calculateTextWidthPixelsBeforeCurrentWord(String[] sections) {
        for (int j = 0; j < sections.length - 1; j++) {
            textWidthPixelsBeforeCurrentWord += f_11884601.m_09235706(sections[j] + " ");
        }
    }

    @Unique
    boolean tryMatch(String s) {
        try {
            AtomicBoolean valid = new AtomicBoolean(false);
            RetroChatUtil.commands.stream().forEach(a -> {
                if (a.name().equals(s)) {
                    if (!f_78495264.f_26407825.f_50876584) {
                        valid.set(true);
                    } else {
                        if (mp_op) {
                            valid.set(true);
                        } else {
                            if (!a.needsPermissions()) {
                                valid.set(true);
                            }
                        }
                    }
                }
            });
            if (valid.get()) {
                 return true;
            }
        } catch (Exception e) {
            return false;
        }
        return false;
    }

    private static final int KEY_SECTION = 103;

    @Inject(method = "render", at = @At(value = "HEAD"), cancellable = true)
    public void replace(int mouseX, int mouseY, float delta, CallbackInfo ci) {
        ensureFieldsInitialized();
        this.m_57734177(2, this.f_07021018 - 14, this.f_05230747 - 2, this.f_07021018 - 2, Integer.MIN_VALUE);
        renderSuggestions(mouseX, mouseY, delta);
        String textToRender = "> " + this.getText();
        int textColor = 0xE0E0E0;

        /* Determine cursor position (0 means end of the string) */
        int cursorPosition = 0;
        if (mojangFix) {
            cursorPosition = MJFChatAccess.getCursorPosition();
        }

        /* Determine if text goes off the screen and if so then determine how many characters need cut for it to fit on screen */
        int stringWidth = f_11884601.m_09235706(textToRender);
        int shiftBy = -1; // -1 means do not shift
        if (stringWidth > (this.f_05230747 - 15)) {
            int textToRenderFullLength = textToRender.length();
            int widthToRemove = 0;
            int textIndex;

            /* Remove characters from the start of the string until the string can fit on the screen */
            for(textIndex = 0; textIndex < textToRender.length(); ++textIndex) {
                if (textToRender.charAt(textIndex) == KEY_SECTION) {
                    ++textIndex;
                } else {
                    int charIndex = C_77279411.f_42800273.indexOf(textToRender.charAt(textIndex));
                    if (charIndex >= 0) {
                        widthToRemove += f_11884601.f_45069205[charIndex + 32];
                    }
                }

                if ((stringWidth - widthToRemove) < (this.f_05230747 - 15)) {
                    break;
                }
            }

            /* Determine what section of the string to render based on cursor position */
            if (textIndex <= (textToRenderFullLength + (cursorPosition - 2))) {
                textToRender = textToRender.substring(textIndex);
            } else {
                shiftBy = textIndex - (textToRenderFullLength + (cursorPosition - 2));
                textToRender = textToRender.substring(textIndex - shiftBy, textToRenderFullLength - shiftBy);
            }
        }

        /* Determine text color and render prompt text */
        int widthOffset = 0;
        int charsRendered = 0;
        if (textToRender.startsWith("> ")) {
            String typedText = textToRender.substring(2);
            if (  typedText.startsWith("/")
               && !typedText.contains(" ")
               && !tryMatch(typedText.substring(1))
            ) {
                m_62884682(this.f_11884601, "> /", 4, this.f_07021018 - 12, textColor);
                widthOffset = f_11884601.m_09235706("> /");
                textColor = 0xFC5454;
                charsRendered = 3;
            } else if (typedText.startsWith("/")){
                if (!tryMatch(typedText.split(" ")[0].substring(1))) {
                    m_62884682(this.f_11884601, "> ", 4, this.f_07021018 - 12, textColor);
                    widthOffset = f_11884601.m_09235706("> ");
                    textColor = 0xFC5454;
                    charsRendered = 2;
                }
            }
        }

        /* Determine where to position cursor */
        boolean caretVisible = focusedTicks / 6 % 2 == 0;
        if (0 <= shiftBy) {
            textToRender = (new StringBuilder(textToRender)).insert(2, (caretVisible) ? "_" : "").toString();
        } else {
            textToRender = (new StringBuilder(textToRender)).insert(textToRender.length() + cursorPosition, (caretVisible) ? "_" : "").toString();
        }

        /* Render text, render screen, and cancel original method */
        m_62884682(this.f_11884601,  textToRender.substring(charsRendered), 4 + widthOffset, this.f_07021018 - 12, textColor);
        super.m_93956703(mouseX, mouseY, delta);
        ci.cancel();
    }

    @Unique
    public void renderSuggestions(int mouseX, int mouseY, float delta) {
        try {
            if (suggestions.length > 0) {
                ensureChosenIsInRange();
                renderChosenSuggestion();
                if (suggestions.length > 1) {
                    renderMultipleSuggestions();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Unique
    private void ensureChosenIsInRange() {
        if (chosen < 0 || chosen >= suggestions.length) {
            chosen = 0;
        }
    }

    @Unique
    private void renderChosenSuggestion() {
        this.m_62884682(this.f_11884601, suggestions[chosen], 4 + textWidthPixels, this.f_07021018 - 12, 0xAAAAAA);
        if (autocomplete) {
            appendText(suggestions[chosen]);
            autocomplete = false;
            suggestions = new String[0];
        }
    }

    @Unique
    private void renderMultipleSuggestions() {
        int textWidthCurrentWord = f_11884601.m_09235706(currentWord);
        textWidthPixelsBeforeCurrentWord = f_11884601.m_09235706("> " + getText()) - textWidthCurrentWord;
        m_57734177(textWidthPixelsBeforeCurrentWord + 4,
                this.f_07021018 - 14 - (10 * suggestions.length),
                textWidthPixelsBeforeCurrentWord + textWidthCurrentWord + getMaxSuggestionWidth() + 4,
                this.f_07021018 - 14,
                0xFF000000);

        for (int i = 0; i < suggestions.length; i++) {
            this.m_62884682(this.f_11884601, currentWord + suggestions[i], textWidthPixelsBeforeCurrentWord + 4, this.f_07021018 - 12 - (10 * (i + 1)), i == chosen ? 0xfcfc00 : 0xFFFFFF);
        }
    }

    @Unique
    private int getMaxSuggestionWidth() {
        int maxWidth = 0;
        for (String suggestion : suggestions) {
            int width = f_11884601.m_09235706(suggestion);
            if (maxWidth < width) {
                maxWidth = width;
            }
        }
        return maxWidth;
    }
}
