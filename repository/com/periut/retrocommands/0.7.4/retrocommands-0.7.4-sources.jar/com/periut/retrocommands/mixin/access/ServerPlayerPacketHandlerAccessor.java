package com.periut.retrocommands.mixin.access;

import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_99660737;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_99660737.class)
public interface ServerPlayerPacketHandlerAccessor {
    @Accessor("player")
    C_49202226 getServerPlayer();
}
