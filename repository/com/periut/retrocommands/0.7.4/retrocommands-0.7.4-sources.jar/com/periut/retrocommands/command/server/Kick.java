package com.periut.retrocommands.command.server;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.ServerUtil;
import com.periut.retrocommands.util.SharedCommandSource;
import net.minecraft.unmapped.C_29639016;
import net.minecraft.unmapped.C_49202226;

public class Kick implements Command {
    @Override
    public void command(SharedCommandSource commandSource, String[] parameters) {
        if (parameters.length < 2) {
            manual(commandSource);
            return;
        }
        String message = ServerUtil.appendEnd(2, parameters);
        C_49202226 player = null;
        C_29639016 scm = ServerUtil.getConnectionManager();

        for (int i = 0; i < scm.f_62748363.size(); ++i) {
            C_49202226 var9 = (C_49202226) scm.f_62748363.get(i);
            if (var9.f_59008391.equalsIgnoreCase(parameters[1])) {
                player = var9;
            }
        }

        if (player != null) {
            player.f_70275341.m_85508200(parameters.length > 2 ? message : "Kicked by admin");
            ServerUtil.sendFeedbackAndLog(commandSource.getName(), "Kicking " + player.f_59008391);
        } else {
            commandSource.sendFeedback("Can't find user " + message + ". No kick.");
        }
    }

    @Override
    public String name() {
        return "kick";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /kick {player}");
        commandSource.sendFeedback("Info: Removes a player from the server");
    }

    @Override
    public boolean disableInSingleplayer() {
        return true;
    }
}
