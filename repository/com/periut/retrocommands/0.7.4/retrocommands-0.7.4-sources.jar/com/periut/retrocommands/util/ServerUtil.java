package com.periut.retrocommands.util;

import com.periut.retrocommands.RetroCommands;
import com.periut.retrocommands.api.PosParse;
import com.periut.retrocommands.command.server.Tpa;
import com.periut.retrocommands.dimension.BareTravelAgent;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import com.periut.retrocommands.RetroCommandsNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.unmapped.C_29639016;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.api.registry.DimensionRegistry;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.api.world.dimension.DimensionHelper;
import net.ornithemc.osl.networking.api.server.ServerPlayNetworking;

import java.util.Optional;
import java.util.logging.Logger;

import static com.periut.retrocommands.command.vanilla.Teleport.switchDimensions;
import static com.periut.retrocommands.command.vanilla.Teleport.teleport;
import static com.periut.retrocommands.command.server.Tpa.requests;

public class ServerUtil {
    public static Logger LOGGER = Logger.getLogger("Minecraft");

    public static MinecraftServer getServer() {
        return (MinecraftServer) FabricLoader.getInstance().getGameInstance();
    }

    public static C_29639016 getConnectionManager() {
        return getServer().f_65897993;
    }

    public static void sendFeedbackAndLog(String user, String message) {
        String str = user + ": " + message;
        ServerUtil.getConnectionManager().m_27308858("§7(" + str + ")");
        LOGGER.info(str);
    }

    public static String appendEnd(int start, String[] parameters) {
        StringBuilder joinedString = new StringBuilder();
        for (int i = start; i < parameters.length; i++) {
            joinedString.append(parameters[i]).append(" ");
        }

        return joinedString.toString();
    }

    public static boolean isOp(String name) {
        return getServer().f_65897993.m_55622692(name);
    }

    public static void serverTeleport(C_40996800 p, double x, double y, double z) {
        C_49202226 sp = (C_49202226) p;
        sp.f_70275341.m_40197477(x, y, z, p.f_80130373, p.f_03549461);
    }

    public static void teleportPlayerToPos(SharedCommandSource source, String targetName, PosParse pos, String dim) {
        C_40996800 target = ServerUtil.getConnectionManager().m_77290284(targetName);
        if (target == null) {
            source.sendFeedback("Can't find user " + targetName + ". No tp.");
        } else {
            if (!dim.isEmpty()) {
                if (!switchDimensions(source, dim)) {
                    source.sendFeedback("Dimension " + dim + " does not exist. No tp.");
                    return;
                }
            }
            teleport(target, target.f_78826675, target.f_31030949, target.f_97691941);
            source.sendFeedback("Teleporting " + targetName + " to " + pos + ".");
        }
    }

    @Environment(EnvType.SERVER)
    public static void teleportToPlayer(SharedCommandSource source, C_40996800 player, String targetName) {
        C_40996800 target = ServerUtil.getConnectionManager().m_77290284(targetName);
        if (target == null) {
            source.sendFeedback("Can't find user " + targetName + ". No tp.");
        } else {
            switchDim(source, player, target);
            teleport(player, target.f_78826675, target.f_31030949, target.f_97691941);
            source.sendFeedback("Teleporting " + player.f_59008391 + " to " + targetName + ".");
        }
    }

    @Environment(EnvType.SERVER)
    public static void teleportPlayerToPlayer(SharedCommandSource source, String playerName, String targetName) {
        C_40996800 player = ServerUtil.getConnectionManager().m_77290284(playerName);
        C_40996800 target = ServerUtil.getConnectionManager().m_77290284(targetName);
        if (player == null) {
            source.sendFeedback("Can't find user " + playerName + ". No tp.");
            return;
        }
        else if (target == null) {
            source.sendFeedback("Can't find user " + targetName + ". No tp.");
            return;
        } else {
            switchDim(source, player, target);
            teleport(player, target.f_78826675, target.f_31030949, target.f_97691941);
            source.sendFeedback("Teleporting " + player.f_59008391 + " to " + targetName + ".");
        }
    }

    private static void switchDim(SharedCommandSource source, C_40996800 player, C_40996800 target) {
        if (player.f_15409937 != target.f_15409937) {
            if (!FabricLoader.getInstance().isModLoaded("station-dimensions-v0")) {
                source.sendFeedback("User " + player.f_59008391 + " and " + target.f_59008391 + " are in different dimensions. No tp.");
                return;
            }
            Optional<Identifier> dim = DimensionRegistry.INSTANCE.getId(target.f_15409937);
            if (dim.isPresent()) {
                DimensionHelper.switchDimension(player, dim.get(), 1, new BareTravelAgent());
            } else {
                source.sendFeedback("User " + player.f_59008391 + " and " + target.f_59008391 + " are in different dimensions. No tp.");
                return;
            }
        }
    }

    public static void tpa(SharedCommandSource commandSource, String[] parameters) {
        C_40996800 player = commandSource.getPlayer();
        if (player == null) {
            commandSource.sendFeedback("You must be a player to tpa.");
            return;
        }

        if (parameters.length > 1) {
            C_64041439 world = ServerUtil.getServer().m_54705229(0);

            if (parameters[1].equals("accept")) {
                for (int i = requests.size() - 1; i >= 0; i--) {
                    Tpa.Request request = requests.get(i);
                    if (request.to.equals(player.f_59008391)) {
                        if (world.m_13949261() - request.time > 2400) {
                            commandSource.sendFeedback("This tpa request has expired");
                            requests.remove(request);
                            return;
                        } else {
                            C_40996800 from = ServerUtil.getConnectionManager().m_77290284(request.from);
                            if (from != null) {
                                ServerUtil.teleportPlayerToPlayer(commandSource, request.from, request.to);
                            } else {
                                commandSource.sendFeedback(request.from + " is no longer online.");
                            }
                            return;
                        }
                    }
                }
            }

            C_40996800 target = ServerUtil.getConnectionManager().m_77290284(parameters[1]);
            if (target == null) {
                commandSource.sendFeedback("Can't find user " + parameters[1] + ". No tpa.");
                return;
            }

            target.m_83523863("§7" + player.f_59008391 + " wants to tp to you.");
            target.m_83523863("§7type \"/tpa accept\" to allow them to. (expires in 2 min)");

            requests.add(new Tpa.Request(player.f_59008391, target.f_59008391, world.m_13949261()));

        } else {
            commandSource.sendFeedback("You must have a target to tpa to.");
        }
    }

    public static void informPlayerOpStatus(String playerName) {
        C_49202226 player = (C_49202226) getConnectionManager().m_77290284(playerName);
        if (player == null) return;
        ServerPlayNetworking.send(player, RetroCommandsNetworking.OP_CHANNEL, buffer -> {
            buffer.writeBoolean(isOp(playerName));
        });
    }

    public static void informPlayerDisabledCommands(String playerName) {
        C_49202226 player = (C_49202226) getConnectionManager().m_77290284(playerName);
        if (player == null) return;
        ServerPlayNetworking.send(player, RetroCommandsNetworking.DISABLED_CHANNEL, buffer -> {
            if (!RetroCommands.cryConfig) {
                buffer.writeString("");
            } else {
                buffer.writeString(String.join(",", RetroCommands.disabled_commands));
            }
        });
    }
}
