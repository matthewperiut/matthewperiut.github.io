package com.periut.retrocommands.mixin.feature;

import com.periut.retrocommands.api.PlayerWarps;
import com.periut.retrocommands.command.extra.God;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_74087615;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

// Priority 999 to cancel fire even when in creative, because creative also cancels here.
// BHCreative uses priority 1000
@Mixin(value = C_40996800.class, priority = 999)
public class PlayerBaseMixin implements PlayerWarps {
    @Inject(method = "damage", at = @At("HEAD"), cancellable = true)
    public void onGod(C_42232651 i, int par2, CallbackInfoReturnable<Boolean> cir) {
        C_40996800 player = (C_40996800) (Object) this;

        if (God.isPlayerInvincible.containsKey(player.f_59008391))
            if (God.isPlayerInvincible.get(player.f_59008391)) {
                if (player.f_56993461 > 0)
                    player.f_56993461 = 0;

                cir.cancel();
            }
    }

    @Unique
    String warpStr = "";

    @Override
    public void spc$setWarpString(String warp) {
        warpStr = warp;
    }

    @Override
    public String spc$getWarpString() {
        return warpStr;
    }

    @Inject(method = "readNbt", at = @At("TAIL"))
    private void readFromTag(C_74087615 tag, CallbackInfo ci) {
        if (tag.m_97612750("warps")) warpStr = tag.m_47517355("warps");
    }

    @Inject(method = "writeNbt", at = @At("TAIL"))
    private void writeToTag(C_74087615 tag, CallbackInfo ci) {
        if (!warpStr.isEmpty()) tag.m_91017064("warps", warpStr);
    }
}
