package com.periut.retrocommands.command.server;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.ParameterSuggestUtil;
import com.periut.retrocommands.util.ServerUtil;
import com.periut.retrocommands.util.SharedCommandSource;
import java.util.Arrays;
import net.minecraft.unmapped.C_47185453;

public class Tell implements Command {
    @Override
    public void command(SharedCommandSource commandSource, String[] parameters) {
        if (parameters.length > 3) {
            String a = parameters[1];
            String b = "";
            for (int i = 2; i < parameters.length; i++) {
                b += parameters[i];
            }
            String message = "§7" + commandSource.getName() + " whispers " + b;
            System.out.println(message + " to " + a);
            if (!ServerUtil.getConnectionManager().m_70956744(a, new C_47185453(message))) {
                commandSource.sendFeedback("§cThere's no player by that name online.");
            }
        }
    }

    @Override
    public String name() {
        return "tell";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /tell {player} <message>");
        commandSource.sendFeedback("Whisper to another player");
    }

    @Override
    public String[] suggestion(SharedCommandSource source, int parameterNum, String currentInput, String totalInput) {
        if (parameterNum == 1) {
            System.out.println(currentInput);
            System.out.println(Arrays.toString(ParameterSuggestUtil.suggestPlayerName(currentInput)));
        }
        return new String[0];
    }
}
