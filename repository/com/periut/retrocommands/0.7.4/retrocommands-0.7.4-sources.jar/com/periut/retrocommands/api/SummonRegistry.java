package com.periut.retrocommands.api;

import com.periut.retrocommands.command.vanilla.Summon;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;

public class SummonRegistry {
    private static Map<Class<? extends C_42232651>, SummonCommand> entityFactories = new HashMap<>();

    public static void add(Class<? extends C_42232651> entity, SummonCommand cmd, String param_desc) {
        SummonCommand c = entityFactories.put(entity, cmd);
        if (c != null)
            System.out.println("[retrocommands] Overwrote " + c + " with " + cmd + " for summoning " + entity);


        Summon.help.put(entity, param_desc);
    }

    public static C_42232651 create(Class<? extends C_42232651> entityClass, C_64041439 level, PosParse pos, String[] param) {
        SummonCommand entityConstructor = entityFactories.get(entityClass);
        if (entityConstructor != null) {
            return entityConstructor.create(level, pos, param);
        }
        return null;
    }
}
