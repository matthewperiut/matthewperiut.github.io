package com.periut.retrocommands.command.extra;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.SharedCommandSource;
import java.lang.reflect.Field;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_64676926;


public class ToggleDownfall implements Command {
    // Thank you mine_diver for this code, it's beautiful

    private static final Field worldInfoField = getField(C_64041439.class, new String[]{"properties", "field_220"});

    // from HMI, blame mine_diver
    //clean mine_diver code
    //Used for easy reflection with obfuscated or regular fields
    public static Field getField(Class<?> target, String[] names) {
        for (Field field : target.getDeclaredFields()) {
            for (String name : names) {
                if (field.getName().equals(name)) {
                    field.setAccessible(true);
                    return field;
                }
            }
        }
        return null;
    }

    @Override
    public void command(SharedCommandSource commandSource, String[] parameters) {
        C_40996800 player = commandSource.getPlayer();
        if (player == null) {
            return;
        }

        C_64676926 worldInfo = null;
        try {
            worldInfo = (C_64676926) worldInfoField.get(player.f_94306729);
        } catch (Exception ignored) {

        }

        try {
            assert worldInfo != null;
            worldInfo.m_19998054(!worldInfo.m_59728072());
            worldInfo.m_63337208(!worldInfo.m_94635407());
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        }

        commandSource.sendFeedback("Toggled downfall");
    }

    @Override
    public String name() {
        return "toggledownfall";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /toggledownfall");
        commandSource.sendFeedback("Info: Toggles the weather");
    }
}
