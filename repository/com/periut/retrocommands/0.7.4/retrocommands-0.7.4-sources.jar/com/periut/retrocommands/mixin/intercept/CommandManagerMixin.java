package com.periut.retrocommands.mixin.intercept;

import com.periut.retrocommands.util.RetroChatUtil;
import com.periut.retrocommands.util.SharedCommandSource;
import net.minecraft.unmapped.C_79915627;
import net.minecraft.unmapped.C_81097776;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_79915627.class)
public class CommandManagerMixin {
    @Inject(method = "executeCommand", at = @At(value = "HEAD"), cancellable = true)
    private void processSPCommands(C_81097776 par1, CallbackInfo ci) {
        String command = par1.f_88660840;

        RetroChatUtil.handleCommand(new SharedCommandSource(par1.f_29949921), command, true);

        ci.cancel();
    }
}
