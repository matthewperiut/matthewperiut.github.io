package com.periut.retrocommands.command.extra;

import com.periut.retrocommands.api.Command;
import com.periut.retrocommands.util.SharedCommandSource;
import net.minecraft.unmapped.C_40996800;


public class Clock implements Command {
    public void command(SharedCommandSource commandSource, String[] parameters) {
        C_40996800 player = commandSource.getPlayer();
        if (player == null) {
            return;
        }

        commandSource.sendFeedback("Time is " + String.valueOf(player.f_94306729.m_13949261()));
        commandSource.sendFeedback("Days: " + String.valueOf((int) (player.f_94306729.m_13949261() / 24000)));
    }

    @Override
    public String name() {
        return "clock";
    }

    @Override
    public void manual(SharedCommandSource commandSource) {
        commandSource.sendFeedback("Usage: /clock");
        commandSource.sendFeedback("Info: tells you the time in-game");
    }

    @Override
    public boolean needsPermissions() {
        return false;
    }
}
