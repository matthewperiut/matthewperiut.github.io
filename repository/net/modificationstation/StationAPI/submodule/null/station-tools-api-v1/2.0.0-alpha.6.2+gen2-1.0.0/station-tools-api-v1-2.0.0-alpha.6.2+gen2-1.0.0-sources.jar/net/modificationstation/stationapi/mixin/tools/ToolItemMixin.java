package net.modificationstation.stationapi.mixin.tools;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_53672520;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.minecraft.unmapped.C_98888256.net.minecraft.unmapped.C_74597326;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.item.tool.StationToolItem;
import net.modificationstation.stationapi.api.tag.TagKey;
import net.modificationstation.stationapi.impl.item.ToolEffectivenessImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_53672520.class)
class ToolItemMixin extends C_98888256 implements StationToolItem {
    @Shadow protected C_74597326 toolMaterial;
    @Unique
    private TagKey<C_81592558> stationapi_effectiveBlocks;

    private ToolItemMixin(int id) {
        super(id);
    }

    @Override
    public void setEffectiveBlocks(TagKey<C_81592558> effectiveBlocks) {
        stationapi_effectiveBlocks = effectiveBlocks;
    }

    @Override
    public TagKey<C_81592558> getEffectiveBlocks(C_88708284 stack) {
        return stationapi_effectiveBlocks;
    }

    @Override
    public C_74597326 getMaterial(C_88708284 stack) {
        return toolMaterial;
    }

    @Override
    public boolean isSuitableFor(C_40996800 player, C_88708284 itemStack, C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return ToolEffectivenessImpl.shouldApplyCustomLogic(itemStack, state)
                ? ToolEffectivenessImpl.isSuitableFor(itemStack, state) : super.isSuitableFor(player, itemStack, blockView, blockPos, state);
    }

    @Override
    public float getMiningSpeedMultiplier(C_40996800 player, C_88708284 itemStack, C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return ToolEffectivenessImpl.shouldApplyCustomLogic(itemStack, state) && ToolEffectivenessImpl.isSuitableFor(itemStack, state)
                ? ToolEffectivenessImpl.getMiningSpeedMultiplier(itemStack) : super.getMiningSpeedMultiplier(player, itemStack, blockView, blockPos, state);
    }
}
