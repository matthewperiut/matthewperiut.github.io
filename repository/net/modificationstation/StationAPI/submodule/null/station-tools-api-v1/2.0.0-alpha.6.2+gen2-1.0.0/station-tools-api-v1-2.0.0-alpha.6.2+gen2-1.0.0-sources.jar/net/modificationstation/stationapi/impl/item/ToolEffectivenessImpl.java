package net.modificationstation.stationapi.impl.item;

import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.item.tool.StationTool;
import net.modificationstation.stationapi.api.item.tool.ToolLevel;
import net.modificationstation.stationapi.api.registry.BlockRegistry;
import net.modificationstation.stationapi.api.registry.ItemRegistry;
import net.modificationstation.stationapi.api.util.Namespace;

import java.util.Objects;

public class ToolEffectivenessImpl {
    public static boolean shouldApplyCustomLogic(C_88708284 item, BlockState state) {
        // 1. Disable custom tool logic if both the block and the tool are vanilla
        // This is done to preserve the vanilla mining speeds
        // 2. Disable custom tool logic if the tool doesn't provide its tool type tag
        // This is done to allow tools to handle suitability and speed the vanilla way
        return (Objects.requireNonNull(ItemRegistry.INSTANCE.getId(item.m_23235460())).namespace != Namespace.MINECRAFT
                || Objects.requireNonNull(BlockRegistry.INSTANCE.getId(state.getBlock())).namespace != Namespace.MINECRAFT)
                && (!(item.m_23235460() instanceof StationTool stationTool)
                || stationTool.getEffectiveBlocks(item) != null);
    }

    public static boolean isSuitableFor(C_88708284 item, BlockState state) {
        return item.m_23235460() instanceof StationTool stationTool
                && state.isIn(stationTool.getEffectiveBlocks(item))
                && ToolLevel.isSuitable(stationTool.getMaterial(item).getToolLevel(), state);
    }

    public static float getMiningSpeedMultiplier(C_88708284 item) {
        return ((StationTool) item.m_23235460()).getMaterial(item).m_77342003();
    }
}
