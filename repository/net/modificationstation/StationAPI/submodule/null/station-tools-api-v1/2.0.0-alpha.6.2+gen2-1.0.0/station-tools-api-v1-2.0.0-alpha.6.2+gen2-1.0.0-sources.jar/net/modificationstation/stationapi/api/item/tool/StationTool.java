package net.modificationstation.stationapi.api.item.tool;

import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.tag.TagKey;

/**
 * This interface is injected into all tool items and "pseudo" tool items (such as {@link StationHoeItem},
 * {@link StationShearsItem} and {@link StationSwordItem}) to provide the StationAPI's extended tools functionality.
 */
public interface StationTool {
    void setEffectiveBlocks(TagKey<C_81592558> effectiveBlocks);

    TagKey<C_81592558> getEffectiveBlocks(C_88708284 stack);

    C_98888256.net/minecraft/unmapped/C_74597326 getMaterial(C_88708284 stack);
}
