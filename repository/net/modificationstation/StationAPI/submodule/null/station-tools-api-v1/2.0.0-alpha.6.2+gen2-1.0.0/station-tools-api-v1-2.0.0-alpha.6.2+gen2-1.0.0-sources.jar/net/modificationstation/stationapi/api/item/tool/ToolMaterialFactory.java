package net.modificationstation.stationapi.api.item.tool;

import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.mixin.tools.ToolMaterialAccessor;

public class ToolMaterialFactory {
    private static int nextId = C_98888256.net/minecraft/unmapped/C_74597326.values().length;

    public static C_98888256.net/minecraft/unmapped/C_74597326 create(String materialName, int miningLevel, int durability, float miningSpeed, int attackDamage) {
        return ToolMaterialAccessor.stationapi_create(materialName, nextId++, miningLevel, durability, miningSpeed, attackDamage);
    }
}
