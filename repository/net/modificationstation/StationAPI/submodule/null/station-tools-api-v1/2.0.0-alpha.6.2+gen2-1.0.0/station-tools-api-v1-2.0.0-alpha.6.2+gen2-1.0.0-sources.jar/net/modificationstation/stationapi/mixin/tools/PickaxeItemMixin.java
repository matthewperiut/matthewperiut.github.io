package net.modificationstation.stationapi.mixin.tools;

import net.minecraft.unmapped.C_50456764;
import net.minecraft.unmapped.C_53672520;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_98888256.net.minecraft.unmapped.C_74597326;
import net.modificationstation.stationapi.api.registry.BlockRegistry;
import net.modificationstation.stationapi.api.tag.TagKey;
import net.modificationstation.stationapi.api.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_50456764.class)
class PickaxeItemMixin extends C_53672520 {
    private PickaxeItemMixin(int i, int j, C_74597326 arg, C_81592558[] args) {
        super(i, j, arg, args);
    }

    @Inject(
            method = "<init>",
            at = @At("RETURN")
    )
    private void stationapi_injectAtCtor(int arg, C_74597326 par2, CallbackInfo ci) {
        setEffectiveBlocks(TagKey.of(BlockRegistry.INSTANCE.getKey(), Identifier.of("mineable/pickaxe")));
    }
}
