package net.modificationstation.stationapi.api.item.tool;

import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.util.Util;

public interface StationToolMaterial {
    default C_98888256.net/minecraft/unmapped/C_74597326 toolLevel(ToolLevel toolLevel) {
        return Util.assertImpl();
    }

    default ToolLevel getToolLevel() {
        return Util.assertImpl();
    }
}
