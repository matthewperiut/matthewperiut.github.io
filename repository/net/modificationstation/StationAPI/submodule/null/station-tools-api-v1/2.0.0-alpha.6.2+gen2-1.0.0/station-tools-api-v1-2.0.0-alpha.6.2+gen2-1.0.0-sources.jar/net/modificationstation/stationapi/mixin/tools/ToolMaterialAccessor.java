package net.modificationstation.stationapi.mixin.tools;

import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_98888256.net/minecraft/unmapped/C_74597326.class)
public interface ToolMaterialAccessor {
    @Invoker("<init>")
    static C_98888256.net/minecraft/unmapped/C_74597326 stationapi_create(String materialName, int id, int miningLevel, int itemDurability, float miningSpeed, int attackDamage) {
        return Util.assertMixin();
    }
}
