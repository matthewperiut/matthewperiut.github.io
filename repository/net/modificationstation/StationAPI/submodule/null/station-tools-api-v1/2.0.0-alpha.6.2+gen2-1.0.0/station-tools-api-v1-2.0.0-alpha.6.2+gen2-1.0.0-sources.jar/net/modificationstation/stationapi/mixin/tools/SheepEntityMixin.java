package net.modificationstation.stationapi.mixin.tools;

import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.minecraft.unmapped.C_99730074;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.impl.item.ShearsOverrideEvent;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_99730074.class)
class SheepEntityMixin {
    @Redirect(
            method = "interact",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;itemId:I",
                    opcode = Opcodes.GETFIELD
            )
    )
    private int stationapi_hijackSheepShearing(C_88708284 stack) {
        return StationAPI.EVENT_BUS.post(
                ShearsOverrideEvent.builder()
                        .itemStack(stack)
                        .overrideShears(false)
                        .build()
        ).overrideShears ? C_98888256.f_18374421.f_57562535 : stack.f_59294634;
    }
}
