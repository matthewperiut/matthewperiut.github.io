package net.modificationstation.stationapi.api.item.tool;

import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.tag.TagKey;
import net.modificationstation.stationapi.api.util.Util;

public interface StationHoeItem extends StationTool {
    @Override
    default void setEffectiveBlocks(TagKey<C_81592558> effectiveBlocks) {
        Util.assertImpl();
    }

    @Override
    default TagKey<C_81592558> getEffectiveBlocks(C_88708284 stack) {
        return Util.assertImpl();
    }

    @Override
    default C_98888256.net/minecraft/unmapped/C_74597326 getMaterial(C_88708284 stack) {
        return Util.assertImpl();
    }
}
