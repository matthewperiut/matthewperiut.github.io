package net.modificationstation.stationapi.mixin.tools;

import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.item.tool.StationToolMaterial;
import net.modificationstation.stationapi.api.item.tool.ToolLevel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_98888256.net/minecraft/unmapped/C_74597326.class)
class ToolMaterialMixin implements StationToolMaterial {
    @Unique
    private ToolLevel stationapi_toolLevel;

    @Override
    @Unique
    public C_98888256.net/minecraft/unmapped/C_74597326 toolLevel(ToolLevel toolLevel) {
        stationapi_toolLevel = toolLevel;
        return C_98888256.net/minecraft/unmapped/C_74597326.class.cast(this);
    }

    @Override
    @Unique
    public ToolLevel getToolLevel() {
        return stationapi_toolLevel;
    }
}
