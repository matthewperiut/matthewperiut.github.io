package net.modificationstation.stationapi.api.client.gui.widget;

import net.minecraft.unmapped.C_85125467;

public interface PressAction {

    void onPress(C_85125467 button);
}
