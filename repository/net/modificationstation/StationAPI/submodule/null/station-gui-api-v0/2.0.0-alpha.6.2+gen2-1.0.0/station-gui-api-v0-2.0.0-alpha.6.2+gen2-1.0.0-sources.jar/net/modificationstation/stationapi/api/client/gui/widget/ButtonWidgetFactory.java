package net.modificationstation.stationapi.api.client.gui.widget;

import net.minecraft.unmapped.C_85125467;

public interface ButtonWidgetFactory {

    C_85125467 newButton(int id);
}
