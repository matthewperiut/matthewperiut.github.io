package net.modificationstation.stationapi.mixin.gui.client;

import net.minecraft.unmapped.C_43588014;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_87007645;
import net.modificationstation.stationapi.api.client.gui.screen.EditWorldScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

import java.util.List;

import static net.modificationstation.stationapi.api.client.gui.screen.EditWorldScreen.EDIT_KEY;

@Mixin(C_43588014.class)
class SelectWorldScreenMixin extends C_85740840 {
    @Shadow private List<C_87007645> saves;
    @Shadow private int selectedWorldId;

    @ModifyConstant(
            method = "addButton",
            constant = @Constant(stringValue = "selectWorld.rename")
    )
    private String stationapi_replaceRenameWithEdit(String constant) {
        return EDIT_KEY;
    }

    @ModifyArg(
            method = "buttonClicked",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/Minecraft;setScreen(Lnet/minecraft/client/gui/screen/Screen;)V",
                    ordinal = 2
            ),
            index = 0
    )
    private C_85740840 stationapi_openEditWorld(C_85740840 arg) {
        return new EditWorldScreen(this, saves.get(selectedWorldId));
    }
}
