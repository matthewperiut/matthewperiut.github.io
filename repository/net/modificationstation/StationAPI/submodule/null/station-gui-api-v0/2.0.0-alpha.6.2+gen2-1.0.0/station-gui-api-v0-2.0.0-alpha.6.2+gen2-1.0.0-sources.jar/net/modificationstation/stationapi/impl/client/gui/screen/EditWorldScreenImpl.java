package net.modificationstation.stationapi.impl.client.gui.screen;

import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.unmapped.C_10696192;
import net.minecraft.unmapped.C_76536438;
import net.minecraft.unmapped.C_85125467;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.event.gui.screen.EditWorldScreenEvent;
import net.modificationstation.stationapi.api.client.gui.widget.ButtonWidgetDetachedContext;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.mixin.gui.client.ScreenAccessor;

import java.lang.invoke.MethodHandles;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class EditWorldScreenImpl {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void registerRenameWorld(EditWorldScreenEvent.ScrollableButtonContextRegister event) {
        event.contexts.add(screen -> new ButtonWidgetDetachedContext(
                id -> new C_85125467(id, 0, 0, C_76536438.m_79832914("selectWorld.rename")),
                button -> ((ScreenAccessor) screen).getMinecraft().m_52715402(new C_10696192(screen, screen.worldData.m_07607595()))
        ));
    }
}
