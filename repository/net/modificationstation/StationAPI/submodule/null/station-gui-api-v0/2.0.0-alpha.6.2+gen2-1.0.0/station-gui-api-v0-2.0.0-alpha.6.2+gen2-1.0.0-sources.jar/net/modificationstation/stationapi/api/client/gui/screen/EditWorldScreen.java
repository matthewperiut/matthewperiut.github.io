package net.modificationstation.stationapi.api.client.gui.screen;

import com.google.common.collect.ImmutableList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_11164199;
import net.minecraft.unmapped.C_76536438;
import net.minecraft.unmapped.C_76575783;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_87007645;
import net.minecraft.unmapped.C_96603444;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.event.gui.screen.EditWorldScreenEvent;
import net.modificationstation.stationapi.api.client.gui.widget.ButtonWidgetAttachedContext;
import net.modificationstation.stationapi.api.client.gui.widget.ButtonWidgetContextAttacher;
import net.modificationstation.stationapi.api.client.gui.widget.ButtonWidgetDeferredDetachedContext;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;

@Environment(EnvType.CLIENT)
public class EditWorldScreen extends StationScreen {

    public static final String
            SELECTWORLD_KEY = "selectWorld",
            EDIT_KEY = SELECTWORLD_KEY + "." + NAMESPACE + ".edit",
            EDIT_TITLE_KEY = SELECTWORLD_KEY + "." + NAMESPACE + ".editTitle";
    private static final ImmutableList<ButtonWidgetDeferredDetachedContext<EditWorldScreen>> CUSTOM_EDIT_BUTTONS = StationAPI.EVENT_BUS.post(EditWorldScreenEvent.ScrollableButtonContextRegister.builder().contexts(ImmutableList.builder()).build()).contexts.build();

    protected final C_85740840 parent;
    public final C_87007645 worldData;
    protected EditButtonList buttonMenu;

    public EditWorldScreen(C_85740840 parent, C_87007645 worldData) {
        this.parent = parent;
        this.worldData = worldData;
    }

    @Override
    public void m_41805697() {
        super.m_41805697();
        btns.attach(
                id -> new C_11164199(id, f_05230747 / 2 - 75, f_07021018 - 48, C_76536438.m_79832914("gui.done")),
                button -> f_78495264.m_52715402(parent)
        );
        buttonMenu = new EditButtonList();
        CUSTOM_EDIT_BUTTONS.stream().map(context -> context.init(this)).forEach(buttonMenu.btns::attach);
    }

    @Override
    public void m_93956703(int mouseX, int mouseY, float delta) {
        buttonMenu.m_60498464(mouseX, mouseY, delta);
        m_50067982(f_11884601, C_76536438.m_79832914(EDIT_TITLE_KEY), f_05230747 / 2, 20, Color.WHITE.hashCode());
        super.m_93956703(mouseX, mouseY, delta);
    }

    @Environment(EnvType.CLIENT)
    protected class EditButtonList extends C_76575783 {

        protected final List<ButtonWidgetAttachedContext> editButtons = new ArrayList<>();
        protected final ButtonWidgetContextAttacher btns = ButtonWidgetContextAttacher.toList(editButtons);
        protected C_85125467 lastClickedButton;

        public EditButtonList() {
            super(f_78495264, EditWorldScreen.this.f_05230747, EditWorldScreen.this.f_07021018, 32, EditWorldScreen.this.f_07021018 - 64, 24);
            m_82644576(false);
        }

        @Override
        protected int m_87897431() {
            return editButtons.size();
        }

        @Override
        protected void m_07503748(int id, boolean doubleClick) {
            ButtonWidgetAttachedContext entry = editButtons.get(id);
            C_85125467 button = entry.button();
            if (button.m_07260289(f_78495264, mouseX, mouseY)) {
                lastClickedButton = button;
                f_78495264.f_52467463.m_61706856("random.click", 1.0f, 1.0f);
                entry.action().onPress(button);
            }
        }

        @Override
        protected boolean m_62450030(int i) {
            return lastClickedButton.f_92999450 == i;
        }

        @Override
        protected void m_73025081() {
            EditWorldScreen.this.m_34695786();
        }

        @Override
        public void m_60498464(int mouseX, int mouseY, float delta) {
            this.mouseX = mouseX;
            this.mouseY = mouseY;
            super.m_60498464(mouseX, mouseY, delta);
        }

        private int mouseX, mouseY;

        @Override
        protected void m_41486279(int entryId, int x, int y, int height, C_96603444 tessellator) {
            C_85125467 button = editButtons.get(entryId).button();
            button.f_99054304 = x + 10;
            button.f_24716782 = y;
            button.m_43811351(f_78495264, mouseX, mouseY);
        }
    }

}
