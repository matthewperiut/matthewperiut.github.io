package net.modificationstation.stationapi.api.client.gui.widget;

import net.minecraft.unmapped.C_85740840;

public interface ButtonWidgetDeferredDetachedContext<T extends C_85740840> {

    ButtonWidgetDetachedContext init(T screen);
}
