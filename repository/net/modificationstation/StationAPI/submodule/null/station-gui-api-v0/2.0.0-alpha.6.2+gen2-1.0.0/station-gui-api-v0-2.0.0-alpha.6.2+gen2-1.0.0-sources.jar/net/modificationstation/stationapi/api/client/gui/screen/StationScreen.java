package net.modificationstation.stationapi.api.client.gui.screen;

import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import net.modificationstation.stationapi.api.client.gui.widget.ButtonWidgetContextAttacher;
import net.modificationstation.stationapi.api.client.gui.widget.PressAction;

import java.util.ArrayList;
import java.util.List;

public class StationScreen extends C_85740840 {

    protected final List<PressAction> actions = new ArrayList<>();
    @SuppressWarnings("unchecked")
    protected final ButtonWidgetContextAttacher btns = ButtonWidgetContextAttacher.toListDeconstructed(f_78519977, actions);

    @Override
    public void m_41805697() {
        super.m_41805697();
        f_78519977.clear();
        actions.clear();
    }

    @Override
    protected void m_30778170(C_85125467 button) {
        super.m_30778170(button);
        actions.get(button.f_92999450).onPress(button);
    }
}
