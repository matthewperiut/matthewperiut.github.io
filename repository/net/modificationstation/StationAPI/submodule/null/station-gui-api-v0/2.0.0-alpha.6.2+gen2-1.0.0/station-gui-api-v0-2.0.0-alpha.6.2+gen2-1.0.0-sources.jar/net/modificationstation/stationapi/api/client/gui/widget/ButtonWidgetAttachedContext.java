package net.modificationstation.stationapi.api.client.gui.widget;

import net.minecraft.unmapped.C_85125467;

public record ButtonWidgetAttachedContext(C_85125467 button, PressAction action) {}
