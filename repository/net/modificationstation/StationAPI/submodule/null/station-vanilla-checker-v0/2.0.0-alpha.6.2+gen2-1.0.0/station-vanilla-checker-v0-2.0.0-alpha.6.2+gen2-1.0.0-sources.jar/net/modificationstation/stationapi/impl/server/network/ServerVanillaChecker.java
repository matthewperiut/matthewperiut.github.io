package net.modificationstation.stationapi.impl.server.network;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.metadata.ModMetadata;
import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_76536438;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.registry.MessageListenerRegistryEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.server.event.network.PlayerAttemptLoginEvent;
import net.modificationstation.stationapi.impl.network.ModdedPacketHandlerSetter;

import java.lang.invoke.MethodHandles;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import static net.modificationstation.stationapi.api.StationAPI.LOGGER;
import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;
import static net.modificationstation.stationapi.impl.network.VanillaChecker.CLIENT_REQUIRED_MODS;
import static net.modificationstation.stationapi.impl.network.VanillaChecker.MASK;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public class ServerVanillaChecker {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void onPlayerLogin(PlayerAttemptLoginEvent event) {
        if ((event.loginHelloPacket.f_48791654 & MASK) == MASK) {
            Map<String, String> mods = new HashMap<>();
            FabricLoader.getInstance().getAllMods().forEach(modContainer -> mods.put(modContainer.getMetadata().getId(), modContainer.getMetadata().getVersion().getFriendlyString()));
            ((ModdedPacketHandlerSetter) event.serverLoginNetworkHandler).setModded(mods);
        }
        else if (!CLIENT_REQUIRED_MODS.isEmpty()) {
            LOGGER.error("Player \"" + event.loginHelloPacket.f_50178374 + "\" attempted joining the server without " + NAMESPACE.getName() + ", disconnecting.");
            event.serverLoginNetworkHandler.m_83399148(C_76536438.m_79832914("disconnect." + NAMESPACE + ".missingStation"));
        }
    }

    @EventListener
    private static void registerMessages(MessageListenerRegistryEvent event) {
        event.register(NAMESPACE.id("modlist"), (player, message) -> {
            if (!CLIENT_REQUIRED_MODS.isEmpty()) {
                LOGGER.info("Received a list of mods from player \"" + player.f_59008391 + "\", verifying...");
                C_49202226 serverPlayer = (C_49202226) player;
                String version = message.strings[0];
                String serverStationVersion = NAMESPACE.getVersion().getFriendlyString();
                if (!version.equals(serverStationVersion)) {
                    LOGGER.error("Player \"" + player.f_59008391 + "\" has a mismatching " + NAMESPACE.getName() + " version \"" + version + "\", disconnecting.");
                    serverPlayer.f_70275341.m_85508200(C_76536438.m_00994426("disconnect." + NAMESPACE + ".stationVersionMismatch", serverStationVersion, version));
                    return;
                }
                Map<String, String> clientMods = new HashMap<>();
                for (int i = 1; i < message.strings.length; i += 2)
                    clientMods.put(message.strings[i], message.strings[i + 1]);
                LOGGER.info("Player \"" + player.f_59008391 + "\"'s mods: " + clientMods.entrySet().stream().map(stringStringEntry -> "modid=" + stringStringEntry.getKey() + " version=" + stringStringEntry.getValue()).collect(Collectors.joining(", ", "[", "]")));
                String modid;
                String clientVersion;
                String serverVersion;
                for (ModContainer serverMod : CLIENT_REQUIRED_MODS) {
                    ModMetadata modMetadata = serverMod.getMetadata();
                    modid = modMetadata.getId();
                    serverVersion = modMetadata.getVersion().getFriendlyString();
                    if (clientMods.containsKey(modid)) {
                        clientVersion = clientMods.get(modid);
                        if (clientVersion == null || !clientVersion.equals(serverVersion)) {
                            LOGGER.error("Player \"" + player.f_59008391 + "\" has a mismatching " + modMetadata.getName() + " (" + modid + ")" + " version \"" + clientVersion + "\", disconnecting.");
                            serverPlayer.f_70275341.m_85508200(C_76536438.m_00994426("disconnect." + NAMESPACE + ".modVersionMismatch", modMetadata.getName(), modid, serverVersion, clientVersion == null ? "null" : clientVersion));
                            return;
                        }
                    } else {
                        LOGGER.error("Player \"" + player.f_59008391 + "\" has a missing mod " + modMetadata.getName() + " (" + modid + "), disconnecting.");
                        serverPlayer.f_70275341.m_85508200(C_76536438.m_00994426("disconnect." + NAMESPACE + ".missingMod", modMetadata.getName(), modid, serverVersion));
                        return;
                    }
                }
                LOGGER.info("Player \"" + player.f_59008391 + "\"'s mods have passed verification.");
            }
        });
    }
}
