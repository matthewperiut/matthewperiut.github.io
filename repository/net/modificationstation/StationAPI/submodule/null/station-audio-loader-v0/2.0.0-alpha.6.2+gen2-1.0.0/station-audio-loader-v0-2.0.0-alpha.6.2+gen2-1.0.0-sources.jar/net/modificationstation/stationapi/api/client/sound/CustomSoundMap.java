package net.modificationstation.stationapi.api.client.sound;

import java.net.URL;
import net.minecraft.unmapped.C_58043465;

public interface CustomSoundMap {
    C_58043465 putSound(String id, URL url);
}
