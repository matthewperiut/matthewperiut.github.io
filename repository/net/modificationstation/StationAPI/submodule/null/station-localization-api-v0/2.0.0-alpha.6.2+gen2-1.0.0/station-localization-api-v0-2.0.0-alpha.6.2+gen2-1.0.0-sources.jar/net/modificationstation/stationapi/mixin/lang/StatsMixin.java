package net.modificationstation.stationapi.mixin.lang;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import lombok.val;
import net.minecraft.unmapped.C_23058753;
import net.minecraft.unmapped.C_76536438;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_89105241;
import net.minecraft.unmapped.C_95106612;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.impl.resource.language.DeferredTranslationKeyHolder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import java.util.function.Supplier;

@Mixin(C_95106612.class)
class StatsMixin {
    @WrapOperation(
            method = "<clinit>",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/resource/language/I18n;getTranslation(Ljava/lang/String;)Ljava/lang/String;"
            )
    )
    private static String stationapi_captureTranslationKey(
            String translationKey, Operation<String> original,
            @Share("translationKey") LocalRef<String> capturedTranslationKey
    ) {
        capturedTranslationKey.set(translationKey);
        return original.call(translationKey);
    }

    @ModifyExpressionValue(
            method = "<clinit>",
            at = {
                    @At(
                            value = "NEW",
                            target = "(ILjava/lang/String;)Lnet/minecraft/stat/SimpleStat;"
                    ),
                    @At(
                            value = "NEW",
                            target = "(ILjava/lang/String;Lnet/minecraft/stat/StatFormatter;)Lnet/minecraft/stat/SimpleStat;"
                    )
            }
    )
    private static C_23058753 stationapi_setCapturedTranslationKey(
            C_23058753 original,
            @Share("translationKey") LocalRef<String> translationKey
    ) {
        val capturedTranslationKey = translationKey.get();
        ((DeferredTranslationKeyHolder) original).stationapi_initTranslationKey(() -> C_76536438.m_79832914(capturedTranslationKey));
        return original;
    }

    @WrapOperation(
            method = {
                    "initializeCraftedItemStats",
                    "initItemsUsedStats",
                    "initializeBrokenItemStats"
            },
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/item/Item;getTranslatedName()Ljava/lang/String;"
            )
    )
    private static String stationapi_captureFormatStringGetter(
            C_98888256 instance, Operation<String> original,
            @Share("formatStringGetter") LocalRef<Supplier<String>> capturedFormatStringGetter
    ) {
        capturedFormatStringGetter.set(() -> original.call(instance));
        return original.call(instance);
    }

    @WrapOperation(
            method = "initBlocksMined",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/Block;getTranslatedName()Ljava/lang/String;"
            )
    )
    private static String stationapi_captureFormatStringGetter(
            C_81592558 instance, Operation<String> original,
            @Share("formatStringGetter") LocalRef<Supplier<String>> capturedFormatStringGetter
    ) {
        capturedFormatStringGetter.set(() -> original.call(instance));
        return original.call(instance);
    }

    @WrapOperation(
            method = {
                    "initializeCraftedItemStats",
                    "initBlocksMined",
                    "initItemsUsedStats",
                    "initializeBrokenItemStats"
            },
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/resource/language/I18n;getTranslation(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;"
            )
    )
    private static String stationapi_captureTranslationKey(
            String translationKey, Object[] formatObjects, Operation<String> original,
            @Share("translationKey") LocalRef<String> capturedTranslationKey
    ) {
        capturedTranslationKey.set(translationKey);
        return original.call(translationKey, formatObjects);
    }

    @ModifyExpressionValue(
            method = {
                    "initializeCraftedItemStats",
                    "initBlocksMined",
                    "initItemsUsedStats",
                    "initializeBrokenItemStats"
            },
            at = @At(
                    value = "NEW",
                    target = "(ILjava/lang/String;I)Lnet/minecraft/stat/ItemOrBlockStat;"
            )
    )
    private static C_89105241 stationapi_setTranslationKey(
            C_89105241 original,
            @Share("translationKey") LocalRef<String> translationKey,
            @Share("formatStringGetter") LocalRef<Supplier<String>> formatStringGetter
    ) {
        val capturedTranslationKey = translationKey.get();
        val capturedFormatStringGetter = formatStringGetter.get();
        ((DeferredTranslationKeyHolder) original).stationapi_initTranslationKey(() -> C_76536438.m_00994426(capturedTranslationKey, capturedFormatStringGetter.get()));
        return original;
    }
}
