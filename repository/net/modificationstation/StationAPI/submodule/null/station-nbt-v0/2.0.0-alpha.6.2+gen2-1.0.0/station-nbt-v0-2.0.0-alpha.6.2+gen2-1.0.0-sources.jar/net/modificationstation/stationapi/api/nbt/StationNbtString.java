package net.modificationstation.stationapi.api.nbt;

import net.minecraft.unmapped.C_74891195;
import net.modificationstation.stationapi.api.util.Util;

public interface StationNbtString extends StationNbtElement {
    @Override
    default C_74891195 copy() {
        return Util.assertImpl();
    }
}
