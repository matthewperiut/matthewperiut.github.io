package net.modificationstation.stationapi.mixin.nbt;

import net.minecraft.unmapped.C_79370641;
import net.minecraft.unmapped.C_97075175;
import net.modificationstation.stationapi.api.nbt.StationNbtList;
import net.modificationstation.stationapi.api.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

import java.util.List;
import java.util.Objects;

@Mixin(C_79370641.class)
class NbtListMixin implements StationNbtList {
    @Shadow private List<C_97075175> value;

    @Override
    @Unique
    public boolean equals(Object obj) {
        return this == obj || (obj instanceof C_79370641 tag && Objects.equals(value, ((NbtListAccessor) tag).stationapi$getValue()));
    }

    @Override
    @Unique
    public C_79370641 copy() {
        return Util.make(new C_79370641(), tag -> value.forEach(value -> tag.m_43125067(value.copy())));
    }
}
