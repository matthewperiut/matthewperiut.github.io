package net.modificationstation.stationapi.api.nbt;

import net.minecraft.unmapped.C_79370641;
import net.modificationstation.stationapi.api.util.Util;

public interface StationNbtList extends StationNbtElement {
    @Override
    default C_79370641 copy() {
        return Util.assertImpl();
    }
}
