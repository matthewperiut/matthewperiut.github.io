package net.modificationstation.stationapi.api.nbt;

import net.minecraft.unmapped.C_06229858;
import net.modificationstation.stationapi.api.util.Util;

public interface StationNbtDouble extends StationNbtElement {
    @Override
    default C_06229858 copy() {
        return Util.assertImpl();
    }
}
