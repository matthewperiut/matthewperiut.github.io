package net.modificationstation.stationapi.api.nbt;

import com.google.common.base.Predicates;
import com.google.common.collect.Iterators;
import com.google.common.collect.Lists;
import com.google.common.collect.PeekingIterator;
import com.google.common.primitives.Bytes;
import com.google.common.primitives.Ints;
import com.google.common.primitives.Longs;
import com.mojang.datafixers.DataFixUtils;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.mojang.serialization.MapLike;
import com.mojang.serialization.RecordBuilder;
import net.minecraft.nbt.*;
import net.minecraft.unmapped.C_02949887;
import net.minecraft.unmapped.C_03009146;
import net.minecraft.unmapped.C_06229858;
import net.minecraft.unmapped.C_50870163;
import net.minecraft.unmapped.C_57925352;
import net.minecraft.unmapped.C_64685490;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_74891195;
import net.minecraft.unmapped.C_79370641;
import net.minecraft.unmapped.C_80104453;
import net.minecraft.unmapped.C_90490889;
import net.minecraft.unmapped.C_97075175;
import net.modificationstation.stationapi.api.util.Util;
import net.modificationstation.stationapi.mixin.nbt.NbtCompoundAccessor;
import net.modificationstation.stationapi.mixin.nbt.NbtListAccessor;
import org.jetbrains.annotations.Nullable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.*;
import java.util.function.*;
import java.util.stream.IntStream;
import java.util.stream.LongStream;
import java.util.stream.Stream;

/**
 * Used to handle Minecraft NBTs within {@link com.mojang.serialization.Dynamic
 * dynamics} for DataFixerUpper, allowing generalized serialization logic
 * shared across different type of data structures. Use {@link NbtOps#INSTANCE}
 * for the ops singleton.
 * 
 * <p>For instance, dimension data may be stored as JSON in data packs, but
 * they will be transported in packets as NBT. DataFixerUpper allows
 * generalizing the dimension serialization logic to prevent duplicate code,
 * where the NBT ops allow the DataFixerUpper dimension serialization logic
 * to interact with Minecraft NBTs.
 * 
 * @see NbtOps#INSTANCE
 */
public class NbtOps implements DynamicOps<C_97075175> {
    /**
     * An singleton of the NBT dynamic ops.
     * 
     * <p>This ops does not compress maps (replace field name to value pairs
     * with an ordered list of values in serialization). In fact, since
     * Minecraft NBT lists can only contain elements of the same type, this op
     * cannot compress maps.
     */
    public static final NbtOps INSTANCE = new NbtOps();

    private static final C_97075175 NBT_END = new C_50870163();

    protected NbtOps() {
    }

    @Override
    public C_97075175 empty() {
        return NBT_END;
    }

    @Override
    public <U> U convertTo(DynamicOps<U> dynamicOps, C_97075175 nbtElement) {
        return switch (nbtElement.m_65815168()) {
            case 0 -> dynamicOps.empty();
            case 1 -> dynamicOps.createByte(((C_64685490) nbtElement).f_51076588);
            case 2 -> dynamicOps.createShort(((C_80104453) nbtElement).f_12548853);
            case 3 -> dynamicOps.createInt(((C_57925352) nbtElement).f_17751193);
            case 4 -> dynamicOps.createLong(((C_90490889) nbtElement).f_67818615);
            case 5 -> dynamicOps.createFloat(((C_02949887) nbtElement).f_97688492);
            case 6 -> dynamicOps.createDouble(((C_06229858) nbtElement).f_79544156);
            case 7 -> dynamicOps.createByteList(ByteBuffer.wrap(((C_03009146) nbtElement).f_70145617));
            case 8 -> dynamicOps.createString(((C_74891195) nbtElement).f_82092533);
            case 9 -> convertList(dynamicOps, nbtElement);
            case 10 -> convertMap(dynamicOps, nbtElement);
            case 11 -> dynamicOps.createIntList(Arrays.stream(((NbtIntArray) nbtElement).data));
            case 12 -> dynamicOps.createLongList(Arrays.stream(((NbtLongArray) nbtElement).data));
            default -> throw new IllegalStateException("Unknown tag type: " + nbtElement);
        };
    }

    @Override
    public DataResult<Number> getNumberValue(C_97075175 nbtElement) {
        return switch (nbtElement.m_65815168()) {
            case 1 -> DataResult.success(((C_64685490) nbtElement).f_51076588);
            case 2 -> DataResult.success(((C_80104453) nbtElement).f_12548853);
            case 3 -> DataResult.success(((C_57925352) nbtElement).f_17751193);
            case 4 -> DataResult.success(((C_90490889) nbtElement).f_67818615);
            case 5 -> DataResult.success(((C_02949887) nbtElement).f_97688492);
            case 6 -> DataResult.success(((C_06229858) nbtElement).f_79544156);
            default -> DataResult.error(() -> "Not a number");
        };
    }

    @Override
    public C_97075175 createNumeric(Number number) {
        return new C_06229858(number.doubleValue());
    }

    @Override
    public C_97075175 createByte(byte b) {
        return new C_64685490(b);
    }

    @Override
    public C_97075175 createShort(short s) {
        return new C_80104453(s);
    }

    @Override
    public C_97075175 createInt(int i) {
        return new C_57925352(i);
    }

    @Override
    public C_97075175 createLong(long l) {
        return new C_90490889(l);
    }

    @Override
    public C_97075175 createFloat(float f) {
        return new C_02949887(f);
    }

    @Override
    public C_97075175 createDouble(double d) {
        return new C_06229858(d);
    }

    @Override
    public C_97075175 createBoolean(boolean bl) {
        return new C_64685490((byte) (bl ? 1 : 0));
    }

    @Override
    public DataResult<String> getStringValue(C_97075175 nbtElement) {
        return nbtElement instanceof C_74891195 stringTag ? DataResult.success(stringTag.f_82092533) : DataResult.error(() -> "Not a string");
    }

    @Override
    public C_97075175 createString(String string) {
        return new C_74891195(string);
    }

    private static class ListArrayTag<T extends C_97075175> extends C_79370641 {

        private final T array;

        private <U extends C_97075175> ListArrayTag(
                final T array,
                final Function<T, Predicate<U>> adderFactory,
                final Function<T, IntFunction<U>> getterFactory,
                final Function<T, IntSupplier> sizeGetterFactory,
                final byte listTypeId
        ) {
            this.array = array;
            final Predicate<U> adder = adderFactory.apply(array);
            final IntFunction<U> getter = getterFactory.apply(array);
            final IntSupplier sizeGetter = sizeGetterFactory.apply(array);
            final NbtListAccessor _super = (NbtListAccessor) this;
            _super.stationapi$setValue(new AbstractList<U>() {

                @Override
                public boolean add(U abstractTag) {
                    return adder.test(abstractTag);
                }

                @Override
                public U get(int index) {
                    return getter.apply(index);
                }

                @Override
                public int size() {
                    return sizeGetter.getAsInt();
                }
            });
            _super.stationapi$setType(listTypeId);
        }

        @Override
        public byte m_65815168() {
            return array.m_65815168();
        }

        @Override
        public String toString() {
            return array.toString();
        }

        @Override
        public void m_20830783(DataOutput out) {
            try {
                array.m_20830783(out);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        @Override
        public void m_52126384(DataInput in) {
            try {
                array.m_52126384(in);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        @Override
        public String m_27193928() {
            return array.m_27193928();
        }

        @Override
        public C_97075175 m_44918998(String string) {
            return array.m_44918998(string);
        }
    }

    private static C_79370641 createList(byte knownType, byte valueType) {
        if (NbtOps.isTypeEqual(knownType, valueType, (byte) 4)) return new ListArrayTag<>(new NbtLongArray(new long[0]), array -> Predicates.compose(Predicates.alwaysTrue(), tag -> array.data = insert(array.data, tag.f_67818615)), array -> i -> new C_90490889(array.data[i]), array -> () -> array.data.length, (byte) 4);
        if (NbtOps.isTypeEqual(knownType, valueType, (byte) 1)) return new ListArrayTag<>(new C_03009146(new byte[0]), array -> Predicates.compose(Predicates.alwaysTrue(), tag -> array.f_70145617 = insert(array.f_70145617, tag.f_51076588)), array -> i -> new C_64685490(array.f_70145617[i]), array -> () -> array.f_70145617.length, (byte) 1);
        if (NbtOps.isTypeEqual(knownType, valueType, (byte) 3)) return new ListArrayTag<>(new NbtIntArray(new int[0]), array -> Predicates.compose(Predicates.alwaysTrue(), tag -> array.data = insert(array.data, tag.f_17751193)), array -> i -> new C_57925352(array.data[i]), array -> () -> array.data.length, (byte) 3);
        return new C_79370641();
    }

    private static long[] insert(long[] array, long value) {
        long[] newArray = Arrays.copyOf(array, array.length + 1);
        newArray[array.length] = value;
        return newArray;
    }

    private static byte[] insert(byte[] array, byte value) {
        byte[] newArray = Arrays.copyOf(array, array.length + 1);
        newArray[array.length] = value;
        return newArray;
    }

    private static int[] insert(int[] array, int value) {
        int[] newArray = Arrays.copyOf(array, array.length + 1);
        newArray[array.length] = value;
        return newArray;
    }

    private static boolean isTypeEqual(byte knownType, byte valueType, byte expectedType) {
        return knownType == expectedType && (valueType == expectedType || valueType == 0);
    }

    private static void addAll(C_79370641 destination, C_97075175 source, C_97075175 additionalValue) {
        if (source instanceof C_79370641 abstractNbtList) {
            IntStream.of(0, abstractNbtList.m_89439680()).mapToObj(abstractNbtList::m_59132367).forEach(destination::m_43125067);
        }
        destination.m_43125067(additionalValue);
    }

    private static void addAll(C_79370641 destination, C_97075175 source, List<C_97075175> additionalValues) {
        if (source instanceof C_79370641 abstractNbtList) {
            IntStream.of(0, abstractNbtList.m_89439680()).mapToObj(abstractNbtList::m_59132367).forEach(destination::m_43125067);
        }
        additionalValues.forEach(destination::m_43125067);
    }

    @Override
    public DataResult<C_97075175> mergeToList(C_97075175 nbtElement, C_97075175 nbtElement2) {
        if (!(nbtElement instanceof C_79370641) && !(nbtElement instanceof C_50870163))
            return DataResult.error(() -> "mergeToList called with not a list: " + nbtElement, nbtElement);
        C_79370641 abstractNbtList = NbtOps.createList(nbtElement instanceof C_79370641 ? ((NbtListAccessor)nbtElement).stationapi$getType() : (byte)0, nbtElement2.m_65815168());
        NbtOps.addAll(abstractNbtList, nbtElement, nbtElement2);
        return DataResult.success(abstractNbtList);
    }

    @Override
    public DataResult<C_97075175> mergeToList(C_97075175 nbtElement, List<C_97075175> list) {
        if (!(nbtElement instanceof C_79370641) && !(nbtElement instanceof C_50870163))
            return DataResult.error(() -> "mergeToList called with not a list: " + nbtElement, nbtElement);
        C_79370641 abstractNbtList = NbtOps.createList(nbtElement instanceof C_79370641 ? ((NbtListAccessor)nbtElement).stationapi$getType() : (byte)0, list.stream().findFirst().map(C_97075175::m_65815168).orElse((byte)0));
        NbtOps.addAll(abstractNbtList, nbtElement, list);
        return DataResult.success(abstractNbtList);
    }

    @Override
    public DataResult<C_97075175> mergeToMap(C_97075175 nbtElement, C_97075175 nbtElement2, C_97075175 nbtElement3) {
        if (!(nbtElement instanceof C_74087615) && !(nbtElement instanceof C_50870163))
            return DataResult.error(() -> "mergeToMap called with not a map: " + nbtElement, nbtElement);
        if (!(nbtElement2 instanceof C_74891195 stringTag))
            return DataResult.error(() -> "key is not a string: " + nbtElement2, nbtElement);
        C_74087615 nbtCompound = nbtElement instanceof C_74087615 nbtCompound2 ? nbtCompound2.copy() : new C_74087615();
        nbtCompound.m_21770494(stringTag.f_82092533, nbtElement3);
        return DataResult.success(nbtCompound);
    }

    @Override
    public DataResult<C_97075175> mergeToMap(C_97075175 nbtElement, MapLike<C_97075175> mapLike) {
        if (!(nbtElement instanceof C_74087615) && !(nbtElement instanceof C_50870163))
            return DataResult.error(() -> "mergeToMap called with not a map: " + nbtElement, nbtElement);
        C_74087615 nbtCompound = nbtElement instanceof C_74087615 nbtCompound2 ? nbtCompound2.copy() : new C_74087615();
        List<C_97075175> invalidKeys = new ArrayList<>();
        mapLike.entries().forEach(pair -> {
            C_97075175 key = pair.getFirst();
            if (key instanceof C_74891195 stringTag)
                nbtCompound.m_21770494(stringTag.f_82092533, pair.getSecond());
            else
                invalidKeys.add(key);
        });
        return invalidKeys.isEmpty() ? DataResult.success(nbtCompound) : DataResult.error(() -> "some keys are not strings: " + invalidKeys, nbtCompound);
    }

    @Override
    public DataResult<Stream<Pair<C_97075175, C_97075175>>> getMapValues(C_97075175 nbtElement) {
        if (!(nbtElement instanceof C_74087615 nbtCompound)) return DataResult.error(() -> "Not a map: " + nbtElement);
        return DataResult.success(((NbtCompoundAccessor) nbtCompound).stationapi$getEntries().entrySet().stream().map(entry -> Pair.of(createString(entry.getKey()), entry.getValue())));
    }

    @Override
    public DataResult<Consumer<BiConsumer<C_97075175, C_97075175>>> getMapEntries(C_97075175 nbtElement) {
        if (!(nbtElement instanceof C_74087615 nbtCompound)) return DataResult.error(() -> "Not a map: " + nbtElement);
        return DataResult.success(entryConsumer -> ((NbtCompoundAccessor) nbtCompound).stationapi$getEntries().forEach((key, value) -> entryConsumer.accept(this.createString(key), value)));
    }

    @Override
    public DataResult<MapLike<C_97075175>> getMap(C_97075175 nbtElement) {
        if (!(nbtElement instanceof C_74087615 nbtCompound)) return DataResult.error(() -> "Not a map: " + nbtElement);
        return DataResult.success(new MapLike<>() {

            @Override
            @Nullable
            public C_97075175 get(C_97075175 nbtElement) {
                return ((NbtCompoundAccessor) nbtCompound).stationapi$getEntries().get(nbtElement.toString());
            }

            @Override
            @Nullable
            public C_97075175 get(String string) {
                return ((NbtCompoundAccessor) nbtCompound).stationapi$getEntries().get(string);
            }

            @Override
            public Stream<Pair<C_97075175, C_97075175>> entries() {
                return ((NbtCompoundAccessor) nbtCompound).stationapi$getEntries().entrySet().stream().map(entry -> Pair.of(createString(entry.getKey()), entry.getValue()));
            }

            public String toString() {
                return "MapLike[" + nbtCompound + "]";
            }
        });
    }

    @Override
    public C_97075175 createMap(Stream<Pair<C_97075175, C_97075175>> stream) {
        return Util.make(new C_74087615(), nbtCompound -> stream.forEach(entry -> nbtCompound.m_21770494(entry.getFirst().toString(), entry.getSecond())));
    }

    @Override
    public DataResult<Stream<C_97075175>> getStream(C_97075175 nbtElement) {
        return nbtElement instanceof C_79370641 listTag ? DataResult.success(IntStream.range(0, listTag.m_89439680()).mapToObj(listTag::m_59132367)) : DataResult.error(() -> "Not a list");
    }

    @Override
    public DataResult<Consumer<Consumer<C_97075175>>> getList(C_97075175 nbtElement) {
        if (nbtElement instanceof C_79370641 abstractNbtList) {
            return DataResult.success(IntStream.range(0, abstractNbtList.m_89439680()).mapToObj(abstractNbtList::m_59132367)::forEach);
        }
        return DataResult.error(() -> "Not a list: " + nbtElement);
    }

    @Override
    public DataResult<ByteBuffer> getByteBuffer(C_97075175 nbtElement) {
        if (nbtElement instanceof C_03009146 nbtByteArray)
            return DataResult.success(ByteBuffer.wrap(nbtByteArray.f_70145617));
        return DynamicOps.super.getByteBuffer(nbtElement);
    }

    @Override
    public C_97075175 createByteList(ByteBuffer byteBuffer) {
        return new C_03009146(DataFixUtils.toArray(byteBuffer));
    }

    @Override
    public DataResult<IntStream> getIntStream(C_97075175 nbtElement) {
        if (nbtElement instanceof NbtIntArray nbtIntArray)
            return DataResult.success(Arrays.stream(nbtIntArray.data));
        return DynamicOps.super.getIntStream(nbtElement);
    }

    @Override
    public C_97075175 createIntList(IntStream intStream) {
        return new NbtIntArray(intStream.toArray());
    }

    @Override
    public DataResult<LongStream> getLongStream(C_97075175 nbtElement) {
        if (nbtElement instanceof NbtLongArray nbtLongArray)
            return DataResult.success(Arrays.stream(nbtLongArray.data));
        return DynamicOps.super.getLongStream(nbtElement);
    }

    @Override
    public C_97075175 createLongList(LongStream longStream) {
        return new NbtLongArray(longStream.toArray());
    }

    @Override
    public C_97075175 createList(Stream<C_97075175> stream) {
        PeekingIterator<C_97075175> peekingIterator = Iterators.peekingIterator(stream.iterator());
        if (!peekingIterator.hasNext()) return new C_79370641();
        C_97075175 nbtElement = peekingIterator.peek();
        if (nbtElement instanceof C_64685490 nbtByte) {
            ArrayList<Byte> list = Lists.newArrayList(Iterators.transform(peekingIterator, nbt -> nbtByte.f_51076588));
            return new C_03009146(Bytes.toArray(list));
        }
        if (nbtElement instanceof C_57925352 nbtInt) {
            ArrayList<Integer> list = Lists.newArrayList(Iterators.transform(peekingIterator, nbt -> nbtInt.f_17751193));
            return new NbtIntArray(Ints.toArray(list));
        }
        if (nbtElement instanceof C_90490889 nbtLong) {
            ArrayList<Long> list = Lists.newArrayList(Iterators.transform(peekingIterator, nbt -> nbtLong.f_67818615));
            return new NbtLongArray(Longs.toArray(list));
        }
        C_79370641 list = new C_79370641();
        while (peekingIterator.hasNext()) {
            C_97075175 nbtElement2 = peekingIterator.next();
            if (nbtElement2 instanceof C_50870163) continue;
            list.m_43125067(nbtElement2);
        }
        return list;
    }

    @Override
    public C_97075175 remove(C_97075175 nbtElement, String string) {
        if (nbtElement instanceof C_74087615 nbtCompound) {
            C_74087615 nbtCompound2 = new C_74087615();
            ((NbtCompoundAccessor) nbtCompound).stationapi$getEntries().entrySet().stream().filter(entry -> !Objects.equals(entry.getKey(), string)).forEach(entry -> nbtCompound2.m_21770494(entry.getKey(), entry.getValue()));
            return nbtCompound2;
        }
        return nbtElement;
    }

    public String toString() {
        return "NBT";
    }

    @Override
    public RecordBuilder<C_97075175> mapBuilder() {
        return new MapBuilder();
    }

    class MapBuilder
    extends RecordBuilder.AbstractStringBuilder<C_97075175, C_74087615> {
        protected MapBuilder() {
            super(NbtOps.this);
        }

        @Override
        protected C_74087615 initBuilder() {
            return new C_74087615();
        }

        @Override
        protected C_74087615 append(String string, C_97075175 nbtElement, C_74087615 nbtCompound) {
            nbtCompound.m_21770494(string, nbtElement);
            return nbtCompound;
        }

        @Override
        protected DataResult<C_97075175> build(C_74087615 nbtCompound, C_97075175 nbtElement) {
            if (nbtElement == null || nbtElement instanceof C_50870163) return DataResult.success(nbtCompound);
            if (nbtElement instanceof C_74087615 nbtCompound3) {
                C_74087615 nbtCompound2 = Util.make(new C_74087615(), compoundTag -> ((NbtCompoundAccessor) nbtCompound3).stationapi$getEntries().forEach(compoundTag::m_21770494));
                ((NbtCompoundAccessor) nbtCompound).stationapi$getEntries().forEach(nbtCompound2::m_21770494);
                return DataResult.success(nbtCompound2);
            }
            return DataResult.error(() -> "mergeToMap called with not a map: " + nbtElement, nbtElement);
        }
    }
}

