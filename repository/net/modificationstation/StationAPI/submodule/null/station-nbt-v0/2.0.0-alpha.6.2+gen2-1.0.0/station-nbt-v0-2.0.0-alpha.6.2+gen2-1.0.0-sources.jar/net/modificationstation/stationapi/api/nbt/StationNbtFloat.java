package net.modificationstation.stationapi.api.nbt;

import net.minecraft.unmapped.C_02949887;
import net.modificationstation.stationapi.api.util.Util;

public interface StationNbtFloat extends StationNbtElement {
    @Override
    default C_02949887 copy() {
        return Util.assertImpl();
    }
}
