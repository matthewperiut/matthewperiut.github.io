package net.modificationstation.stationapi.mixin.nbt;

import net.minecraft.unmapped.C_64685490;
import net.modificationstation.stationapi.api.nbt.StationNbtByte;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_64685490.class)
class NbtByteMixin implements StationNbtByte {
    @Shadow public byte value;

    @Override
    @Unique
    public boolean equals(Object obj) {
        return this == obj || (obj instanceof C_64685490 tag && value == tag.f_51076588);
    }

    @Override
    @Unique
    public C_64685490 copy() {
        return new C_64685490(value);
    }
}
