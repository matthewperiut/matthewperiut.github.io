package net.modificationstation.stationapi.mixin.nbt;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_97075175;

@Mixin(C_74087615.class)
public interface NbtCompoundAccessor {
    @Accessor("entries")
    Map<String, C_97075175> stationapi$getEntries();
}
