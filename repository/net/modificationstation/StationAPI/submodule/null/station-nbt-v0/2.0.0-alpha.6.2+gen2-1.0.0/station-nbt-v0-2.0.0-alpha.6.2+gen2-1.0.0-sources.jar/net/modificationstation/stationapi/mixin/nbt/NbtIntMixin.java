package net.modificationstation.stationapi.mixin.nbt;

import net.minecraft.unmapped.C_57925352;
import net.modificationstation.stationapi.api.nbt.StationNbtInt;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_57925352.class)
class NbtIntMixin implements StationNbtInt {
    @Shadow public int value;

    @Override
    @Unique
    public boolean equals(Object obj) {
        return this == obj || (obj instanceof C_57925352 tag && value == tag.f_17751193);
    }

    @Override
    @Unique
    public C_57925352 copy() {
        return new C_57925352(value);
    }
}
