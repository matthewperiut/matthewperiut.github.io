package net.modificationstation.stationapi.api.nbt;

import net.minecraft.unmapped.C_57925352;
import net.modificationstation.stationapi.api.util.Util;

public interface StationNbtInt extends StationNbtElement {
    @Override
    default C_57925352 copy() {
        return Util.assertImpl();
    }
}
