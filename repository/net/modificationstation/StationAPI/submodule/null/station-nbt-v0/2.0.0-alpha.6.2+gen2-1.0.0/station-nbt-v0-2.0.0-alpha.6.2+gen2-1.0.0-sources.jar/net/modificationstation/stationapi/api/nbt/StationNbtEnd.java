package net.modificationstation.stationapi.api.nbt;

import net.minecraft.unmapped.C_50870163;
import net.modificationstation.stationapi.api.util.Util;

public interface StationNbtEnd extends StationNbtElement {
    @Override
    default C_50870163 copy() {
        return Util.assertImpl();
    }
}
