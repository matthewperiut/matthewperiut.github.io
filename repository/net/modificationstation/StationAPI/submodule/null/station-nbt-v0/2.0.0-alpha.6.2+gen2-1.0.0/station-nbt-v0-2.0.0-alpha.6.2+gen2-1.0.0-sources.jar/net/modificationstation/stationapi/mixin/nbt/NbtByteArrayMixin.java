package net.modificationstation.stationapi.mixin.nbt;

import net.minecraft.unmapped.C_03009146;
import net.modificationstation.stationapi.api.nbt.StationNbtByteArray;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

import java.util.Arrays;

@Mixin(C_03009146.class)
class NbtByteArrayMixin implements StationNbtByteArray {
    @Shadow public byte[] value;

    @Override
    @Unique
    public boolean equals(Object obj) {
        return this == obj || (obj instanceof C_03009146 tag && Arrays.equals(value, tag.f_70145617));
    }

    @Override
    @Unique
    public C_03009146 copy() {
        return new C_03009146(Arrays.copyOf(value, value.length));
    }
}
