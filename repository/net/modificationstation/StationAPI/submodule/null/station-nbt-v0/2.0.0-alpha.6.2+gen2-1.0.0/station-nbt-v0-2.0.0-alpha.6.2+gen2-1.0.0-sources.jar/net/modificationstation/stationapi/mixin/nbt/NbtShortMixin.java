package net.modificationstation.stationapi.mixin.nbt;

import net.minecraft.unmapped.C_80104453;
import net.modificationstation.stationapi.api.nbt.StationNbtShort;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_80104453.class)
class NbtShortMixin implements StationNbtShort {
    @Shadow public short value;

    @Override
    @Unique
    public boolean equals(Object obj) {
        return this == obj || (obj instanceof C_80104453 tag && value == tag.f_12548853);
    }

    @Override
    @Unique
    public C_80104453 copy() {
        return new C_80104453(value);
    }
}
