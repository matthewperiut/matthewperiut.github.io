package net.modificationstation.stationapi.mixin.nbt;

import net.minecraft.unmapped.C_74891195;
import net.modificationstation.stationapi.api.nbt.StationNbtString;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

import java.util.Objects;

@Mixin(C_74891195.class)
class NbtStringMixin implements StationNbtString {
    @Shadow public String value;

    @Override
    @Unique
    public boolean equals(Object obj) {
        return this == obj || (obj instanceof C_74891195 tag && Objects.equals(value, tag.f_82092533));
    }

    @Override
    @Unique
    public C_74891195 copy() {
        return new C_74891195(value);
    }
}
