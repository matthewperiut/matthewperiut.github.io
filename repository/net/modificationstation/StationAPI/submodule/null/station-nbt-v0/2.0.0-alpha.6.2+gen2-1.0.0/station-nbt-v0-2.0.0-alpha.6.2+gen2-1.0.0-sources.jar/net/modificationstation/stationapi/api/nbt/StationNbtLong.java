package net.modificationstation.stationapi.api.nbt;

import net.minecraft.unmapped.C_90490889;
import net.modificationstation.stationapi.api.util.Util;

public interface StationNbtLong extends StationNbtElement {
    @Override
    default C_90490889 copy() {
        return Util.assertImpl();
    }
}
