package net.modificationstation.stationapi.mixin.nbt;

import net.minecraft.unmapped.C_02949887;
import net.modificationstation.stationapi.api.nbt.StationNbtFloat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_02949887.class)
class NbtFloatMixin implements StationNbtFloat {
    @Shadow public float value;

    @Override
    @Unique
    public boolean equals(Object obj) {
        return this == obj || (obj instanceof C_02949887 tag && value == tag.f_97688492);
    }

    @Override
    @Unique
    public C_02949887 copy() {
        return new C_02949887(value);
    }
}
