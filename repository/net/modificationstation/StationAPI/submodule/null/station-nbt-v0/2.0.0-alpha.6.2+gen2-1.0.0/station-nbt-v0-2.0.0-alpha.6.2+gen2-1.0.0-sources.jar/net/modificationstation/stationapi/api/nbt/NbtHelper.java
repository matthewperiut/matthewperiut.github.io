package net.modificationstation.stationapi.api.nbt;

import com.mojang.datafixers.DSL;
import com.mojang.serialization.Dynamic;
import net.minecraft.unmapped.C_74087615;
import net.modificationstation.stationapi.api.datafixer.DataFixers;

import java.util.Set;

public class NbtHelper {
    /**
     * Uses the data fixer to update an NBT compound object.
     *
     * @param fixType the fix type
     * @param compound the NBT compound object to fix
     */
    public static C_74087615 update(DSL.TypeReference fixType, C_74087615 compound) {
        return (C_74087615) DataFixers.update(fixType, new Dynamic<>(NbtOps.INSTANCE, compound)).getValue();
    }

    public static C_74087615 getDataVersions(C_74087615 compound) {
        return (C_74087615) DataFixers.getDataVersions(new Dynamic<>(NbtOps.INSTANCE, compound)).getValue();
    }

    public static C_74087615 addDataVersions(C_74087615 compound) {
        return (C_74087615) DataFixers.addDataVersions(new Dynamic<>(NbtOps.INSTANCE, compound)).getValue();
    }

    public static boolean requiresUpdating(C_74087615 compound) {
        return DataFixers.requiresUpdating(new Dynamic<>(NbtOps.INSTANCE, compound));
    }

    public static Set<DataFixers.UpdateData> getUpdateList(C_74087615 compound) {
        return DataFixers.getUpdateList(new Dynamic<>(NbtOps.INSTANCE, compound));
    }
}
