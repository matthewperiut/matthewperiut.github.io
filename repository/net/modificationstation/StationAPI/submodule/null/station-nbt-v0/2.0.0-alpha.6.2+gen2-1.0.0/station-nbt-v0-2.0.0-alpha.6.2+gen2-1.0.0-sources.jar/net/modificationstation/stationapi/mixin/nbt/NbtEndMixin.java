package net.modificationstation.stationapi.mixin.nbt;

import net.minecraft.unmapped.C_50870163;
import net.modificationstation.stationapi.api.nbt.StationNbtEnd;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_50870163.class)
class NbtEndMixin implements StationNbtEnd {
    @Override
    @Unique
    public boolean equals(Object obj) {
        return this == obj || obj instanceof C_50870163;
    }

    @Override
    @Unique
    public C_50870163 copy() {
        return new C_50870163();
    }
}
