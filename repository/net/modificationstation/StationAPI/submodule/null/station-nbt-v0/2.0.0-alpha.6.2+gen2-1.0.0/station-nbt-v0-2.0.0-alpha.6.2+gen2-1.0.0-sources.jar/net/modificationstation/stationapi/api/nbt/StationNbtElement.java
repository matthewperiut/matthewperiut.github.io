package net.modificationstation.stationapi.api.nbt;

import net.minecraft.unmapped.C_97075175;

public interface StationNbtElement {
    C_97075175 copy();
}
