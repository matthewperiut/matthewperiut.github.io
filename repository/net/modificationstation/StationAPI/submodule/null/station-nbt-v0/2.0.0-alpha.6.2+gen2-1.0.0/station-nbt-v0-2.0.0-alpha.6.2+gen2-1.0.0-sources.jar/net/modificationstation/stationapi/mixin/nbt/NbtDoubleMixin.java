package net.modificationstation.stationapi.mixin.nbt;

import net.minecraft.unmapped.C_06229858;
import net.modificationstation.stationapi.api.nbt.StationNbtDouble;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_06229858.class)
class NbtDoubleMixin implements StationNbtDouble {
    @Shadow public double value;

    @Override
    @Unique
    public boolean equals(Object obj) {
        return this == obj || (obj instanceof C_06229858 tag && value == tag.f_79544156);
    }

    @Override
    @Unique
    public C_06229858 copy() {
        return new C_06229858(value);
    }
}
