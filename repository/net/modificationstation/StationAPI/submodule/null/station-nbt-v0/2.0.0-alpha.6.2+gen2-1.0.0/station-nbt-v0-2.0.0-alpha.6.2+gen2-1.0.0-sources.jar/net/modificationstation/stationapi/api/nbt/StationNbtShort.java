package net.modificationstation.stationapi.api.nbt;

import net.minecraft.unmapped.C_80104453;
import net.modificationstation.stationapi.api.util.Util;

public interface StationNbtShort extends StationNbtElement {
    @Override
    default C_80104453 copy() {
        return Util.assertImpl();
    }
}
