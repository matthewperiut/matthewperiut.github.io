package net.modificationstation.stationapi.api.nbt;

import net.minecraft.unmapped.C_64685490;
import net.modificationstation.stationapi.api.util.Util;

public interface StationNbtByte extends StationNbtElement {
    @Override
    default C_64685490 copy() {
        return Util.assertImpl();
    }
}
