package net.modificationstation.stationapi.mixin.nbt;

import net.minecraft.unmapped.C_90490889;
import net.modificationstation.stationapi.api.nbt.StationNbtLong;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_90490889.class)
class NbtLongMixin implements StationNbtLong {
    @Shadow public long value;

    @Override
    @Unique
    public boolean equals(Object obj) {
        return this == obj || (obj instanceof C_90490889 tag && value == tag.f_67818615);
    }

    @Override
    @Unique
    public C_90490889 copy() {
        return new C_90490889(value);
    }
}
