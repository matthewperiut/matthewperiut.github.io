package net.modificationstation.stationapi.api.nbt;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import java.util.Arrays;
import net.minecraft.unmapped.C_97075175;

public class NbtIntArray extends C_97075175 {
    public int[] data;

    public NbtIntArray() {}

    public NbtIntArray(int[] value) {
        this.data = value;
    }

    @Override
    public void m_20830783(DataOutput out) {
        try {
            out.writeInt(this.data.length);
            for (int l : data)
                out.writeInt(l);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_52126384(DataInput in) {
        try {
            int length = in.readInt();
            data = new int[length];
            for (int i = 0; i < length; i++)
                data[i] = in.readInt();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public byte m_65815168() {
        return 11;
    }

    @Override
    public boolean equals(Object obj) {
        return this == obj || (obj instanceof NbtIntArray tag && Arrays.equals(data, tag.data));
    }

    @Override
    public NbtIntArray copy() {
        return new NbtIntArray(Arrays.copyOf(data, data.length));
    }
}
