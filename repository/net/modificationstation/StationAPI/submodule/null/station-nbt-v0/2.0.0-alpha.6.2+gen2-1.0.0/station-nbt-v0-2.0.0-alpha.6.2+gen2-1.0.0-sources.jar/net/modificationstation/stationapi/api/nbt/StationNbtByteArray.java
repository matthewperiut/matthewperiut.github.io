package net.modificationstation.stationapi.api.nbt;

import net.minecraft.unmapped.C_03009146;
import net.modificationstation.stationapi.api.util.Util;

public interface StationNbtByteArray extends StationNbtElement {
    @Override
    default C_03009146 copy() {
        return Util.assertImpl();
    }
}
