package net.modificationstation.stationapi.mixin.nbt;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.unmapped.C_79370641;
import net.minecraft.unmapped.C_97075175;

@Mixin(C_79370641.class)
public interface NbtListAccessor {
    @Accessor("value")
    void stationapi$setValue(List<? extends C_97075175> value);

    @Accessor("type")
    byte stationapi$getType();

    @Accessor("type")
    void stationapi$setType(byte type);

    @Accessor("value")
    List<C_97075175> stationapi$getValue();
}
