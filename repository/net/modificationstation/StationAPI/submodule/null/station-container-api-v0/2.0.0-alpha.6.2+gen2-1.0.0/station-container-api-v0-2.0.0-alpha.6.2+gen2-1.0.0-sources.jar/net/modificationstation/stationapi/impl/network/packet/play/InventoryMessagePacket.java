package net.modificationstation.stationapi.impl.network.packet.play;

import net.minecraft.unmapped.C_43616774;
import net.modificationstation.stationapi.api.network.packet.MessagePacket;
import net.modificationstation.stationapi.api.util.Identifier;

public class InventoryMessagePacket extends MessagePacket {
    public C_43616774 inventory;

    /**
     * Default Message constructor.
     *
     * @param identifier the Message's identifier.
     */
    public InventoryMessagePacket(Identifier identifier) {
        super(identifier);
    }
}
