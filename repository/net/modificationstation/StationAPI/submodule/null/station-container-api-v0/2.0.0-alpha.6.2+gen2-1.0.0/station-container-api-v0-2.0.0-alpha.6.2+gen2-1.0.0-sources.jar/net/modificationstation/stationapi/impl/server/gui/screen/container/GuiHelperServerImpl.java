package net.modificationstation.stationapi.impl.server.gui.screen.container;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_46053237;
import net.minecraft.unmapped.C_54028238;
import net.modificationstation.stationapi.api.network.packet.MessagePacket;
import net.modificationstation.stationapi.impl.gui.screen.container.GuiHelperImpl;
import net.modificationstation.stationapi.mixin.container.server.ServerPlayerEntityAccessor;

public class GuiHelperServerImpl extends GuiHelperImpl {

    @Override
    protected void sideDependentPacket(C_40996800 player, C_43616774 inventory, MessagePacket message) {
        ((ServerPlayerEntityAccessor) player).invokeIncrementScreenHandlerSyncId();
        message.ints = new int[] { ((ServerPlayerEntityAccessor) player).getScreenHandlerSyncId() };
    }

    @Override
    protected void afterPacketSent(C_40996800 player, C_46053237 container) {
        player.f_25936683 = container;
        container.f_66294390 = ((ServerPlayerEntityAccessor) player).getScreenHandlerSyncId();
        container.m_22289062((C_54028238) player);
    }
}
