package net.modificationstation.stationapi.impl.gui.screen.container;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_46053237;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.network.packet.MessagePacket;
import net.modificationstation.stationapi.api.network.packet.PacketHelper;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.impl.network.packet.play.InventoryMessagePacket;

import java.util.function.Consumer;

public abstract class GuiHelperImpl {

    public void openGUI(C_40996800 player, Identifier identifier, C_43616774 inventory, C_46053237 container) {
        openGUI(player, identifier, inventory, container, (message) -> {});
    }

    public void openGUI(C_40996800 player, Identifier identifier, C_43616774 inventory, C_46053237 container, Consumer<MessagePacket> customData) {
        MessagePacket message = new InventoryMessagePacket(Identifier.of(StationAPI.NAMESPACE, "open_gui"));
        message.strings = new String[] { identifier.toString() };
        sideDependentPacket(player, inventory, message);
        customData.accept(message);
        PacketHelper.sendTo(player, message);
        afterPacketSent(player, container);
    }

    protected abstract void sideDependentPacket(C_40996800 player, C_43616774 inventory, MessagePacket message);

    protected abstract void afterPacketSent(C_40996800 player, C_46053237 container);
}
