package net.modificationstation.stationapi.api.client.gui.screen;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_85740840;
import net.modificationstation.stationapi.api.network.packet.MessagePacket;

public record GuiHandler(ScreenFactory screenFactory, InventoryFactory inventoryFactory) {
    @FunctionalInterface
    public interface ScreenFactory {
        C_85740840 create(C_40996800 player, C_43616774 inventory, MessagePacket packet);
    }

    @FunctionalInterface
    public interface ScreenFactoryNoMessage extends ScreenFactory {
        @Override
        default C_85740840 create(C_40996800 player, C_43616774 inventory, MessagePacket packet) {
            return create(player, inventory);
        }

        C_85740840 create(C_40996800 player, C_43616774 inventory);
    }

    @FunctionalInterface
    public interface InventoryFactory {
        C_43616774 create();
    }
}
