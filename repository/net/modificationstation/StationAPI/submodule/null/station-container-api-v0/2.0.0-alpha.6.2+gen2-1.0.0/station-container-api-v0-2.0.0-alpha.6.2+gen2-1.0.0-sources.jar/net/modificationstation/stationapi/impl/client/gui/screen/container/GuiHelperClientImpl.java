package net.modificationstation.stationapi.impl.client.gui.screen.container;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_46053237;
import net.modificationstation.stationapi.api.network.packet.MessagePacket;
import net.modificationstation.stationapi.impl.network.packet.play.InventoryMessagePacket;
import net.modificationstation.stationapi.impl.gui.screen.container.GuiHelperImpl;

public class GuiHelperClientImpl extends GuiHelperImpl {

    @Override
    protected void sideDependentPacket(C_40996800 player, C_43616774 inventory, MessagePacket message) {
        ((InventoryMessagePacket) message).inventory = inventory;
    }

    @Override
    protected void afterPacketSent(C_40996800 player, C_46053237 container) {

    }
}
