package net.modificationstation.stationapi.mixin.container.server;

import net.minecraft.unmapped.C_49202226;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_49202226.class)
public interface ServerPlayerEntityAccessor {
    @Invoker
    void invokeIncrementScreenHandlerSyncId();

    @Accessor
    int getScreenHandlerSyncId();
}
