package net.modificationstation.stationapi.impl.client.network;

import net.fabricmc.loader.api.FabricLoader;
import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_40996800;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.gui.screen.GuiHandler;
import net.modificationstation.stationapi.api.client.registry.GuiHandlerRegistry;
import net.modificationstation.stationapi.api.event.registry.GuiHandlerRegistryEvent;
import net.modificationstation.stationapi.api.event.registry.MessageListenerRegistryEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.network.packet.MessagePacket;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.impl.network.packet.play.InventoryMessagePacket;

import java.lang.invoke.MethodHandles;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class GuiClientNetworkHandler {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void registerMessageListeners(MessageListenerRegistryEvent event) {
        event.register(NAMESPACE.id("open_gui"), GuiClientNetworkHandler::handleGui);
        StationAPI.EVENT_BUS.post(new GuiHandlerRegistryEvent());
    }

    private static void handleGui(C_40996800 player, MessagePacket message) {
        boolean isClient = player.f_94306729.f_50876584;
        GuiHandler guiHandler = GuiHandlerRegistry.INSTANCE.get(Identifier.of(message.strings[0]));
        if (guiHandler != null)
            //noinspection deprecation
            ((Minecraft) FabricLoader.getInstance().getGameInstance()).m_52715402(guiHandler.screenFactory().create(player, isClient ? guiHandler.inventoryFactory().create() : ((InventoryMessagePacket) message).inventory, message));
        if (isClient)
            player.f_25936683.f_66294390 = message.ints[0];
    }
}
