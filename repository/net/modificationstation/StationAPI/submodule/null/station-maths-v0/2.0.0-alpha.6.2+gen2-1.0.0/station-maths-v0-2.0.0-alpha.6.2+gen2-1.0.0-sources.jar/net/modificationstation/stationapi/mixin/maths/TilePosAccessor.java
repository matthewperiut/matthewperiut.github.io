package net.modificationstation.stationapi.mixin.maths;

import net.minecraft.unmapped.C_32594356;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_32594356.class)
public interface TilePosAccessor {
    @Mutable
    @Accessor("x")
    void stationapi_setX(int x);

    @Mutable
    @Accessor("y")
    void stationapi_setY(int y);

    @Mutable
    @Accessor("z")
    void stationapi_setZ(int z);
}
