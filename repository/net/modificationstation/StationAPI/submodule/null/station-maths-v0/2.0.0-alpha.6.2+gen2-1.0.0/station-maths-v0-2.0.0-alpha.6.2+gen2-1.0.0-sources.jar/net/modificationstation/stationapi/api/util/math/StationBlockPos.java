package net.modificationstation.stationapi.api.util.math;

import com.google.common.collect.AbstractIterator;
import com.mojang.serialization.Codec;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_82690114;
import net.modificationstation.stationapi.api.util.BlockRotation;
import net.modificationstation.stationapi.api.util.Util;
import org.apache.commons.lang3.Validate;

import java.util.Optional;
import java.util.Random;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

import static net.minecraft.unmapped.C_45510667.m_80489169;

public interface StationBlockPos {
    Codec<C_32594356> CODEC = Codec.INT_STREAM.comapFlatMap(
            stream -> Util.toArray(stream, 3).map(values -> new C_32594356(values[0], values[1], values[2])),
            pos -> IntStream.of(pos.getX(), pos.getY(), pos.getZ())
    ).stable();
    /**
     * The block position which x, y, and z values are all zero.
     */
    C_32594356 ORIGIN = new C_32594356(0, 0, 0);
    int
            SIZE_BITS_X = 1 + MathHelper.floorLog2(MathHelper.smallestEncompassingPowerOfTwo(30000000)),
            SIZE_BITS_Z = SIZE_BITS_X,
            SIZE_BITS_Y = 64 - SIZE_BITS_X - SIZE_BITS_Z,
            BIT_SHIFT_X = SIZE_BITS_Y + SIZE_BITS_Z,
            BIT_SHIFT_Z = SIZE_BITS_Y;
    long
            BITS_X = (1L << SIZE_BITS_X) - 1L,
            BITS_Z = (1L << SIZE_BITS_Z) - 1L,
            BITS_Y = (1L << SIZE_BITS_Y) - 1L;

    static C_32594356 create(double x, double y, double z) {
        return new C_32594356(m_80489169(x), m_80489169(y), m_80489169(z));
    }

    static C_32594356 create(Vec3d pos) {
        return create(pos.x, pos.y, pos.z);
    }

    static C_32594356 create(Position pos) {
        return create(pos.getX(), pos.getY(), pos.getZ());
    }

    static C_32594356 create(Vec3i pos) {
        return new C_32594356(pos.getX(), pos.getY(), pos.getZ());
    }

    static long offset(long value, Direction direction) {
        return add(value, direction.getOffsetX(), direction.getOffsetY(), direction.getOffsetZ());
    }

    static long add(long value, int x, int y, int z) {
        return asLong(unpackLongX(value) + x, unpackLongY(value) + y, unpackLongZ(value) + z);
    }

    static int unpackLongX(long packedPos) {
        return (int) (packedPos << 64 - BIT_SHIFT_X - SIZE_BITS_X >> 64 - SIZE_BITS_X);
    }

    static int unpackLongY(long packedPos) {
        return (int) (packedPos << 64 - SIZE_BITS_Y >> 64 - SIZE_BITS_Y);
    }

    static int unpackLongZ(long packedPos) {
        return (int) (packedPos << 64 - BIT_SHIFT_Z - SIZE_BITS_Z >> 64 - SIZE_BITS_Z);
    }

    static C_32594356 fromLong(long packedPos) {
        return new C_32594356(unpackLongX(packedPos), unpackLongY(packedPos), unpackLongZ(packedPos));
    }

    static long asLong(int x, int y, int z) {
        long l = 0L;
        l |= ((long) x & BITS_X) << BIT_SHIFT_X;
        l |= ((long) y & BITS_Y);
        return l |= ((long) z & BITS_Z) << BIT_SHIFT_Z;
    }

    static long removeChunkSectionLocalY(long y) {
        return y & 0xFFFFFFFFFFFFFFF0L;
    }

    /**
     * Iterates through {@code count} random block positions in a given range around the given position.
     *
     * <p>The iterator yields positions in no specific order. The same position
     * may be returned multiple times by the iterator.
     *
     * @param range  the maximum distance from the given pos in any axis
     * @param around the {@link C_32594356} to iterate around
     * @param count  the number of positions to iterate
     */
    static Iterable<C_32594356> iterateRandomly(Random random, int count, C_32594356 around, int range) {
        return iterateRandomly(
                random, count,
                around.getX() - range, around.getY() - range, around.getZ() - range,
                around.getX() + range, around.getY() + range, around.getZ() + range
        );
    }

    /**
     * Iterates through {@code count} random block positions in the given area.
     *
     * <p>The iterator yields positions in no specific order. The same position
     * may be returned multiple times by the iterator.
     *
     * @param count the number of positions to iterate
     * @param minX  the minimum x value for returned positions
     * @param minY  the minimum y value for returned positions
     * @param minZ  the minimum z value for returned positions
     * @param maxX  the maximum x value for returned positions
     * @param maxY  the maximum y value for returned positions
     * @param maxZ  the maximum z value for returned positions
     */
    static Iterable<C_32594356> iterateRandomly(Random random, int count, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        final int i = maxX - minX + 1;
        final int j = maxY - minY + 1;
        final int k = maxZ - minZ + 1;
        return () -> new AbstractIterator<>() {
            final MutableBlockPos pos = new MutableBlockPos();
            int remaining = count;

            @Override
            protected C_32594356 computeNext() {
                if (this.remaining <= 0) {
                    return this.endOfData();
                }
                MutableBlockPos blockPos = this.pos.set(minX + random.nextInt(i), minY + random.nextInt(j), minZ + random.nextInt(k));
                --this.remaining;
                return blockPos;
            }
        };
    }

    /**
     * Iterates block positions around the {@code center}. The iteration order
     * is mainly based on the manhattan distance of the position from the
     * center.
     *
     * <p>For the same manhattan distance, the positions are iterated by y
     * offset, from negative to positive. For the same y offset, the positions
     * are iterated by x offset, from negative to positive. For the two
     * positions with the same x and y offsets and the same manhattan distance,
     * the one with a positive z offset is visited first before the one with a
     * negative z offset.
     *
     * @param rangeY the maximum y difference from the center
     * @param rangeZ the maximum z difference from the center
     * @param center the center of iteration
     * @param rangeX the maximum x difference from the center
     */
    static Iterable<C_32594356> iterateOutwards(C_32594356 center, int rangeX, int rangeY, int rangeZ) {
        final int sum = rangeX + rangeY + rangeZ;
        final int x = center.getX();
        final int y = center.getY();
        final int z = center.getZ();
        return () -> new AbstractIterator<>() {
            private final MutableBlockPos pos = new MutableBlockPos();
            private int manhattanDistance;
            private int limitX;
            private int limitY;
            private int dx;
            private int dy;
            private boolean swapZ;

            @Override
            protected C_32594356 computeNext() {
                if (this.swapZ) {
                    this.swapZ = false;
                    this.pos.setZ(z - (this.pos.f_31865394 - z));
                    return this.pos;
                }
                MutableBlockPos blockPos = null;
                while (blockPos == null) {
                    if (this.dy > this.limitY) {
                        ++this.dx;
                        if (this.dx > this.limitX) {
                            ++this.manhattanDistance;
                            if (this.manhattanDistance > sum) {
                                return this.endOfData();
                            }
                            this.limitX = Math.min(rangeX, this.manhattanDistance);
                            this.dx = -this.limitX;
                        }
                        this.limitY = Math.min(rangeY, this.manhattanDistance - Math.abs(this.dx));
                        this.dy = -this.limitY;
                    }
                    int i2 = this.dx;
                    int j2 = this.dy;
                    int k2 = this.manhattanDistance - Math.abs(i2) - Math.abs(j2);
                    if (k2 <= rangeZ) {
                        this.swapZ = k2 != 0;
                        blockPos = this.pos.set(x + i2, y + j2, z + k2);
                    }
                    ++this.dy;
                }
                return blockPos;
            }
        };
    }

    static Optional<C_32594356> findClosest(C_32594356 pos, int horizontalRange, int verticalRange, Predicate<C_32594356> condition) {
        for (C_32594356 blockPos : iterateOutwards(pos, horizontalRange, verticalRange, horizontalRange)) {
            if (!condition.test(blockPos)) continue;
            return Optional.of(blockPos);
        }
        return Optional.empty();
    }

    static Stream<C_32594356> streamOutwards(C_32594356 center, int maxX, int maxY, int maxZ) {
        return StreamSupport.stream(iterateOutwards(center, maxX, maxY, maxZ).spliterator(), false);
    }

    static Iterable<C_32594356> iterate(C_32594356 start, C_32594356 end) {
        return iterate(
                Math.min(start.getX(), end.getX()), Math.min(start.getY(), end.getY()), Math.min(start.getZ(), end.getZ()),
                Math.max(start.getX(), end.getX()), Math.max(start.getY(), end.getY()), Math.max(start.getZ(), end.getZ())
        );
    }

    static Stream<C_32594356> stream(C_32594356 start, C_32594356 end) {
        return StreamSupport.stream(iterate(start, end).spliterator(), false);
    }

    static Stream<C_32594356> stream(C_82690114 box) {
        return stream(m_80489169(box.f_87518512), m_80489169(box.f_80314167), m_80489169(box.f_85940458), m_80489169(box.f_89130367), m_80489169(box.f_98553650), m_80489169(box.f_24562106));
    }

    static Stream<C_32594356> stream(int startX, int startY, int startZ, int endX, int endY, int endZ) {
        return StreamSupport.stream(iterate(startX, startY, startZ, endX, endY, endZ).spliterator(), false);
    }

    static Iterable<C_32594356> iterate(int startX, int startY, int startZ, int endX, int endY, int endZ) {
        final int i = endX - startX + 1;
        final int j = endY - startY + 1;
        int k = endZ - startZ + 1;
        final int l = i * j * k;
        return () -> new AbstractIterator<>() {
            private final MutableBlockPos pos = new MutableBlockPos();
            private int index;

            @Override
            protected C_32594356 computeNext() {
                if (this.index == l) {
                    return this.endOfData();
                }
                int i2 = this.index % i;
                int j2 = this.index / i;
                int k = j2 % j;
                int l2 = j2 / j;
                ++this.index;
                return this.pos.set(startX + i2, startY + k, startZ + l2);
            }
        };
    }

    /**
     * Iterates block positions around the {@code center} in a square of
     * ({@code 2 * radius + 1}) by ({@code 2 * radius + 1}). The blocks
     * are iterated in a (square) spiral around the center.
     *
     * <p>The first block returned is the center, then the iterator moves
     * a block towards the first direction, followed by moving along
     * the second direction.
     *
     * @param firstDirection  the direction the iterator moves first
     * @param secondDirection the direction the iterator moves after the first
     * @param center          the center of iteration
     * @param radius          the maximum chebychev distance
     * @throws IllegalStateException when the 2 directions lie on the same axis
     */
    static Iterable<MutableBlockPos> iterateInSquare(C_32594356 center, int radius, Direction firstDirection, Direction secondDirection) {
        Validate.validState(firstDirection.getAxis() != secondDirection.getAxis(), "The two directions cannot be on the same axis");
        return () -> new AbstractIterator<>() {
            private final Direction[] directions;
            private final MutableBlockPos pos;
            private final int maxDirectionChanges;
            private int directionChangeCount;
            private int maxSteps;
            private int steps;
            private int currentX;
            private int currentY;
            private int currentZ;

            {
                this.directions = new Direction[]{firstDirection, secondDirection, firstDirection.getOpposite(), secondDirection.getOpposite()};
                this.pos = center.mutableCopy().move(secondDirection);
                this.maxDirectionChanges = 4 * radius;
                this.directionChangeCount = -1;
                this.currentX = this.pos.getX();
                this.currentY = this.pos.getY();
                this.currentZ = this.pos.getZ();
            }

            @Override
            protected MutableBlockPos computeNext() {
                this.pos.set(this.currentX, this.currentY, this.currentZ).move(this.directions[(this.directionChangeCount + 4) % 4]);
                this.currentX = this.pos.getX();
                this.currentY = this.pos.getY();
                this.currentZ = this.pos.getZ();
                if (this.steps >= this.maxSteps) {
                    if (this.directionChangeCount >= this.maxDirectionChanges) {
                        return this.endOfData();
                    }
                    ++this.directionChangeCount;
                    this.steps = 0;
                    this.maxSteps = this.directionChangeCount / 2 + 1;
                }
                ++this.steps;
                return this.pos;
            }
        };
    }

    default int getX() {
        return Util.assertImpl();
    }

    default int getY() {
        return Util.assertImpl();
    }

    default int getZ() {
        return Util.assertImpl();
    }

    default long asLong() {
        return asLong(getX(), getY(), getZ());
    }

    default C_32594356 add(double d, double e, double f) {
        return Util.assertImpl();
    }

    default C_32594356 add(int i, int j, int k) {
        return Util.assertImpl();
    }

    default C_32594356 add(Vec3i vec3i) {
        return add(vec3i.getX(), vec3i.getY(), vec3i.getZ());
    }

    default C_32594356 subtract(Vec3i vec3i) {
        return add(-vec3i.getX(), -vec3i.getY(), -vec3i.getZ());
    }

    default C_32594356 multiply(int i) {
        return Util.assertImpl();
    }

    default C_32594356 down() {
        return new C_32594356(getX(), getY() - 1, getZ());
    }

    default C_32594356 down(int distance) {
        return new C_32594356(getX(), getY() - distance, getZ());
    }

    default C_32594356 up() {
        return new C_32594356(getX(), getY() + 1, getZ());
    }

    default C_32594356 up(int distance) {
        return new C_32594356(getX(), getY() + distance, getZ());
    }

    default C_32594356 east() {
        return new C_32594356(getX(), getY(), getZ() - 1);
    }

    default C_32594356 east(int distance) {
        return new C_32594356(getX(), getY(), getZ() - distance);
    }

    default C_32594356 west() {
        return new C_32594356(getX(), getY(), getZ() + 1);
    }

    default C_32594356 west(int distance) {
        return new C_32594356(getX(), getY(), getZ() + distance);
    }

    default C_32594356 north() {
        return new C_32594356(getX() - 1, getY(), getZ());
    }

    default C_32594356 north(int distance) {
        return new C_32594356(getX() - distance, getY(), getZ());
    }

    default C_32594356 south() {
        return new C_32594356(getX() + 1, getY(), getZ());
    }

    default C_32594356 south(int distance) {
        return new C_32594356(getX() + distance, getY(), getZ());
    }

    default C_32594356 offset(Direction direction) {
        return new C_32594356(getX() + direction.getOffsetX(), getY() + direction.getOffsetY(), getZ() + direction.getOffsetZ());
    }

    default C_32594356 offset(Direction direction, int i) {
        return Util.assertImpl();
    }

    default C_32594356 offset(Direction.Axis axis, int i) {
        return Util.assertImpl();
    }

    default C_32594356 rotate(BlockRotation rotation) {
        return Util.assertImpl();
    }

    default C_32594356 crossProduct(Vec3i pos) {
        return new C_32594356(
                getY() * pos.getZ() - getZ() * pos.getY(),
                getZ() * pos.getX() - getX() * pos.getZ(),
                getX() * pos.getY() - getY() * pos.getX()
        );
    }

    default C_32594356 withY(int y) {
        return new C_32594356(this.getX(), y, this.getZ());
    }

    default C_32594356 toImmutable() {
        return Util.assertImpl();
    }

    default MutableBlockPos mutableCopy() {
        return new MutableBlockPos(getX(), getY(), getZ());
    }
}
