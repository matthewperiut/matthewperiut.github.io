package net.modificationstation.stationapi.api.block;

import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.util.Util;

public interface StationBlockItemsBlock extends BlockItemToggle {
    @Override
    default C_81592558 disableAutoItemRegistration() {
        return Util.assertImpl();
    }

    @Override
    default boolean isAutoItemRegistrationDisabled() {
        return Util.assertImpl();
    }
}
