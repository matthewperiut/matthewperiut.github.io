package net.modificationstation.stationapi.api.template.item;

public class MetaBlockItem extends TemplateBlockItem {
    public MetaBlockItem(int i) {
        super(i);
        m_56494446(true);
    }

    @Override
    public int m_65403122(int i) {
        return i;
    }
}
