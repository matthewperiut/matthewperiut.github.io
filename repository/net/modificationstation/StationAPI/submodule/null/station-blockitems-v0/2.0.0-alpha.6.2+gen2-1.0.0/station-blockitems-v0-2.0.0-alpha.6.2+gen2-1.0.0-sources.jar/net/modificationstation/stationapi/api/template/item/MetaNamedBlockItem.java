package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_88708284;

public class MetaNamedBlockItem extends MetaBlockItem {
    public MetaNamedBlockItem(int i) {
        super(i);
    }

    @Override
    public String m_81802680(C_88708284 item) {
        return m_27822537() + item.m_21098843();
    }
}
