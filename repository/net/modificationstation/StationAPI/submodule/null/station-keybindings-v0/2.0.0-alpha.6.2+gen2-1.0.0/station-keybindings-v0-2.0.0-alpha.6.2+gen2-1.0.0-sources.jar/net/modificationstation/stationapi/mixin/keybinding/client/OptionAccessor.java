package net.modificationstation.stationapi.mixin.keybinding.client;

import net.minecraft.unmapped.C_76792751;
import net.modificationstation.stationapi.api.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_76792751.net/minecraft/unmapped/C_92207510.class)
public interface OptionAccessor {
    @Invoker("<init>")
    static C_76792751.net/minecraft/unmapped/C_92207510 stationapi_create(String optionName, int id, String translationKey, boolean slider, boolean toggle) {
        return Util.assertMixin();
    }
}
