package net.modificationstation.stationapi.api.client.option;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.minecraft.unmapped.C_76792751;
import net.modificationstation.stationapi.mixin.keybinding.client.OptionAccessor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class OptionFactory {
    private static int nextId = C_76792751.net/minecraft/unmapped/C_92207510.values().length;

    public static C_76792751.net/minecraft/unmapped/C_92207510 create(String optionName, String translationKey, boolean slider, boolean toggle) {
        return OptionAccessor.stationapi_create(optionName, nextId++, translationKey, slider, toggle);
    }
}
