package net.modificationstation.stationapi.api.client.event.option;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_23708450;
import java.util.List;

/**
 * Used to add keybindings to the keybinding screen.
 * Implement this in the class you plan to use to add your keybindings, and then override registerKeyBindings(List{@literal <KeyBinding>} keyBindings).
 * You then want to add your instantiated keybindings into the list using keyBindings.add(myKeybind).
 * All events need to be registered in your mod's preInit method using KeyBindingRegister.EVENT.register(yourInstantiatedClass).
 * <p>
 * You also likely want to use the KeyPressed event to handle your keybindings.
 *
 * @author mine_diver
 * @see C_23708450
 * @see List#add(Object)
 */
@SuperBuilder
public class KeyBindingRegisterEvent extends Event {
    public final List<C_23708450> keyBindings;
    
    public final void register(C_23708450 keyBinding) {
        keyBindings.add(keyBinding);
    }
}
