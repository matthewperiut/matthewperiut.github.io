package net.modificationstation.stationapi.api.block;

import net.minecraft.unmapped.C_81592558;

public interface BlockItemToggle {
    C_81592558 disableAutoItemRegistration();

    boolean isAutoItemRegistrationDisabled();
}
