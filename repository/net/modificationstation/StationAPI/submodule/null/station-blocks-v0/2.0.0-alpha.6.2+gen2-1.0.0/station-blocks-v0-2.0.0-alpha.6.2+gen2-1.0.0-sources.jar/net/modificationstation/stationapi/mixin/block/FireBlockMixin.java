package net.modificationstation.stationapi.mixin.block;

import net.minecraft.unmapped.C_32290952;
import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.block.FireBurnableRegisterEvent;
import net.modificationstation.stationapi.api.registry.tag.BlockTags;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

@Mixin(C_32290952.class)
abstract class FireBlockMixin {
    @Shadow protected abstract void registerFlammableBlock(int i, int j, int k);

    @Inject(
            method = "init",
            at = @At("RETURN")
    )
    private void stationapi_postBurnableRegister(CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(FireBurnableRegisterEvent.builder().addBurnable(this::registerFlammableBlock).build());
    }

    @ModifyConstant(
            method = "onTick",
            constant = {
                    @Constant(
                            intValue = 0,
                            ordinal = 0
                    ),
                    @Constant(
                            intValue = 1,
                            ordinal = 1
                    )
            }
    )
    private int stationapi_allowInfiniburnBlocks(int constant, C_64041439 world, int x, int y, int z, Random random) {
        return world.getBlockState(x, y - 1, z).isIn(BlockTags.INFINIBURN) ? 1 : 0;
    }
}
