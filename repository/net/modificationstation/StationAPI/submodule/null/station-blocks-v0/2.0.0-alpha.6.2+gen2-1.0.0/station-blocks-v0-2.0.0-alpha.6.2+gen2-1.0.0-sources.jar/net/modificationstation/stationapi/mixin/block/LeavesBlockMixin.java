package net.modificationstation.stationapi.mixin.block;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.unmapped.C_44922783;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.registry.tag.BlockTags;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(C_44922783.class)
public class LeavesBlockMixin {

    @WrapOperation(method = "onTick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/World;getBlockId(III)I"))
    private int makeModdedLogsAndLeavesWork(C_64041439 instance, int x, int y, int z, Operation<Integer> original) {
        BlockState state = instance.getBlockState(x, y, z);
        if (state.isIn(BlockTags.LOGS)) {
            return C_81592558.f_78280144.f_84602679;
        }
        if (state.isIn(BlockTags.LEAVES)) {
            return C_81592558.f_00276986.f_84602679;
        }

        return original.call(instance, x, y, z);
    }
}
