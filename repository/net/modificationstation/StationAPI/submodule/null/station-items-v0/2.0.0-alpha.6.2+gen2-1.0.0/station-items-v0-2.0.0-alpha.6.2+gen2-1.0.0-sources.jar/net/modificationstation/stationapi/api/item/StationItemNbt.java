package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_74087615;

public interface StationItemNbt {
    C_74087615 getStationNbt();
}
