package net.modificationstation.stationapi.mixin.item.client;

import net.minecraft.unmapped.C_87711245;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_87711245.class)
public interface HandledScreenAccessor {
    @Accessor("backgroundWidth")
    int stationapi_getBackgroundWidth();

    @Accessor("backgroundHeight")
    int stationapi_getBackgroundHeight();
}
