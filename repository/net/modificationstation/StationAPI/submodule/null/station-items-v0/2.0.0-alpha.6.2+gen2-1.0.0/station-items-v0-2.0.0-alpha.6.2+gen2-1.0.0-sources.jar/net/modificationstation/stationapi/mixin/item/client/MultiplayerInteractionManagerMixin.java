package net.modificationstation.stationapi.mixin.item.client;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_34267874;
import net.minecraft.unmapped.C_45175654;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.entity.player.PlayerEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_45175654.class)
class MultiplayerInteractionManagerMixin extends C_34267874 {
    private MultiplayerInteractionManagerMixin(Minecraft minecraft) {
        super(minecraft);
    }

    @Inject(
            method = "getReachDistance",
            at = @At("RETURN"),
            cancellable = true
    )
    private void stationapi_getBlockReach(CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue((float) StationAPI.EVENT_BUS.post(
                PlayerEvent.Reach.builder()
                        .player(f_17565231.f_28396371)
                        .type(C_24654288.net/minecraft/unmapped/C_25850426.f_13890456)
                        .currentReach(cir.getReturnValueF())
                        .build()
        ).currentReach);
    }

    @Inject(
            method = "processBlockBreakingAction",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/Block;getHardness(Lnet/minecraft/entity/player/PlayerEntity;)F"
            ),
            cancellable = true
    )
    private void stationapi_processBlockBreakingAction_preMine(int x, int y, int z, int side, CallbackInfo ci) {
        C_88708284 stack = this.f_17565231.f_28396371.f_29439708.m_27760697();
        if (stack != null && !stack.preMine(this.f_17565231.f_28396371.f_94306729.getBlockState(x, y, z), x, y, z, side, this.f_17565231.f_28396371))
            ci.cancel();
    }
}
