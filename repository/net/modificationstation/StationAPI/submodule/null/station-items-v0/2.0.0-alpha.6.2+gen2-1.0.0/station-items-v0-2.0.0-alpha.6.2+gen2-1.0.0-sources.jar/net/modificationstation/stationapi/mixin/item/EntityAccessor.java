package net.modificationstation.stationapi.mixin.item;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Random;
import net.minecraft.unmapped.C_42232651;

@Mixin(C_42232651.class)
public interface EntityAccessor {
    @Accessor("random")
    Random stationapi_getRandom();
}
