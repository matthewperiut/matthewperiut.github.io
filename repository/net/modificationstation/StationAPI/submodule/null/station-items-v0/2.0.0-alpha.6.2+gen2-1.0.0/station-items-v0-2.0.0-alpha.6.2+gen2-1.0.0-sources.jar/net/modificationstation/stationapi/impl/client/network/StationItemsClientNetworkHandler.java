package net.modificationstation.stationapi.impl.client.network;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_06774341;
import net.minecraft.unmapped.C_34399650;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.impl.item.StationNBTSetter;
import net.modificationstation.stationapi.impl.network.StationItemsNetworkHandler;
import net.modificationstation.stationapi.impl.network.packet.s2c.play.StationEntityEquipmentUpdateS2CPacket;
import net.modificationstation.stationapi.impl.network.packet.s2c.play.StationItemEntitySpawnS2CPacket;
import net.modificationstation.stationapi.mixin.item.client.ClientNetworkHandlerAccessor;

public class StationItemsClientNetworkHandler extends StationItemsNetworkHandler {
    @Override
    public boolean m_95861517() {
        return false;
    }

    @Override
    public void onItemEntitySpawn(StationItemEntitySpawnS2CPacket packet) {
        //noinspection deprecation
        C_34399650 clientWorld = (C_34399650) ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_26407825;
        double x = (double)packet.f_17103444 / 32.0;
        double y = (double)packet.f_47155130 / 32.0;
        double z = (double)packet.f_02582861 / 32.0;
        C_88708284 stack = new C_88708284(packet.f_14614129, packet.f_51835474, packet.f_37259644);
        if (packet.stationNbt != null)
            StationNBTSetter.cast(stack).setStationNbt(packet.stationNbt);
        C_06774341 entity = new C_06774341(clientWorld, x, y, z, stack);
        entity.f_24826402 = (double)packet.f_85566945 / 128.0;
        entity.f_35148123 = (double)packet.f_35831023 / 128.0;
        entity.f_21201587 = (double)packet.f_80937884 / 128.0;
        entity.f_16319839 = packet.f_17103444;
        entity.f_59722398 = packet.f_47155130;
        entity.f_79826809 = packet.f_02582861;
        clientWorld.m_34714727(packet.f_40035946, entity);
    }

    @Override
    public void onEntityEquipmentUpdate(StationEntityEquipmentUpdateS2CPacket packet) {
        //noinspection deprecation
        C_42232651 entity = ((ClientNetworkHandlerAccessor) ((Minecraft) FabricLoader.getInstance().getGameInstance()).m_55181026()).stationapi_getEntity(packet.f_30073456);
        if (entity != null) {
            final C_88708284 stack;
            if (packet.f_10516060 < 0)
                stack = null;
            else {
                stack = new C_88708284(packet.f_10516060, 1, packet.f_96552024);
                if (packet.stationNbt != null) StationNBTSetter.cast(stack).setStationNbt(packet.stationNbt);
            }
            entity.equipStack(packet.f_55417713, stack);
        }
    }
}
