package net.modificationstation.stationapi.mixin.item.client;

import net.minecraft.unmapped.C_29058632;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_29058632.class)
public interface DrawContextAccessor {
    @Invoker
    void invokeFill(int x1, int y1, int x2, int y2, int color);
}
