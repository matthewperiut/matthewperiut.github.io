package net.modificationstation.stationapi.mixin.item;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.item.UseOnEntityFirst;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_40996800.class)
abstract class PlayerEntityMixin extends C_74425583 {
    private PlayerEntityMixin(C_64041439 arg) {
        super(arg);
    }

    @Shadow public abstract C_88708284 getHand();

    @Inject(
            method = "interact",
            at = @At(value = "HEAD"),
            cancellable = true
    )
    private void stationapi_hijackInteractWith(C_42232651 arg, CallbackInfo ci) {
        C_88708284 stack = getHand();
        //noinspection DataFlowIssue
        if (stack != null && stack.m_23235460() instanceof UseOnEntityFirst use && use.onUseOnEntityFirst(stack, (C_40996800) (Object) this, this.f_94306729, arg))
            ci.cancel();
    }


    @Inject(
            method = "attack",
            at = @At("HEAD"),
            cancellable = true
    )
    public void stationapi_attack_preHit(C_42232651 entity, CallbackInfo ci) {
        C_88708284 stack = this.getHand();
        //noinspection DataFlowIssue
        if (stack != null && !stack.preHit(entity, (C_40996800) (Object) this)) ci.cancel();
    }
}
