package net.modificationstation.stationapi.mixin.item;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.entity.StationItemsEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_42232651.class)
abstract class EntityMixin implements StationItemsEntity {
    @Environment(EnvType.CLIENT)
    @Shadow public abstract void setEquipmentStack(int slot, int itemId, int count);

    @SuppressWarnings("AddedMixinMembersNamePattern")
    @Override
    @Unique
    @Environment(EnvType.CLIENT)
    public void equipStack(int slot, C_88708284 stack) {
        setEquipmentStack(slot, stack == null ? -1 : stack.f_59294634, stack == null ? 0 : stack.m_21098843());
    }
}
