package net.modificationstation.stationapi.mixin.item.client.network.itemnbt;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.unmapped.C_18902094;
import net.minecraft.unmapped.C_45175654;
import net.minecraft.unmapped.C_88014908;
import net.minecraft.unmapped.C_88033048;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.network.ModdedPacketHandler;
import net.modificationstation.stationapi.impl.network.packet.c2s.play.StationClickSlotC2SPacket;
import net.modificationstation.stationapi.impl.network.packet.c2s.play.StationPlayerInteractBlockC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(C_45175654.class)
class MultiplayerInteractionManagerMixin {
    @Shadow private C_88014908 networkHandler;

    @WrapOperation(
            method = {
                    "interactBlock",
                    "interactItem"
            },
            at = @At(
                    value = "NEW",
                    target = "(IIIILnet/minecraft/item/ItemStack;)Lnet/minecraft/network/packet/c2s/play/PlayerInteractBlockC2SPacket;"
            )
    )
    private C_18902094 stationapi_redirectPlayerInteractBlockPacket(int x, int y, int z, int side, C_88708284 stack, Operation<C_18902094> original) {
        return ((ModdedPacketHandler) networkHandler).isModded() ?
                new StationPlayerInteractBlockC2SPacket(x, y, z, side, stack) :
                original.call(x, y, z, side, stack);
    }

    @WrapOperation(
            method = "clickSlot",
            at = @At(
                    value = "NEW",
                    target = "(IIIZLnet/minecraft/item/ItemStack;S)Lnet/minecraft/network/packet/c2s/play/ClickSlotC2SPacket;"
            )
    )
    private C_88033048 stationapi_redirectClickSlotPacket(int syncId, int slot, int button, boolean holdingShift, C_88708284 stack, short actionType, Operation<C_88033048> original) {
        return ((ModdedPacketHandler) networkHandler).isModded() ?
                new StationClickSlotC2SPacket(syncId, slot, button, holdingShift, stack, actionType) :
                original.call(syncId, slot, button, holdingShift, stack, actionType);
    }
}
