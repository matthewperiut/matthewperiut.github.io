package net.modificationstation.stationapi.api.client.event.gui.screen.container;


import lombok.experimental.SuperBuilder;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_87711245;
import net.modificationstation.stationapi.api.event.item.ItemStackEvent;
import org.jetbrains.annotations.Nullable;

import java.util.*;

@SuperBuilder
public class TooltipBuildEvent extends ItemStackEvent {
    /**
     * Containers aren't guaranteed to exist when rendering a tooltip.
     */
    @Nullable
    public final C_87711245 container;
    public final C_87542771 inventory;
    public final ArrayList<String> tooltip;

    public void add(String tooltip) {
        this.tooltip.add(tooltip);
    }
}
