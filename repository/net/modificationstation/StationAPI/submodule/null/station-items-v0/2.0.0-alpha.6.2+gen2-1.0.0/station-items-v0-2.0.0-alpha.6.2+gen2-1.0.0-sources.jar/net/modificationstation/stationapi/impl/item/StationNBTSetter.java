package net.modificationstation.stationapi.impl.item;

import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_88708284;

public interface StationNBTSetter {
    static StationNBTSetter cast(C_88708284 stack) {
        return StationNBTSetter.class.cast(stack);
    }

    void setStationNbt(C_74087615 stationNbt);
}
