package net.modificationstation.stationapi.impl.network.packet.s2c.play;

import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_21829382;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_97075175;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.api.network.packet.PacketType;
import net.modificationstation.stationapi.impl.network.StationItemsNetworkHandler;
import org.jetbrains.annotations.NotNull;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class StationEntityEquipmentUpdateS2CPacket extends C_21829382 implements ManagedPacket<StationEntityEquipmentUpdateS2CPacket> {
    public static final PacketType<StationEntityEquipmentUpdateS2CPacket> TYPE = PacketType.builder(true, false, StationEntityEquipmentUpdateS2CPacket::new).build();

    public C_74087615 stationNbt;

    private StationEntityEquipmentUpdateS2CPacket() {}

    public StationEntityEquipmentUpdateS2CPacket(int id, int slot, C_88708284 itemStack) {
        super(id, slot, itemStack);
        this.stationNbt = itemStack == null ? null : itemStack.getStationNbt();
    }

    @Override
    public void m_13296744(DataInputStream stream) {
        super.m_13296744(stream);
        try {
            if (stream.readBoolean()) return;
            stationNbt = (C_74087615) C_74087615.m_46974369(stream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_17566769(DataOutputStream stream) {
        super.m_17566769(stream);
        boolean empty = stationNbt == null || stationNbt.m_45469513().isEmpty();
        try {
            stream.writeBoolean(empty);
            if (empty) return;
            C_97075175.m_71107467(stationNbt, stream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_04853589(C_10918870 networkHandler) {
        ((StationItemsNetworkHandler) networkHandler).onEntityEquipmentUpdate(this);
    }

    @Override
    public @NotNull PacketType<StationEntityEquipmentUpdateS2CPacket> getType() {
        return TYPE;
    }
}
