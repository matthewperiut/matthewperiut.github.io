package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_74087615;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.util.Util;

public interface StationItemStack extends StationItemNbt {
    @Override
    default C_74087615 getStationNbt() {
        return Util.assertImpl();
    }

    default boolean preHit(C_42232651 otherEntity, C_40996800 player) {
        return Util.assertImpl();
    }

    default boolean preMine(BlockState blockState, int x, int y, int z, int side, C_40996800 player) {
        return Util.assertImpl();
    }
}
