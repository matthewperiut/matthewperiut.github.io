package net.modificationstation.stationapi.mixin.item;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_75630531;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.bonemeal.BonemealAPI;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_75630531.class)
class DyeItemMixin {
    @Inject(
            method = "useOnBlock",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/World;getBlockId(III)I",
                    ordinal = 0
            ),
            cancellable = true
    )
    private void stationapi_onBonemealUse(C_88708284 item, C_40996800 player, C_64041439 world, int x, int y, int z, int side, CallbackInfoReturnable<Boolean> info) {
        BlockState state = world.getBlockState(x, y, z);
        if (state.getBlock().onBonemealUse(world, x, y, z, state)) {
            world.m_76770021(x, y, z, x, y, z);
            info.setReturnValue(true);
            if (!world.f_50876584) item.f_60602012--;
            return;
        }
        if (BonemealAPI.generate(world, x, y, z, state, side)) {
            world.m_76770021(x - 8, y - 8, z - 8, x + 8, y + 8, z + 8);
            info.setReturnValue(true);
            if (!world.f_50876584) item.f_60602012--;
        }
    }
}
