package net.modificationstation.stationapi.api.client.event.gui.screen.container;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.event.Cancelable;
import net.mine_diver.unsafeevents.event.EventPhases;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_87711245;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.item.ItemStackEvent;
import org.jetbrains.annotations.Nullable;

@Cancelable
@SuperBuilder
@EventPhases(StationAPI.INTERNAL_PHASE)
public class TooltipRenderEvent extends ItemStackEvent {
    /**
     * Containers aren't guaranteed to exist when rendering a tooltip.
     */
    @Nullable
    public final C_87711245 container;
    public final C_23014920 textManager;
    public final C_87542771 inventory;
    public final int
            mouseX,
            mouseY;
    public final float delta;
    public final String originalTooltip;
}
