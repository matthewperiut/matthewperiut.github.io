package net.modificationstation.stationapi.mixin.item;

import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Objects;
import net.minecraft.unmapped.C_12356698;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46053237;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_88708284;

@Mixin(C_46053237.class)
class ScreenHandlerMixin {
    @Inject(
            method = "onSlotClick",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;itemId:I",
                    opcode = Opcodes.GETFIELD,
                    ordinal = 0
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void stationapi_captureSecondItemStack(int clickType, int flag, boolean player, C_40996800 par4, CallbackInfoReturnable<C_88708284> cir, C_88708284 var5, C_87542771 var6, C_12356698 var12, C_88708284 var13, C_88708284 var14) {
        otherStationNBT = var14.getStationNbt();
    }

    @Unique
    private C_74087615 otherStationNBT;

    @Redirect(
            method = "onSlotClick",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;itemId:I",
                    opcode = Opcodes.GETFIELD,
                    ordinal = 0
            )
    )
    private int stationapi_continueStatement(C_88708284 instance) {
        if (Objects.equals(instance.getStationNbt(), otherStationNBT))
            return instance.f_59294634;
        else {
            notchGodDamnit = true;
            return Integer.MIN_VALUE;
        }
    }

    @Unique
    private boolean notchGodDamnit;

    @Redirect(
            method = "onSlotClick",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;itemId:I",
                    opcode = Opcodes.GETFIELD,
                    ordinal = 1
            )
    )
    private int stationapi_fixStackableNBTs(C_88708284 instance) {
        if (notchGodDamnit) {
            notchGodDamnit = false;
            return Integer.MAX_VALUE;
        } else
            return instance.f_59294634;
    }

    @Inject(
            method = "onSlotClick",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;itemId:I",
                    opcode = Opcodes.GETFIELD,
                    ordinal = 2
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void stationapi_captureFirstItemStack(int clickType, int flag, boolean player, C_40996800 par4, CallbackInfoReturnable<C_88708284> cir, C_88708284 var5, C_87542771 var6, C_12356698 var12, C_88708284 var13) {
        thisStationNBT = var13.getStationNbt();
    }

    @Unique
    private C_74087615 thisStationNBT;

    @Redirect(
            method = "onSlotClick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/item/ItemStack;getMaxCount()I",
                    ordinal = 2
            )
    )
    private int stationapi_cancelStatement(C_88708284 instance) {
        return Objects.equals(thisStationNBT, instance.getStationNbt()) ? instance.f_59294634 : 0;
    }

    @Redirect(
            method = "insertItem",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;itemId:I",
                    opcode = Opcodes.GETFIELD,
                    ordinal = 0
            )
    )
    private int stationapi_checkStatement(C_88708284 instance, C_88708284 arg, int i, int j, boolean flag) {
        if (Objects.equals(instance.getStationNbt(), arg.getStationNbt()))
            return instance.f_59294634;
        else
            return arg.f_59294634 - 1;
    }
}
