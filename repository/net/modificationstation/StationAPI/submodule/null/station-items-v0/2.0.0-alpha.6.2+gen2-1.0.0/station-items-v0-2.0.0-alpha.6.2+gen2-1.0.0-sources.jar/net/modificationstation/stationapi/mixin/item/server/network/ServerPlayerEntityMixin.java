package net.modificationstation.stationapi.mixin.item.server.network;

import net.minecraft.unmapped.C_21829382;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_75191757;
import net.minecraft.unmapped.C_78726810;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.impl.network.packet.s2c.play.StationEntityEquipmentUpdateS2CPacket;
import net.modificationstation.stationapi.impl.network.packet.s2c.play.StationInventoryS2CPacket;
import net.modificationstation.stationapi.impl.network.packet.s2c.play.StationScreenHandlerSlotUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;

@Mixin(C_49202226.class)
class ServerPlayerEntityMixin {
    @Redirect(
            method = "tick",
            at = @At(
                    value = "NEW",
                    target = "(IILnet/minecraft/item/ItemStack;)Lnet/minecraft/network/packet/s2c/play/EntityEquipmentUpdateS2CPacket;"
            )
    )
    private C_21829382 stationapi_redirectEntityEquipmentUpdatePacket(int entityId, int slot, C_88708284 stack) {
        return new StationEntityEquipmentUpdateS2CPacket(entityId, slot, stack);
    }

    @Redirect(
            method = {
                    "onSlotUpdate",
                    "onContentsUpdate(Lnet/minecraft/screen/ScreenHandler;Ljava/util/List;)V",
                    "updateCursorStack"
            },
            at = @At(
                    value = "NEW",
                    target = "(IILnet/minecraft/item/ItemStack;)Lnet/minecraft/network/packet/s2c/play/ScreenHandlerSlotUpdateS2CPacket;"
            )
    )
    private C_75191757 stationapi_redirectSlotUpdatePacket(int slot, int stack, C_88708284 itemStack) {
        return new StationScreenHandlerSlotUpdateS2CPacket(slot, stack, itemStack);
    }

    @Redirect(
            method = "onContentsUpdate(Lnet/minecraft/screen/ScreenHandler;Ljava/util/List;)V",
            at = @At(
                    value = "NEW",
                    target = "(ILjava/util/List;)Lnet/minecraft/network/packet/s2c/play/InventoryS2CPacket;"
            )
    )
    private C_78726810 stationapi_redirectInventoryPacket(int contents, List<C_88708284> list) {
        return new StationInventoryS2CPacket(contents, list);
    }
}
