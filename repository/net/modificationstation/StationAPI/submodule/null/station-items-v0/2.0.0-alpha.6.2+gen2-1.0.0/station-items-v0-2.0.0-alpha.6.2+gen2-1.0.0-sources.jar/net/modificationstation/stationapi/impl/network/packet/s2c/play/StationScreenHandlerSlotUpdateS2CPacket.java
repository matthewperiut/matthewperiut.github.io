package net.modificationstation.stationapi.impl.network.packet.s2c.play;

import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_75191757;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_97075175;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.api.network.packet.PacketType;
import net.modificationstation.stationapi.impl.item.StationNBTSetter;
import org.jetbrains.annotations.NotNull;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class StationScreenHandlerSlotUpdateS2CPacket extends C_75191757 implements ManagedPacket<StationScreenHandlerSlotUpdateS2CPacket> {
    public static final PacketType<StationScreenHandlerSlotUpdateS2CPacket> TYPE = PacketType.builder(true, false, StationScreenHandlerSlotUpdateS2CPacket::new).build();

    private StationScreenHandlerSlotUpdateS2CPacket() {}

    public StationScreenHandlerSlotUpdateS2CPacket(int syncId, int slot, C_88708284 stack) {
        super(syncId, slot, stack);
    }

    @Override
    public void m_13296744(DataInputStream stream) {
        try {
            this.f_02223463 = stream.readByte();
            this.f_20923223 = stream.readShort();
            short var2 = stream.readShort();
            if (var2 >= 0) {
                byte var3 = stream.readByte();
                short var4 = stream.readShort();
                this.f_00352698 = new C_88708284(var2, var3, var4);

                if (stream.readBoolean()) return;
                StationNBTSetter.cast(f_00352698).setStationNbt((C_74087615) C_97075175.m_46974369(stream));
            } else {
                this.f_00352698 = null;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_17566769(DataOutputStream stream) {
        try {
            stream.writeByte(this.f_02223463);
            stream.writeShort(this.f_20923223);
            if (this.f_00352698 == null) {
                stream.writeShort(-1);
            } else {
                stream.writeShort(this.f_00352698.f_59294634);
                stream.writeByte(this.f_00352698.f_60602012);
                stream.writeShort(this.f_00352698.m_21098843());

                C_74087615 stationNbt = f_00352698.getStationNbt();
                boolean empty = stationNbt.m_45469513().isEmpty();
                stream.writeBoolean(empty);
                if (empty) return;
                C_97075175.m_71107467(stationNbt, stream);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public @NotNull PacketType<StationScreenHandlerSlotUpdateS2CPacket> getType() {
        return TYPE;
    }
}
