package net.modificationstation.stationapi.mixin.item.server.network;

import net.minecraft.unmapped.C_75191757;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_99660737;
import net.modificationstation.stationapi.impl.network.packet.s2c.play.StationScreenHandlerSlotUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_99660737.class)
class ServerPlayNetworkHandlerMixin {
    @Redirect(
            method = "onPlayerInteractBlock",
            at = @At(
                    value = "NEW",
                    target = "(IILnet/minecraft/item/ItemStack;)Lnet/minecraft/network/packet/s2c/play/ScreenHandlerSlotUpdateS2CPacket;"
            )
    )
    private C_75191757 stationapi_redirectSlotUpdatePacket(int slot, int stack, C_88708284 itemStack) {
        return new StationScreenHandlerSlotUpdateS2CPacket(slot, stack, itemStack);
    }
}
