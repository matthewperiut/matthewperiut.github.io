package net.modificationstation.stationapi.mixin.item;

import net.minecraft.unmapped.C_62147686;
import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.block.StationBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(C_62147686.class)
public abstract class CropBlockMixin implements StationBlock {

    @Shadow public abstract void applyFullGrowth(C_64041439 world, int i, int j, int k);

    @Override
    public boolean onBonemealUse(C_64041439 world, int x, int y, int z, BlockState state) {
        if (!world.f_50876584) {
            applyFullGrowth(world, x, y, z); // Full grows crop.
        }
        return true;
    }
}
