package net.modificationstation.stationapi.mixin.item.client;

import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_82920792;
import net.minecraft.unmapped.C_84615110;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.event.render.item.ItemOverlayRenderEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_84615110.class)
class ItemRendererMixin {
    @Inject(
            method = "renderGuiItemDecoration",
            at = @At(value = "RETURN")
    )
    private void stationapi_fancyItemOverlays(C_23014920 arg, C_82920792 arg1, C_88708284 item, int i, int j, CallbackInfo ci) {
        //noinspection DataFlowIssue
        StationAPI.EVENT_BUS.post(
                ItemOverlayRenderEvent.builder()
                        .itemX(i).itemY(j)
                        .itemStack(item)
                        .textRenderer(arg)
                        .textureManager(arg1)
                        .itemRenderer((C_84615110) (Object) this)
                        .build()
        );
    }
}
