package net.modificationstation.stationapi.api.client.item;

import net.minecraft.unmapped.C_88708284;
import org.jetbrains.annotations.NotNull;

/**
 * Can be implemented on Items, BlockItems and Blocks.
 * BlockItems take precedence over Blocks if both have this implemented.
 */
public interface CustomTooltipProvider {

    /**
     * @return An array of Strings, each new array entry is a new line. Supports formatting codes.
     */
    @NotNull String[] getTooltip(C_88708284 stack, String originalTooltip);
}
