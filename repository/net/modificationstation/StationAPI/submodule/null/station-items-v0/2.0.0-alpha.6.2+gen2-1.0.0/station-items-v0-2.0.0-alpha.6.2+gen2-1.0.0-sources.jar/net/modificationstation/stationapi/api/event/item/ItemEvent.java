package net.modificationstation.stationapi.api.event.item;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_98888256;

@SuperBuilder
public abstract class ItemEvent extends Event {
    public final C_98888256 item;

    @SuperBuilder
    public static class TranslationKeyChanged extends ItemEvent {
        public String translationKeyOverride;
    }
}
