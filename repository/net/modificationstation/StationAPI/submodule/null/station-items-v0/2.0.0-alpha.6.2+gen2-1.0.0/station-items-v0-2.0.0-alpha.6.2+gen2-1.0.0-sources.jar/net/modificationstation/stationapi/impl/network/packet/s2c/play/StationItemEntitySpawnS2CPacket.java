package net.modificationstation.stationapi.impl.network.packet.s2c.play;

import net.minecraft.unmapped.C_06774341;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_91508932;
import net.minecraft.unmapped.C_97075175;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.api.network.packet.PacketType;
import net.modificationstation.stationapi.impl.network.StationItemsNetworkHandler;
import org.jetbrains.annotations.NotNull;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class StationItemEntitySpawnS2CPacket extends C_91508932 implements ManagedPacket<StationItemEntitySpawnS2CPacket> {
    public static final PacketType<StationItemEntitySpawnS2CPacket> TYPE = PacketType.builder(true, false, StationItemEntitySpawnS2CPacket::new).build();

    public C_74087615 stationNbt;

    private StationItemEntitySpawnS2CPacket() {}

    public StationItemEntitySpawnS2CPacket(C_06774341 itemEntity) {
        super(itemEntity);
        stationNbt = itemEntity.f_15367317.getStationNbt();
    }

    @Override
    public void m_13296744(DataInputStream stream) {
        super.m_13296744(stream);
        try {
            if (stream.readBoolean()) return;
            stationNbt = (C_74087615) C_97075175.m_46974369(stream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_17566769(DataOutputStream stream) {
        super.m_17566769(stream);
        boolean empty = stationNbt.m_45469513().isEmpty();
        try {
            stream.writeBoolean(empty);
            if (empty) return;
            C_97075175.m_71107467(stationNbt, stream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_04853589(C_10918870 networkHandler) {
        ((StationItemsNetworkHandler) networkHandler).onItemEntitySpawn(this);
    }

    @Override
    public @NotNull PacketType<StationItemEntitySpawnS2CPacket> getType() {
        return TYPE;
    }
}
