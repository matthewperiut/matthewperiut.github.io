package net.modificationstation.stationapi.impl.network.packet.c2s.play;

import net.minecraft.unmapped.C_18902094;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_97075175;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.api.network.packet.PacketType;
import net.modificationstation.stationapi.impl.item.StationNBTSetter;
import org.jetbrains.annotations.NotNull;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class StationPlayerInteractBlockC2SPacket extends C_18902094 implements ManagedPacket<StationPlayerInteractBlockC2SPacket> {
    public static final PacketType<StationPlayerInteractBlockC2SPacket> TYPE = PacketType.builder(false, true, StationPlayerInteractBlockC2SPacket::new).build();

    private StationPlayerInteractBlockC2SPacket() {}

    public StationPlayerInteractBlockC2SPacket(int x, int y, int z, int side, C_88708284 stack) {
        super(x, y, z, side, stack);
    }

    @Override
    public void m_13296744(DataInputStream stream) {
        super.m_13296744(stream);
        if (f_66913551 == null) return;
        try {
            if (stream.readBoolean()) return;
            StationNBTSetter.cast(f_66913551).setStationNbt((C_74087615) C_97075175.m_46974369(stream));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_17566769(DataOutputStream stream) {
        super.m_17566769(stream);
        if (f_66913551 == null) return;
        boolean empty = f_66913551.getStationNbt().m_45469513().isEmpty();
        try {
            stream.writeBoolean(empty);
            if (empty) return;
            C_97075175.m_71107467(f_66913551.getStationNbt(), stream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public @NotNull PacketType<StationPlayerInteractBlockC2SPacket> getType() {
        return TYPE;
    }
}
