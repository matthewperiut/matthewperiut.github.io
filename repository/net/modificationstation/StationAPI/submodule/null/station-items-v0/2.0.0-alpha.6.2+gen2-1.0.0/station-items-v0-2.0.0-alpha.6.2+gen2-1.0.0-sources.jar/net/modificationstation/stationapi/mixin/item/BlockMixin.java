package net.modificationstation.stationapi.mixin.item;

import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.block.StationItemsBlock;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(C_81592558.class)
class BlockMixin implements StationItemsBlock {

}
