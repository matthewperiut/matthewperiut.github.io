package net.modificationstation.stationapi.impl.entity.player;

import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.entity.player.PlayerEvent;
import net.modificationstation.stationapi.api.item.CustomReachProvider;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;

import java.lang.invoke.MethodHandles;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class ItemCustomReachImpl {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void getReach(PlayerEvent.Reach event) {
        C_88708284 stack = event.player.m_01577449();
        if (stack != null) {
            C_98888256 item = stack.m_23235460();
            if (item instanceof CustomReachProvider provider)
                event.currentReach = provider.getReach(stack, event.player, event.type, event.currentReach);
        }
    }
}