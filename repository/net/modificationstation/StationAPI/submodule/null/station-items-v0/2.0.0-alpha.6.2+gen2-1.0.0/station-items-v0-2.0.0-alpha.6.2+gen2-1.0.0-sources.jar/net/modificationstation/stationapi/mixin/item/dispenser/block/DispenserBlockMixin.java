package net.modificationstation.stationapi.mixin.item.dispenser.block;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalBooleanRef;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import net.minecraft.unmapped.C_63102660;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_75648698;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.dispenser.DispenseEvent;
import net.modificationstation.stationapi.api.dispenser.ItemDispenseContext;
import net.modificationstation.stationapi.impl.dispenser.DispenserInfoStorage;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

@Mixin(C_75648698.class)
class DispenserBlockMixin {
    @Inject(
            method = "dispense",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;itemId:I",
                    ordinal = 0
            ),
            cancellable = true
    )
    private void stationapi_dispatchDispenseEvent(
            C_64041439 world, int x, int y, int z, Random random, CallbackInfo ci,
            @Local(index = 11) C_63102660 dispenserBlockEntity, @Local(index = 12) LocalRef<C_88708284> dispensedStackRef,
            @Share("skipSpecial") LocalBooleanRef skipSpecialRef
    ) {
        int slot = DispenserInfoStorage.slot;
        ItemDispenseContext context = new ItemDispenseContext(dispensedStackRef.get(), dispenserBlockEntity, slot);

        if (StationAPI.EVENT_BUS.post(
                DispenseEvent.builder().context(context).build()
        ).isCanceled()) ci.cancel();

        dispensedStackRef.set(context.itemStack);
        skipSpecialRef.set(context.skipSpecial);
    }

    @WrapOperation(
            method = "dispense",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/Item;id:I"
            )
    )
    private int stationapi_skipSpecial(
            C_98888256 instance, Operation<Integer> original,
            @Local(index = 12) C_88708284 dispensedStackRef,
            @Share("skipSpecial") LocalBooleanRef skipSpecialRef
    ) {
        return skipSpecialRef.get() ? dispensedStackRef.f_59294634 + 1 : original.call(instance);
    }
}
