package net.modificationstation.stationapi.mixin.item.server;

import net.minecraft.unmapped.C_14230742;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.item.UseOnBlockFirst;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_14230742.class)
class class_70Mixin {
    @Shadow public C_40996800 player;

    @Inject(
            method = "interactBlock",
            at = @At("HEAD"),
            cancellable = true
    )
    private void stationapi_injectOnPlaceBlock(C_40996800 playerBase, C_64041439 world, C_88708284 stack, int i, int j, int k, int i1, CallbackInfoReturnable<Boolean> cir) {
        if (stack != null && stack.m_23235460() instanceof UseOnBlockFirst use && use.onUseOnBlockFirst(stack, playerBase, world, i, j, k, i1))
            cir.setReturnValue(true);
    }

    @Inject(
            method = "onBlockBreakingAction",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/ServerWorld;getBlockId(III)I"
            ),
            cancellable = true
    )
    public void stationapi_onBlockBreakingAction_preMine(int x, int y, int z, int side, CallbackInfo ci){
        C_88708284 stack = this.player.f_29439708.m_27760697();
        if (stack != null && !stack.preMine(this.player.f_94306729.getBlockState(x, y, z), x, y, z, side, this.player))
            ci.cancel();
    }
}
