package net.modificationstation.stationapi.mixin.item;

import net.minecraft.unmapped.C_95106612;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.registry.AfterBlockAndItemRegisterEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_95106612.class)
class StatsMixin {
    @Inject(
            method = "initializeCraftedItemStats",
            at = @At(
                    value = "NEW",
                    target = "()Ljava/util/HashSet;",
                    shift = At.Shift.BEFORE
            )
    )
    private static void stationapi_afterBlockAndItemRegister(CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(AfterBlockAndItemRegisterEvent.builder().build());
    }
}
