package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.api.util.Namespace;
import net.modificationstation.stationapi.api.util.Util;

public interface StationItem {
    default C_98888256 setTranslationKey(Namespace namespace, String translationKey) {
        return Util.assertImpl();
    }

    default C_98888256 setTranslationKey(Identifier translationKey) {
        return setTranslationKey(translationKey.namespace, translationKey.path);
    }

    default boolean preHit(C_88708284 stack, C_42232651 otherEntity, C_40996800 player) {
        return Util.assertImpl();
    }

    default boolean preMine(C_88708284 stack, BlockState blockState, int x, int y, int z, int side, C_40996800 player) {
        return Util.assertImpl();
    }

    default int getMaxDamage(C_88708284 stack) {
        return Util.assertImpl();
    }
}
