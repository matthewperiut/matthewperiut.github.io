package net.modificationstation.stationapi.impl.network.packet.s2c.play;

import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_78726810;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_97075175;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.api.network.packet.PacketType;
import net.modificationstation.stationapi.impl.item.StationNBTSetter;
import org.jetbrains.annotations.NotNull;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.List;

public class StationInventoryS2CPacket extends C_78726810 implements ManagedPacket<StationInventoryS2CPacket> {
    public static final PacketType<StationInventoryS2CPacket> TYPE = PacketType.builder(true, false, StationInventoryS2CPacket::new).build();

    private StationInventoryS2CPacket() {}

    public StationInventoryS2CPacket(int syncId, List<C_88708284> contents) {
        super(syncId, contents);
    }

    @Override
    public void m_13296744(DataInputStream stream) {
        try {
            this.f_46606448 = stream.readByte();
            int n = stream.readShort();
            this.f_36613003 = new C_88708284[n];
            for (int i = 0; i < n; ++i) {
                short s = stream.readShort();
                if (s < 0) continue;
                byte by = stream.readByte();
                short s2 = stream.readShort();
                C_88708284 stack = new C_88708284(s, by, s2);

                if (!stream.readBoolean())
                    StationNBTSetter.cast(stack).setStationNbt((C_74087615) C_97075175.m_46974369(stream));

                this.f_36613003[i] = stack;
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_17566769(DataOutputStream stream) {
        try {
            stream.writeByte(this.f_46606448);
            stream.writeShort(this.f_36613003.length);
            for (int i = 0; i < this.f_36613003.length; ++i) {
                C_88708284 stack = this.f_36613003[i];
                if (stack == null) {
                    stream.writeShort(-1);
                    continue;
                }
                stream.writeShort((short) stack.f_59294634);
                stream.writeByte((byte) stack.f_60602012);
                stream.writeShort((short) stack.m_21098843());

                C_74087615 stationNbt = stack.getStationNbt();
                boolean empty = stationNbt.m_45469513().isEmpty();
                stream.writeBoolean(empty);
                if (empty) continue;
                C_97075175.m_71107467(stationNbt, stream);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public @NotNull PacketType<StationInventoryS2CPacket> getType() {
        return TYPE;
    }
}
