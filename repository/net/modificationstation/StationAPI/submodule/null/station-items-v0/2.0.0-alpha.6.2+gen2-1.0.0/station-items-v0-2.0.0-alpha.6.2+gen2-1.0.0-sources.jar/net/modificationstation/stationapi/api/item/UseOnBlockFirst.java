package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;

public interface UseOnBlockFirst {
    boolean onUseOnBlockFirst(C_88708284 stack, C_40996800 player, C_64041439 world, int x, int y, int z, int sideClicked);
}
