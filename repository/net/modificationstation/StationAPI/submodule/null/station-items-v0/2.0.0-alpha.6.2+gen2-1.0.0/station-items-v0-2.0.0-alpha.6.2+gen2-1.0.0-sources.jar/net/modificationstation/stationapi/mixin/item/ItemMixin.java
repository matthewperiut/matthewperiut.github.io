package net.modificationstation.stationapi.mixin.item;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.event.item.ItemEvent;
import net.modificationstation.stationapi.api.item.StationItem;
import net.modificationstation.stationapi.api.util.Namespace;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(C_98888256.class)
abstract class ItemMixin implements StationItem {
    @Mutable
    @Shadow @Final public int id;

    @Shadow public abstract C_98888256 setTranslationKey(String string);

    @Shadow public abstract int getMaxDamage();

    @ModifyVariable(
            method = "setTranslationKey(Ljava/lang/String;)Lnet/minecraft/item/Item;",
            at = @At("HEAD"),
            argsOnly = true
    )
    private String stationapi_getName(String name) {
        return StationAPI.EVENT_BUS.post(
                ItemEvent.TranslationKeyChanged.builder()
                        .item(C_98888256.class.cast(this))
                        .translationKeyOverride(name)
                        .build()
        ).translationKeyOverride;
    }

    @Override
    @Unique
    public C_98888256 setTranslationKey(Namespace namespace, String translationKey) {
        return setTranslationKey(namespace + "." + translationKey);
    }

    @Override
    @Unique
    public boolean preHit(C_88708284 stack, C_42232651 otherEntity, C_40996800 player) {
        return true;
    }

    @Override
    @Unique
    public boolean preMine(C_88708284 stack, BlockState blockState, int x, int y, int z, int side, C_40996800 player) {
        return true;
    }

    @Override
    @Unique
    public int getMaxDamage(C_88708284 stack) {
        return getMaxDamage();
    }
}
