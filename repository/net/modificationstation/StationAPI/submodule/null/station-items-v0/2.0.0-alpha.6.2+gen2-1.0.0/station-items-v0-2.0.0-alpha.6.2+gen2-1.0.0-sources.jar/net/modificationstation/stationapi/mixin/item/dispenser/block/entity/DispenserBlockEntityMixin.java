package net.modificationstation.stationapi.mixin.item.dispenser.block.entity;

import net.minecraft.unmapped.C_63102660;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.impl.dispenser.DispenserInfoStorage;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_63102660.class)
class DispenserBlockEntityMixin {
    @Shadow
    private C_88708284[] inventory;

    @Inject(method = "removeStack", at = @At("HEAD"))
    private void stationapi_customDispenserCaptureInventoryAndSlot(int slot, int amt, CallbackInfoReturnable<C_88708284> cir) {
        DispenserInfoStorage.slot = slot;
    }
}
