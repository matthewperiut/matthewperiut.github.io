package net.modificationstation.stationapi.mixin.item;

import net.minecraft.unmapped.C_78726810;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(C_78726810.class)
class InventoryS2CPacketMixin {

}
