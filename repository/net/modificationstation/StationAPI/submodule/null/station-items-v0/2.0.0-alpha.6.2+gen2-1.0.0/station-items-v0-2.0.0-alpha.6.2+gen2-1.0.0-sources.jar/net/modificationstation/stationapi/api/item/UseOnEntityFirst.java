package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;

public interface UseOnEntityFirst {
    boolean onUseOnEntityFirst(C_88708284 stack, C_40996800 player, C_64041439 world, C_42232651 entity);
}
