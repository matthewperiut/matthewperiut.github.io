package net.modificationstation.stationapi.impl.network;

import net.minecraft.unmapped.C_10918870;
import net.modificationstation.stationapi.impl.network.packet.s2c.play.StationEntityEquipmentUpdateS2CPacket;
import net.modificationstation.stationapi.impl.network.packet.s2c.play.StationItemEntitySpawnS2CPacket;

public abstract class StationItemsNetworkHandler extends C_10918870 {
    public void onItemEntitySpawn(StationItemEntitySpawnS2CPacket packet) {
        m_10633301(packet);
    }

    public void onEntityEquipmentUpdate(StationEntityEquipmentUpdateS2CPacket packet) {
        m_10633301(packet);
    }
}
