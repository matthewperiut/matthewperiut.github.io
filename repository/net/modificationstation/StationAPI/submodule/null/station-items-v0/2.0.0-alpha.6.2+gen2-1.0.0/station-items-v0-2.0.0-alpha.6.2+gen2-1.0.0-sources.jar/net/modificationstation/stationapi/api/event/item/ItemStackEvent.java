package net.modificationstation.stationapi.api.event.item;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;

@SuperBuilder
public abstract class ItemStackEvent extends Event {
    public final C_88708284 itemStack;

    @SuperBuilder
    public static class Crafted extends ItemStackEvent {
        public final C_64041439 world;
        public final C_40996800 player;
    }
}
