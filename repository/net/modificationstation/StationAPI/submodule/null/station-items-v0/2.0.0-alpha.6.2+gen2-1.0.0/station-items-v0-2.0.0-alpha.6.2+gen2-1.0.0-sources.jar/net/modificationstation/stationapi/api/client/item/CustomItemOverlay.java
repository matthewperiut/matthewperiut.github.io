package net.modificationstation.stationapi.api.client.item;

import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_82920792;
import net.minecraft.unmapped.C_84615110;
import net.minecraft.unmapped.C_88708284;

public interface CustomItemOverlay {
    void renderItemOverlay(C_84615110 itemRenderer, int itemX, int itemY, C_88708284 stack, C_23014920 textRenderer, C_82920792 textureManager);
}
