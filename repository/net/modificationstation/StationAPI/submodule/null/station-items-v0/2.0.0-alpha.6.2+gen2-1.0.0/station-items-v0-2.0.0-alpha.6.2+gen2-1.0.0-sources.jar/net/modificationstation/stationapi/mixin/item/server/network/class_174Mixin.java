package net.modificationstation.stationapi.mixin.item.server.network;

import net.minecraft.unmapped.C_06774341;
import net.minecraft.unmapped.C_21829382;
import net.minecraft.unmapped.C_77505663;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_91508932;
import net.modificationstation.stationapi.impl.network.packet.s2c.play.StationEntityEquipmentUpdateS2CPacket;
import net.modificationstation.stationapi.impl.network.packet.s2c.play.StationItemEntitySpawnS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_77505663.class)
class class_174Mixin {
    @Redirect(
            method = "updateListener",
            at = @At(
                    value = "NEW",
                    target = "(IILnet/minecraft/item/ItemStack;)Lnet/minecraft/network/packet/s2c/play/EntityEquipmentUpdateS2CPacket;"
            )
    )
    private C_21829382 stationapi_redirectEntityEquipmentUpdatePacket(int entityId, int slot, C_88708284 stack) {
        return new StationEntityEquipmentUpdateS2CPacket(entityId, slot, stack);
    }

    @Redirect(
            method = "createAddEntityPacket",
            at = @At(
                    value = "NEW",
                    target = "(Lnet/minecraft/entity/ItemEntity;)Lnet/minecraft/network/packet/s2c/play/ItemEntitySpawnS2CPacket;"
            )
    )
    private C_91508932 stationapi_redirectItemEntitySpawnPacket(C_06774341 itemEntity) {
        return new StationItemEntitySpawnS2CPacket(itemEntity);
    }
}
