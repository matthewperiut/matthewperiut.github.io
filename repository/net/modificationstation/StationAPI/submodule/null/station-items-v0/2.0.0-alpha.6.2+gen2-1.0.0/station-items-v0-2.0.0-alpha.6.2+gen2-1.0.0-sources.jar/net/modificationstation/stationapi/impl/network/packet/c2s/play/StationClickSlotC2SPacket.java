package net.modificationstation.stationapi.impl.network.packet.c2s.play;

import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_88033048;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_97075175;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.api.network.packet.PacketType;
import net.modificationstation.stationapi.impl.item.StationNBTSetter;
import org.jetbrains.annotations.NotNull;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class StationClickSlotC2SPacket extends C_88033048 implements ManagedPacket<StationClickSlotC2SPacket> {
    public static final PacketType<StationClickSlotC2SPacket> TYPE = PacketType.builder(false, true, StationClickSlotC2SPacket::new).build();

    private StationClickSlotC2SPacket() {}

    public StationClickSlotC2SPacket(int syncId, int slot, int button, boolean holdingShift, C_88708284 stack, short actionType) {
        super(syncId, slot, button, holdingShift, stack, actionType);
    }

    @Override
    public void m_13296744(DataInputStream stream) {
        super.m_13296744(stream);
        if (f_25060990 == null) return;
        try {
            if (stream.readBoolean()) return;
            StationNBTSetter.cast(f_25060990).setStationNbt((C_74087615) C_97075175.m_46974369(stream));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_17566769(DataOutputStream stream) {
        super.m_17566769(stream);
        if (f_25060990 == null) return;
        boolean empty = f_25060990.getStationNbt().m_45469513().isEmpty();
        try {
            stream.writeBoolean(empty);
            if (empty) return;
            C_97075175.m_71107467(f_25060990.getStationNbt(), stream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public @NotNull PacketType<StationClickSlotC2SPacket> getType() {
        return TYPE;
    }
}
