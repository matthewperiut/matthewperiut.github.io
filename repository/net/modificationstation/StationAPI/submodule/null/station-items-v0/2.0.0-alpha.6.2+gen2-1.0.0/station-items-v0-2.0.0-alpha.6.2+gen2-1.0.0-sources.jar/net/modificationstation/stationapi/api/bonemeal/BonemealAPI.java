package net.modificationstation.stationapi.api.bonemeal;

import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.minecraft.unmapped.C_30339133;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.tag.TagKey;
import net.modificationstation.stationapi.api.util.collection.WeightedList;
import net.modificationstation.stationapi.api.util.math.Direction;

import java.util.Map;
import java.util.Random;

public class BonemealAPI {
    private static final Map<TagKey<C_81592558>, WeightedList<C_30339133>> PLACERS_TAG = new Reference2ObjectOpenHashMap<>();
    private static final Map<BlockState, WeightedList<C_30339133>> PLACERS_BLOCK = new Reference2ObjectOpenHashMap<>();
    private static final WeightedList<C_30339133> CACHE = new WeightedList<>();

    public static void addPlant(BlockState ground, BlockState plant, int weight) {
        addPlant(ground, new SimpleStateFeature(plant), weight);
    }

    public static void addPlant(BlockState ground, C_30339133 plant, int weight) {
        PLACERS_BLOCK.computeIfAbsent(ground, g -> new WeightedList<>()).add(plant, weight);
    }

    public static void addPlant(TagKey<C_81592558> ground, BlockState plant, int weight) {
        addPlant(ground, new SimpleStateFeature(plant), weight);
    }

    public static void addPlant(TagKey<C_81592558> ground, C_30339133 plant, int weight) {
        PLACERS_TAG.computeIfAbsent(ground, g -> new WeightedList<>()).add(plant, weight);
    }

    public static boolean generate(C_64041439 world, int x, int y, int z, BlockState state, int side) {
        updateCache(state);
        if (CACHE.isEmpty()) return false;
        Random random = world.f_33453426;
        Direction offset = Direction.byId(side);
        CACHE.get(random).m_85015587(
                world,
                random,
                x + offset.getOffsetX(),
                y + offset.getOffsetY(),
                z + offset.getOffsetZ()
        );
        for (byte i = 0; i < 127; i++) {
            int px = x + random.nextInt(7) - 3;
            int py = y + random.nextInt(5) - 2;
            int pz = z + random.nextInt(7) - 3;
            state = world.getBlockState(px, py, pz);
            updateCache(state);
            if (CACHE.isEmpty()) continue;
            CACHE.get(random).m_85015587(world, random, px, py + 1, pz);
        }
        return true;
    }

    private static void updateCache(BlockState state) {
        CACHE.clear();
        WeightedList<C_30339133> structures = PLACERS_BLOCK.get(state);
        if (structures != null) CACHE.addAll(structures);
        state.streamTags().forEach(tag -> {
            WeightedList<C_30339133> tagStructures = PLACERS_TAG.get(tag);
            if (tagStructures != null) CACHE.addAll(tagStructures);
        });
    }

    private static class SimpleStateFeature extends C_30339133 {
        private final BlockState state;

        private SimpleStateFeature(BlockState state) {
            this.state = state;
        }

        @Override
        public boolean m_85015587(C_64041439 world, Random random, int x, int y, int z) {
            BlockState worldState = world.getBlockState(x, y, z);
            if (!worldState.isAir()) return false;
            if (state.getBlock().m_29306917(world, x, y, z)) {
                if (!world.f_50876584) {
                    world.setBlockStateWithoutNotifyingNeighbors(x, y, z, state);
                }
                return true;
            }
            return false;
        }
    }

    private static class GrassFeature extends C_30339133 {
        private static final BlockState STATE = C_81592558.f_83907852.getDefaultState();

        @Override
        public boolean m_85015587(C_64041439 world, Random random, int x, int y, int z) {
            BlockState worldState = world.getBlockState(x, y, z);
            if (!worldState.isAir()) return false;
            if (STATE.getBlock().m_29306917(world, x, y, z)) {
                if (!world.f_50876584) {
                    world.setBlockStateWithoutNotifyingNeighbors(x, y, z, STATE);
                    world.m_38188749(x, y, z, 1);
                }
                return true;
            }
            return false;
        }
    }

    static {
        BlockState grass = C_81592558.f_41096518.getDefaultState();
        addPlant(grass, new GrassFeature(), 10);
        addPlant(grass, C_81592558.f_38977206.getDefaultState(), 1);
        addPlant(grass, C_81592558.f_72900486.getDefaultState(), 1);
    }
}
