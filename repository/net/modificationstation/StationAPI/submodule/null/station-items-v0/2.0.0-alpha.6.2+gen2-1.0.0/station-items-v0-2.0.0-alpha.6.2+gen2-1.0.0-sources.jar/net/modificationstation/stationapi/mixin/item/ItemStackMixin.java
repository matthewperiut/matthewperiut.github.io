package net.modificationstation.stationapi.mixin.item;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.event.item.ItemStackEvent;
import net.modificationstation.stationapi.api.item.StationItemStack;
import net.modificationstation.stationapi.impl.item.StationNBTSetter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Objects;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;
import static net.modificationstation.stationapi.api.util.Identifier.of;

@Mixin(C_88708284.class)
abstract class ItemStackMixin implements StationItemStack, StationNBTSetter {
    @Shadow
    public int itemId;

    @Shadow public abstract C_98888256 getItem();

    @Inject(
            method = "onCraft",
            at = @At("RETURN")
    )
    private void stationapi_onCreation(C_64041439 arg, C_40996800 arg1, CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(
                ItemStackEvent.Crafted.builder()
                        .itemStack(C_88708284.class.cast(this))
                        .world(arg)
                        .player(arg1)
                        .build()
        );
    }

    @Unique
    private C_74087615 stationapi_stationNbt = new C_74087615();

    @Inject(
            method = "split",
            at = @At("RETURN")
    )
    private void stationapi_setSplitStackNbt(int par1, CallbackInfoReturnable<C_88708284> cir) {
        if (!stationapi_stationNbt.m_45469513().isEmpty())
            StationNBTSetter.cast(cir.getReturnValue()).setStationNbt(stationapi_stationNbt.copy());
    }

    @Inject(
            method = "writeNbt",
            at = @At("RETURN")
    )
    private void stationapi_toTagCustom(C_74087615 par1, CallbackInfoReturnable<C_74087615> cir) {
        if (!stationapi_stationNbt.m_45469513().isEmpty())
            cir.getReturnValue().m_18682924(of(NAMESPACE, "item_nbt").toString(), stationapi_stationNbt);
    }

    @Inject(
            method = "readNbt",
            at = @At("RETURN")
    )
    private void stationapi_fromTagCustom(C_74087615 par1, CallbackInfo ci) {
        stationapi_stationNbt = par1.m_81819352(of(NAMESPACE, "item_nbt").toString());
    }

    @Inject(
            method = "copy",
            at = @At("RETURN")
    )
    private void stationapi_copy(CallbackInfoReturnable<C_88708284> cir) {
        if (!stationapi_stationNbt.m_45469513().isEmpty())
            StationNBTSetter.cast(cir.getReturnValue()).setStationNbt(stationapi_stationNbt.copy());
    }

    @Inject(
            method = "equals2",
            at = @At("HEAD"),
            cancellable = true
    )
    private void stationapi_isStackIdentical(C_88708284 par1, CallbackInfoReturnable<Boolean> cir) {
        if (!Objects.equals(stationapi_stationNbt, par1.getStationNbt()))
            cir.setReturnValue(false);
    }

    @Inject(
            method = "isItemEqual",
            at = @At("HEAD"),
            cancellable = true
    )
    private void stationapi_isDamageAndIDIdentical(C_88708284 par1, CallbackInfoReturnable<Boolean> cir) {
        if (!Objects.equals(stationapi_stationNbt, par1.getStationNbt()))
            cir.setReturnValue(false);
    }

    @Inject(
            method = "toString",
            at = @At("RETURN"),
            cancellable = true
    )
    private void stationapi_toStringNBT(CallbackInfoReturnable<String> cir) {
        cir.setReturnValue(cir.getReturnValue() + ", stationNBT=[" + stationapi_stationNbt + "]");
    }

    @Inject(
            method = "equals",
            at = @At("HEAD"),
            cancellable = true
    )
    private void stationapi_isStackIdentical2(C_88708284 par1, CallbackInfoReturnable<Boolean> cir) {
        if (!Objects.equals(stationapi_stationNbt, par1.getStationNbt()))
            cir.setReturnValue(false);
    }

    @Override
    @Unique
    public boolean preHit(C_42232651 otherEntity, C_40996800 player) {
        return getItem().preHit(C_88708284.class.cast(this), otherEntity, player);
    }

    @Override
    @Unique
    public boolean preMine(BlockState blockState, int x, int y, int z, int side, C_40996800 player) {
        return getItem().preMine(C_88708284.class.cast(this), blockState, x, y, z, side, player);
    }

    @Redirect(
            method = "getMaxDamage",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/item/Item;getMaxDamage()I"
            )
    )
    private int stationapi_getDurabilityPerStack(C_98888256 instance) {
        return instance.getMaxDamage(C_88708284.class.cast(this));
    }

    @Redirect(
            method = "isDamageable",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/item/Item;getMaxDamage()I"
            )
    )
    private int stationapi_hasDurability_getDurabilityPerStack(C_98888256 instance) {
        return instance.getMaxDamage(C_88708284.class.cast(this));
    }

    @Override
    @Unique
    public C_74087615 getStationNbt() {
        return this.stationapi_stationNbt;
    }

    @Override
    @Unique
    public void setStationNbt(C_74087615 stationNbt) {
        this.stationapi_stationNbt = stationNbt;
    }
}
