package net.modificationstation.stationapi.api.client;

import net.minecraft.unmapped.C_71827890;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_87711245;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.event.gui.screen.container.TooltipBuildEvent;
import net.modificationstation.stationapi.api.client.item.CustomTooltipProvider;

import java.util.*;

public class TooltipHelper {

    /**
     * Public helper that returns the whole
     */
    public static ArrayList<String> getTooltipForItemStack(String originalTooltip, C_88708284 itemStack, C_87542771 playerInventory, C_87711245 container) {
        ArrayList<String> newTooltip;
        CustomTooltipProvider provider = null;

        if (itemStack.m_23235460() instanceof CustomTooltipProvider itemProvider) {
            provider = itemProvider;
        }
        else if (itemStack.m_23235460() instanceof C_71827890 blockItem && blockItem.getBlock() instanceof CustomTooltipProvider blockProvider) {
            provider = blockProvider;
        }

        if (provider != null) {
            newTooltip = new ArrayList<>(Arrays.asList(provider.getTooltip(itemStack, originalTooltip)));
        }
        else {
            newTooltip = new ArrayList<>(){{add(originalTooltip);}};
        }

        StationAPI.EVENT_BUS.post(TooltipBuildEvent.builder()
                .tooltip(newTooltip)
                .inventory(playerInventory)
                .container(container)
                .itemStack(itemStack)
                .build()
        );

        return newTooltip;
    }
}
