package net.modificationstation.stationapi.mixin.item.client;

import net.minecraft.unmapped.C_34267874;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.item.UseOnBlockFirst;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_34267874.class)
class InteractionManagerMixin {
    @Inject(
            method = "interactBlock",
            at = @At("HEAD"),
            cancellable = true
    )
    private void stationapi_injectOnPlaceBlock(C_40996800 playerBase, C_64041439 world, C_88708284 stack, int i, int j, int k, int i1, CallbackInfoReturnable<Boolean> cir) {
        if (stack != null && stack.m_23235460() instanceof UseOnBlockFirst use && use.onUseOnBlockFirst(stack, playerBase, world, i, j, k, i1))
            cir.setReturnValue(true);
    }
}
