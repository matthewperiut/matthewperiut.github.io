package net.modificationstation.stationapi.api.entity;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.util.Util;

public interface StationItemsEntity {
    @Environment(EnvType.CLIENT)
    default void equipStack(int slot, C_88708284 stack) {
        Util.assertImpl();
    }
}
