package net.modificationstation.stationapi.mixin.item;

import net.minecraft.unmapped.C_34225397;
import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.block.StationBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

import java.util.Random;

@Mixin(C_34225397.class)
public abstract class SaplingBlockMixin implements StationBlock {
    @Shadow public abstract void generate(C_64041439 world, int x, int y, int z, Random random);

    @Override
    public boolean onBonemealUse(C_64041439 world, int x, int y, int z, BlockState state) {
        if (!world.f_50876584) {
            generate(world, x, y, z, world.f_33453426);
        }
        return true;
    }
}
