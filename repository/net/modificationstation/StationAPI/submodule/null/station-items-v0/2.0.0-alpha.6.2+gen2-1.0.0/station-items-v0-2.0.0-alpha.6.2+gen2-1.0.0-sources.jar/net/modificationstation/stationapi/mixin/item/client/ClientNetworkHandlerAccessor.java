package net.modificationstation.stationapi.mixin.item.client;

import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_88014908;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_88014908.class)
public interface ClientNetworkHandlerAccessor {
    @Invoker("getEntity")
    C_42232651 stationapi_getEntity(int entityId);
}
