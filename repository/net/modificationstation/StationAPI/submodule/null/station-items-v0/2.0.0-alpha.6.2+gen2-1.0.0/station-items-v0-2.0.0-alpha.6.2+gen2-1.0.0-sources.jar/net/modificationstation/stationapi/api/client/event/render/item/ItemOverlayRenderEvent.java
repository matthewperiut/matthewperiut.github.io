package net.modificationstation.stationapi.api.client.event.render.item;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.mine_diver.unsafeevents.event.EventPhases;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_82920792;
import net.minecraft.unmapped.C_84615110;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.StationAPI;

@SuperBuilder
@EventPhases(StationAPI.INTERNAL_PHASE)
public class ItemOverlayRenderEvent extends Event {
    public final int itemX, itemY;
    public final C_88708284 itemStack;
    public final C_23014920 textRenderer;
    public final C_82920792 textureManager;
    public final C_84615110 itemRenderer;
}
