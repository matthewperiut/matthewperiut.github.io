package net.modificationstation.stationapi.mixin.item.client;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_54810664;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_54810664.class)
abstract class OtherPlayerEntityMixin extends C_40996800 {
    private OtherPlayerEntityMixin(C_64041439 world) {
        super(world);
    }

    @SuppressWarnings("AddedMixinMembersNamePattern")
    @Override
    @Unique
    public void equipStack(int slot, C_88708284 stack) {
        if (slot == 0) this.f_29439708.f_35249023[this.f_29439708.f_13682807] = stack;
        else this.f_29439708.f_52412003[slot - 1] = stack;
    }
}
