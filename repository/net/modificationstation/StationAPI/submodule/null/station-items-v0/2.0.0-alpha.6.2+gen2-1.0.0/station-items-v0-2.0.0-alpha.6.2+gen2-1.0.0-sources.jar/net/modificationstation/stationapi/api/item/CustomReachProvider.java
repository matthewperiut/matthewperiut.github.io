package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_88708284;

public interface CustomReachProvider {
    double getReach(C_88708284 stack, C_40996800 player, C_24654288.net/minecraft/unmapped/C_25850426 type, double currentReach);
}
