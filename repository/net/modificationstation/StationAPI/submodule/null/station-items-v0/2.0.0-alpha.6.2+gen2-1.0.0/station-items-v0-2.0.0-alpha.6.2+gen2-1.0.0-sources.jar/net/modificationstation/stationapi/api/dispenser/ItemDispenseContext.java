package net.modificationstation.stationapi.api.dispenser;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_63102660;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.item.CustomDispenseBehavior;
import net.modificationstation.stationapi.api.util.math.Direction;
import net.modificationstation.stationapi.mixin.item.EntityAccessor;

import java.util.Random;

/**
 * Utility class for changing dispenser behavior, providing tools to customize behavior
 * @author matthewperiut
 * @see DispenseEvent
 * @see CustomDispenseBehavior
 */
public class ItemDispenseContext {
    public final C_63102660 dispenser;
    public final int slot;
    public final Direction direction;
    public C_88708284 itemStack;
    /**
     * Skips special vanilla behavior for arrows, snowballs and eggs.
     */
    public boolean skipSpecial;

    public ItemDispenseContext(C_88708284 itemStack, C_63102660 dispenser, int slot) {
        this.dispenser = dispenser;
        this.itemStack = itemStack;
        this.slot = slot;
        direction = Direction.byId(dispenser.f_18133822.m_06541281(dispenser.f_07118142, dispenser.f_33969464, dispenser.f_77944174));
    }

    public static void genericShootEntity(C_42232651 entity, double velX, double velY, double velZ, float pitch, float yaw) {
        float var9 = C_45510667.m_14578936(velX * velX + velY * velY + velZ * velZ);
        velX /= var9;
        velY /= var9;
        velZ /= var9;
        Random random = ((EntityAccessor) entity).stationapi_getRandom();
        velX += random.nextGaussian() * 0.007499999832361937 * yaw;
        velY += random.nextGaussian() * 0.007499999832361937 * yaw;
        velZ += random.nextGaussian() * 0.007499999832361937 * yaw;
        velX *= pitch;
        velY *= pitch;
        velZ *= pitch;
        entity.f_24826402 = velX;
        entity.f_35148123 = velY;
        entity.f_21201587 = velZ;
        float var10 = C_45510667.m_14578936(velX * velX + velZ * velZ);
        entity.f_74900774 = entity.f_80130373 = (float) (Math.atan2(velX, velZ) * 180.0 / 3.1415927410125732);
        entity.f_45219594 = entity.f_03549461 = (float) (Math.atan2(velY, var10) * 180.0 / 3.1415927410125732);
    }

    public interface ShootEntityFunction {
        void shoot(C_42232651 entity, double velX, double velY, double velZ, float pitch, float yaw);
    }

    public void shootEntity(C_42232651 entity) {
        shootEntity(entity, ItemDispenseContext::genericShootEntity);
    }

    public void shootEntity(C_42232651 entity, ShootEntityFunction shootFunc) {
        entity.m_70517412(dispenser.f_07118142 + 0.5, dispenser.f_33969464 + 0.5, dispenser.f_77944174 + 0.5);
        shootFunc.shoot(entity, direction.getOffsetX(), direction.getOffsetY() + 0.1, direction.getOffsetZ(), 1.1F, 6.0F);
        dispenser.f_18133822.m_09670988(entity);
        dispenser.f_18133822.m_80788745(1002, dispenser.f_07118142, dispenser.f_33969464, dispenser.f_77944174, 0);
        dispenser.f_18133822.m_80788745(2000, dispenser.f_07118142, dispenser.f_33969464, dispenser.f_77944174, direction.getOffsetX() + 1 + (direction.getOffsetZ() + 1) * 3);
    }

    public C_32594356 getFacingBlockPos() {
        return new C_32594356(dispenser.f_07118142, dispenser.f_33969464, dispenser.f_77944174).add(direction.getVector());
    }
}
