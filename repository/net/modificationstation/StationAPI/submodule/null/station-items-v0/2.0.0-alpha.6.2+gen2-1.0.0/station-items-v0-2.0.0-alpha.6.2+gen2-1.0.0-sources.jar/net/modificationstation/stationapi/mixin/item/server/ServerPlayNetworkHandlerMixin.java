package net.modificationstation.stationapi.mixin.item.server;

import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_99660737;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.entity.player.PlayerEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(C_99660737.class)
class ServerPlayNetworkHandlerMixin {
    @Shadow
    private C_49202226 player;

    @ModifyConstant(
            method = "handlePlayerAction",
            constant = @Constant(doubleValue = 36)
    )
    private double stationapi_getBlockReach(double originalReach) {
        return Math.pow(StationAPI.EVENT_BUS.post(
                PlayerEvent.Reach.builder()
                        .player(player)
                        .type(C_24654288.net/minecraft/unmapped/C_25850426.f_13890456)
                        .currentReach(Math.sqrt(originalReach))
                        .build()
        ).currentReach, 2);
    }

    @ModifyConstant(
            method = "handleInteractEntity",
            constant = @Constant(doubleValue = 36)
    )
    private double stationapi_getEntityReach(double originalReach) {
        return Math.pow(StationAPI.EVENT_BUS.post(
                PlayerEvent.Reach.builder()
                        .player(player)
                        .type(C_24654288.net/minecraft/unmapped/C_25850426.f_19478796)
                        .currentReach(Math.sqrt(originalReach))
                        .build()
        ).currentReach, 2);
    }
}
