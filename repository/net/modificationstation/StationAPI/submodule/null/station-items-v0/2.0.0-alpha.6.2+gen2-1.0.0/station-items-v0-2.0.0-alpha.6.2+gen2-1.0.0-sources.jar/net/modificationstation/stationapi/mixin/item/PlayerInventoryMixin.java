package net.modificationstation.stationapi.mixin.item;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.impl.item.StationNBTSetter;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Objects;

@Mixin(C_87542771.class)
class PlayerInventoryMixin {
    @Shadow
    public C_88708284[] main;

    @WrapOperation(
            method = "combineStacks",
            at = @At(
                    value = "NEW",
                    target = "(III)Lnet/minecraft/item/ItemStack;"
            )
    )
    private C_88708284 stationapi_newItemStack(
            int id, int count, int damage, Operation<C_88708284> original,
            @Local(index = 1, argsOnly = true) C_88708284 stack
    ) {
        final var newStack = original.call(id, count, damage);
        StationNBTSetter.cast(newStack).setStationNbt(stack.getStationNbt());
        return newStack;
    }

    @Redirect(
            method = "indexOf(Lnet/minecraft/item/ItemStack;)I",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;count:I",
                    opcode = Opcodes.GETFIELD,
                    ordinal = 1
            )
    )
    private int stationapi_captureItemStack(C_88708284 instance, C_88708284 instance2) {
        if (Objects.equals(instance.getStationNbt(), instance2.getStationNbt()))
            return instance.f_60602012;
        else {
            notchGodDamnit = true;
            return Integer.MAX_VALUE;
        }
    }

    @Unique
    private boolean notchGodDamnit;

    @Redirect(
            method = "indexOf(Lnet/minecraft/item/ItemStack;)I",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/player/PlayerInventory;getMaxCountPerStack()I"
            )
    )
    private int stationapi_fixStackableNBTs(C_87542771 instance) {
        if (notchGodDamnit) {
            notchGodDamnit = false;
            return Integer.MIN_VALUE;
        } else
            return instance.m_48421899();
    }
}
