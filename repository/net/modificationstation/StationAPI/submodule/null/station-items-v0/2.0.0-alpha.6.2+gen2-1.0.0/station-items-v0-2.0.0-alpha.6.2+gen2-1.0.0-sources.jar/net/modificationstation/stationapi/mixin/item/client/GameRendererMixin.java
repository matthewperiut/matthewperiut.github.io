package net.modificationstation.stationapi.mixin.item.client;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_03140863;
import net.minecraft.unmapped.C_24654288;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.entity.player.PlayerEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(C_03140863.class)
class GameRendererMixin {
    @Shadow
    private Minecraft client;

    @ModifyConstant(
            method = "updateTargetedEntity(F)V",
            constant = @Constant(doubleValue = 3)
    )
    private double stationapi_getEntityReach(double originalReach) {
        return StationAPI.EVENT_BUS.post(
                PlayerEvent.Reach.builder()
                        .player(client.f_28396371)
                        .type(C_24654288.net/minecraft/unmapped/C_25850426.f_19478796)
                        .currentReach(originalReach)
                        .build()
        ).currentReach;
    }
}
