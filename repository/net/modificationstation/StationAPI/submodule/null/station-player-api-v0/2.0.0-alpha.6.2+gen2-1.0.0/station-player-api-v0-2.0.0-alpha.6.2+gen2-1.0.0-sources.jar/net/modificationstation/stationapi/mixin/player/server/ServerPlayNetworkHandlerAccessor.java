package net.modificationstation.stationapi.mixin.player.server;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_99660737;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Environment(EnvType.SERVER)
@Mixin(C_99660737.class)
public interface ServerPlayNetworkHandlerAccessor {
    @Accessor
    C_49202226 getPlayer();
}
