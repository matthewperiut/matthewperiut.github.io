package net.modificationstation.stationapi.impl.client.entity.player;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_40996800;
import net.modificationstation.stationapi.impl.entity.player.PlayerHelperImpl;

public class PlayerHelperClientImpl extends PlayerHelperImpl {

    @Override
    public C_40996800 getPlayerFromGame() {
        //noinspection deprecation
        return ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_28396371;
    }

    @Override
    public C_40996800 getPlayerFromPacketHandler(C_10918870 packetHandler) {
        return getPlayerFromGame();
    }
}
