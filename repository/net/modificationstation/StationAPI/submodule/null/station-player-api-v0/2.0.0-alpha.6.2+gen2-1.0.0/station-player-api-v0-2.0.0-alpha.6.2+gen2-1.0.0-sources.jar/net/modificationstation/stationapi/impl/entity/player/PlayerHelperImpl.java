package net.modificationstation.stationapi.impl.entity.player;

import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_40996800;

public abstract class PlayerHelperImpl {

    public abstract C_40996800 getPlayerFromGame();

    public abstract C_40996800 getPlayerFromPacketHandler(C_10918870 packetHandler);
}
