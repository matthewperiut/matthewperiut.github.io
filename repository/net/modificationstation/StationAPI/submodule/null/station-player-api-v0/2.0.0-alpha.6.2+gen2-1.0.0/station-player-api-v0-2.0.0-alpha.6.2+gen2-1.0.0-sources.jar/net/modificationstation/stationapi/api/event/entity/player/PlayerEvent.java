package net.modificationstation.stationapi.api.event.entity.player;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.mine_diver.unsafeevents.event.EventPhases;
import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_40996800;
import net.modificationstation.stationapi.api.StationAPI;

@SuperBuilder
public abstract class PlayerEvent extends Event {
    public final C_40996800 player;

    @SuperBuilder
    @EventPhases(StationAPI.INTERNAL_PHASE)
    public static class Reach extends PlayerEvent {
        public final C_24654288.net/minecraft/unmapped/C_25850426 type;
        public double currentReach;
    }
}
