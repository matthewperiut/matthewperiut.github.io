package net.modificationstation.stationapi.impl.server.entity.player;

import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_99660737;
import net.modificationstation.stationapi.impl.entity.player.PlayerHelperImpl;
import net.modificationstation.stationapi.mixin.player.server.ServerPlayNetworkHandlerAccessor;

public class PlayerHelperServerImpl extends PlayerHelperImpl {

    @Override
    public C_40996800 getPlayerFromGame() {
        return null;
    }

    @Override
    public C_40996800 getPlayerFromPacketHandler(C_10918870 packetHandler) {
        return packetHandler instanceof C_99660737 ? ((ServerPlayNetworkHandlerAccessor) packetHandler).getPlayer() : getPlayerFromGame();
    }
}
