package net.modificationstation.stationapi.api.entity.player;

import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_40996800;
import net.modificationstation.stationapi.api.util.API;
import net.modificationstation.stationapi.api.util.SideUtil;
import net.modificationstation.stationapi.impl.client.entity.player.PlayerHelperClientImpl;
import net.modificationstation.stationapi.impl.entity.player.PlayerHelperImpl;
import net.modificationstation.stationapi.impl.server.entity.player.PlayerHelperServerImpl;

/**
 * Sided player helper class.
 * @author mine_diver
 */
public final class PlayerHelper {

    /**
     * Implementation instance.
     */
    @SuppressWarnings("Convert2MethodRef") // Method references load their target classes on both sides, causing crashes.
    private static final PlayerHelperImpl INSTANCE = SideUtil.get(() -> new PlayerHelperClientImpl(), () -> new PlayerHelperServerImpl());

    /**
     * @return client's player instance if the current side is client, or null if the current side is server.
     */
    @API
    public static C_40996800 getPlayerFromGame() {
        return INSTANCE.getPlayerFromGame();
    }

    /**
     * @param packetHandler the {@link C_10918870} to retrieve the player instance from.
     * @return {@link PlayerHelper#getPlayerFromGame()} if the current side is client, or the player instance from the given {@link C_10918870} if the current side is server.
     */
    @API
    public static C_40996800 getPlayerFromPacketHandler(C_10918870 packetHandler) {
        return INSTANCE.getPlayerFromPacketHandler(packetHandler);
    }
}
