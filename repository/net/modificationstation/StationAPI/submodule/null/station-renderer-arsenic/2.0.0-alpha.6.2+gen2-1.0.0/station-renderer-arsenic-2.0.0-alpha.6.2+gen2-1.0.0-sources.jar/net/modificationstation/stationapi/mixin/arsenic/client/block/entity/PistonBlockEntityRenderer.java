package net.modificationstation.stationapi.mixin.arsenic.client.block.entity;

import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_98403025;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(net.minecraft.unmapped.C_30642684.class)
class PistonBlockEntityRenderer {
    @Redirect(
            method = "render(Lnet/minecraft/block/entity/PistonBlockEntity;DDDF)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/block/BlockRenderManager;renderWithoutCulling(Lnet/minecraft/block/Block;III)V"
            )
    )
    private void stationapi_renderBlockState(
            C_03670941 manager, C_81592558 block, int x, int y, int z,
            C_98403025 pistonBlockEntity, double renderX, double renderY, double renderZ, float partialTicks
    ) {
        manager.renderAllSides(pistonBlockEntity.getPushedBlockState(), x, y, z);
    }
}
