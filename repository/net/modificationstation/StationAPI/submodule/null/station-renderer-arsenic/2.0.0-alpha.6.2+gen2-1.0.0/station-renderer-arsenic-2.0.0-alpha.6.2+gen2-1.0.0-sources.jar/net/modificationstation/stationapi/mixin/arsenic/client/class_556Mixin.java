package net.modificationstation.stationapi.mixin.arsenic.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_35412243;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.impl.client.arsenic.renderer.render.ArsenicOverlayRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_35412243.class)
@Environment(EnvType.CLIENT)
class class_556Mixin {
    @Unique
    private final ArsenicOverlayRenderer arsenic_plugin = new ArsenicOverlayRenderer((C_35412243) (Object) this);

    /**
     * @reason there's no saving notch code
     * @author mine_diver
     */
    @Overwrite
    public void renderItem(C_74425583 entity, C_88708284 item) {
        arsenic_plugin.renderItem3D(entity, item);
    }

    /**
     * @reason there's no saving notch code
     * @author mine_diver
     */
    @Overwrite
    public void render(float f) {
        arsenic_plugin.renderItem(f);
    }
}
