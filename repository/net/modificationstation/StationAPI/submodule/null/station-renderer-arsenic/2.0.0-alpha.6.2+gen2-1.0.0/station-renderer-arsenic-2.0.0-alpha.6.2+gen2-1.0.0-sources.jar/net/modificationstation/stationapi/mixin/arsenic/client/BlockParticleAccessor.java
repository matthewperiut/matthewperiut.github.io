package net.modificationstation.stationapi.mixin.arsenic.client;

import net.minecraft.unmapped.C_13986175;
import net.minecraft.unmapped.C_81592558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_13986175.class)
public interface BlockParticleAccessor {
    @Accessor
    C_81592558 getBlock();
}
