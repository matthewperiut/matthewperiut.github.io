package net.modificationstation.stationapi.mixin.arsenic.client.overlay;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_35412243;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.client.StationRenderAPI;
import net.modificationstation.stationapi.api.client.render.model.BakedModel;
import net.modificationstation.stationapi.api.client.texture.Sprite;
import net.modificationstation.stationapi.api.client.texture.atlas.Atlas;
import net.modificationstation.stationapi.api.client.texture.atlas.Atlases;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import static net.modificationstation.stationapi.impl.client.arsenic.renderer.render.ArsenicBlockRenderer.*;

@Mixin(C_35412243.class)
class BlockOverlayMixin {
    @Shadow private Minecraft minecraft;
    @Unique
    private Atlas stationapi_block_atlas;
    @Unique
    private Sprite stationapi_block_texture;

    @Inject(
            method = "renderScreenOverlays",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderTexturedOverlay(FI)V"
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void stationapi_overlay_overrideAtlas(
            float par1, CallbackInfo ci, int x, int y, int z, int var5, int blockId
    ) {
        BakedModel model = StationRenderAPI.getBakedModelManager().getBlockModels().getModel(minecraft.f_26407825.getBlockState(x, y, z));
        if (model.isBuiltin())
            stationapi_block_atlas = C_81592558.f_44428008[blockId].getAtlas();
        else
            stationapi_block_texture = model.getSprite();
    }

    @Inject(
            method = "renderTexturedOverlay",
            at = @At("HEAD")
    )
    private void stationapi_block_captureTexture(float i, int texture, CallbackInfo ci) {
        if (stationapi_block_texture == null) {
            if (stationapi_block_atlas == null)
                stationapi_block_atlas = Atlases.getTerrain();
            stationapi_block_texture = stationapi_block_atlas.getTexture(texture).getSprite();
        }
    }

    @ModifyConstant(
            method = "renderTexturedOverlay",
            constant = @Constant(floatValue = 2F / ATLAS_SIZE)
    )
    private float stationapi_block_modTextureCoordOffset(float constant) {
        return adjustU(constant, stationapi_block_texture);
    }

    @ModifyVariable(
            method = "renderTexturedOverlay",
            index = 2,
            at = @At(
                    value = "LOAD",
                    ordinal = 0
            ),
            argsOnly = true
    )
    private int stationapi_block_modTextureX(int value) {
        return stationapi_block_texture.getX();
    }

    @ModifyConstant(
            method = "renderTexturedOverlay",
            constant = {
                    @Constant(
                            intValue = TEX_SIZE,
                            ordinal = 0
                    ),
                    @Constant(
                            intValue = TEX_SIZE,
                            ordinal = 1
                    )
            }
    )
    private int stationapi_block_removeXWrap(int constant) {
        return StationRenderAPI.getBakedModelManager().getAtlas(Atlases.GAME_ATLAS_TEXTURE).getWidth();
    }

    @ModifyConstant(
            method = "renderTexturedOverlay",
            constant = {
                    @Constant(
                            floatValue = ATLAS_SIZE,
                            ordinal = 0
                    ),
                    @Constant(
                            floatValue = ATLAS_SIZE,
                            ordinal = 1
                    )
            }
    )
    private float stationapi_block_modAtlasWidth(float constant) {
        return StationRenderAPI.getBakedModelManager().getAtlas(Atlases.GAME_ATLAS_TEXTURE).getWidth();
    }

    @ModifyConstant(
            method = "renderTexturedOverlay",
            constant = @Constant(
                    floatValue = ADJUSTED_TEX_SIZE,
                    ordinal = 0
            )
    )
    private float stationapi_block_modTextureWidth(float constant) {
        return adjustToWidth(constant, stationapi_block_texture);
    }

    @ModifyVariable(
            method = "renderTexturedOverlay",
            index = 2,
            at = @At(
                    value = "LOAD",
                    ordinal = 2
            ),
            argsOnly = true
    )
    private int stationapi_block_modTextureY(int value) {
        return stationapi_block_texture.getY();
    }

    @ModifyConstant(
            method = "renderTexturedOverlay",
            constant = {
                    @Constant(
                            intValue = TEX_SIZE,
                            ordinal = 2
                    ),
                    @Constant(
                            intValue = TEX_SIZE,
                            ordinal = 3
                    )
            }
    )
    private int stationapi_block_removeYWrap(int constant) {
        return 1;
    }

    @ModifyConstant(
            method = "renderTexturedOverlay",
            constant = {
                    @Constant(
                            floatValue = ATLAS_SIZE,
                            ordinal = 2
                    ),
                    @Constant(
                            floatValue = ATLAS_SIZE,
                            ordinal = 3
                    )
            }
    )
    private float stationapi_block_modAtlasHeight(float constant) {
        return StationRenderAPI.getBakedModelManager().getAtlas(Atlases.GAME_ATLAS_TEXTURE).getHeight();
    }

    @ModifyConstant(
            method = "renderTexturedOverlay",
            constant = @Constant(
                    floatValue = ADJUSTED_TEX_SIZE,
                    ordinal = 1
            )
    )
    private float stationapi_block_modTextureHeight(float constant) {
        return adjustToHeight(constant, stationapi_block_texture);
    }

    @Inject(
            method = "renderTexturedOverlay",
            at = @At("RETURN")
    )
    private void stationapi_block_releaseCaptured(float i, int par2, CallbackInfo ci) {
        stationapi_block_atlas = null;
        stationapi_block_texture = null;
    }
}
