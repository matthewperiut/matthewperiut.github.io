package net.modificationstation.stationapi.mixin.arsenic.client.gui;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.unmapped.C_15891356;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_96603444;
import net.modificationstation.stationapi.api.client.texture.Sprite;
import net.modificationstation.stationapi.api.client.texture.atlas.Atlases;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_15891356.class)
class AchievementsScreenMixin extends C_85740840 {
    @Redirect(
            method = "renderIcons",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screen/AchievementsScreen;drawTexture(IIIIII)V",
                    ordinal = 0
            )
    )
    private void stationapi_background_renderTexture(
            C_15891356 instance, int x, int y, int texX, int texY, int width, int height,
            @Local(index = 26) int textureId
    ) {
        Sprite texture = Atlases.getTerrain().getTexture(textureId).getSprite();
        C_96603444 tessellator = C_96603444.f_99414865;
        tessellator.m_35940071();
        tessellator.m_75942980(x, y + height, f_02657644, texture.getMinU(), texture.getMaxV());
        tessellator.m_75942980(x + width, y + height, f_02657644, texture.getMaxU(), texture.getMaxV());
        tessellator.m_75942980(x + width, y, f_02657644, texture.getMaxU(), texture.getMinV());
        tessellator.m_75942980(x, y, f_02657644, texture.getMinU(), texture.getMinV());
        tessellator.m_70070273();
    }
}
