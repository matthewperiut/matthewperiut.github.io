package net.modificationstation.stationapi.mixin.arsenic.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Random;
import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_84615110;

@Mixin(C_84615110.class)
public interface ItemRendererAccessor {
    @Accessor
    Random getRandom();

    @Accessor
    C_03670941 getBlockRenderer();
}
