package net.modificationstation.stationapi.impl.client.arsenic.renderer.render;

import com.google.common.collect.ImmutableList;
import com.google.common.primitives.Ints;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_14999373;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_34399650;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_96603444;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.client.StationRenderAPI;
import net.modificationstation.stationapi.api.client.color.block.BlockColors;
import net.modificationstation.stationapi.api.client.color.item.ItemColors;
import net.modificationstation.stationapi.api.client.render.item.ItemModels;
import net.modificationstation.stationapi.api.client.render.model.*;
import net.modificationstation.stationapi.api.client.render.model.json.ModelTransformation;
import net.modificationstation.stationapi.api.client.render.model.json.Transformation;
import net.modificationstation.stationapi.api.client.texture.StationTextureManager;
import net.modificationstation.stationapi.api.client.texture.atlas.Atlases;
import net.modificationstation.stationapi.api.registry.ItemRegistry;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.api.util.Util;
import net.modificationstation.stationapi.api.util.crash.CrashException;
import net.modificationstation.stationapi.api.util.crash.CrashReport;
import net.modificationstation.stationapi.api.util.crash.CrashReportSection;
import net.modificationstation.stationapi.api.util.exception.CrashReportSectionBlockState;
import net.modificationstation.stationapi.api.util.math.Direction;
import net.modificationstation.stationapi.api.util.math.MathHelper;
import net.modificationstation.stationapi.impl.client.arsenic.renderer.aocalc.LightingCalculatorImpl;
import org.jetbrains.annotations.Nullable;

import java.nio.ByteOrder;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Random;

import static org.lwjgl.opengl.GL11.*;

public class BakedModelRendererImpl implements BakedModelRenderer {

    private static final Direction[] DIRECTIONS = Util.make(() -> {
        Direction[] originalValues = Direction.values();
        return Arrays.copyOf(originalValues, originalValues.length + 1);
    });

    private final C_96603444 tessellator = C_96603444.f_99414865;
    private final LightingCalculatorImpl light = new LightingCalculatorImpl(3);
    private final Random random = new Random();
    private final ItemModels itemModels = Util.make(new ItemModels(StationRenderAPI.getBakedModelManager()), models -> {
        for (Identifier id : ItemRegistry.INSTANCE.getIds())
            models.putModel(ItemRegistry.INSTANCE.get(id), ModelIdentifier.of(id, "inventory"));
        models.reloadModels();
    });
    private final BlockColors blockColors = StationRenderAPI.getBlockColors();
    private final ItemColors itemColors = StationRenderAPI.getItemColors();
    private boolean damage;

    @Override
    public boolean renderBlock(BlockState state, C_32594356 pos, C_46108969 world, boolean cull, Random random) {
        try {
//            BlockRenderType blockRenderType = state.getRenderType();
//            if (blockRenderType != BlockRenderType.MODEL) {
//                return false;
//            }
            return render(world, StationRenderAPI.getBakedModelManager().getBlockModels().getModel(state), state, pos, cull, random, state.getRenderingSeed(pos));
        }
        catch (Throwable throwable) {
            CrashReport crashReport = CrashReport.create(throwable, "Tesselating block in world");
            CrashReportSection crashReportSection = crashReport.addElement("Block being tesselated");
            CrashReportSectionBlockState.addBlockInfo(crashReportSection, world, pos, state);
            throw new CrashException(crashReport);
        }
    }

    @Override
    public boolean render(C_46108969 world, BakedModel model, BlockState state, C_32594356 pos, boolean cull, Random random, long seed) {
        boolean rendered = false;
        model = Objects.requireNonNull(model.getOverrides().apply(model, state, world, pos, (int) seed));
        C_81592558 block = state.getBlock();
        light.initialize(
                block,
                world, pos.f_06162490, pos.f_08824702, pos.f_31865394,
                Minecraft.m_85834129() && model.useAmbientOcclusion()
        );
        ImmutableList<BakedQuad> qs;
        BakedQuad q;
        float[] qlight = light.light;
        for (int quadSet = 0, size = DIRECTIONS.length; quadSet < size; quadSet++) {
            Direction face = DIRECTIONS[quadSet];
            random.setSeed(seed);
            qs = model.getQuads(state, face, random);
            if (!qs.isEmpty() && (face == null || block.m_28922194(world, pos.f_06162490 + face.getOffsetX(), pos.f_08824702 + face.getOffsetY(), pos.f_31865394 + face.getOffsetZ(), quadSet))) {
                rendered = true;
                for (int j = 0, quadSize = qs.size(); j < quadSize; j++) {
                    q = qs.get(j);
                    light.calculateForQuad(q);
                    renderQuad(world, state, pos, q, qlight);
                }
            }
        }
        return rendered;
    }

    private float redI2F(int color) {
        return ((color >> 16) & 255) / 255F;
    }

    private float greenI2F(int color) {
        return ((color >> 8) & 255) / 255F;
    }

    private float blueI2F(int color) {
        return (color & 255) / 255F;
    }

    private int colorF2I(float r, float g, float b) {
        final int ri = colorChannelF2I(r), gi = colorChannelF2I(g), bi = colorChannelF2I(b);
        return ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN ?
                (0xFF << 24) | (bi << 16) | (gi << 8) | ri :
                (ri << 24) | (gi << 16) | (bi << 8) | 0xFF;
    }

    private int colorChannelF2I(float colorChannel) {
        return Ints.constrainToRange((int) (colorChannel * 255), 0, 255);
    }

    @Override
    public void renderDamage(BlockState state, C_32594356 pos, C_46108969 world, float progress) {
//        if (state.getRenderType() != BlockRenderType.MODEL) {
//            return;
//        }
        BakedModel bakedModel = StationRenderAPI.getBakedModelManager().getBlockModels().getModel(state);
        long l = state.getRenderingSeed(pos);
        damage = true;
        //noinspection deprecation
        StationTextureManager.get(((Minecraft) FabricLoader.getInstance().getGameInstance()).f_45465196).getTexture(ModelLoader.BLOCK_DESTRUCTION_STAGE_TEXTURES.get((int) (progress * 10))).bindTexture();
        render(world, bakedModel, state, pos, true, this.random, l);
        damage = false;
    }

    private void renderQuad(C_46108969 world, BlockState state, C_32594356 pos, BakedQuad quad, float[] brightness) {
        if (quad.hasColor()) {
            int i = blockColors.getColor(state, world, pos, quad.getColorIndex());
            float
                    r = redI2F(i),
                    g = greenI2F(i),
                    b = blueI2F(i);
            tessellator.quad(quad, pos.f_06162490, pos.f_08824702, pos.f_31865394,
                    colorF2I(r * brightness[0], g * brightness[0], b * brightness[0]),
                    colorF2I(r * brightness[1], g * brightness[1], b * brightness[1]),
                    colorF2I(r * brightness[2], g * brightness[2], b * brightness[2]),
                    colorF2I(r * brightness[3], g * brightness[3], b * brightness[3]),
                    0, 0, 0,
                    damage
            );
        } else
            tessellator.quad(quad, pos.f_06162490, pos.f_08824702, pos.f_31865394,
                    colorF2I(brightness[0], brightness[0], brightness[0]),
                    colorF2I(brightness[1], brightness[1], brightness[1]),
                    colorF2I(brightness[2], brightness[2], brightness[2]),
                    colorF2I(brightness[3], brightness[3], brightness[3]),
                    0, 0, 0,
                    damage
            );
    }

    @Override
    public ItemModels getItemModels() {
        return this.itemModels;
    }

    private void renderBakedItemModel(BakedModel model, C_88708284 stack, float brightness) {
        for (Direction direction : Direction.values()) {
            random.setSeed(42L);
            renderBakedItemQuads(model.getQuads(null, direction, random), stack, brightness);
        }
        random.setSeed(42L);
        renderBakedItemQuads(model.getQuads(null, null, random), stack, brightness);
    }

    private void renderBakedItemModelFlat(BakedModel model, C_88708284 stack, float brightness) {
        random.setSeed(42L);
        boolean bl = stack != null && stack.f_59294634 != 0 && stack.f_60602012 > 0;
        for (BakedQuad bakedQuad : model.getQuads(null, null, random)) {
            if (bakedQuad.getFace() != Direction.SOUTH) continue;
            int i = bl && bakedQuad.hasColor() ? this.itemColors.getColor(stack, bakedQuad.getColorIndex()) : -1;
            float light = MathHelper.lerp(bakedQuad.getEmission(), brightness, 1F);
            i = colorF2I(redI2F(i) * light, greenI2F(i) * light, blueI2F(i) * light);
            tessellator.quad(bakedQuad, 0, 0, 0, i, i, i, i, 0, 1, 0, false);
        }
    }

    @Override
    public void renderItem(C_88708284 stack, ModelTransformation.Mode renderMode, float brightness, BakedModel model) {
        if (stack == null || stack.f_59294634 == 0) return;
        Transformation transformation = model.getTransformation().getTransformation(renderMode);
        transformation.apply();
        boolean side = model.isSideLit();
        if (side && renderMode == ModelTransformation.Mode.GUI) {
            float angle = transformation.rotation.getY() - 315;
            if (angle != 0) {
                C_14999373.m_94129982();
                glPushMatrix();
                glRotatef(angle, 0, 1, 0);
                C_14999373.m_00064778();
                glPopMatrix();
            }
        }
        glTranslatef(-0.5F, -0.5F, -0.5F);
        if (model.isBuiltin()) return;
        if (!side && renderMode == ModelTransformation.Mode.GROUND)
            renderBakedItemModelFlat(model, stack, brightness);
        else
            renderBakedItemModel(model, stack, brightness);
    }

    private void renderBakedItemQuads(List<BakedQuad> quads, C_88708284 stack, float brightness) {
        boolean bl = stack != null && stack.f_59294634 != 0 && stack.f_60602012 > 0;
        for (BakedQuad bakedQuad : quads) {
            int i = bl && bakedQuad.hasColor() ? this.itemColors.getColor(stack, bakedQuad.getColorIndex()) : -1;
            float light = MathHelper.lerp(bakedQuad.getEmission(), brightness, 1F);
            i = colorF2I(redI2F(i) * light, greenI2F(i) * light, blueI2F(i) * light);
            Direction face = bakedQuad.getFace();
            tessellator.quad(bakedQuad, 0, 0, 0, i, i, i, i, face.getOffsetX(), face.getOffsetY(), face.getOffsetZ(), false);
        }
    }

    @Override
    public BakedModel getModel(C_88708284 stack, @Nullable C_64041439 world, @Nullable C_74425583 entity, int seed) {
        BakedModel bakedModel = this.itemModels.getModel(stack);
        C_34399650 clientWorld = world instanceof C_34399650 ? (C_34399650) world : null;
        BakedModel bakedModel2 = bakedModel.getOverrides().apply(bakedModel, stack, clientWorld, entity, seed);
        return bakedModel2 == null ? this.itemModels.getModelManager().getMissingModel() : bakedModel2;
    }

    @Override
    public void renderItem(@Nullable C_74425583 entity, C_88708284 item, ModelTransformation.Mode renderMode, @Nullable C_64041439 world, float brightness, int seed) {
        if (item == null || item.f_59294634 == 0 || item.f_60602012 < 1) return;
        BakedModel bakedModel = this.getModel(item, world, entity, seed);
        this.renderItem(item, renderMode, brightness, bakedModel);
    }

    protected void renderGuiItemModel(C_88708284 stack, int x, int y, BakedModel model) {
        StationRenderAPI.getBakedModelManager().getAtlas(Atlases.GAME_ATLAS_TEXTURE).setFilter(false, false);
        glPushMatrix();
        glTranslated(x, y, 14.5 /* approximate. should probably be replaced later with a value properly calculated against vanilla's transformations */);
        glTranslatef(8, 8, 0);
        glScalef(1, -1, 1);
        glScalef(16, 16, 16);
        boolean flat = !model.isSideLit();
        if (flat) glDisable(GL_LIGHTING);
        tessellator.m_35940071();
        this.renderItem(stack, ModelTransformation.Mode.GUI, 1, model);
        tessellator.m_70070273();
        if (flat) glEnable(GL_LIGHTING);
        glPopMatrix();
        if (!flat) {
            C_14999373.m_94129982();
            glPushMatrix();
            glRotatef(120.0f, 1.0f, 0.0f, 0.0f);
            C_14999373.m_00064778();
            glPopMatrix();
        }
        glEnable(GL_CULL_FACE);
    }

    /**
     * Renders an item in a GUI with the player as the attached entity
     * for calculating model overrides.
     */
    @Override
    public void renderInGuiWithOverrides(C_88708284 stack, int x, int y) {
        //noinspection deprecation
        this.innerRenderInGui(((Minecraft) FabricLoader.getInstance().getGameInstance()).f_28396371, stack, x, y, 0);
    }

    private void innerRenderInGui(@Nullable C_74425583 entity, C_88708284 stack, int x, int y, int seed) {
        if (stack == null || stack.f_59294634 == 0 || stack.f_60602012 < 1) return;
        BakedModel bakedModel = this.getModel(stack, null, entity, seed);
        try {
            this.renderGuiItemModel(stack, x, y, bakedModel);
        }
        catch (Throwable throwable) {
            CrashReport crashReport = CrashReport.create(throwable, "Rendering item");
            CrashReportSection crashReportSection = crashReport.addElement("Item being rendered");
            crashReportSection.add("Item Type", () -> String.valueOf(stack.m_23235460()));
            crashReportSection.add("Item Damage", () -> String.valueOf(stack.m_21098843()));
            crashReportSection.add("Item NBT", () -> String.valueOf(stack.getStationNbt()));
            throw new CrashException(crashReport);
        }
    }
}
