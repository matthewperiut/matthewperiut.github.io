package net.modificationstation.stationapi.impl.client.arsenic.renderer.render.particle;

import lombok.Getter;
import net.minecraft.unmapped.C_13986175;
import net.minecraft.unmapped.C_47540058;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_96603444;
import net.modificationstation.stationapi.api.client.StationRenderAPI;
import net.modificationstation.stationapi.api.client.model.block.BlockWorldModelProvider;
import net.modificationstation.stationapi.api.client.render.model.BakedModel;
import net.modificationstation.stationapi.api.client.texture.Sprite;
import net.modificationstation.stationapi.api.client.texture.atlas.Atlases;
import net.modificationstation.stationapi.api.world.BlockStateView;
import net.modificationstation.stationapi.mixin.arsenic.client.BlockParticleAccessor;
import net.modificationstation.stationapi.mixin.arsenic.client.ParticleAccessor;

public class ArsenicDiggingParticle {

    private final C_13986175 digging;
    private final ParticleAccessor particleBaseAccessor;
    @Getter
    private Sprite texture;

    public ArsenicDiggingParticle(C_13986175 digging) {
        this.digging = digging;
        particleBaseAccessor = (ParticleAccessor) digging;
        texture = StationRenderAPI.getBakedModelManager().getAtlas(Atlases.GAME_ATLAS_TEXTURE).getSprite(((BlockParticleAccessor) digging).getBlock().getAtlas().getTexture(particleBaseAccessor.getTextureId()).getId());
    }

    public void checkBlockCoords(int x, int y, int z) {
        C_81592558 block = ((BlockParticleAccessor) digging).getBlock();
        if (block instanceof BlockWorldModelProvider provider)
            texture = provider.getCustomWorldModel(digging.f_94306729, x, y, z).getBaked().getSprite();
        else {
            BakedModel model = StationRenderAPI.getBakedModelManager().getBlockModels().getModel(((BlockStateView) digging.f_94306729).getBlockState(x, y, z));
            if (!model.isBuiltin())
                texture = model.getSprite();
        }
    }

    public void render(C_96603444 tessellator, float delta, float yawX, float pitchX, float yawY, float pitchY1, float pitchY2) {
        float
                startU = texture.getMinU() + (particleBaseAccessor.getPrevU() / 4) * (texture.getMaxU() - texture.getMinU()),
                endU = startU + 0.24975F * (texture.getMaxU() - texture.getMinU()),
                startV = texture.getMinV() + (particleBaseAccessor.getPrevV() / 4) * (texture.getMaxV() - texture.getMinV()),
                endV = startV + 0.24975F * (texture.getMaxV() - texture.getMinV()),
                randomMultiplier = 0.1F * particleBaseAccessor.getScale(),
                renderX = (float)(digging.f_59999765 + (digging.f_78826675 - digging.f_59999765) * (double)delta - C_47540058.f_37914722),
                renderY = (float)(digging.f_90348373 + (digging.f_31030949 - digging.f_90348373) * (double)delta - C_47540058.f_59479165),
                renderZ = (float)(digging.f_88346412 + (digging.f_97691941 - digging.f_88346412) * (double)delta - C_47540058.f_68501249),
                brightness = digging.m_95186532(delta);
        tessellator.m_73671468(brightness * particleBaseAccessor.getRed(), brightness * particleBaseAccessor.getGreen(), brightness * particleBaseAccessor.getBlue());
        tessellator.m_75942980(renderX - yawX * randomMultiplier - pitchY1 * randomMultiplier, renderY - pitchX * randomMultiplier, renderZ - yawY * randomMultiplier - pitchY2 * randomMultiplier, startU, endV);
        tessellator.m_75942980(renderX - yawX * randomMultiplier + pitchY1 * randomMultiplier, renderY + pitchX * randomMultiplier, renderZ - yawY * randomMultiplier + pitchY2 * randomMultiplier, startU, startV);
        tessellator.m_75942980(renderX + yawX * randomMultiplier + pitchY1 * randomMultiplier, renderY + pitchX * randomMultiplier, renderZ + yawY * randomMultiplier + pitchY2 * randomMultiplier, endU, startV);
        tessellator.m_75942980(renderX + yawX * randomMultiplier - pitchY1 * randomMultiplier, renderY - pitchX * randomMultiplier, renderZ + yawY * randomMultiplier - pitchY2 * randomMultiplier, endU, endV);
    }
}
