package net.modificationstation.stationapi.impl.client.arsenic.renderer.render;

import net.minecraft.unmapped.C_02041937;
import net.minecraft.unmapped.C_82920792;
import net.modificationstation.stationapi.api.client.StationRenderAPI;
import net.modificationstation.stationapi.api.client.texture.atlas.Atlases;
import net.modificationstation.stationapi.mixin.render.client.TextureManagerAccessor;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

public final class ArsenicTextureManager {

    private final C_82920792 self;
    private final TextureManagerAccessor access;

    public ArsenicTextureManager(C_82920792 self) {
        this.self = self;
        access = (TextureManagerAccessor) self;
    }

    public void getTextureId(String par1, CallbackInfoReturnable<Integer> cir) {
        switch (par1) {
            case "/terrain.png", "/gui/items.png" -> cir.setReturnValue(StationRenderAPI.getBakedModelManager().getAtlas(Atlases.GAME_ATLAS_TEXTURE).getGlId());
        }
    }

    public void ensureBufferCapacity(int expectedCapacity) {
        if (expectedCapacity > access.getImageBuffer().capacity())
            access.setImageBuffer(C_02041937.m_00433401(expectedCapacity));
    }
}
