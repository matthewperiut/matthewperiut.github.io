package net.modificationstation.stationapi.mixin.arsenic.client;

import net.minecraft.unmapped.C_13986175;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_96603444;
import net.modificationstation.stationapi.impl.client.arsenic.renderer.render.particle.ArsenicDiggingParticle;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_13986175.class)
class BlockParticleMixin {
    @Unique
    private ArsenicDiggingParticle stationapi$arsenicDiggingParticle;

    @Inject(
            method = "<init>",
            at = @At("RETURN")
    )
    private void stationapi_onCor(C_64041439 arg, double d, double d1, double d2, double d3, double d4, double d5, C_81592558 arg1, int i, int j, CallbackInfo ci) {
        stationapi$arsenicDiggingParticle = new ArsenicDiggingParticle((C_13986175) (Object) this);
    }

    @Inject(
            method = "color",
            at = @At("HEAD")
    )
    private void stationapi_checkBlockCoords(int i, int j, int k, CallbackInfoReturnable<C_13986175> cir) {
        stationapi$arsenicDiggingParticle.checkBlockCoords(i, j, k);
    }

    /**
     * @reason there's no saving notch code
     * @author mine_diver
     */
    @Overwrite
    public void render(C_96603444 arg, float f, float f1, float f2, float f3, float f4, float f5) {
        stationapi$arsenicDiggingParticle.render(arg, f, f1, f2, f3, f4, f5);
    }
}
