package net.modificationstation.stationapi.impl.client.arsenic.renderer.render;

import net.minecraft.unmapped.C_96603444;
import net.modificationstation.stationapi.mixin.arsenic.client.TessellatorAccessor;

public final class ArsenicTessellator {

    private final C_96603444 tessellator;
    private final TessellatorAccessor a;

    public ArsenicTessellator(C_96603444 tessellator) {
        this.tessellator = tessellator;
        a = (TessellatorAccessor) tessellator;
    }

    public void afterVertex() {
        if (a.stationapi$getVertexCount() % 4 == 0)
            tessellator.ensureBufferCapacity(48);
    }
}
