package net.modificationstation.stationapi.mixin.arsenic.client;

import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_24384787;
import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.client.StationRenderAPI;
import net.modificationstation.stationapi.api.client.render.RendererAccess;
import net.modificationstation.stationapi.api.client.render.model.VanillaBakedModel;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.Objects;

@Mixin(C_24384787.class)
class WorldRendererMixin {
    @Shadow private C_64041439 world;
    @Shadow public float miningProgress;

    @Redirect(
            method = "renderMiningProgress",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/block/BlockRenderManager;renderWithTexture(Lnet/minecraft/block/Block;IIII)V"
            )
    )
    private void stationapi_renderDamage(C_03670941 instance, C_81592558 block, int j, int k, int l, int texture, C_40996800 arg, C_24654288 arg2, int i, C_88708284 arg3, float f) {
        BlockState state = world.getBlockState(j, k, l);
        if (StationRenderAPI.getBakedModelManager().getBlockModels().getModel(state) instanceof VanillaBakedModel)
            instance.m_84431382(block, j, k, l, texture);
        else
            Objects.requireNonNull(RendererAccess.INSTANCE.getRenderer()).bakedModelRenderer().renderDamage(state, new C_32594356(j, k, l), world, miningProgress);
    }
}
