package net.modificationstation.stationapi.mixin.arsenic.client.particle;

import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import net.minecraft.unmapped.C_47540058;
import net.minecraft.unmapped.C_47900077;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_96603444;
import net.modificationstation.stationapi.api.client.texture.Sprite;
import net.modificationstation.stationapi.api.client.texture.atlas.Atlases;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static net.modificationstation.stationapi.impl.client.arsenic.renderer.render.ArsenicBlockRenderer.ATLAS_SIZE;

@Mixin(C_47900077.class)
class ItemParticleMixin extends C_47540058 {
    private ItemParticleMixin(C_64041439 world, double x, double y, double z, double velocityX, double velocityY, double velocityZ) {
        super(world, x, y, z, velocityX, velocityY, velocityZ);
    }

    @Inject(
            method = "render",
            at = @At("HEAD")
    )
    private void stationapi_initializeSprite(
            C_96603444 f, float g, float h, float i, float j, float k, float par7, CallbackInfo ci,
            @Share("sprite") LocalRef<Sprite> spriteRef
    ) {
        spriteRef.set(Atlases.getGuiItems().getTexture(f_63348640).getSprite());
    }

    @ModifyVariable(
            method = "render",
            at = @At("STORE"),
            index = 8
    )
    private float stationapi_modStartU(
            float value,
            @Share("sprite") LocalRef<Sprite> spriteRef
    ) {
        Sprite sprite = spriteRef.get();
        return sprite.getMinU() + (sprite.getMaxU() - sprite.getMinU()) * f_76706888 / 4;
    }

    @ModifyConstant(
            method = "render",
            constant = @Constant(
                    floatValue = 3.996F / ATLAS_SIZE,
                    ordinal = 0
            )
    )
    private float stationapi_modEndU(
            float constant,
            @Share("sprite") LocalRef<Sprite> spriteRef
    ) {
        Sprite sprite = spriteRef.get();
        return (sprite.getMaxU() - sprite.getMinU()) / 3.996F;
    }

    @ModifyVariable(
            method = "render",
            at = @At("STORE"),
            index = 10
    )
    private float stationapi_modStartV(
            float value,
            @Share("sprite") LocalRef<Sprite> spriteRef
    ) {
        Sprite sprite = spriteRef.get();
        return sprite.getMinV() + (sprite.getMaxV() - sprite.getMinV()) * f_34520038 / 4;
    }

    @ModifyConstant(
            method = "render",
            constant = @Constant(
                    floatValue = 3.996F / ATLAS_SIZE,
                    ordinal = 1
            )
    )
    private float stationapi_modEndV(
            float constant,
            @Share("sprite") LocalRef<Sprite> spriteRef
    ) {
        Sprite sprite = spriteRef.get();
        return (sprite.getMaxV() - sprite.getMinV()) / 3.996F;
    }
}
