package net.modificationstation.stationapi.mixin.arsenic.client;

import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_46108969;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_03670941.class)
public interface BlockRenderManagerAccessor {
    @Accessor
    C_46108969 getBlockView();

    @Accessor
    int getTextureOverride();

    @Accessor
    boolean getSkipFaceCulling();
}
