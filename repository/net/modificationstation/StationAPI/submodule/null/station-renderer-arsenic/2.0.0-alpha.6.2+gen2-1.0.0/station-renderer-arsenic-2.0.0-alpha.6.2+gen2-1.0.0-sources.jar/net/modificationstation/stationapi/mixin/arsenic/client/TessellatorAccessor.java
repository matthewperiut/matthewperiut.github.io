package net.modificationstation.stationapi.mixin.arsenic.client;

import net.minecraft.unmapped.C_96603444;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_96603444.class)
public interface TessellatorAccessor {
    @Accessor("vertexCount")
    int stationapi$getVertexCount();
}
