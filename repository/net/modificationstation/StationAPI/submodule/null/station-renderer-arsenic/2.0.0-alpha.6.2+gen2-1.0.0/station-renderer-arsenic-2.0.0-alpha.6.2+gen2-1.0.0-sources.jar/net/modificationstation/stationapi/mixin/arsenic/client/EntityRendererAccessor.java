package net.modificationstation.stationapi.mixin.arsenic.client;

import net.minecraft.unmapped.C_32232284;
import net.minecraft.unmapped.C_53593123;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_53593123.class)
public interface EntityRendererAccessor {
    @Accessor
    C_32232284 getDispatcher();
}
