package net.modificationstation.stationapi.mixin.arsenic.client;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_54686545;
import net.minecraft.unmapped.C_82920792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Minecraft.class)
class MinecraftMixin {
    @Redirect(
            method = "init",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/texture/TextureManager;addDynamicTexture(Lnet/minecraft/client/render/texture/DynamicTexture;)V"
            )
    )
    private void stationapi_stopVanillaTextureBinders(C_82920792 textureManager, C_54686545 arg) {}
}
