package net.modificationstation.stationapi.mixin.arsenic.client;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_35412243;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_96459994;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_35412243.class)
public interface class_556Accessor {
    @Accessor("minecraft")
    Minecraft stationapi$getMinecraft();

    @Accessor("stack")
    C_88708284 stationapi$getStack();

    @Accessor("height")
    float stationapi$getHeight();

    @Accessor("prevHeight")
    float stationapi$getPrevHeight();

    @Accessor("blockRenderManager")
    C_03670941 stationapi$getBlockRenderManager();

    @Accessor("mapRenderer")
    C_96459994 stationapi$getMapRenderer();
}
