package net.modificationstation.stationapi.impl.client.arsenic.renderer.render;

import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_14999373;
import net.minecraft.unmapped.C_32232284;
import net.minecraft.unmapped.C_34859172;
import net.minecraft.unmapped.C_35412243;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_53593123;
import net.minecraft.unmapped.C_57778754;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88220120;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_96603444;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.client.StationRenderAPI;
import net.modificationstation.stationapi.api.client.render.model.BakedModel;
import net.modificationstation.stationapi.api.client.render.model.VanillaBakedModel;
import net.modificationstation.stationapi.api.client.render.model.json.ModelTransformation;
import net.modificationstation.stationapi.api.client.texture.Sprite;
import net.modificationstation.stationapi.api.client.texture.SpriteAtlasTexture;
import net.modificationstation.stationapi.api.client.texture.SpriteContents;
import net.modificationstation.stationapi.api.client.texture.atlas.Atlases;
import net.modificationstation.stationapi.api.client.texture.atlas.CustomAtlasProvider;
import net.modificationstation.stationapi.api.item.BlockItemForm;
import net.modificationstation.stationapi.mixin.arsenic.client.class_556Accessor;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL12.GL_RESCALE_NORMAL;

public final class ArsenicOverlayRenderer {

    private final class_556Accessor access;

    public ArsenicOverlayRenderer(C_35412243 overlayRenderer) {
        access = (class_556Accessor) overlayRenderer;
    }

    public void renderItem3D(C_74425583 entity, C_88708284 item) {
        SpriteAtlasTexture atlas = StationRenderAPI.getBakedModelManager().getAtlas(Atlases.GAME_ATLAS_TEXTURE);
        atlas.bindTexture();
        glPushMatrix();
        BakedModel model = RendererHolder.RENDERER.getModel(item, entity.f_94306729, entity, entity.f_11112215);
        if (model instanceof VanillaBakedModel) renderVanilla(entity, item, atlas);
        else renderModel(entity, item);

        glPopMatrix();
    }

    private void renderVanilla(C_74425583 entity, C_88708284 item, SpriteAtlasTexture atlas) {
        C_81592558 block;
        if (item.m_23235460() instanceof BlockItemForm blockItemForm && C_03670941.m_23090332((block = blockItemForm.getBlock()).m_43136364()))
            access.stationapi$getBlockRenderManager().m_96377958(block, item.m_21098843(), entity.m_95186532(1.0F));
        else {
            C_96603444 var3 = C_96603444.f_99414865;
            int var4 = entity.m_75043345(item);
            Sprite texture = atlas.getSprite(((CustomAtlasProvider) item.m_23235460()).getAtlas().getTexture(var4).getId());
            float var5 = texture.getMinU();
            float var6 = texture.getMinU() + (texture.getMaxU() - texture.getMinU()) * 0.999375F;
            float var7 = texture.getMinV();
            float var8 = texture.getMinV() + (texture.getMaxV() - texture.getMinV()) * 0.999375F;
            float var9 = 1.0F;
            float var10 = 0.0F;
            float var11 = 0.3F;
            glEnable(GL_RESCALE_NORMAL);
            glTranslatef(-var10, -var11, 0.0F);
            float var12 = 1.5F;
            glScalef(var12, var12, var12);
            glRotatef(50.0F, 0.0F, 1.0F, 0.0F);
            glRotatef(335.0F, 0.0F, 0.0F, 1.0F);
            glTranslatef(-0.9375F, -0.0625F, 0.0F);
            float var13 = 0.0625F;
            var3.m_35940071();
            var3.m_86080397(0.0F, 0.0F, 1.0F);
            var3.m_75942980(0.0D, 0.0D, 0.0D, var6, var8);
            var3.m_75942980(var9, 0.0D, 0.0D, var5, var8);
            var3.m_75942980(var9, 1.0D, 0.0D, var5, var7);
            var3.m_75942980(0.0D, 1.0D, 0.0D, var6, var7);
            var3.m_70070273();
            var3.m_35940071();
            var3.m_86080397(0.0F, 0.0F, -1.0F);
            var3.m_75942980(0.0D, 1.0D, 0.0F - var13, var6, var7);
            var3.m_75942980(var9, 1.0D, 0.0F - var13, var5, var7);
            var3.m_75942980(var9, 0.0D, 0.0F - var13, var5, var8);
            var3.m_75942980(0.0D, 0.0D, 0.0F - var13, var6, var8);
            var3.m_70070273();
            var3.m_35940071();
            var3.m_86080397(-1.0F, 0.0F, 0.0F);

            final SpriteContents contents = texture.getContents();
            int atlasWidth = (int) (contents.getWidth() / (texture.getMaxU() - texture.getMinU()));
            int atlasHeight = (int) (contents.getHeight() / (texture.getMaxV() - texture.getMinV()));
            int width = contents.getWidth();
            int height = contents.getHeight();
            float du = 1F / (atlasWidth * 2);
            float dv = 1F / (atlasHeight * 2);

            for (int var14 = 0; var14 < width; ++var14) {
                float var15 = (float) var14 / width;
                float var16 = var6 + (var5 - var6) * var15 - du;
                float var17 = var9 * var15;
                var3.m_75942980(var17, 0.0D, 0.0F - var13, var16, var8);
                var3.m_75942980(var17, 0.0D, 0.0D, var16, var8);
                var3.m_75942980(var17, 1.0D, 0.0D, var16, var7);
                var3.m_75942980(var17, 1.0D, 0.0F - var13, var16, var7);
            }

            var3.m_70070273();
            var3.m_35940071();
            var3.m_86080397(1.0F, 0.0F, 0.0F);

            for (int var18 = 0; var18 < width; ++var18) {
                float var21 = (float) var18 / width;
                float var24 = var6 + (var5 - var6) * var21 - du;
                float var27 = var9 * var21 + 1F / width;
                var3.m_75942980(var27, 1.0D, 0.0F - var13, var24, var7);
                var3.m_75942980(var27, 1.0D, 0.0D, var24, var7);
                var3.m_75942980(var27, 0.0D, 0.0D, var24, var8);
                var3.m_75942980(var27, 0.0D, 0.0F - var13, var24, var8);
            }

            var3.m_70070273();
            var3.m_35940071();
            var3.m_86080397(0.0F, 1.0F, 0.0F);

            for (int var19 = 0; var19 < height; ++var19) {
                float var22 = (float) var19 / height;
                float var25 = var8 + (var7 - var8) * var22 - dv;
                float var28 = var9 * var22 + 1F / height;
                var3.m_75942980(0.0D, var28, 0.0D, var6, var25);
                var3.m_75942980(var9, var28, 0.0D, var5, var25);
                var3.m_75942980(var9, var28, 0.0F - var13, var5, var25);
                var3.m_75942980(0.0D, var28, 0.0F - var13, var6, var25);
            }

            var3.m_70070273();
            var3.m_35940071();
            var3.m_86080397(0.0F, -1.0F, 0.0F);

            for (int var20 = 0; var20 < height; ++var20) {
                float var23 = (float) var20 / height;
                float var26 = var8 + (var7 - var8) * var23 - dv;
                float var29 = var9 * var23;
                var3.m_75942980(var9, var29, 0.0D, var5, var26);
                var3.m_75942980(0.0D, var29, 0.0D, var6, var26);
                var3.m_75942980(0.0D, var29, 0.0F - var13, var6, var26);
                var3.m_75942980(var9, var29, 0.0F - var13, var5, var26);
            }

            var3.m_70070273();
            glDisable(GL_RESCALE_NORMAL);
        }
    }

    private void renderModel(C_74425583 entity, C_88708284 item) {
        glTranslated(0, 3D / 16, -5D / 16);
        glRotatef(20, 1, 0, 0);
        glRotatef(45, 0, 1, 0);
        glScalef(-1, -1, 1);

        // funny little workaround to undo default third person transformation
        glRotatef(45, 0, 1, 0);
        glRotatef(-75, 1, 0, 0);
        glTranslated(0, -2.5 / 16, 0);

        C_96603444.f_99414865.m_35940071();
        renderItem(entity, item, ModelTransformation.Mode.THIRD_PERSON_RIGHT_HAND);
        C_96603444.f_99414865.m_70070273();
    }

    public void renderItem(float f) {
        float var2 = access.stationapi$getPrevHeight() + (access.stationapi$getHeight() - access.stationapi$getPrevHeight()) * f;
        C_57778754 var3 = access.stationapi$getMinecraft().f_28396371;
        float var4 = var3.f_45219594 + (var3.f_03549461 - var3.f_45219594) * f;
        glPushMatrix();
        glRotatef(var4, 1.0F, 0.0F, 0.0F);
        glRotatef(var3.f_74900774 + (var3.f_80130373 - var3.f_74900774) * f, 0.0F, 1.0F, 0.0F);
        C_14999373.m_00064778();
        glPopMatrix();
        C_88708284 var5 = access.stationapi$getStack();
        float var6 = access.stationapi$getMinecraft().f_26407825.m_80119644(C_45510667.m_80489169(var3.f_78826675), C_45510667.m_80489169(var3.f_31030949), C_45510667.m_80489169(var3.f_97691941));
        if (var5 != null) {
            int var7 = C_98888256.f_38445253[var5.f_59294634].m_73217034(var5.m_21098843());
            float var8 = (float)(var7 >> 16 & 255) / 255.0F;
            float var9 = (float)(var7 >> 8 & 255) / 255.0F;
            float var10 = (float)(var7 & 255) / 255.0F;
            glColor4f(var6 * var8, var6 * var9, var6 * var10, 1.0F);
        } else glColor4f(var6, var6, var6, 1.0F);

        if (var5 != null) if (var5.f_59294634 == C_98888256.f_69447318.f_57562535) renderMap(f, var2, var3, var4, var5);
        else if (RendererHolder.RENDERER.getItemModels().getModel(var5) instanceof VanillaBakedModel)
            renderVanilla(f, var2, var3, var5);
        else renderModel(f, var2, var3, var5);
        else renderHand(f, var2, var3);

        glDisable(GL_RESCALE_NORMAL);
        C_14999373.m_94129982();
    }

    private void renderMap(float f, float var2, C_57778754 var3, float var4, C_88708284 var5) {
        glPushMatrix();
        float var16 = 0.8F;
        float var23 = var3.m_73829618(f);
        float var31 = C_45510667.m_61414107(var23 * (float) Math.PI);
        float var40 = C_45510667.m_61414107(C_45510667.m_51290972(var23) * (float) Math.PI);
        glTranslatef(-var40 * 0.4F, C_45510667.m_61414107(C_45510667.m_51290972(var23) * (float) Math.PI * 2.0F) * 0.2F, -var31 * 0.2F);
        var23 = 1.0F - var4 / 45.0F + 0.1F;
        if (var23 < 0.0F) var23 = 0.0F;

        if (var23 > 1.0F) var23 = 1.0F;

        var23 = -C_45510667.m_64246150(var23 * (float) Math.PI) * 0.5F + 0.5F;
        glTranslatef(0.0F, 0.0F * var16 - (1.0F - var2) * 1.2F - var23 * 0.5F + 0.04F, -0.9F * var16);
        glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
        glRotatef(var23 * -85.0F, 0.0F, 0.0F, 1.0F);
        glEnable(GL_RESCALE_NORMAL);
        glBindTexture(3553, access.stationapi$getMinecraft().f_45465196.m_10985437(access.stationapi$getMinecraft().f_28396371.f_22410523, access.stationapi$getMinecraft().f_28396371.m_75979057()));

        for (int var32 = 0; var32 < 2; ++var32) {
            int var41 = var32 * 2 - 1;
            glPushMatrix();
            glTranslatef(-0.0F, -0.6F, 1.1F * (float) var41);
            glRotatef((float) (-45 * var41), 1.0F, 0.0F, 0.0F);
            glRotatef(-90.0F, 0.0F, 0.0F, 1.0F);
            glRotatef(59.0F, 0.0F, 0.0F, 1.0F);
            glRotatef((float) (-65 * var41), 0.0F, 1.0F, 0.0F);
            C_53593123 var11 = C_32232284.f_14776289.m_12262986(access.stationapi$getMinecraft().f_28396371);
            C_34859172 var12 = (C_34859172) var11;
            float var13 = 1.0F;
            glScalef(var13, var13, var13);
            var12.m_22498300();
            glPopMatrix();
        }

        var31 = var3.m_73829618(f);
        var40 = C_45510667.m_61414107(var31 * var31 * (float) Math.PI);
        float var44 = C_45510667.m_61414107(C_45510667.m_51290972(var31) * (float) Math.PI);
        glRotatef(-var40 * 20.0F, 0.0F, 1.0F, 0.0F);
        glRotatef(-var44 * 20.0F, 0.0F, 0.0F, 1.0F);
        glRotatef(-var44 * 80.0F, 1.0F, 0.0F, 0.0F);
        var31 = 0.38F;
        glScalef(var31, var31, var31);
        glRotatef(90.0F, 0.0F, 1.0F, 0.0F);
        glRotatef(180.0F, 0.0F, 0.0F, 1.0F);
        glTranslatef(-1.0F, -1.0F, 0.0F);
        var40 = 0.015625F;
        glScalef(var40, var40, var40);
        access.stationapi$getMinecraft().f_45465196.m_72568250(access.stationapi$getMinecraft().f_45465196.m_33729172("/misc/mapbg.png"));
        C_96603444 var45 = C_96603444.f_99414865;
        glNormal3f(0.0F, 0.0F, -1.0F);
        var45.m_35940071();
        byte var46 = 7;
        var45.m_75942980(-var46, 128 + var46, 0.0D, 0.0D, 1.0D);
        var45.m_75942980(128 + var46, 128 + var46, 0.0D, 1.0D, 1.0D);
        var45.m_75942980(128 + var46, -var46, 0.0D, 1.0D, 0.0D);
        var45.m_75942980(-var46, -var46, 0.0D, 0.0D, 0.0D);
        var45.m_70070273();
        C_88220120 var47 = C_98888256.f_69447318.m_67587820(var5, access.stationapi$getMinecraft().f_26407825);
        access.stationapi$getMapRenderer().m_67759734(access.stationapi$getMinecraft().f_28396371, access.stationapi$getMinecraft().f_45465196, var47);
        glPopMatrix();
    }

    private void renderVanilla(float f, float var2, C_57778754 var3, C_88708284 var5) {
        glPushMatrix();
        float f12 = 0.8f;
        float f4 = var3.m_73829618(f);
        float f3 = C_45510667.m_61414107(f4 * (float)Math.PI);
        float f2 = C_45510667.m_61414107(C_45510667.m_51290972(f4) * (float)Math.PI);
        glTranslatef(-f2 * 0.4f, C_45510667.m_61414107(C_45510667.m_51290972(f4) * (float)Math.PI * 2.0f) * 0.2f, -f3 * 0.2f);
        glTranslatef(0.7f * f12, -0.65f * f12 - (1.0f - var2) * 0.6f, -0.9f * f12);
        glRotatef(45.0f, 0.0f, 1.0f, 0.0f);
        glEnable(GL_RESCALE_NORMAL);
        f4 = var3.m_73829618(f);
        f3 = C_45510667.m_61414107(f4 * f4 * (float)Math.PI);
        f2 = C_45510667.m_61414107(C_45510667.m_51290972(f4) * (float)Math.PI);
        glRotatef(-f3 * 20.0f, 0.0f, 1.0f, 0.0f);
        glRotatef(-f2 * 20.0f, 0.0f, 0.0f, 1.0f);
        glRotatef(-f2 * 80.0f, 1.0f, 0.0f, 0.0f);
        f4 = 0.4f;
        glScalef(f4, f4, f4);
        if (var5.m_23235460().m_49298884()) glRotatef(180.0f, 0.0f, 1.0f, 0.0f);
        this.renderItem3D(var3, var5);
        glPopMatrix();
    }

    private void renderModel(float f, float var2, C_57778754 var3, C_88708284 var5) {
        glPushMatrix();
        float var17 = var3.m_73829618(f);
        glTranslated(0.56, var2 * 0.6 - 1.12, -0.72);
        glEnable(GL_RESCALE_NORMAL);

        float fu = -0.4f * C_45510667.m_61414107(C_45510667.m_51290972(var17) * (float) Math.PI);
        float g = 0.2f * C_45510667.m_61414107(C_45510667.m_51290972(var17) * ((float) Math.PI * 2));
        float h = -0.2f * C_45510667.m_61414107(var17 * (float) Math.PI);
        glTranslatef(fu, g, h);
        applySwingOffset(var17);

        if (var5.m_23235460().m_49298884()) glRotatef(180, 0, 1, 0);

        SpriteAtlasTexture atlas = StationRenderAPI.getBakedModelManager().getAtlas(Atlases.GAME_ATLAS_TEXTURE);
        atlas.bindTexture();
        C_96603444.f_99414865.m_35940071();
        this.renderItem(var3, var5, ModelTransformation.Mode.FIRST_PERSON_RIGHT_HAND);
        C_96603444.f_99414865.m_70070273();
        glPopMatrix();
    }

    private void renderHand(float f, float var2, C_57778754 var3) {
        glPushMatrix();
        float var15 = 0.8F;
        float var20 = var3.m_73829618(f);
        float var28 = C_45510667.m_61414107(var20 * (float) Math.PI);
        float var37 = C_45510667.m_61414107(C_45510667.m_51290972(var20) * (float) Math.PI);
        glTranslatef(-var37 * 0.3F, C_45510667.m_61414107(C_45510667.m_51290972(var20) * (float) Math.PI * 2.0F) * 0.4F, -var28 * 0.4F);
        glTranslatef(0.8F * var15, -0.75F * var15 - (1.0F - var2) * 0.6F, -0.9F * var15);
        glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
        glEnable(GL_RESCALE_NORMAL);
        var20 = var3.m_73829618(f);
        var28 = C_45510667.m_61414107(var20 * var20 * (float) Math.PI);
        var37 = C_45510667.m_61414107(C_45510667.m_51290972(var20) * (float) Math.PI);
        glRotatef(var37 * 70.0F, 0.0F, 1.0F, 0.0F);
        glRotatef(-var28 * 20.0F, 0.0F, 0.0F, 1.0F);
        glBindTexture(0xde1, access.stationapi$getMinecraft().f_45465196.m_10985437(access.stationapi$getMinecraft().f_28396371.f_22410523, access.stationapi$getMinecraft().f_28396371.m_75979057()));
        glTranslatef(-1.0F, 3.6F, 3.5F);
        glRotatef(120.0F, 0.0F, 0.0F, 1.0F);
        glRotatef(200.0F, 1.0F, 0.0F, 0.0F);
        glRotatef(-135.0F, 0.0F, 1.0F, 0.0F);
        glScalef(1.0F, 1.0F, 1.0F);
        glTranslatef(5.6F, 0.0F, 0.0F);
        C_53593123 var22 = C_32232284.f_14776289.m_12262986(access.stationapi$getMinecraft().f_28396371);
        C_34859172 var30 = (C_34859172) var22;
        var37 = 1.0F;
        glScalef(var37, var37, var37);
        var30.m_22498300();
        glPopMatrix();
    }

    private void applySwingOffset(float swingProgress) {
        float f = C_45510667.m_61414107(swingProgress * swingProgress * (float)Math.PI);
        glRotatef(45.0f + f * -20.0f, 0, 1, 0);
        float g = C_45510667.m_61414107(C_45510667.m_51290972(swingProgress) * (float)Math.PI);
        glRotatef(g * -20.0f, 0, 0, 1);
        glRotatef(g * -80.0f, 1, 0, 0);
        glRotatef(-45.0f, 0, 1, 0);
    }

    public void renderItem(C_74425583 entity, C_88708284 item, ModelTransformation.Mode renderMode) {
        if (item == null || item.f_59294634 == 0 || item.f_60602012 < 1) return;
        RendererHolder.RENDERER.renderItem(entity, item, renderMode, entity.f_94306729, entity.m_95186532(1), entity.f_11112215 + renderMode.ordinal());
    }
}
