package net.modificationstation.stationapi.mixin.arsenic.client;

import net.minecraft.unmapped.C_47540058;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_47540058.class)
public interface ParticleAccessor {
    @Accessor
    int getTextureId();

    @Accessor
    float getPrevU();

    @Accessor
    float getPrevV();

    @Accessor
    float getScale();

    @Accessor
    float getRed();

    @Accessor
    float getGreen();

    @Accessor
    float getBlue();
}
