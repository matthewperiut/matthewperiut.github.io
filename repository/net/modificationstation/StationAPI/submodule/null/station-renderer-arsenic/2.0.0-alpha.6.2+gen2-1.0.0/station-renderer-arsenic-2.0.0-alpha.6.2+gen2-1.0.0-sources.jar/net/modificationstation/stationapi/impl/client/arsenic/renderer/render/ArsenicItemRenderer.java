package net.modificationstation.stationapi.impl.client.arsenic.renderer.render;

import lombok.val;
import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_06774341;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_82920792;
import net.minecraft.unmapped.C_84615110;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_96603444;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.block.States;
import net.modificationstation.stationapi.api.client.StationRenderAPI;
import net.modificationstation.stationapi.api.client.model.item.ItemWithRenderer;
import net.modificationstation.stationapi.api.client.render.model.BakedModel;
import net.modificationstation.stationapi.api.client.render.model.VanillaBakedModel;
import net.modificationstation.stationapi.api.client.render.model.json.ModelTransformation;
import net.modificationstation.stationapi.api.client.texture.Sprite;
import net.modificationstation.stationapi.api.client.texture.SpriteAtlasTexture;
import net.modificationstation.stationapi.api.client.texture.atlas.Atlases;
import net.modificationstation.stationapi.api.client.texture.atlas.CustomAtlasProvider;
import net.modificationstation.stationapi.api.item.BlockItemForm;
import net.modificationstation.stationapi.mixin.arsenic.client.EntityRendererAccessor;
import net.modificationstation.stationapi.mixin.arsenic.client.ItemRendererAccessor;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL12.GL_RESCALE_NORMAL;

public final class ArsenicItemRenderer {

    private final C_84615110 itemRenderer;
    private final ItemRendererAccessor itemRendererAccessor;
    private final EntityRendererAccessor entityRendererAccessor;

    public ArsenicItemRenderer(C_84615110 itemRenderer) {
        this.itemRenderer = itemRenderer;
        this.itemRendererAccessor = (ItemRendererAccessor) this.itemRenderer;
        this.entityRendererAccessor = (EntityRendererAccessor) this.itemRenderer;
    }

    public void render(C_06774341 item, double x, double y, double z, float rotation, float delta) {
        itemRendererAccessor.getRandom().setSeed(187L);
        C_88708284 var10 = item.f_15367317;
        float var11 = C_45510667.m_61414107(((float)item.f_48081161 + delta) / 10.0F + item.f_66400805) * 0.1F + 0.1F;
        float var12 = (((float)item.f_48081161 + delta) / 20.0F + item.f_66400805) * (180F / (float)Math.PI);
        byte renderedAmount = (byte) (item.f_15367317.f_60602012 > 20 ? 4 : item.f_15367317.f_60602012 > 5 ? 3 : item.f_15367317.f_60602012 > 1 ? 2 : 1);

        glEnable(GL_RESCALE_NORMAL);
        SpriteAtlasTexture atlas = StationRenderAPI.getBakedModelManager().getAtlas(Atlases.GAME_ATLAS_TEXTURE);
        if (var10.f_59294634 != States.AIR.get().getBlock().f_84602679) {
            BakedModel model = RendererHolder.RENDERER.getModel(var10, item.f_94306729, null, item.f_11112215);
            if (model instanceof VanillaBakedModel) {
                renderVanilla(item, (float) x, (float) y, (float) z, delta, var10, var11, var12, renderedAmount, atlas);
            } else if (!model.isBuiltin()) {
                renderModel(item, (float) x, (float) y, (float) z, delta, var10, var11, var12, renderedAmount, atlas, model);
            }
        }

        glDisable(GL_RESCALE_NORMAL);
    }

    private void renderVanilla(C_06774341 item, float x, float y, float z, float delta, C_88708284 var10, float var11, float var12, byte renderedAmount, SpriteAtlasTexture atlas) {
        glPushMatrix();
        glTranslatef(x, y + var11, z);
        C_81592558 block;
        if (var10.m_23235460() instanceof BlockItemForm blockItemForm && C_03670941.m_23090332((block = blockItemForm.getBlock()).m_43136364())) {
            glRotatef(var12, 0.0F, 1.0F, 0.0F);
            atlas.bindTexture();
            float var28 = 0.25F;
            if (!block.m_76696200() && block.f_84602679 != C_81592558.f_66929948.f_84602679 && block.m_43136364() != 16) {
                var28 = 0.5F;
            }

            glScalef(var28, var28, var28);

            for (int var29 = 0; var29 < renderedAmount; ++var29) {
                glPushMatrix();
                if (var29 > 0) {
                    float var30 = (itemRendererAccessor.getRandom().nextFloat() * 2.0F - 1.0F) * 0.2F / var28;
                    float var31 = (itemRendererAccessor.getRandom().nextFloat() * 2.0F - 1.0F) * 0.2F / var28;
                    float var32 = (itemRendererAccessor.getRandom().nextFloat() * 2.0F - 1.0F) * 0.2F / var28;
                    glTranslatef(var30, var31, var32);
                }

                itemRendererAccessor.getBlockRenderer().m_96377958(block, var10.m_21098843(), item.m_95186532(delta));
                glPopMatrix();
            }
        } else {
            glScalef(0.5F, 0.5F, 0.5F);
            int var14 = var10.m_98662398();
            atlas.bindTexture();
            Sprite texture = atlas.getSprite(((CustomAtlasProvider) var10.m_23235460()).getAtlas().getTexture(var14).getId());

            C_96603444 var15 = C_96603444.f_99414865;
            float var20 = 1.0F;
            float var21 = 0.5F;
            float var22 = 0.25F;
            if (itemRenderer.f_24956313) {
                int var23 = C_98888256.f_38445253[var10.f_59294634].m_73217034(var10.m_21098843());
                float var24 = (float) ((var23 >> 16) & 255) / 255.0F;
                float var25 = (float) ((var23 >> 8) & 255) / 255.0F;
                float var26 = (float) (var23 & 255) / 255.0F;
                float var27 = item.m_95186532(delta);
                glColor4f(var24 * var27, var25 * var27, var26 * var27, 1.0F);
            }

            for (int var33 = 0; var33 < renderedAmount; ++var33) {
                glPushMatrix();
                if (var33 > 0) {
                    float var34 = (itemRendererAccessor.getRandom().nextFloat() * 2.0F - 1.0F) * 0.3F;
                    float var35 = (itemRendererAccessor.getRandom().nextFloat() * 2.0F - 1.0F) * 0.3F;
                    float var36 = (itemRendererAccessor.getRandom().nextFloat() * 2.0F - 1.0F) * 0.3F;
                    glTranslatef(var34, var35, var36);
                }

                glRotatef(180.0F - entityRendererAccessor.getDispatcher().f_72637476, 0.0F, 1.0F, 0.0F);
                var15.m_35940071();
                var15.m_86080397(0.0F, 1.0F, 0.0F);
                var15.m_75942980(0.0F - var21, 0.0F - var22, 0.0D, texture.getMinU(), texture.getMaxV());
                var15.m_75942980(var20 - var21, 0.0F - var22, 0.0D, texture.getMaxU(), texture.getMaxV());
                var15.m_75942980(var20 - var21, 1.0F - var22, 0.0D, texture.getMaxU(), texture.getMinV());
                var15.m_75942980(0.0F - var21, 1.0F - var22, 0.0D, texture.getMinU(), texture.getMinV());
                var15.m_70070273();
                glPopMatrix();
            }
        }
        glPopMatrix();
    }

    private void renderModel(C_06774341 item, float x, float y, float z, float delta, C_88708284 var10, float var11, float var12, byte renderedAmount, SpriteAtlasTexture atlas, BakedModel model) {
        glPushMatrix();
        atlas.bindTexture();
        glTranslatef(x, y + var11 + 0.25F * model.getTransformation().getTransformation(ModelTransformation.Mode.GROUND).scale.getY(), z);

        val sideLit = model.isSideLit();
        C_96603444 tessellator = C_96603444.f_99414865;

        if (sideLit) glRotatef(var12, 0, 1, 0);

        for (int var29 = 0; var29 < renderedAmount; ++var29) {
            glPushMatrix();
            if (var29 > 0)
                glTranslatef(
                        (itemRendererAccessor.getRandom().nextFloat() * 2 - 1) * .2F,
                        (itemRendererAccessor.getRandom().nextFloat() * 2 - 1) * .2F,
                        (itemRendererAccessor.getRandom().nextFloat() * 2 - 1) * .2F
                );

            if (!sideLit)
                glRotatef(180 - entityRendererAccessor.getDispatcher().f_72637476, 0, 1, 0);

            tessellator.m_35940071();
            RendererHolder.RENDERER.renderItem(var10, ModelTransformation.Mode.GROUND, item.m_95186532(delta), model);
            tessellator.m_70070273();
            glPopMatrix();
        }
        glPopMatrix();
    }

    public void renderItemOnGui(C_23014920 textRenderer, C_82920792 textureManager, C_88708284 itemStack, int x, int y, CallbackInfo ci) {
        if (itemStack != null) {
            C_98888256 item = itemStack.m_23235460();
            if (item instanceof ItemWithRenderer renderer) {
                renderer.renderItemOnGui(itemRenderer, textRenderer, textureManager, itemStack, x, y);
                ci.cancel();
            } else if (!(RendererHolder.RENDERER.getItemModels().getModel(itemStack) instanceof VanillaBakedModel)) { // TODO: implement a better check
                StationRenderAPI.getBakedModelManager().getAtlas(Atlases.GAME_ATLAS_TEXTURE).bindTexture();
                RendererHolder.RENDERER.renderInGuiWithOverrides(itemStack, x, y);
                ci.cancel();
            }
        }
    }

    public void renderItemOnGui(C_23014920 textRenderer, C_82920792 textureManager, int id, int damage, int texture, int x, int y) {
        C_98888256 item = C_98888256.f_38445253[id];
        if (item instanceof ItemWithRenderer renderer) {
            renderer.renderItemOnGui(itemRenderer, textRenderer, textureManager, id, damage, texture, x, y);
            return;
        }
        SpriteAtlasTexture atlas = StationRenderAPI.getBakedModelManager().getAtlas(Atlases.GAME_ATLAS_TEXTURE);
        C_81592558 block;
        if (item instanceof BlockItemForm blockItemForm && C_03670941.m_23090332((block = blockItemForm.getBlock()).m_43136364())) {
            atlas.bindTexture();
            glPushMatrix();
            glTranslatef((float)(x - 2), (float)(y + 3), -3.0F);
            glScalef(10.0F, 10.0F, 10.0F);
            glTranslatef(1.0F, 0.5F, 1.0F);
            glScalef(1.0F, 1.0F, -1.0F);
            glRotatef(210.0F, 1.0F, 0.0F, 0.0F);
            glRotatef(45.0F, 0.0F, 1.0F, 0.0F);
            int var15 = item.m_73217034(damage);
            float var16 = (float)((var15 >> 16) & 255) / 255.0F;
            float var12 = (float)((var15 >> 8) & 255) / 255.0F;
            float var13 = (float)(var15 & 255) / 255.0F;
            if (itemRenderer.f_24956313) {
                glColor4f(var16, var12, var13, 1.0F);
            }

            glRotatef(-90.0F, 0.0F, 1.0F, 0.0F);
            itemRendererAccessor.getBlockRenderer().f_22802101 = itemRenderer.f_24956313;
            itemRendererAccessor.getBlockRenderer().m_96377958(block, damage, 1.0F);
            itemRendererAccessor.getBlockRenderer().f_22802101 = true;
            glPopMatrix();
        } else if (texture >= 0) {
            glDisable(GL_LIGHTING);
            atlas.bindTexture();
            Sprite sprite = atlas.getSprite(((CustomAtlasProvider) item).getAtlas().getTexture(texture).getId());

            int var8 = item.m_73217034(damage);
            float var9 = (float)((var8 >> 16) & 255) / 255.0F;
            float var10 = (float)((var8 >> 8) & 255) / 255.0F;
            float var11 = (float)(var8 & 255) / 255.0F;
            if (itemRenderer.f_24956313) {
                glColor4f(var9, var10, var11, 1.0F);
            }

            renderItemQuad(x, y, sprite.getMinU(), sprite.getMinV(), sprite.getMaxU(), sprite.getMaxV());
            glEnable(GL_LIGHTING);
        }

        glEnable(GL_CULL_FACE);
    }

    public void renderItemQuad(int x, int y, double startU, double startV, double endU, double endV) {
        C_96603444 var10 = C_96603444.f_99414865;
        var10.m_35940071();
        var10.m_75942980(x, y + 16, 0, startU, endV);
        var10.m_75942980(x + 16, y + 16, 0, endU, endV);
        var10.m_75942980(x + 16, y, 0, endU, startV);
        var10.m_75942980(x, y, 0, startU, startV);
        var10.m_70070273();
    }
}
