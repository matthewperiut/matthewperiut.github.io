package net.modificationstation.stationapi.mixin.arsenic.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_06774341;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_53593123;
import net.minecraft.unmapped.C_82920792;
import net.minecraft.unmapped.C_84615110;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.impl.client.arsenic.renderer.render.ArsenicItemRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_84615110.class)
@Environment(EnvType.CLIENT)
abstract class ItemRendererMixin extends C_53593123 {
    @Unique
    private final ArsenicItemRenderer arsenic_plugin = new ArsenicItemRenderer((C_84615110) (Object) this);

    /**
     * @reason there's no saving notch code
     * @author mine_diver
     */
    @Overwrite
    public void render(C_06774341 arg, double d, double d1, double d2, float f, float f1) {
        arsenic_plugin.render(arg, d, d1, d2, f, f1);
    }

    /**
     * @reason there's no saving notch code
     * @author mine_diver
     */
    @Overwrite
    public void renderGuiItem(C_23014920 textRenderer, C_82920792 textureManagerArg, int itemId, int damage, int textureIndex, int textureX, int textureY) {
        arsenic_plugin.renderItemOnGui(textRenderer, textureManagerArg, itemId, damage, textureIndex, textureX, textureY);
    }

    @Inject(
            method = "renderGuiItem(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/client/texture/TextureManager;Lnet/minecraft/item/ItemStack;II)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void stationapi_onRenderItemOnGuiItemStack(C_23014920 arg1, C_82920792 arg2, C_88708284 i, int j, int par5, CallbackInfo ci) {
        arsenic_plugin.renderItemOnGui(arg1, arg2, i, j, par5, ci);
    }

    /**
     * @reason there's no saving notch code
     * @author mine_diver
     */
    @Overwrite
    public void drawTexture(int i, int j, int k, int i1, int j1, int k1) {
        arsenic_plugin.renderItemQuad(i, j, k, i1, j1, k1);
    }
}
