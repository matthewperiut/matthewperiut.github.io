package net.modificationstation.stationapi.api.world.dimension;

import net.minecraft.unmapped.C_40996800;
import net.modificationstation.stationapi.impl.block.NetherPortalImpl;

public interface TeleportationManager {

    default void switchDimension(C_40996800 player) {
        NetherPortalImpl.switchDimension(player);
    }
}
