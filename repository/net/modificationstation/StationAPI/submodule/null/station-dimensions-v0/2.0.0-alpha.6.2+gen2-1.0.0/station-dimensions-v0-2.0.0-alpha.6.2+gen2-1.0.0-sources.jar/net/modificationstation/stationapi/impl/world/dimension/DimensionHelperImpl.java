package net.modificationstation.stationapi.impl.world.dimension;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_87391831;
import net.modificationstation.stationapi.api.util.Identifier;

public abstract class DimensionHelperImpl {

    public abstract void switchDimension(C_40996800 player, Identifier destination, double scale, C_87391831 travelAgent);
}
