package net.modificationstation.stationapi.impl.server.world.dimension;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.unmapped.C_04694721;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_70668269;
import net.minecraft.unmapped.C_87391831;
import net.modificationstation.stationapi.api.registry.DimensionRegistry;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.impl.world.dimension.DimensionHelperImpl;

import static net.modificationstation.stationapi.api.world.dimension.VanillaDimensions.OVERWORLD;

public class DimensionHelperServerImpl extends DimensionHelperImpl {

    @Override
    public void switchDimension(C_40996800 player, Identifier destination, double scale, C_87391831 travelAgent) {
        //noinspection deprecation
        MinecraftServer server = (MinecraftServer) FabricLoader.getInstance().getGameInstance();
        C_49202226 serverPlayer = (C_49202226) player;
        C_70668269 var2 = server.m_54705229(serverPlayer.f_15409937);
        DimensionRegistry dimensions = DimensionRegistry.INSTANCE;

        int overworldSerial = dimensions.getLegacyId(OVERWORLD).orElseThrow(() -> new IllegalStateException("Overworld not found!"));
        int destinationSerial = dimensions.getLegacyId(destination).orElseThrow(() -> new IllegalArgumentException("Unknown dimension: " + destination + "!"));

        player.f_15409937 = player.f_15409937 == destinationSerial ? overworldSerial : destinationSerial;

        C_70668269 var4 = server.m_54705229(serverPlayer.f_15409937);
        serverPlayer.f_70275341.m_61088315(new C_04694721((byte)serverPlayer.f_15409937));
        var2.m_31627685(serverPlayer);
        serverPlayer.f_42219270 = false;
        double var5 = serverPlayer.f_78826675;
        double var7 = serverPlayer.f_97691941;
        if (serverPlayer.f_15409937 == destinationSerial) {
            var5 *= scale;
            var7 *= scale;
        } else {
            var5 /= scale;
            var7 /= scale;
        }
        serverPlayer.m_12877971(var5, serverPlayer.f_31030949, var7, serverPlayer.f_80130373, serverPlayer.f_03549461);
        if (serverPlayer.m_48190713())
            var2.m_15238577(serverPlayer, false);

        if (serverPlayer.m_48190713()) {
            var4.m_09670988(serverPlayer);
            serverPlayer.m_12877971(var5, serverPlayer.f_31030949, var7, serverPlayer.f_80130373, serverPlayer.f_03549461);
            var4.m_15238577(serverPlayer, false);
            var4.f_55499904.f_95421973 = true;
            travelAgent.m_72853764(var4, serverPlayer);
            var4.f_55499904.f_95421973 = false;
        }

        server.f_65897993.m_31698239(serverPlayer);
        serverPlayer.f_70275341.m_40197477(serverPlayer.f_78826675, serverPlayer.f_31030949, serverPlayer.f_97691941, serverPlayer.f_80130373, serverPlayer.f_03549461);
        serverPlayer.m_67289058(var4);
        server.f_65897993.m_18431033(serverPlayer, var4);
        server.f_65897993.m_44114554(serverPlayer);
    }
}
