package net.modificationstation.stationapi.mixin.dimension.server;

import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_99660737;
import net.modificationstation.stationapi.api.registry.DimensionRegistry;
import net.modificationstation.stationapi.api.world.dimension.VanillaDimensions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(C_99660737.class)
class ServerPlayNetworkHandlerMixin {
    @Shadow private C_49202226 player;

    @ModifyConstant(
            method = "onPlayerRespawn",
            constant = @Constant(intValue = 0)
    )
    private int stationapi_modifyRespawnDimension(int original) {
        return player.f_94306729.f_00524883.m_25703618() ? player.f_15409937 : DimensionRegistry.INSTANCE.getLegacyId(VanillaDimensions.OVERWORLD).orElseThrow(() -> new IllegalStateException("Overworld not found!"));
    }
}
