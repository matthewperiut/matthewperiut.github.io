package net.modificationstation.stationapi.mixin.dimension;

import net.minecraft.unmapped.C_90532916;
import net.modificationstation.stationapi.api.registry.DimensionRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_90532916.class)
class DimensionMixin {
    @Shadow public int id;

    @Inject(
            method = "fromId",
            at = @At("HEAD"),
            cancellable = true
    )
    private static void stationapi_getDimension(int id, CallbackInfoReturnable<C_90532916> cir) {
        cir.setReturnValue(DimensionRegistry.INSTANCE.getByLegacyId(id).map(dimensionFactory -> dimensionFactory.factory.get()).orElse(null));
    }
}
