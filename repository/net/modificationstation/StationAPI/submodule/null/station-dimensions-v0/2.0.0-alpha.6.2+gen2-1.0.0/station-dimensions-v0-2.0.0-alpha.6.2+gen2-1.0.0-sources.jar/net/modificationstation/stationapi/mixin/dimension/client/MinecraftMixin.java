package net.modificationstation.stationapi.mixin.dimension.client;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_57778754;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.registry.DimensionRegistryEvent;
import net.modificationstation.stationapi.api.registry.DimensionRegistry;
import net.modificationstation.stationapi.api.world.dimension.DimensionHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Minecraft.class)
class MinecraftMixin {
    @Shadow public C_57778754 player;

    @Inject(
            method = "init",
            at = @At("TAIL")
    )
    private void stationapi_initDimensions(CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(new DimensionRegistryEvent());
    }

    @Redirect(
            method = "respawnPlayer(ZI)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/Minecraft;changeDimension()V"
            )
    )
    private void stationapi_switchDimension(Minecraft minecraft) {
        DimensionHelper.switchDimension(player, DimensionRegistry.INSTANCE.getIdByLegacyId(player.f_15409937).orElseThrow(() -> new IllegalArgumentException("Unknown dimension: " + player.f_15409937 + "!")), 1, null);
    }
}
