package net.modificationstation.stationapi.api.block;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_87391831;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.api.world.dimension.DimensionHelper;
import net.modificationstation.stationapi.api.world.dimension.TeleportationManager;

public interface CustomPortal extends TeleportationManager {

    @Override
    default void switchDimension(C_40996800 player) {
        DimensionHelper.switchDimension(player, getDimension(player), getDimensionScale(player), getTravelAgent(player));
    }

    Identifier getDimension(C_40996800 player);

    default double getDimensionScale(C_40996800 player) {
        return 1;
    }

    C_87391831 getTravelAgent(C_40996800 player);
}
