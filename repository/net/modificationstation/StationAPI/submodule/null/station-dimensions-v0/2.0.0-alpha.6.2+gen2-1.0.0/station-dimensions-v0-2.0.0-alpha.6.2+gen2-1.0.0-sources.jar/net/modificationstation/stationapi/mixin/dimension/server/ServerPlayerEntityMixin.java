package net.modificationstation.stationapi.mixin.dimension.server;

import net.minecraft.unmapped.C_29639016;
import net.minecraft.unmapped.C_49202226;
import net.modificationstation.stationapi.api.entity.HasTeleportationManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_49202226.class)
abstract class ServerPlayerEntityMixin implements HasTeleportationManager {
    @Redirect(
            method = "playerTick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/PlayerManager;changePlayerDimension(Lnet/minecraft/entity/player/ServerPlayerEntity;)V"
            )
    )
    private void stationapi_overrideSwitchDimensions(C_29639016 serverPlayerConnectionManager, C_49202226 serverPlayer) {
        //noinspection DataFlowIssue
        getTeleportationManager().switchDimension((C_49202226) (Object) this);
    }
}
