package net.modificationstation.stationapi.impl.block;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.server.MinecraftServer;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_49202226;
import net.modificationstation.stationapi.api.util.SideUtil;

public class NetherPortalImpl {

    public static void switchDimension(C_40996800 player) {
        //noinspection Convert2MethodRef
        SideUtil.run(() -> switchDimensionClient(), () -> switchDimensionServer(player));
    }

    @Environment(EnvType.SERVER)
    private static void switchDimensionServer(C_40996800 player) {
        //noinspection deprecation
        ((MinecraftServer) FabricLoader.getInstance().getGameInstance()).f_65897993.m_97100336((C_49202226) player);
    }

    @Environment(EnvType.CLIENT)
    private static void switchDimensionClient() {
        //noinspection deprecation
        ((Minecraft) FabricLoader.getInstance().getGameInstance()).m_28966604();
    }
}
