package net.modificationstation.stationapi.mixin.dimension.client;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_57778754;
import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.api.entity.HasTeleportationManager;
import net.modificationstation.stationapi.api.registry.DimensionRegistry;
import net.modificationstation.stationapi.api.world.dimension.VanillaDimensions;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_57778754.class)
abstract class ClientPlayerEntityMixin extends C_40996800 implements HasTeleportationManager {
    private ClientPlayerEntityMixin(C_64041439 arg) {
        super(arg);
    }

    @ModifyConstant(
            method = "respawn",
            constant = @Constant(intValue = 0)
    )
    private int stationapi_getRespawnDimension(int constant) {
        return f_94306729.f_00524883.m_25703618() ? f_15409937 : DimensionRegistry.INSTANCE.getLegacyId(VanillaDimensions.OVERWORLD).orElseThrow(() -> new IllegalStateException("Couldn't find overworld dimension in the registry!"));
    }

    @Redirect(
            method = "tickMovement",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/Minecraft;changeDimension()V"
            )
    )
    private void stationapi_overrideSwitchDimensions(Minecraft minecraft) {
        //noinspection DataFlowIssue
        getTeleportationManager().switchDimension((C_57778754) (Object) this);
    }
}
