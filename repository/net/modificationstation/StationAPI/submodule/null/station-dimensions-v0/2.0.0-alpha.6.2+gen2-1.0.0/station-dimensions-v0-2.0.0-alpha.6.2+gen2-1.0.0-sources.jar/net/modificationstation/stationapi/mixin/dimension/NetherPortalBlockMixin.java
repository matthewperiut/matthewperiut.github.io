package net.modificationstation.stationapi.mixin.dimension;

import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_71940803;
import net.modificationstation.stationapi.api.entity.HasTeleportationManager;
import net.modificationstation.stationapi.api.world.dimension.TeleportationManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_71940803.class)
class NetherPortalBlockMixin implements TeleportationManager {
    @Inject(
            method = "onEntityCollision",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/Entity;tickPortalCooldown()V"
            )
    )
    private void stationapi_onEntityCollision(C_64041439 world, int x, int y, int z, C_42232651 entityBase, CallbackInfo ci) {
        if (entityBase instanceof HasTeleportationManager manager)
            manager.setTeleportationManager(this);
    }
}
