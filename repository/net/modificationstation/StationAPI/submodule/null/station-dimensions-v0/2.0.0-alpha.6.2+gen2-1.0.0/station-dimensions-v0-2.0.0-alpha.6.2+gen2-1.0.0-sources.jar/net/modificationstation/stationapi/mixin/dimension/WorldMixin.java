package net.modificationstation.stationapi.mixin.dimension;

import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_64676926;
import net.modificationstation.stationapi.api.registry.DimensionRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_64041439.class)
class WorldMixin {
    @Shadow protected C_64676926 properties;

    @Redirect(
            method = "<init>(Lnet/minecraft/world/storage/WorldStorage;Ljava/lang/String;JLnet/minecraft/world/dimension/Dimension;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/WorldProperties;getDimensionId()I"
            )
    )
    private int stationapi_modIf(C_64676926 worldProperties) {
        return DimensionRegistry.INSTANCE.getByLegacyId(worldProperties.m_49268608()).map(dimensionSupplier -> -1).orElse(0);
    }

    @ModifyConstant(
            method = "<init>(Lnet/minecraft/world/storage/WorldStorage;Ljava/lang/String;JLnet/minecraft/world/dimension/Dimension;)V",
            constant = @Constant(
                    intValue = -1,
                    ordinal = 1
            )
    )
    private int stationapi_getDimensionId(int constant) {
        return properties.m_49268608();
    }
}
