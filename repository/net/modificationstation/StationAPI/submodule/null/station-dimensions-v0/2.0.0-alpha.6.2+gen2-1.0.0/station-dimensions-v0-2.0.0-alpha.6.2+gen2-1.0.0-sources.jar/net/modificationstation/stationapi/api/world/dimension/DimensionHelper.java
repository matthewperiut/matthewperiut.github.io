package net.modificationstation.stationapi.api.world.dimension;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_87391831;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.api.util.SideUtil;
import net.modificationstation.stationapi.impl.client.world.dimension.DimensionHelperClientImpl;
import net.modificationstation.stationapi.impl.server.world.dimension.DimensionHelperServerImpl;
import net.modificationstation.stationapi.impl.world.dimension.DimensionHelperImpl;

public class DimensionHelper {

    @SuppressWarnings("Convert2MethodRef") // Method references load their target classes on both sides, causing crashes.
    private static final DimensionHelperImpl INSTANCE = SideUtil.get(() -> new DimensionHelperClientImpl(), () -> new DimensionHelperServerImpl());

    public static void switchDimension(C_40996800 player, Identifier destination, double scale, C_87391831 travelAgent) {
        INSTANCE.switchDimension(player, destination, scale, travelAgent);
    }
}
