package net.modificationstation.stationapi.impl.client.world.dimension;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_76536438;
import net.minecraft.unmapped.C_87391831;
import net.minecraft.unmapped.C_90532916;
import net.modificationstation.stationapi.api.client.world.dimension.TravelMessageProvider;
import net.modificationstation.stationapi.api.registry.DimensionRegistry;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.impl.world.dimension.DimensionHelperImpl;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;
import static net.modificationstation.stationapi.api.world.dimension.VanillaDimensions.OVERWORLD;

public class DimensionHelperClientImpl extends DimensionHelperImpl {

    @Override
    public void switchDimension(C_40996800 player, Identifier destination, double scale, C_87391831 travelAgent) {

        DimensionRegistry dimensions = DimensionRegistry.INSTANCE;

        //noinspection deprecation
        Minecraft game = (Minecraft) FabricLoader.getInstance().getGameInstance();
        int overworldSerial = dimensions.getLegacyId(OVERWORLD).orElseThrow(() -> new IllegalStateException("Couldn't find overworld dimension in the registry!"));
        int destinationSerial = dimensions.getLegacyId(destination).orElseThrow(() -> new IllegalArgumentException("Unknown dimension: " + destination + "!"));

        player.f_15409937 = player.f_15409937 == destinationSerial ? overworldSerial : destinationSerial;

        game.f_26407825.m_28736857(player);
        player.f_42219270 = false;
        double var1 = player.f_78826675;
        double var3 = player.f_97691941;
        if (player.f_15409937 == destinationSerial) {
            var1 *= scale;
            var3 *= scale;
            player.m_12877971(var1, player.f_31030949, var3, player.f_80130373, player.f_03549461);
            if (player.m_48190713()) {
                game.f_26407825.m_15238577(player, false);
            }

            C_90532916 dimension = C_90532916.m_09825512(destinationSerial);
            C_64041439 var10 = new C_64041439(game.f_26407825, dimension);
            game.m_04848709(var10, C_76536438.m_00994426(dimension instanceof TravelMessageProvider provider ? provider.getEnteringTranslationKey() : "gui." + NAMESPACE + ".entering", destination), player);
        } else {
            var1 /= scale;
            var3 /= scale;
            player.m_12877971(var1, player.f_31030949, var3, player.f_80130373, player.f_03549461);
            if (player.m_48190713()) {
                game.f_26407825.m_15238577(player, false);
            }

            C_64041439 var12 = new C_64041439(game.f_26407825, C_90532916.m_09825512(overworldSerial));
            game.m_04848709(var12, C_76536438.m_00994426(player.f_94306729.f_00524883 instanceof TravelMessageProvider provider ? provider.getLeavingTranslationKey() : "gui." + NAMESPACE + ".leaving", destination), player);
        }

        player.f_94306729 = game.f_26407825;
        if (player.m_48190713()) {
            player.m_12877971(var1, player.f_31030949, var3, player.f_80130373, player.f_03549461);
            game.f_26407825.m_15238577(player, false);
            travelAgent.m_72853764(game.f_26407825, player);
        }
    }
}
