package net.modificationstation.stationapi.impl.client.resource;

import lombok.experimental.UtilityClass;
import net.minecraft.unmapped.C_96603444;

@UtilityClass
public class ReloadScreenTessellatorHolder {
    public C_96603444 reloadScreenTessellator;
}
