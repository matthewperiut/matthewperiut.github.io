package net.modificationstation.stationapi.mixin.resourceloader.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.zip.ZipFile;
import net.minecraft.unmapped.C_55615542;

@Mixin(C_55615542.class)
public interface ZipTexturePackAccessor {
    @Accessor
    ZipFile getZip();
}
