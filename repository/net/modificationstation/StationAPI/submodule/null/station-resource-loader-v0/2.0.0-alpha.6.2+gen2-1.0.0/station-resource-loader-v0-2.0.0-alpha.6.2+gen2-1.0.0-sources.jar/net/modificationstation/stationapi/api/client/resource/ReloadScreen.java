package net.modificationstation.stationapi.api.client.resource;

import com.google.common.primitives.Floats;
import com.google.common.primitives.Longs;
import it.unimi.dsi.fastutil.doubles.Double2DoubleFunction;
import it.unimi.dsi.fastutil.longs.Long2DoubleFunction;
import lombok.val;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_96603444;
import net.modificationstation.stationapi.api.resource.ResourceReload;
import net.modificationstation.stationapi.api.util.math.ColorHelper;
import net.modificationstation.stationapi.config.LoadingScreenOption;
import net.modificationstation.stationapi.config.StationConfig;
import net.modificationstation.stationapi.impl.client.resource.ReloadScreenManagerImpl;

import java.util.Optional;
import java.util.Random;
import java.util.concurrent.CompletionException;
import java.util.function.*;

import static java.util.Map.of;
import static net.modificationstation.stationapi.api.StationAPI.LOGGER;
import static net.modificationstation.stationapi.api.util.math.MathHelper.ceil;
import static net.modificationstation.stationapi.api.util.math.MathHelper.lerp;
import static org.lwjgl.opengl.GL11.*;

@SuppressWarnings("UnstableApiUsage")
class ReloadScreen extends C_85740840 {
    private static final long MAX_FPS = 60;
    private static final int BACKGROUND_COLOR_DEFAULT_RED = 0x35;
    private static final int BACKGROUND_COLOR_DEFAULT_GREEN = 0x86;
    private static final int BACKGROUND_COLOR_DEFAULT_BLUE = 0xE7;
    private static final int BACKGROUND_COLOR_EXCEPTION_RED = 0xFF;
    private static final int BACKGROUND_COLOR_EXCEPTION_GREEN = 0x29;
    private static final int BACKGROUND_COLOR_EXCEPTION_BLUE = 0x29;

    private static final Object BACKGROUND_DEFAULT_DELTA_KEY = new Object();
    private static final Object BACKGROUND_EXCEPTION_DELTA_KEY = new Object();
    private static final Object STAGE_0_DEFAULT_DELTA_KEY = new Object();
    private static final Object STAGE_0_EXCEPTION_DELTA_KEY = new Object();

    private static final Double2DoubleFunction SIN_90_DELTA = delta -> C_45510667.m_61414107((float) (delta * Math.PI / 2));
    private static final Double2DoubleFunction COS_90_DELTA = delta -> C_45510667.m_64246150((float) (delta * Math.PI / 2));
    private static final Double2DoubleFunction INVERSE_DELTA = delta -> 1 - delta;

    private static final String LOGO_TEMPLATE = "/assets/station-resource-loader-v0/textures/gui/stationapi_reload%s.png";
    private static final String LOGO_MOJANG = "/title/mojang.png";

    private final long BACKGROUND_START = 0;
    private long BACKGROUND_FADE_IN = 1000;
    private long STAGE_0_START = BACKGROUND_START + BACKGROUND_FADE_IN;
    private long STAGE_0_FADE_IN = 2000;
    private long GLOBAL_FADE_OUT = 1000;
    private long RELOAD_START = STAGE_0_START + STAGE_0_FADE_IN;
    private long EXCEPTION_TRANSFORM = 500;
    private static final long WRAP_UP_DURATION = 100; // 100ms wrap-up period after loading
    private boolean inWrapUp = false;
    private long wrapUpStart = 0;

    private final C_85740840 parent;
    private final Runnable done;
    private final C_96603444 tessellator;
    private boolean firstRenderTick = true;
    private long initTimestamp;
    private long currentTime;
    private float progress;
    private final Runnable backgroundEmitter;
    private final Runnable stage0Emitter;
    private boolean finished;
    private long fadeOutStart;
    private float scrollProgress;
    private final String logo;
    private boolean exceptionThrown;
    private long exceptionStart;
    private Exception exception;
    private final String stapiLogo;

    ReloadScreen(
            C_85740840 parent,
            Runnable done,
            C_96603444 tessellator
    ) {
        ReloadScreenManager.reloadScreen = this;
        this.parent = parent;
        this.done = done;
        this.tessellator = tessellator;

        stapiLogo = LOGO_TEMPLATE.formatted(
                switch (new Random().nextInt(100)) {
                    case 0 -> "_dimando";
                    case 1 -> "_old";
                    default -> "";
                }
        );

        logo = stapiLogo;

        if(
                isScreenType(LoadingScreenOption.NO_ANIMATE) ||
                isScreenType(LoadingScreenOption.HIDE) ||
                isScreenType(LoadingScreenOption.FORGE)
        ) {
            BACKGROUND_FADE_IN =
            STAGE_0_START =
            STAGE_0_FADE_IN =
            GLOBAL_FADE_OUT =
            RELOAD_START =
            EXCEPTION_TRANSFORM = 1;
        }
        else if (ReloadScreenManager.isUsingEarlyRenderLoop()) {
            // Faster animations for single-threaded LWJGL3 mode
            BACKGROUND_FADE_IN = 250;
            STAGE_0_START = BACKGROUND_START + BACKGROUND_FADE_IN;
            STAGE_0_FADE_IN = 500;
            GLOBAL_FADE_OUT = 300;
            RELOAD_START = STAGE_0_START + STAGE_0_FADE_IN;
            EXCEPTION_TRANSFORM = 200;
        }
        else {
            BACKGROUND_FADE_IN = 1000;
            STAGE_0_START = BACKGROUND_START + BACKGROUND_FADE_IN;
            STAGE_0_FADE_IN = 2000;
            GLOBAL_FADE_OUT = 1000;
            RELOAD_START = STAGE_0_START + STAGE_0_FADE_IN;
            EXCEPTION_TRANSFORM = 500;
        }
        Long2DoubleFunction backgroundFadeInDelta = time -> (double) Longs.constrainToRange(time - BACKGROUND_START, 0, BACKGROUND_FADE_IN) / BACKGROUND_FADE_IN;
        Long2DoubleFunction stage0FadeInDelta = time -> (double) Longs.constrainToRange(time - STAGE_0_START, 0, STAGE_0_FADE_IN) / STAGE_0_FADE_IN;

        Function<LongSupplier, Long2DoubleFunction> globalFadeOutDeltaFactory = fadeOutStartGetter -> INVERSE_DELTA.composeLong(time -> (double) Longs.constrainToRange(time - fadeOutStartGetter.getAsLong(), 0, GLOBAL_FADE_OUT) / GLOBAL_FADE_OUT);
        Function<LongSupplier, Long2DoubleFunction> backgroundExceptionFadeInFactory = fadeInStartGetter -> time -> (double) Longs.constrainToRange(time - fadeInStartGetter.getAsLong(), 0, EXCEPTION_TRANSFORM) / EXCEPTION_TRANSFORM;
        Function<LongSupplier, Long2DoubleFunction> stage0ExceptionTransformFactory = transformStartGetter -> time -> (double) Longs.constrainToRange(time - transformStartGetter.getAsLong(), 0, EXCEPTION_TRANSFORM) / EXCEPTION_TRANSFORM;

        val globalFadeOutComposer = when(() -> finished, globalFadeOutDeltaFactory.apply(() -> fadeOutStart));
        val deltaMap = of(
                BACKGROUND_DEFAULT_DELTA_KEY, globalFadeOutComposer.apply(backgroundFadeInDelta).andThenDouble(SIN_90_DELTA),
                BACKGROUND_EXCEPTION_DELTA_KEY, backgroundExceptionFadeInFactory.apply(() -> exceptionStart).andThenDouble(COS_90_DELTA).andThenDouble(INVERSE_DELTA),
                STAGE_0_DEFAULT_DELTA_KEY, globalFadeOutComposer.apply(stage0FadeInDelta).andThenDouble(SIN_90_DELTA),
                STAGE_0_EXCEPTION_DELTA_KEY, stage0ExceptionTransformFactory.apply(() -> exceptionStart).andThenDouble(COS_90_DELTA)
        );

        ToDoubleFunction<Object> deltaFunc = key -> deltaMap.get(key).applyAsDouble(currentTime);

        backgroundEmitter = () -> renderBackground(deltaFunc);

        stage0Emitter = () -> {
            renderLogo(deltaFunc);
            renderProgressBar(deltaFunc);
        };
    }

    private void renderBackground(ToDoubleFunction<Object> deltaFunc) {
        val delta = deltaFunc.applyAsDouble(BACKGROUND_DEFAULT_DELTA_KEY);
        int red = BACKGROUND_COLOR_DEFAULT_RED;
        int green = BACKGROUND_COLOR_DEFAULT_GREEN;
        int blue = BACKGROUND_COLOR_DEFAULT_BLUE;
        if (
                isScreenType(LoadingScreenOption.HIDE) ||
                isScreenType(LoadingScreenOption.FORGE) ||
                isScreenType(LoadingScreenOption.NO_RECOLOR)
        ) {
            red = green = blue = 0xFF;
        }
        final int color;
        if (exceptionThrown) {
            val exceptionDelta = deltaFunc.applyAsDouble(BACKGROUND_EXCEPTION_DELTA_KEY);
            color = ColorHelper.Argb.getArgb(
                    0xFF,
                    lerp(exceptionDelta, red, BACKGROUND_COLOR_EXCEPTION_RED),
                    lerp(exceptionDelta, green, BACKGROUND_COLOR_EXCEPTION_GREEN),
                    lerp(exceptionDelta, blue, BACKGROUND_COLOR_EXCEPTION_BLUE)
            );
        } else color = parent == null ?
                finished ?
                        ColorHelper.Argb.getArgb(
                                0xFF,
                                lerp(delta, 0xFF, red),
                                lerp(delta, 0xFF, green),
                                lerp(delta, 0xFF, blue)
                        ) :
                        ColorHelper.Argb.getArgb(
                                0xFF,
                                (int) (delta * red),
                                (int) (delta * green),
                                (int) (delta * blue)
                        ) :
                ColorHelper.Argb.getArgb(
                        (int) (delta * 0xFF),
                        red,
                        green,
                        blue
                );
        m_57734177(0, 0, f_05230747, f_07021018, color);
    }

    private void renderProgressBar(ToDoubleFunction<Object> deltaFunc) {
        if (isScreenType(LoadingScreenOption.HIDE)) return;
        if (isScreenType(LoadingScreenOption.FORGE)) {
            if(ReloadScreenManager.LOCATIONS.isEmpty()) return;
            String text = ReloadScreenManager.LOCATIONS.get(ReloadScreenManager.LOCATIONS.size() - 1);
            m_57734177(2, f_07021018 - 2, f_11884601.m_09235706(text) + 5, f_07021018 - 13, -1073741824);
            glEnable(GL_BLEND);
            m_62884682(f_11884601, text, 4, f_07021018 - 11, 0xFFFFFF);
            glDisable(GL_BLEND);
            return;
        }
        val delta = deltaFunc.applyAsDouble(STAGE_0_DEFAULT_DELTA_KEY);
        if (delta == 0) return;
        val color = (int) (delta * 0xFF) << 24 | 0xFFFFFF;
        val v = (float) (10 - delta * 10);
        val ev = exceptionThrown ? (float) (10 - deltaFunc.applyAsDouble(STAGE_0_EXCEPTION_DELTA_KEY) * 10) * 3 - 1 : 0;
        if (isScreenType(LoadingScreenOption.NO_RECOLOR))
            m_57734177(38, f_07021018 - 37 + (int) v, f_05230747 - 38, (int) (f_07021018 - 105 + v * 5), ColorHelper.Argb.getArgb(lerp(delta, 0, 192), 0, 0, 0));
        m_76526958(40, f_05230747 - 40 - 1, (int) (f_07021018 - 90 + v * 5), color);
        if (exceptionThrown) m_76526958(40, f_05230747 - 40 - 1, (int) (f_07021018 - 90 + v * 5 + ev), color);
        m_76526958(40, f_05230747 - 40 - 1, (int) (f_07021018 - 50 + v), color);
        m_76526958(40, f_05230747 - 40 - 1, (int) (f_07021018 - 40 - 1 + v), color);
        m_80229257(40, (int) (f_07021018 - 40 + v), (int) (f_07021018 - 90 + v * 5), color);
        m_80229257(f_05230747 - 40 - 1, (int) (f_07021018 - 40 + v), (int) (f_07021018 - 90 + v * 5), color);
        m_57734177(40 + 3, (int) (f_07021018 - 50 + 3 + v), ceil((f_05230747 - (40 + 3) * 2) * progress + 40 + 3), (int) (f_07021018 - 40 - 3 + v), color);
        val xScale = (float) f_78495264.f_31800787 / f_05230747;
        val yScale = (float) f_78495264.f_74192110 / f_07021018;
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        val locationsScissorsHeight = (int) ((40 - 1 - v * 4 + ev) * yScale);
        if (locationsScissorsHeight > 0) {
            val to = ceil(scrollProgress);
            val scrollDelta = scrollProgress - to;
            glEnable(GL_SCISSOR_TEST);
            glScissor((int) ((40 + 3) * xScale), (int) ((50 - v) * yScale), (int) ((f_05230747 - (40 + 3) * 2) * xScale), locationsScissorsHeight);
            for (int i = 0; i < to; i++) {
                val y = ceil(f_07021018 - 88 + (10 * i) + (scrollDelta * 10) + v * 5 + ev);
                if (y > f_07021018 - 50 + v) break;
                m_62884682(f_11884601, ReloadScreenManager.LOCATIONS.get(to - i - 1), 40 + 3, y, color);
            }
            glDisable(GL_SCISSOR_TEST);
        }
        val exceptionScissorsHeight = (int) ((-1 - v * 4 + ev) * yScale);
        if (exceptionThrown && exceptionScissorsHeight > 0) {
            glEnable(GL_SCISSOR_TEST);
            glScissor((int) ((40 + 3) * xScale), (int) ((91 - v - ev) * yScale), (int) ((f_05230747 - (40 + 3) * 2) * xScale), exceptionScissorsHeight);
            val line = exception.getMessage();
            var curHeight = f_07021018 - 88;
            val lineWidth = f_11884601.m_09235706(line);
            if (lineWidth > f_05230747 - (40 + 3) * 2) {
                var begin = 0;
                var lastSpace = -1;
                for (int cur = 0, lineLength = line.length(); cur < lineLength; cur++) {
                    val isSpace = line.charAt(cur) == ' ';
                    val isEnd = cur + 1 == lineLength;
                    if (isSpace || isEnd) {
                        val newLine = isEnd ? line.substring(begin) : line.substring(begin, cur);
                        val newLineWidth = f_11884601.m_09235706(newLine);
                        if (newLineWidth > f_05230747 - (40 + 3) * 2) {
                            m_62884682(f_11884601, line.substring(begin, lastSpace), 40 + 3, curHeight, color);
                            curHeight += 10;
                            begin = lastSpace + 1;
                        }
                        if (isSpace)
                            lastSpace = cur;
                        if (isEnd) {
                            m_62884682(f_11884601, line.substring(begin), 40 + 3, curHeight, color);
                            curHeight += 10;
                        }
                    }
                }
            } else m_62884682(f_11884601, line, 40 + 3, curHeight, color);
            glDisable(GL_SCISSOR_TEST);
        }
        m_62884682(f_11884601, "Minecraft: " + (
                ReloadScreenManagerImpl.isMinecraftDone ?
                        "Done" :
                        "Working..."
        ), 40 + 3, (int) (f_07021018 - 100 + v * 5), color);
        val stationStatus = "StationAPI: " + (
                isReloadStarted() ?
                        ReloadScreenManager.isReloadComplete() ?
                                "Done" :
                                "Working..." :
                        "Idle"
        );
        m_62884682(f_11884601, stationStatus, f_05230747 - 40 - 3 - f_11884601.m_09235706(stationStatus), (int) (f_07021018 - 100 + v * 5), color);
        glDisable(GL_BLEND);
    }

    private void renderLogo(ToDoubleFunction<Object> deltaFunc) {
        if (
                isScreenType(LoadingScreenOption.SHOW) ||
                isScreenType(LoadingScreenOption.NO_ANIMATE) ||
                isScreenType(LoadingScreenOption.NO_RECOLOR)
        ) {
            int color = 0xFFFFFFFF;
            if (isScreenType(LoadingScreenOption.NO_RECOLOR)) {
                color = 0xFFDD4F3B; // mojang colour
            }
            renderStapiLogo(deltaFunc, (f_05230747 / 2f), (f_07021018 / 2f - 20), 120, 20, color);
        }

        if (
                isScreenType(LoadingScreenOption.HIDE) ||
                isScreenType(LoadingScreenOption.FORGE)
        ) {
            renderMojangLogo(deltaFunc, f_05230747 / 2f, f_07021018 / 2f, f_05230747, f_07021018, 0, 0); // Draws the top left pixel of the logo, which is white, normally.
            renderMojangLogo(deltaFunc, (f_05230747 / 2f) - 1, (f_07021018 / 2f) + 1, 128, 128, 1, 1);
        }

        if (isScreenType(LoadingScreenOption.FORGE)) {
            int color;
            if (exceptionThrown) {
                val exceptionDelta = deltaFunc.applyAsDouble(BACKGROUND_EXCEPTION_DELTA_KEY);
                color = ColorHelper.Argb.getArgb(
                        0xFF,
                        lerp(exceptionDelta, BACKGROUND_COLOR_DEFAULT_RED, BACKGROUND_COLOR_EXCEPTION_RED),
                        lerp(exceptionDelta, BACKGROUND_COLOR_DEFAULT_GREEN, BACKGROUND_COLOR_EXCEPTION_GREEN),
                        lerp(exceptionDelta, BACKGROUND_COLOR_DEFAULT_BLUE, BACKGROUND_COLOR_EXCEPTION_BLUE)
                );
            }
            else {
                color = ColorHelper.Argb.getArgb(0xFF, BACKGROUND_COLOR_DEFAULT_RED, BACKGROUND_COLOR_DEFAULT_GREEN, BACKGROUND_COLOR_DEFAULT_BLUE);
            }
            // Stapi logo is 6:1 aspect
            renderStapiLogo(deltaFunc, f_05230747 - 50, f_07021018 - 10, 48, 8, color);
        }
    }

    private void renderMojangLogo(ToDoubleFunction<Object> deltaFunc, float x, float y, float w, float h, float u, float v) {
        val delta = deltaFunc.applyAsDouble(STAGE_0_DEFAULT_DELTA_KEY);
        if (delta == 0) return;
        f_78495264.f_45465196.m_72568250(f_78495264.f_45465196.m_33729172(LOGO_MOJANG));
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        tessellator.m_35940071();
        tessellator.m_72833996(0xFF, 0xFF, 0xFF, 0xFF);
        tessellator.m_75942980(x - w, y - h - v, 0, 0, 0);
        tessellator.m_75942980(x - w, y + h - v, 0, 0, v);
        tessellator.m_75942980(x + w, y + h - v, 0, u, v);
        tessellator.m_75942980(x + w, y - h - v, 0, u, 0);
        tessellator.m_70070273();
        glDisable(GL_BLEND);
    }

    private void renderStapiLogo(ToDoubleFunction<Object> deltaFunc, float x, float y, float w, float h, int color) {
        double delta = deltaFunc.applyAsDouble(STAGE_0_DEFAULT_DELTA_KEY);
        if (delta == 0) return;
        double v = 10 - delta * 10;
        int a = color >> 24 & 0xFF;
        int r = color >> 16 & 0xFF;
        int g = color >> 8 & 0xFF;
        int b = color & 0xFF;
        f_78495264.f_45465196.m_72568250(f_78495264.f_45465196.m_33729172(logo));
        glEnable(GL_BLEND);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        tessellator.m_35940071();
        tessellator.m_72833996(r, g, b, (int) (a * delta));
        tessellator.m_75942980(x - w, y - h - v, 0, 0, 0);
        tessellator.m_75942980(x - w, y + h - v, 0, 0, 1);
        tessellator.m_75942980(x + w, y + h - v, 0, 1, 1);
        tessellator.m_75942980(x + w, y - h - v, 0, 1, 0);
        tessellator.m_70070273();
        glDisable(GL_BLEND);
    }

    @Override
    public void m_34695786() {
        backgroundEmitter.run();
    }

    private long lastRender;

    @Override
    public void m_93956703(int mouseX, int mouseY, float delta) {
        if (firstRenderTick) {
            firstRenderTick = false;
            initTimestamp = System.currentTimeMillis();
        }
        currentTime = System.currentTimeMillis() - initTimestamp;
        val partial = currentTime - lastRender < (1000 / MAX_FPS);
        if (partial) currentTime = lastRender;
        else lastRender = currentTime;
        val locationsSize = ReloadScreenManager.LOCATIONS.size();

        // Check if we should enter wrap-up mode (loading done, EarlyRenderLoop mode)
        if (!exceptionThrown && !finished && !inWrapUp && ReloadScreenManager.isReloadComplete()) {
            if (ReloadScreenManager.isUsingEarlyRenderLoop()) {
                // Enter wrap-up mode - must complete before finishing
                inWrapUp = true;
                wrapUpStart = currentTime;
            }
        }

        // During wrap-up, accelerate animations to catch up
        float progressLerp = 0.05F;
        float scrollLerp = 0.05F;
        if (inWrapUp) {
            // Speed up lerping during wrap-up
            progressLerp = 0.4F;
            scrollLerp = 0.4F;

            // Wrap-up MUST complete its full duration before finishing
            val wrapUpElapsed = currentTime - wrapUpStart;
            if (wrapUpElapsed >= WRAP_UP_DURATION) {
                try {
                    ReloadScreenManager.getCurrentReload().ifPresent(ResourceReload::throwException);
                    finished = true;
                    fadeOutStart = currentTime;
                    inWrapUp = false;
                } catch (CompletionException e) {
                    exceptionThrown = true;
                    exceptionStart = currentTime;
                    exception = e;
                    inWrapUp = false;
                    LOGGER.error("An exception occurred during resource loading", e);
                }
            }
        } else if (!exceptionThrown && !finished && !(scrollProgress + .1 < locationsSize) && !(progress + .1 < 1) && ReloadScreenManager.isReloadComplete()) {
            // Original logic for non-EarlyRenderLoop mode
            try {
                ReloadScreenManager.getCurrentReload().ifPresent(ResourceReload::throwException);
                finished = true;
                fadeOutStart = currentTime;
            } catch (CompletionException e) {
                exceptionThrown = true;
                exceptionStart = currentTime;
                exception = e;
                LOGGER.error("An exception occurred during resource loading", e);
            }
        }

        if (!partial) {
            Optional<ResourceReload> reload;
            progress = Floats.constrainToRange(progress * (1 - progressLerp) + (isReloadStarted() && (reload = ReloadScreenManager.getCurrentReload()).isPresent() ? reload.get().getProgress() : 0) * progressLerp, 0, 1);
            scrollProgress = Floats.constrainToRange(scrollProgress * (1 - scrollLerp) + locationsSize * scrollLerp, 0, locationsSize);
        }
        if ((finished ? currentTime <= fadeOutStart + GLOBAL_FADE_OUT : currentTime < BACKGROUND_START + BACKGROUND_FADE_IN) && parent != null)
            parent.m_93956703(mouseX, mouseY, delta);
        m_34695786();
        super.m_93956703(mouseX, mouseY, delta);
        stage0Emitter.run();
        if (finished && currentTime - fadeOutStart > GLOBAL_FADE_OUT) {
            ReloadScreenManager.onFinish();
            done.run();
        }
    }

    boolean isReloadStarted() {
        return currentTime > RELOAD_START;
    }

    @Override
    protected void m_76526958(int startX, int endX, int y, int color) {
        if (endX < startX) {
            val n = startX;
            startX = endX;
            endX = n;
        }
        m_57734177(startX, y, endX + 1, y + 1, color);
    }

    @Override
    protected void m_80229257(int x, int startY, int endY, int color) {
        if (endY < startY) {
            val n = startY;
            startY = endY;
            endY = n;
        }
        m_57734177(x, startY + 1, x + 1, endY, color);
    }

    @Override
    protected void m_57734177(int startX, int startY, int endX, int endY, int color) {
        int n;
        if (startX < endX) {
            n = startX;
            startX = endX;
            endX = n;
        }
        if (startY < endY) {
            n = startY;
            startY = endY;
            endY = n;
        }
        val a = (float)(color >> 24 & 0xFF) / 255.0f;
        val r = (float)(color >> 16 & 0xFF) / 255.0f;
        val g = (float)(color >> 8 & 0xFF) / 255.0f;
        val b = (float)(color & 0xFF) / 255.0f;
        glEnable(GL_BLEND);
        glDisable(GL_TEXTURE_2D);
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        glColor4f(r, g, b, a);
        tessellator.m_35940071();
        tessellator.m_51994127(startX, endY, 0.0);
        tessellator.m_51994127(endX, endY, 0.0);
        tessellator.m_51994127(endX, startY, 0.0);
        tessellator.m_51994127(startX, startY, 0.0);
        tessellator.m_70070273();
        glEnable(GL_TEXTURE_2D);
        glDisable(GL_BLEND);
    }

    void setTextRenderer(C_23014920 textRenderer) {
        this.f_11884601 = textRenderer;
    }

    boolean isScreenType(LoadingScreenOption loadingScreenOption) {
        return StationConfig.stationConfigData.loadingScreenOption.equals(loadingScreenOption);
    }

    private UnaryOperator<Long2DoubleFunction> when(BooleanSupplier condition, Long2DoubleFunction ifTrue) {
        return ifFalse -> value -> (condition.getAsBoolean() ? ifTrue : ifFalse).applyAsDouble(value);
    }
}
