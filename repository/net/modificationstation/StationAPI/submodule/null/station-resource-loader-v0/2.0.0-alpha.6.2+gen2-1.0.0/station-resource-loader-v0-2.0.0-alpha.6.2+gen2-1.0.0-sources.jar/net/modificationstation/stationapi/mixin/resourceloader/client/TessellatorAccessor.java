package net.modificationstation.stationapi.mixin.resourceloader.client;

import net.minecraft.unmapped.C_96603444;
import net.modificationstation.stationapi.api.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_96603444.class)
public interface TessellatorAccessor {
    @Invoker("<init>")
    static C_96603444 stationapi_create(int size) {
        return Util.assertMixin();
    }
}
