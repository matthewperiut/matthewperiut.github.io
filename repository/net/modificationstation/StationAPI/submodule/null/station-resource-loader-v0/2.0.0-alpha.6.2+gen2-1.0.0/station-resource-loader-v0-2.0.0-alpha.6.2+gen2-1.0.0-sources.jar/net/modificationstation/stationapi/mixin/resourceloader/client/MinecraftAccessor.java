package net.modificationstation.stationapi.mixin.resourceloader.client;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_82837181;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(Minecraft.class)
public interface MinecraftAccessor {
    @Accessor
    C_82837181 getTimer();

    @Invoker
    void invokeLogGlError(String phase);
}
