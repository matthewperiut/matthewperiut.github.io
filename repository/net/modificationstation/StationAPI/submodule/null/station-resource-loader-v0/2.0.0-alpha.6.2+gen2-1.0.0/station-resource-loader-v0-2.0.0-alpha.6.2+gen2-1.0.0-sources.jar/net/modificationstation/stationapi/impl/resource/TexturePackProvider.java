package net.modificationstation.stationapi.impl.resource;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_55615542;
import net.minecraft.unmapped.C_74530968;
import net.modificationstation.stationapi.api.resource.ResourceType;
import net.modificationstation.stationapi.mixin.resourceloader.client.ZipTexturePackAccessor;

import java.util.function.Consumer;

public class TexturePackProvider implements ResourcePackProvider {
    @Override
    public void register(Consumer<ResourcePackProfile> profileAdder) {
        //noinspection deprecation
        C_74530968 texturePack = ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_20964140.f_25140974;
        if (texturePack instanceof C_55615542 zipTexturePack) {
            String fileName = ((ZipTexturePackAccessor) zipTexturePack).getZip().getName();
            ResourcePackProfile resourcePackProfile = ResourcePackProfile.create(
                    "file/" + fileName,
                    /*Text.literal(string)*/fileName,
                    true,
                    name -> new ZippedTexturePackResourcePack(zipTexturePack, false),
                    ResourceType.CLIENT_RESOURCES,
                    ResourcePackProfile.InsertionPosition.TOP,
                    ResourcePackSource.NONE
            );
            if (resourcePackProfile != null) profileAdder.accept(resourcePackProfile);
        }
    }
}

