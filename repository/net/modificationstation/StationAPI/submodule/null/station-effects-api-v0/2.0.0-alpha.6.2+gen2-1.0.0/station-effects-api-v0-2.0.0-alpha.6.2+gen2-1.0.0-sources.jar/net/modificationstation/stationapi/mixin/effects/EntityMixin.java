package net.modificationstation.stationapi.mixin.effects;

import it.unimi.dsi.fastutil.objects.Reference2ReferenceOpenHashMap;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_79370641;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.effect.EntityEffect;
import net.modificationstation.stationapi.api.effect.EntityEffectType;
import net.modificationstation.stationapi.api.effect.EntityEffectTypeRegistry;
import net.modificationstation.stationapi.api.entity.StationEffectsEntity;
import net.modificationstation.stationapi.api.network.packet.PacketHelper;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.impl.effect.StationEffectsEntityImpl;
import net.modificationstation.stationapi.impl.effect.packet.EffectAddS2CPacket;
import net.modificationstation.stationapi.impl.effect.packet.EffectRemoveAllS2CPacket;
import net.modificationstation.stationapi.impl.effect.packet.EffectRemoveS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collection;
import java.util.Map;

@Mixin(C_42232651.class)
public class EntityMixin implements StationEffectsEntity, StationEffectsEntityImpl {
    @Unique private final Map<EntityEffectType<?>, EntityEffect<?>> stationapi_effects = new Reference2ReferenceOpenHashMap<>();
    
    @Shadow public int id;
    
    @Override
    @Unique
    public void addEffect(EntityEffectType<?> effectType, int ticks) {
        C_42232651 thiz = C_42232651.class.cast(this);
        PacketHelper.dispatchLocallyAndToAllTracking(
                thiz, new EffectAddS2CPacket(thiz, effectType.factory.create(thiz, ticks))
        );
    }

    @Override
    @Unique
    public <EFFECT_INSTANCE extends EntityEffect<EFFECT_INSTANCE>> EFFECT_INSTANCE getEffect(
            EntityEffectType<EFFECT_INSTANCE> effectType
    ) {
        //noinspection unchecked
        return (EFFECT_INSTANCE) stationapi_effects.get(effectType);
    }

    @Override
    @Unique
    public Collection<EntityEffect<?>> getEffects() {
        return stationapi_effects.values();
    }

    @Override
    @Unique
    public boolean hasEffect(EntityEffectType<?> effectType) {
        return stationapi_effects.containsKey(effectType);
    }

    @Override
    @Unique
    public void removeEffect(EntityEffectType<?> effectType) {
        if (!stationapi_effects.containsKey(effectType)) return;
        PacketHelper.dispatchLocallyAndToAllTracking(
                C_42232651.class.cast(this), new EffectRemoveS2CPacket((C_42232651) (Object) this, effectType)
        );
    }
    
    @Override
    @Unique
    public void removeAllEffects() {
        PacketHelper.dispatchLocallyAndToAllTracking(
                C_42232651.class.cast(this), new EffectRemoveAllS2CPacket((C_42232651) (Object) this)
        );
    }

    @Override
    @Unique
    public void stationapi_addEffect(EntityEffect<?> effect, boolean appliedNow) {
        stationapi_effects.put(effect.getType(), effect);
        effect.onAdded(appliedNow);
    }

    @Override
    @Unique
    public void stationapi_removeAllEffects() {
        stationapi_effects.keySet().stream().map(stationapi_effects::remove).forEach(EntityEffect::onRemoved);
    }

    @Override
    @Unique
    public void stationapi_removeEffect(EntityEffectType<?> effectType) {
        stationapi_effects.remove(effectType).onRemoved();
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void stationapi_tickEffects(CallbackInfo info) {
        stationapi_effects.values().forEach(EntityEffect::tick);
    }
    
    @Inject(method = "write", at = @At("HEAD"))
    private void stationapi_writeEntityEffect(C_74087615 tag, CallbackInfo info) {
        if (stationapi_effects.isEmpty()) return;
        C_79370641 effects = new C_79370641();
        stationapi_effects.forEach((type, effect) -> {
            var nbt = new C_74087615();
            effect.write(nbt);
            nbt.m_91017064("id", type.registryEntry.registryKey().getValue().toString());
            nbt.m_20318863("ticks", effect.getTicks());
            effects.m_43125067(nbt);
        });
        tag.m_21770494("stationapi:effects", effects);
    }
    
    @Inject(method = "read", at = @At("HEAD"))
    private void stationapi_readEntityEffect(C_74087615 tag, CallbackInfo info) {
        if (!tag.m_97612750("stationapi:effects")) return;
        C_79370641 effects = tag.m_95654166("stationapi:effects");
        for (int i = 0; i < effects.m_89439680(); i++) {
            C_74087615 effectTag = (C_74087615) effects.m_59132367(i);
            Identifier id = Identifier.of(effectTag.m_47517355("id"));
            EntityEffectType<?> effectType = EntityEffectTypeRegistry.INSTANCE.get(id);
            if (effectType == null) {
                StationAPI.LOGGER.warn("Effect " + id + " is not registered, skipping");
                continue;
            }
            int ticks = effectTag.m_35587574("ticks");
            EntityEffect<?> effect = effectType.factory.create(C_42232651.class.cast(this), ticks);
            effect.read(effectTag);
            stationapi_effects.put(effectType, effect);
        }
    }
}
