package net.modificationstation.stationapi.impl.effect.packet;

import com.mojang.datafixers.util.Either;
import com.mojang.datafixers.util.Pair;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_74087615;
import net.modificationstation.stationapi.api.effect.EntityEffect;
import net.modificationstation.stationapi.api.effect.EntityEffectType;
import net.modificationstation.stationapi.api.effect.EntityEffectTypeRegistry;
import net.modificationstation.stationapi.api.entity.player.PlayerHelper;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.api.network.packet.PacketType;
import net.modificationstation.stationapi.impl.effect.StationEffectsEntityImpl;
import org.jetbrains.annotations.NotNull;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.function.Function;

public class SendAllEffectsPlayerS2CPacket extends C_03562565 implements ManagedPacket<SendAllEffectsPlayerS2CPacket> {
    public static final PacketType<SendAllEffectsPlayerS2CPacket> TYPE = PacketType
            .builder(true, false, SendAllEffectsPlayerS2CPacket::new).build();

    private final Collection<Either<EntityEffect<?>, Pair<EntityEffectType<?>, C_74087615>>> effects;
    
    private SendAllEffectsPlayerS2CPacket() {
        effects = new ArrayList<>();
    }
    
    public SendAllEffectsPlayerS2CPacket(Collection<EntityEffect<?>> effects) {
        this.effects = effects
                .stream()
                .map(Either::<EntityEffect<?>, Pair<EntityEffectType<?>, C_74087615>>left)
                .toList();
    }
    
    @Override
    public void m_13296744(DataInputStream stream) {
        try {
            int count = stream.readShort();
            for (int i = 0; i < count; i++)
                effects.add(Either.right(Pair.of(
                        EntityEffectTypeRegistry.INSTANCE.getOrThrow(stream.readInt()),
                        C_08565163.m_07155133(stream)
                )));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public void m_17566769(DataOutputStream stream) {
        try {
            stream.writeShort(effects.size());
            for (var either : effects) {
                stream.writeInt(EntityEffectTypeRegistry.INSTANCE.getRawId(
                        either.map(EntityEffect::getType, Pair::getFirst)
                ));
                C_08565163.m_94300398(either.map(
                        effect -> {
                            var nbt = new C_74087615();
                            effect.write(nbt);
                            return nbt;
                        },
                        Pair::getSecond
                ), stream);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public void m_04853589(C_10918870 networkHandler) {
        C_40996800 player = PlayerHelper.getPlayerFromPacketHandler(networkHandler);
        effects.forEach(either -> {
            var effect = either.map(
                    Function.identity(),
                    pair -> {
                        var e = pair.getFirst().factory.create(player, 0);
                        e.read(pair.getSecond());
                        return e;
                    }
            );
            ((StationEffectsEntityImpl) player).stationapi_addEffect(effect, false);
        });
    }
    
    @Override
    public int m_85604015() {
        return 0;
    }

    public @NotNull PacketType<SendAllEffectsPlayerS2CPacket> getType() {
        return TYPE;
    }
}
