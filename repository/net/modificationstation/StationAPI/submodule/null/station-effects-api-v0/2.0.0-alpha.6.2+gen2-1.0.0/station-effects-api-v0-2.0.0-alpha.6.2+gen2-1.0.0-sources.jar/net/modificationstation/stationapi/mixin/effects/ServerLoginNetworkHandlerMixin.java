package net.modificationstation.stationapi.mixin.effects;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.unmapped.C_47909326;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_58873528;
import net.modificationstation.stationapi.api.network.packet.PacketHelper;
import net.modificationstation.stationapi.impl.effect.packet.SendAllEffectsPlayerS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_58873528.class)
public class ServerLoginNetworkHandlerMixin {
    @Inject(method = "accept", at = @At(
        value = "INVOKE",
        target = "Lnet/minecraft/entity/player/ServerPlayerEntity;initScreenHandler()V",
        shift = Shift.BEFORE
    ))
    private void stationapi_updatePlayerEffects(C_47909326 packet, CallbackInfo info, @Local C_49202226 player) {
        var effects = player.getEffects();
        if (effects.isEmpty()) return;
        PacketHelper.sendTo(player, new SendAllEffectsPlayerS2CPacket(effects));
    }
}
