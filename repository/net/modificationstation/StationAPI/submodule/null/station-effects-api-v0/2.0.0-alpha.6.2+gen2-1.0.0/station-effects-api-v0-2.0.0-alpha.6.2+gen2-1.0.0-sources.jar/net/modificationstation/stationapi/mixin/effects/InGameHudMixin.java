package net.modificationstation.stationapi.mixin.effects;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_97866173;
import net.modificationstation.stationapi.impl.effect.EffectsRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_97866173.class)
public class InGameHudMixin {
    @Unique private final EffectsRenderer stationapi_effectRenderer = new EffectsRenderer();
    
    @Shadow private Minecraft minecraft;
    
    @Inject(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lorg/lwjgl/opengl/GL11;glColor4f(FFFF)V",
                    shift = Shift.AFTER,
                    ordinal = 0,
                    remap = false
            )
    )
    private void stationapi_renderEffects(float delta, boolean i, int j, int par4, CallbackInfo ci) {
        if (minecraft.f_58088711.f_63869242) return;
        stationapi_effectRenderer.renderEffects(minecraft, delta, false);
    }
}
