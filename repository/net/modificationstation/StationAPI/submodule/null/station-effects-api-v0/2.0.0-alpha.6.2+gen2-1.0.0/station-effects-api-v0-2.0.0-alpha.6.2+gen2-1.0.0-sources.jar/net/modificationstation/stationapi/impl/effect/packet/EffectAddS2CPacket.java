package net.modificationstation.stationapi.impl.effect.packet;

import com.mojang.datafixers.util.Either;
import com.mojang.datafixers.util.Pair;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_74087615;
import net.modificationstation.stationapi.api.effect.EntityEffect;
import net.modificationstation.stationapi.api.effect.EntityEffectType;
import net.modificationstation.stationapi.api.effect.EntityEffectTypeRegistry;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.api.network.packet.PacketType;
import net.modificationstation.stationapi.impl.effect.StationEffectsEntityImpl;
import net.modificationstation.stationapi.mixin.effects.ClientNetworkHandlerAccessor;
import org.jetbrains.annotations.NotNull;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.function.Function;

public class EffectAddS2CPacket extends C_03562565 implements ManagedPacket<EffectAddS2CPacket> {
    public static final PacketType<EffectAddS2CPacket> TYPE = PacketType
            .builder(true, false, EffectAddS2CPacket::new).build();

    private Either<C_42232651, Integer> entity;
    private Either<EntityEffect<?>, Pair<EntityEffectType<?>, C_74087615>> effect;
    
    private EffectAddS2CPacket() {}
    
    public EffectAddS2CPacket(C_42232651 entity, EntityEffect<?> effect) {
        this.entity = Either.left(entity);
        this.effect = Either.left(effect);
    }
    
    @Override
    public void m_13296744(DataInputStream stream) {
        try {
            entity = Either.right(stream.readInt());
            effect = Either.right(Pair.of(
                    EntityEffectTypeRegistry.INSTANCE.getOrThrow(stream.readInt()),
                    C_08565163.m_07155133(stream)
            ));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public void m_17566769(DataOutputStream stream) {
        try {
            stream.writeInt(entity.map(e -> e.f_11112215, Function.identity()));
            stream.writeInt(EntityEffectTypeRegistry.INSTANCE.getRawId(effect.map(
                    EntityEffect::getType, Pair::getFirst
            )));
            C_08565163.m_94300398(effect.map(
                    e -> {
                        var nbt = new C_74087615();
                        e.write(nbt);
                        return nbt;
                    },
                    Pair::getSecond
            ), stream);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public void m_04853589(C_10918870 networkHandler) {
        C_42232651 e = entity.map(
                Function.identity(),
                entityId -> ((ClientNetworkHandlerAccessor) networkHandler).stationapi_getEntityByID(entityId)
        );
        ((StationEffectsEntityImpl) e).stationapi_addEffect(effect.map(
                Function.identity(),
                pair -> {
                    var effect = pair.getFirst().factory.create(e, 0);
                    effect.read(pair.getSecond());
                    return effect;
                }
        ), true);
    }
    
    @Override
    public int m_85604015() {
        return 0;
    }

    public @NotNull PacketType<EffectAddS2CPacket> getType() {
        return TYPE;
    }
}
