package net.modificationstation.stationapi.impl.effect.packet;

import com.mojang.datafixers.util.Either;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_42232651;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.api.network.packet.PacketType;
import net.modificationstation.stationapi.impl.effect.StationEffectsEntityImpl;
import net.modificationstation.stationapi.mixin.effects.ClientNetworkHandlerAccessor;
import org.jetbrains.annotations.NotNull;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.function.Function;

public class EffectRemoveAllS2CPacket extends C_03562565 implements ManagedPacket<EffectRemoveAllS2CPacket> {
    public static final PacketType<EffectRemoveAllS2CPacket> TYPE = PacketType
            .builder(true, false, EffectRemoveAllS2CPacket::new).build();

    private Either<C_42232651, Integer> entity;
    
    private EffectRemoveAllS2CPacket() {}
    
    public EffectRemoveAllS2CPacket(C_42232651 entity) {
        this.entity = Either.left(entity);
    }
    
    @Override
    public void m_13296744(DataInputStream stream) {
        try {
            entity = Either.right(stream.readInt());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public void m_17566769(DataOutputStream stream) {
        try {
            stream.writeInt(entity.map(e -> e.f_11112215, Function.identity()));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    
    @Override
    public void m_04853589(C_10918870 networkHandler) {
        ((StationEffectsEntityImpl) entity.map(
                Function.identity(),
                entityId -> ((ClientNetworkHandlerAccessor) networkHandler).stationapi_getEntityByID(entityId)
        )).stationapi_removeAllEffects();
    }
    
    @Override
    public int m_85604015() {
        return 4;
    }

    public @NotNull PacketType<EffectRemoveAllS2CPacket> getType() {
        return TYPE;
    }
}
