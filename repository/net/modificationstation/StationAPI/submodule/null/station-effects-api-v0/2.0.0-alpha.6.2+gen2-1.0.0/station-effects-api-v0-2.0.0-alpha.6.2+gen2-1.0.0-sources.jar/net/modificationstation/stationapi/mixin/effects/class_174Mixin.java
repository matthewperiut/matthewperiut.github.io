package net.modificationstation.stationapi.mixin.effects;

import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_77505663;
import net.modificationstation.stationapi.api.network.packet.PacketHelper;
import net.modificationstation.stationapi.impl.effect.packet.SendAllEffectsS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_77505663.class)
public class class_174Mixin {
    @Shadow public C_42232651 currentTrackedEntity;
    
    @Inject(method = "updateListener", at = @At(
        value = "INVOKE",
        target = "Lnet/minecraft/server/network/ServerPlayNetworkHandler;sendPacket(Lnet/minecraft/network/packet/Packet;)V",
        shift = Shift.AFTER, ordinal = 0
    ))
    private void stationapi_updateEntities(C_49202226 player, CallbackInfo info) {
        var effects = currentTrackedEntity.getEffects();
        if (effects.isEmpty()) return;
        PacketHelper.sendTo(player, new SendAllEffectsS2CPacket(currentTrackedEntity.f_11112215, effects));
    }
}
