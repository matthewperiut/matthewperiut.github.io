package net.modificationstation.stationapi.impl.effect;

import it.unimi.dsi.fastutil.objects.Reference2IntMap;
import it.unimi.dsi.fastutil.objects.Reference2IntOpenHashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_29058632;
import net.minecraft.unmapped.C_96603444;
import net.modificationstation.stationapi.api.effect.EntityEffect;
import net.modificationstation.stationapi.api.util.Identifier;
import org.lwjgl.opengl.GL11;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;

public class EffectsRenderer extends C_29058632 {
    private final Reference2IntMap<Identifier> effectIcons = new Reference2IntOpenHashMap<>();
    private final List<EntityEffect<?>> renderEffects = new ArrayList<>();
    private C_23014920 textRenderer;
    
    private final Comparator<EntityEffect<?>> comparator = (e1, e2) -> {
        int l1 = getEffectWidth(e1);
        int l2 = getEffectWidth(e2);
        if (l1 == l2) return e1.getType().registryEntry.registryKey().getValue().compareTo(e2.getType().registryEntry.registryKey().getValue());
        return Integer.compare(l2, l1);
    };
    
    public void renderEffects(Minecraft minecraft, float delta, boolean extended) {
        Collection<EntityEffect<?>> effects = minecraft.f_28396371.getEffects();
        if (effects.isEmpty()) return;
        
        textRenderer = minecraft.f_21497584;
        
        renderEffects.clear();
        renderEffects.addAll(effects);
        renderEffects.sort(comparator);
        
        int py = 2;
        for (EntityEffect<?> effect : renderEffects) {
            if (extended) {
                String name = effect.getName();
                String desc = effect.getDescription();
                int width = Math.max(
                    textRenderer.m_09235706(name),
                    textRenderer.m_09235706(desc)
                );
                
                if (effect.isInfinite()) {
                    renderEffectBack(minecraft, py, 30 + width);
                    textRenderer.m_27673420(name, 26, py + 5, 0xFFFFFFFF);
                    textRenderer.m_27673420(desc, 26, py + 14, 0xFFFFFFFF);
                }
                else {
                    String time = getEffectTime(effect, delta);
                    int timeWidth = textRenderer.m_09235706(time);
                    renderEffectBack(minecraft, py, 32 + width + timeWidth);
                    textRenderer.m_27673420(time, 26, py + 9, 0xFFFFFFFF);
                    int x = 28 + timeWidth;
                    textRenderer.m_27673420(name, x, py + 5, 0xFFFFFFFF);
                    textRenderer.m_27673420(desc, x, py + 14, 0xFFFFFFFF);
                }
            }
            else {
                if (effect.isInfinite()) {
                    renderEffectBack(minecraft, py, 26);
                }
                else {
                    String time = getEffectTime(effect, delta);
                    renderEffectBack(minecraft, py, 30 + textRenderer.m_09235706(time));
                    textRenderer.m_27673420(time, 26, py + 9, 0xFFFFFFFF);
                }
            }
            
            Identifier id = effect.getType().registryEntry.registryKey().getValue();
            int texture = effectIcons.computeIfAbsent(id, k ->
                minecraft.f_45465196.m_33729172("/assets/" + id.namespace + "/stationapi/textures/gui/effect/" + id.path + ".png")
            );
            
            renderEffectIcon(py + 5, texture);
            py += 28;
        }
    }
    
    private String getEffectTime(EntityEffect<?> effect, float delta) {
        float ticks = effect.getTicks() + (1.0F - delta);
        int seconds = Math.round(ticks / 20.0F);
        int minutes = seconds / 60;
        return String.format("%02d:%02d", minutes, seconds);
    }
    
    private void renderEffectIcon(int y, int texture) {
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, texture);
        
        C_96603444 tessellator = C_96603444.f_99414865;
        tessellator.m_35940071();
        
        int y2 = y + 16;
        
        tessellator.m_75942980(7, y2, 0.0F, 0.0F, 1.0F);
        tessellator.m_75942980(23, y2, 0.0F, 1.0F, 1.0F);
        tessellator.m_75942980(23, y, 0.0F, 1.0F, 0.0F);
        tessellator.m_75942980(7, y, 0.0F, 0.0F, 0.0F);
        
        tessellator.m_70070273();
    }
    
    private void renderEffectBack(Minecraft minecraft, int y, int width) {
        GL11.glBindTexture(GL11.GL_TEXTURE_2D, minecraft.f_45465196.m_33729172("/achievement/bg.png"));
        
        int x = width - 12;
        int y2 = y + 13;
        
        m_66359748(2, y, 96, 202, 14, 14);
        m_66359748(2, y2, 96, 233 - 13, 14, 14);
        
        if (width > 26) {
            width -= 26;
            m_66359748(15, y, 109, 202, width + 1, 14);
            m_66359748(15, y + 13, 109, 220, width + 1, 14);
        }
        
        m_66359748(x, y, 242, 202, 14, 14);
        m_66359748(x, y2, 242, 220, 14, 14);
    }
    
    private int getEffectWidth(EntityEffect<?> effect) {
        if (effect.isInfinite()) return 26;
        String name = effect.getName();
        String desc = effect.getDescription();
        return Math.max(
            textRenderer.m_09235706(name),
            textRenderer.m_09235706(desc)
        );
    }
}
