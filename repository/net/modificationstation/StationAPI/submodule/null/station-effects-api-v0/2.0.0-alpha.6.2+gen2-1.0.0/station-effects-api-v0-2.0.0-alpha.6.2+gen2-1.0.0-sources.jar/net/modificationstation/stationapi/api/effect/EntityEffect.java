package net.modificationstation.stationapi.api.effect;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_76536438;

public abstract class EntityEffect<THIS extends EntityEffect<THIS>> {
    public static final int INFINITY_TICKS = -1;
    protected C_42232651 entity;
    private int ticks;
    
    private final String nameTranslationKey;
    private final String descriptionTranslationKey;
    
    protected EntityEffect(C_42232651 entity, int ticks) {
        this.entity = entity;
        this.ticks = ticks;
        var effectId =  getType().registryEntry.registryKey().getValue();
        nameTranslationKey = "gui.stationapi.effect." + effectId.namespace + "." + effectId.path + ".name";
        descriptionTranslationKey = nameTranslationKey.substring(0, nameTranslationKey.length() - 4) + "desc";
    }
    
    /**
     * This method is called immediately when the effect is added.
     *
     * @param appliedNow whether the effect was just inflicted on the entity
     *                   or synchronized from the server later.
     */
    public abstract void onAdded(boolean appliedNow);
    
    /**
     * This method is called on each entity tick.
     */
    public abstract void onTick();
    
    /**
     * This method is called immediately when the effect is removed.
     */
    public abstract void onRemoved();
    
    /**
     * Allows to write any custom data to the tag storage.
     * @param tag effect data root tag
     */
    protected abstract void writeNbt(C_74087615 tag);
    
    /**
     * Allows to read any custom data from the tag storage.
     * @param tag effect data root tag
     */
    protected abstract void readNbt(C_74087615 tag);

    public abstract EntityEffectType<THIS> getType();
    
    /**
     * Get remaining effect ticks.
     */
    public final int getTicks() {
        return ticks;
    }
    
    /**
     * Check if effect is infinite.
     */
    public final boolean isInfinite() {
        return ticks == INFINITY_TICKS;
    }
    
    /**
     * Get translated effect name, client side only.
     */
    @Environment(EnvType.CLIENT)
    public final String getName() {
        return C_76536438.m_00994426(nameTranslationKey, nameTranslationKey);
    }
    
    /**
     * Get translated effect description, client side only.
     */
    @Environment(EnvType.CLIENT)
    public final String getDescription() {
        return C_76536438.m_00994426(descriptionTranslationKey, descriptionTranslationKey);
    }

    public final void tick() {
        onTick();
        if (!isInfinite()) {
            ticks--;
            if (ticks == 0) {
                entity.removeEffect(getType());
            }
        }
    }
    
    public final void write(C_74087615 nbt) {
        nbt.m_20318863("ticks", ticks);
        writeNbt(nbt);
    }
    
    public final void read(C_74087615 nbt) {
        ticks = nbt.m_35587574("ticks");
        readNbt(nbt);
    }

    @FunctionalInterface
    public interface Factory<EFFECT_INSTANCE extends EntityEffect<EFFECT_INSTANCE>> {
        EFFECT_INSTANCE create(C_42232651 entity, int ticks);
    }
}
