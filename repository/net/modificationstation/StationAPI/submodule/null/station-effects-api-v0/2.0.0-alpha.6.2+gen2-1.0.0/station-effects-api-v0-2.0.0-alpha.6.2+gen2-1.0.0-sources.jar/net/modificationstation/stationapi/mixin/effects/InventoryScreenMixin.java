package net.modificationstation.stationapi.mixin.effects;

import net.minecraft.unmapped.C_46053237;
import net.minecraft.unmapped.C_85589673;
import net.minecraft.unmapped.C_87711245;
import net.modificationstation.stationapi.impl.effect.EffectsRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_85589673.class)
public abstract class InventoryScreenMixin extends C_87711245 {
    @Unique private final EffectsRenderer stationapi_effectRenderer = new EffectsRenderer();
    
    public InventoryScreenMixin(C_46053237 container) {
        super(container);
    }
    
    @Inject(method = "drawBackground", at = @At("TAIL"))
    private void stationapi_renderEffects(float delta, CallbackInfo info) {
        stationapi_effectRenderer.renderEffects(f_78495264, delta, true);
    }
}
