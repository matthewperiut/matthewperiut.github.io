package net.modificationstation.stationapi.impl.network;

import net.minecraft.unmapped.C_10918870;
import net.modificationstation.stationapi.impl.network.packet.s2c.play.RemapClientRegistryS2CPacket;

public abstract class RegistryPacketHandler extends C_10918870 {
    public void onRemapClientRegistry(RemapClientRegistryS2CPacket packet) {
        m_10633301(packet);
    }
}
