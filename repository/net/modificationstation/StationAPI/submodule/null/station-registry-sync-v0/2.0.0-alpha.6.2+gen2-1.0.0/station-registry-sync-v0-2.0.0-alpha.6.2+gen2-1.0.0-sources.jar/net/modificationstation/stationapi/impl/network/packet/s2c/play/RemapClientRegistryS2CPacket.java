package net.modificationstation.stationapi.impl.network.packet.s2c.play;

import it.unimi.dsi.fastutil.objects.Reference2IntLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.Reference2IntMap;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceLinkedOpenHashMap;
import it.unimi.dsi.fastutil.objects.Reference2ReferenceMap;
import lombok.val;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_10918870;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.api.network.packet.PacketType;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.impl.network.RegistryPacketHandler;
import org.jetbrains.annotations.NotNull;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class RemapClientRegistryS2CPacket extends C_03562565 implements ManagedPacket<RemapClientRegistryS2CPacket> {
    public static final PacketType<RemapClientRegistryS2CPacket> TYPE = PacketType
            .builder(true, false, RemapClientRegistryS2CPacket::new)
            .rawId(0)
            .blocking()
            .build();

    public Reference2ReferenceMap<Identifier, Reference2IntMap<Identifier>> map;

    private RemapClientRegistryS2CPacket() {}

    @Environment(EnvType.SERVER)
    public RemapClientRegistryS2CPacket(Reference2ReferenceMap<Identifier, Reference2IntMap<Identifier>> map) {
        this.map = map;
    }

    @Override
    public void m_13296744(DataInputStream stream) {
        val map = new Reference2ReferenceLinkedOpenHashMap<Identifier, Reference2IntMap<Identifier>>();
        try {
            val mapSize = stream.readInt();
            for (int i = 0; i < mapSize; i++) {
                val registryId = Identifier.tryParse(m_86150294(stream, 32767));
                val registryMapping = new Reference2IntLinkedOpenHashMap<Identifier>();
                val registryMappingSize = stream.readInt();
                for (int i1 = 0; i1 < registryMappingSize; i1++)
                    registryMapping.put(Identifier.tryParse(m_86150294(stream, 32767)), stream.readInt());
                map.put(registryId, registryMapping);
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        this.map = map;
    }

    @Override
    public void m_17566769(DataOutputStream stream) {
        try {
            stream.writeInt(map.size());
            map.forEach((registryId, registryMapping) -> {
                try {
                    m_80888813(registryId.toString(), stream);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                try {
                    stream.writeInt(registryMapping.size());
                    registryMapping.forEach((identifier, rawId) -> {
                        try {
                            m_80888813(identifier.toString(), stream);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                        try {
                            stream.writeInt(rawId);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    });
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            });
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_04853589(C_10918870 arg) {
        ((RegistryPacketHandler) arg).onRemapClientRegistry(this);
    }

    @Override
    public int m_85604015() {
        return map.entrySet()
                .stream()
                .mapToInt(entry ->
                        Short.BYTES + entry.getKey().toString().length() * 2
                                + entry.getValue().reference2IntEntrySet()
                                .stream()
                                .mapToInt(registryEntry -> Short.BYTES + registryEntry.getKey().toString().length() * 2 + Integer.BYTES)
                                .sum())
                .sum();
    }

    @Override
    public @NotNull PacketType<RemapClientRegistryS2CPacket> getType() {
        return TYPE;
    }
}
