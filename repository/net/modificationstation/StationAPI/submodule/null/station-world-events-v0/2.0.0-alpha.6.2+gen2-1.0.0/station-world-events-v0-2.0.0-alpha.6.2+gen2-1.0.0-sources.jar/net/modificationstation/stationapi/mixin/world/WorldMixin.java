package net.modificationstation.stationapi.mixin.world;

import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.world.WorldEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_64041439.class)
class WorldMixin {
    @Inject(
            method = {
                    "<init>(Lnet/minecraft/world/storage/WorldStorage;Ljava/lang/String;Lnet/minecraft/world/dimension/Dimension;J)V",
                    "<init>(Lnet/minecraft/world/World;Lnet/minecraft/world/dimension/Dimension;)V",
                    "<init>(Lnet/minecraft/world/storage/WorldStorage;Ljava/lang/String;JLnet/minecraft/world/dimension/Dimension;)V"
            },
            at = @At("RETURN")
    )
    private void stationapi_onCor1(CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(WorldEvent.Init.builder().world(C_64041439.class.cast(this)).build());
    }
    
    @Inject(
            method = "saveWithLoadingDisplay",
            at = @At("HEAD")
    )
    private void stationapi_onLevelSave(CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(WorldEvent.Save.builder().world(C_64041439.class.cast(this)).build());
    }
}
