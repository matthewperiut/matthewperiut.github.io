package net.modificationstation.stationapi.api.event.world;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_64041439;

@SuperBuilder
public abstract class WorldEvent extends Event {
    public final C_64041439 world;

    @SuperBuilder
    public static class Init extends WorldEvent {}

    @SuperBuilder
    public static class Save extends WorldEvent {}
}
