package net.modificationstation.stationapi.api.event.world;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.mine_diver.unsafeevents.event.EventPhases;
import net.minecraft.unmapped.C_64676926;
import net.minecraft.unmapped.C_74087615;
import net.modificationstation.stationapi.api.StationAPI;

@SuperBuilder
public abstract class WorldPropertiesEvent extends Event {
    public final C_64676926 worldProperties;
    public final C_74087615 nbt;

    @SuperBuilder
    public static class Load extends WorldPropertiesEvent {}

    @SuperBuilder
    @EventPhases(StationAPI.INTERNAL_PHASE)
    public static class Save extends WorldPropertiesEvent {
        public final C_74087615 spPlayerNbt;
    }

    @SuperBuilder
    @EventPhases(StationAPI.INTERNAL_PHASE)
    public static class LoadOnWorldInit extends WorldPropertiesEvent {}
}
