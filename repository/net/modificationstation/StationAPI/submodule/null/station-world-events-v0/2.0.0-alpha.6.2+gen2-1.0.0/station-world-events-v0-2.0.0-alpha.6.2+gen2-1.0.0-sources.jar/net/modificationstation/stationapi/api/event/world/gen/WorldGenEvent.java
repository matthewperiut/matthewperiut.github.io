package net.modificationstation.stationapi.api.event.world.gen;

import lombok.experimental.SuperBuilder;
import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_44627882;
import net.modificationstation.stationapi.api.event.world.WorldEvent;

import java.util.Random;

@SuperBuilder
public abstract class WorldGenEvent extends WorldEvent {
    public final C_44627882 worldSource;

    @SuperBuilder
    public static class ChunkDecoration extends WorldGenEvent {
        public final C_28105876 biome;
        public final int x, z;
        public final Random random;
    }
}
