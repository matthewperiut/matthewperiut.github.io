package net.modificationstation.stationapi.mixin.world.client;

import net.minecraft.unmapped.C_13585651;
import net.minecraft.unmapped.C_44627882;
import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.world.gen.WorldGenEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

@Mixin(C_13585651.class)
class ChunkCacheMixin {
    @Shadow
    private C_64041439 world;

    @Shadow
    private C_44627882 generator;
    @Unique
    private Random modRandom;

    @Inject(
            method = "decorate",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/chunk/ChunkSource;decorate(Lnet/minecraft/world/chunk/ChunkSource;II)V",
                    shift = At.Shift.AFTER
            )
    )
    private void stationapi_onPopulate(C_44627882 worldSource, int chunkX, int chunkZ, CallbackInfo ci) {
        int blockX = chunkX * 16;
        int blockZ = chunkZ * 16;
        if (modRandom == null)
            modRandom = new Random();
        modRandom.setSeed(world.m_92966154());
        long xRandomMultiplier = (modRandom.nextLong() / 2L) * 2L + 1L;
        long zRandomMultiplier = (modRandom.nextLong() / 2L) * 2L + 1L;
        modRandom.setSeed((long) chunkX * xRandomMultiplier + (long) chunkZ * zRandomMultiplier ^ world.m_92966154());
        StationAPI.EVENT_BUS.post(
                WorldGenEvent.ChunkDecoration.builder()
                        .world(world)
                        .worldSource(this.generator)
                        .biome(world.m_72354999().m_16975905(blockX + 16, blockZ + 16))
                        .x(blockX).z(blockZ)
                        .random(modRandom)
                        .build()
        );
    }
}
