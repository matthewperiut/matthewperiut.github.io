package net.modificationstation.stationapi.mixin.world;

import net.minecraft.unmapped.C_64676926;
import net.minecraft.unmapped.C_74087615;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.world.WorldPropertiesEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_64676926.class)
public class WorldPropertiesMixin {
    @Inject(
            method = "<init>(Lnet/minecraft/nbt/NbtCompound;)V",
            at = @At("RETURN")
    )
    private void stationapi_onLoadFromTag(C_74087615 arg, CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(
                WorldPropertiesEvent.Load.builder()
                        .worldProperties((C_64676926) (Object) this)
                        .nbt(arg)
                        .build()
        );
    }

    @Inject(
            method = "updateProperties",
            at = @At("RETURN")
    )
    private void stationapi_onSaveToTag(C_74087615 arg, C_74087615 arg1, CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(
                WorldPropertiesEvent.Save.builder()
                        .worldProperties((C_64676926) (Object) this)
                        .nbt(arg)
                        .spPlayerNbt(arg1)
                        .build()
        );
    }
}
