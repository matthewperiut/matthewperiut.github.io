package net.modificationstation.stationapi.api.worldgen.biome;

import net.minecraft.unmapped.C_28105876;

public class TemplateBiome extends C_28105876 {
    public TemplateBiome(String name) {
        this.f_53376351 = name;
        this.f_40051390.clear();
        this.f_03514753.clear();
        this.f_03244403.clear();
    }
}
