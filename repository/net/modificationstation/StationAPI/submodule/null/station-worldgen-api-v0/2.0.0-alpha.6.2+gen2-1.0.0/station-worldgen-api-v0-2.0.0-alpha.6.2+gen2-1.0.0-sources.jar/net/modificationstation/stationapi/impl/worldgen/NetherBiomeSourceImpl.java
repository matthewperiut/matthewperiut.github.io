package net.modificationstation.stationapi.impl.worldgen;

import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_84173844;
import net.modificationstation.stationapi.api.worldgen.BiomeAPI;
import net.modificationstation.stationapi.api.worldgen.biome.BiomeProvider;

public class NetherBiomeSourceImpl extends C_84173844 {
    private static final NetherBiomeSourceImpl INSTANCE = new NetherBiomeSourceImpl();
    private static final C_28105876[] BUFFER = new C_28105876[1];

    private NetherBiomeSourceImpl() {
        super(C_28105876.f_13553440, 1.0, 0.0);
    }
    
    @Override
    public C_28105876 m_16975905(int x, int z) {
        return m_45507066(BUFFER, x, z, 1, 1)[0];
    }
    
    @Override
    public C_28105876[] m_45507066(C_28105876[] data, int x, int z, int dx, int dz) {
        data = super.m_45507066(data, x, z, dx, dz);

        BiomeProvider provider = BiomeAPI.getNetherProvider();

        int index = 0;
        for (int bx = 0; bx < dx; bx++) {
            for (int bz = 0; bz < dz; bz++) {
                data[index++] = provider.getBiome(x + bx, z + bz, 1.0F, 0.0F);
            }
        }

        return data;
    }

    public static NetherBiomeSourceImpl getInstance() {
        return INSTANCE;
    }
}
