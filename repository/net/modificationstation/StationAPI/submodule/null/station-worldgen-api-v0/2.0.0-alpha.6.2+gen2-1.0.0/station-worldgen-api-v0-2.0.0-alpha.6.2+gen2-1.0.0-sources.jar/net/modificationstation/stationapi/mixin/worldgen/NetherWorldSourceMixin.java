package net.modificationstation.stationapi.mixin.worldgen;

import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_44627882;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_77418302;
import net.minecraft.unmapped.C_99454192;
import net.modificationstation.stationapi.impl.worldgen.WorldDecoratorImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_99454192.class)
class NetherWorldSourceMixin {
    @Shadow private C_64041439 world;

    @Inject(
            method = "decorate",
            at = @At("HEAD")
    )
    private void stationapi_makeSurface(C_44627882 source, int cx, int cz, CallbackInfo info) {
        WorldDecoratorImpl.decorate(this.world, cx, cz);
    }
    
    @Inject(
        method = "decorate",
        at = @At(value = "FIELD", target = "Lnet/minecraft/block/SandBlock;fallInstantly:Z", ordinal = 0, shift = Shift.BEFORE),
        cancellable = true
    )
    private void stationapi_cancelFeatureGeneration(C_44627882 source, int cx, int cz, CallbackInfo info) {
        C_28105876 biome = this.world.m_72354999().m_16975905(cx + 16, cz + 16);
        if (biome.isNoDimensionFeatures()) {
            C_77418302.f_03970181 = false;
            info.cancel();
        }
    }
}
