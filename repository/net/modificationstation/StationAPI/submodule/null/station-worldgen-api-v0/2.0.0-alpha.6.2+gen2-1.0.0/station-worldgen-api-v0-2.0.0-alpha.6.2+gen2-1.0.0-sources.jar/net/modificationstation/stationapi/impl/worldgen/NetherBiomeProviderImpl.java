package net.modificationstation.stationapi.impl.worldgen;

import net.minecraft.unmapped.C_28105876;
import net.modificationstation.stationapi.api.worldgen.biome.VoronoiBiomeProvider;

public class NetherBiomeProviderImpl extends VoronoiBiomeProvider {
    private static final NetherBiomeProviderImpl INSTANCE = new NetherBiomeProviderImpl();

    private NetherBiomeProviderImpl() {
        addBiome(C_28105876.f_13553440);
    }

    public static NetherBiomeProviderImpl getInstance() {
        return INSTANCE;
    }
}
