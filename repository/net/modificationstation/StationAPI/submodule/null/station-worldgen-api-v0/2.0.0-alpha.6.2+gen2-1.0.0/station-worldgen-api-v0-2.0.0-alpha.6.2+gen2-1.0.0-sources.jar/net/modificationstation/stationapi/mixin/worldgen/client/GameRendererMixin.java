package net.modificationstation.stationapi.mixin.worldgen.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_03140863;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.impl.worldgen.FogRendererImpl;
import org.lwjgl.opengl.GL11;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_03140863.class)
class GameRendererMixin {
    @Unique private float stationapi_multiplierA;
    @Unique private float stationapi_multiplierB;
    @Shadow private Minecraft client;
    @Shadow float fogRed;
    @Shadow float fogGreen;
    @Shadow float fogBlue;
    
    @WrapOperation(method = "updateSkyAndFogColors", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/World;getRainGradient(F)F"
    ))
    private float statioapi_captureRainMultiplier(C_64041439 world, float delta, Operation<Float> original) {
        float value = original.call(world, delta);
        if (value > 0.0F) {
            stationapi_multiplierA = 1.0F - value * 0.5F;
            stationapi_multiplierB = 1.0F - value * 0.4F;
        }
        else {
            stationapi_multiplierA = 1.0F;
            stationapi_multiplierB = 1.0F;
        }
        return value;
    }
    
    @WrapOperation(method = "updateSkyAndFogColors", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/World;getThunderGradient(F)F"
    ))
    private float statioapi_captureThunderMultiplier(C_64041439 world, float delta, Operation<Float> original) {
        float value = original.call(world, delta);
        if (value > 0.0F) {
            float multiplier = 1.0f - value * 0.5f;
            stationapi_multiplierA *= multiplier;
            stationapi_multiplierB *= multiplier;
        }
        return value;
    }

    @Inject(
            method = "applyFog(IF)V",
            at = @At("HEAD")
    )
    private void stationapi_changeFogColor(int i, float delta, CallbackInfo info) {
        C_74425583 livingEntity = this.client.f_63700667;
        if (!livingEntity.m_52586232(C_89604096.f_99458234) && !livingEntity.m_52586232(C_89604096.f_70482856)) {
            FogRendererImpl.setupFog(client, delta);
            fogRed = FogRendererImpl.getR() * stationapi_multiplierA;
            fogGreen = FogRendererImpl.getG() * stationapi_multiplierA;
            fogBlue = FogRendererImpl.getB() * stationapi_multiplierB;
        }
    }

    @Inject(
            method = "updateSkyAndFogColors(F)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lorg/lwjgl/opengl/GL11;glClearColor(FFFF)V",
                    remap = false,
                    shift = Shift.AFTER
            )
    )
    private void stationapi_clearWithFogColor(float delta, CallbackInfo info) {
        C_74425583 livingEntity = this.client.f_63700667;
        if (!livingEntity.m_52586232(C_89604096.f_99458234) && !livingEntity.m_52586232(C_89604096.f_70482856)) {
            GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);
            GL11.glClearColor(
                FogRendererImpl.getR() * stationapi_multiplierA,
                FogRendererImpl.getG() * stationapi_multiplierA,
                FogRendererImpl.getB() * stationapi_multiplierB,
                1F
            );
        }
    }
}
