package net.modificationstation.stationapi.api.worldgen.biome;

import java.util.Collection;
import net.minecraft.unmapped.C_28105876;

public interface BiomeProvider {
    /**
     * Biome provider method that return {@link C_28105876} based on conditions
     *
     * @param x           block X position
     * @param z           block Z position
     * @param temperature temperature at position
     * @param downfall     wetness (downfall) at position
     * @return {@link C_28105876}
     */
    C_28105876 getBiome(int x, int z, float temperature, float downfall);

    Collection<C_28105876> getBiomes();
    
    default void setSeed(long seed) {}
}
