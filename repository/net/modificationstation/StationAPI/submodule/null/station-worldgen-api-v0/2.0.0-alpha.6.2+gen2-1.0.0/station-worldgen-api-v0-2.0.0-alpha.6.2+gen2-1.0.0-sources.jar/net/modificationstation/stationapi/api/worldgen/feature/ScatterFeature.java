package net.modificationstation.stationapi.api.worldgen.feature;

import java.util.Random;
import net.minecraft.unmapped.C_30339133;
import net.minecraft.unmapped.C_64041439;

public abstract class ScatterFeature extends C_30339133 {
    protected final C_30339133 feature;
    protected final int iterations;

    public ScatterFeature(C_30339133 feature, int iterations) {
        this.feature = feature;
        this.iterations = iterations;
    }

    @Override
    public boolean m_85015587(C_64041439 world, Random random, int x, int y, int z) {
        boolean result = false;
        for (int i = 0; i < iterations; i++) {
            int px = x + random.nextInt(16);
            int pz = z + random.nextInt(16);
            int py = getHeight(world, random, px, y, pz);
            result = feature.m_85015587(world, random, px, py, pz) | result;
        }
        return result;
    }

    protected abstract int getHeight(C_64041439 world, Random random, int x, int y, int z);
}
