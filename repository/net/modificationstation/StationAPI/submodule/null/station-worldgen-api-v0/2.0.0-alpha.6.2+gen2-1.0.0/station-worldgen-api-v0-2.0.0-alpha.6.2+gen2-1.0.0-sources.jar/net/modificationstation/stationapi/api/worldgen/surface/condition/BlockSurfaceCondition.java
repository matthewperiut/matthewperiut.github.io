package net.modificationstation.stationapi.api.worldgen.surface.condition;

import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.block.BlockState;

public class BlockSurfaceCondition implements SurfaceCondition {
    private final C_81592558 block;

    public BlockSurfaceCondition(C_81592558 block) {
        this.block = block;
    }

    @Override
    public boolean canApply(C_64041439 world, int x, int y, int z, BlockState state) {
        return state.isOf(block);
    }
}
