package net.modificationstation.stationapi.impl.worldgen;

import net.minecraft.unmapped.C_28105876;
import net.modificationstation.stationapi.api.worldgen.biome.ClimateBiomeProvider;

import java.util.Collection;

public class OverworldBiomeProviderImpl extends ClimateBiomeProvider {
    private static final OverworldBiomeProviderImpl INSTANCE = new OverworldBiomeProviderImpl();

    private OverworldBiomeProviderImpl() {
    }

    @Override
    public C_28105876 getBiome(int x, int z, float temperature, float downfall) {
        C_28105876 biome = getBiome(temperature, downfall);
        return biome == null ? C_28105876.m_55213567(temperature, downfall) : biome;
    }

    @Override
    protected C_28105876 getBiome(float temperature, float downfall) {
        C_28105876 biome = super.getBiome(temperature, downfall);
        return biome == null ? C_28105876.m_55213567(temperature, downfall) : biome;
    }
    
    @Override
    public Collection<C_28105876> getBiomes() {
        Collection<C_28105876> biomes = super.getBiomes();
        biomes.add(C_28105876.f_57833480);
        biomes.add(C_28105876.f_63543934);
        biomes.add(C_28105876.f_83615720);
        biomes.add(C_28105876.f_87807357);
        biomes.add(C_28105876.f_54339456);
        biomes.add(C_28105876.f_16568699);
        biomes.add(C_28105876.f_94700108);
        biomes.add(C_28105876.f_73939727);
        biomes.add(C_28105876.f_81101322);
        biomes.add(C_28105876.f_87128404);
        biomes.add(C_28105876.f_87467385);
        return biomes;
    }

    public static OverworldBiomeProviderImpl getInstance() {
        return INSTANCE;
    }
}
