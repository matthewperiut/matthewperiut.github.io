package net.modificationstation.stationapi.api.worldgen.biome;

import it.unimi.dsi.fastutil.objects.ObjectOpenHashSet;
import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_68070166;
import net.modificationstation.stationapi.impl.worldgen.IDVoronoiNoise;

import java.util.Collection;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class BiomeRegionsProvider implements BiomeProvider {
    private final double[] buffer = new double[1];
    private final List<BiomeProvider> providers;

    private IDVoronoiNoise idNoise;
    private C_68070166 distortX;
    private C_68070166 distortZ;

    public BiomeRegionsProvider(List<BiomeProvider> providers) {
        this.providers = providers;
    }

    @Override
    public C_28105876 getBiome(int x, int z, float temperature, float downfall) {
        double px = x * 0.01 + distortX.m_09590463(buffer, x, z, 1, 1, 0.1, 0.1, 0.25)[0] * 0.1;
        double pz = z * 0.01 + distortZ.m_09590463(buffer, x, z, 1, 1, 0.1, 0.1, 0.25)[0] * 0.1;
        int id = idNoise.getID(px, pz, providers.size());
        return providers.get(id).getBiome(x, z, temperature, downfall);
    }
    
    @Override
    public Collection<C_28105876> getBiomes() {
        Set<C_28105876> biomes = new ObjectOpenHashSet<>();
        providers.forEach(provider -> biomes.addAll(provider.getBiomes()));
        return biomes;
    }
    
    @Override
    public void setSeed(long seed) {
        Random random = new Random(seed);
        idNoise = new IDVoronoiNoise(random.nextInt());
        distortX = new C_68070166(new Random(random.nextLong()), 2);
        distortZ = new C_68070166(new Random(random.nextLong()), 2);
        providers.forEach(provider -> provider.setSeed(seed));
    }
}
