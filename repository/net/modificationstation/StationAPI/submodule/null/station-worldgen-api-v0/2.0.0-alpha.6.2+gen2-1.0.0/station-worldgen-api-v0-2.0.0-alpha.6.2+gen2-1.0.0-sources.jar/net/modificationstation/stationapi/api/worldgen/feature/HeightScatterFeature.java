package net.modificationstation.stationapi.api.worldgen.feature;

import java.util.Random;
import net.minecraft.unmapped.C_30339133;
import net.minecraft.unmapped.C_64041439;

public class HeightScatterFeature extends ScatterFeature {
    public HeightScatterFeature(C_30339133 feature, int iterations) {
        super(feature, iterations);
    }

    @Override
    protected int getHeight(C_64041439 world, Random random, int x, int y, int z) {
        return world.m_97500331(x, z);
    }
}
