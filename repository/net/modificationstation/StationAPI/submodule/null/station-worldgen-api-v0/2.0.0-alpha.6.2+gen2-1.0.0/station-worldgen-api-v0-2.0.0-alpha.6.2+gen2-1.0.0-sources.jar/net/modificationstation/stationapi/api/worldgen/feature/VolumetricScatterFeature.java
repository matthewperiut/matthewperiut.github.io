package net.modificationstation.stationapi.api.worldgen.feature;

import java.util.Random;
import net.minecraft.unmapped.C_30339133;
import net.minecraft.unmapped.C_64041439;

public class VolumetricScatterFeature extends ScatterFeature {
    protected final int minHeight;
    protected final int deltaHeight;

    public VolumetricScatterFeature(C_30339133 feature, int iterations, int maxHeight) {
        this(feature, iterations, 0, maxHeight);
    }

    public VolumetricScatterFeature(C_30339133 feature, int iterations, int minHeight, int maxHeight) {
        super(feature, iterations);
        this.minHeight = minHeight;
        this.deltaHeight = maxHeight - minHeight + 1;
    }

    @Override
    protected int getHeight(C_64041439 world, Random random, int x, int y, int z) {
        return minHeight + random.nextInt(deltaHeight);
    }
}
