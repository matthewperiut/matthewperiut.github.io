package net.modificationstation.stationapi.impl.worldgen;

import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_77418302;
import net.modificationstation.stationapi.api.block.BlockState;

import java.util.Random;

public class WorldDecoratorImpl {
    private static final C_28105876[] BIOMES = new C_28105876[256];
    private static final Random RANDOM = new Random();

    public static void decorate(C_64041439 world, int cx, int cz) {
        C_77418302.f_03970181 = true;
        
        int x1 = cx << 4 | 8;
        int z1 = cz << 4 | 8;
        int x2 = x1 + 16;
        int z2 = z1 + 16;
        
        world.m_72354999().m_45507066(BIOMES, x1, z1, 16, 16);

        int index = 0;
        for (int x = x1; x < x2; x++) {
            for (int z = z1; z < z2; z++) {
                C_28105876 biome = BIOMES[index++];
                int minY = world.getBottomY();
                int maxY = world.f_00524883.f_98952613 ? world.getTopY() : world.m_97500331(x, z);
                for (int y = minY; y < maxY; y++) {
                    BlockState state = world.getBlockState(x, y, z);
                    biome.applySurfaceRules(world, x, y, z, state);
                }
            }
        }
    
        C_28105876 biome = BIOMES[136];
    
        if (biome.getFeatures().isEmpty()) return;
        
        RANDOM.setSeed(world.m_92966154());
        long dx = (RANDOM.nextLong() >> 1) << 1 | 1;
        long dy = (RANDOM.nextLong() >> 1) << 1 | 1;
        RANDOM.setSeed((long) cx * dx + (long) cz * dy ^ world.m_92966154());
        
        int y = world.m_97500331(x1, z1);
        biome.getFeatures().forEach(feature -> feature.m_85015587(world, RANDOM, x1, y, z1));
    }
}
