package net.modificationstation.stationapi.api.worldgen.surface.condition;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.util.math.MutableBlockPos;

import java.util.function.Predicate;

public class PositionSurfaceCondition implements SurfaceCondition {
    private final MutableBlockPos pos = new MutableBlockPos(0, 0, 0);
    private final Predicate<C_32594356> predicate;

    public PositionSurfaceCondition(Predicate<C_32594356> predicate) {
        this.predicate = predicate;
    }

    @Override
    public boolean canApply(C_64041439 world, int x, int y, int z, BlockState state) {
        pos.set(x, y, z);
        return predicate.test(pos);
    }
}
