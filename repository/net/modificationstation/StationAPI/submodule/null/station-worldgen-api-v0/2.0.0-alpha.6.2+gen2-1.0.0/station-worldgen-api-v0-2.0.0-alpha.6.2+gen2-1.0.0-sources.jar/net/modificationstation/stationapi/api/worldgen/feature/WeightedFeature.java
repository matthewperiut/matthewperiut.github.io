package net.modificationstation.stationapi.api.worldgen.feature;

import java.util.Random;
import net.minecraft.unmapped.C_30339133;
import net.minecraft.unmapped.C_64041439;

public class WeightedFeature extends C_30339133 {
    private final C_30339133 feature;
    private final int weight;

    public WeightedFeature(C_30339133 feature, int weight) {
        this.feature = feature;
        this.weight = weight;
    }

    @Override
    public boolean m_85015587(C_64041439 world, Random random, int x, int y, int z) {
        if (random.nextInt(weight) > 0) return false;
        return feature.m_85015587(world, random, x, y, z);
    }
}
