package net.modificationstation.stationapi.mixin.worldgen;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_08489468;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_90532916;
import net.modificationstation.stationapi.api.worldgen.BiomeAPI;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_64041439.class)
class WorldMixin {
    @Inject(
        method = "<init>(Lnet/minecraft/world/storage/WorldStorage;Ljava/lang/String;JLnet/minecraft/world/dimension/Dimension;)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/dimension/Dimension;setWorld(Lnet/minecraft/world/World;)V",
            shift = Shift.BEFORE
        )
    )
    private void stationapi_onInit(C_08489468 data, String name, long seed, C_90532916 dimension, CallbackInfo info) {
        if (data.m_16306786() != null) {
            seed = data.m_16306786().m_57785247();
        }
        BiomeAPI.init(C_64041439.class.cast(this), seed);
    }
    
    @Inject(
        method = "<init>(Lnet/minecraft/world/storage/WorldStorage;Ljava/lang/String;Lnet/minecraft/world/dimension/Dimension;J)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/dimension/Dimension;setWorld(Lnet/minecraft/world/World;)V",
            shift = Shift.BEFORE
        )
    )
    @Environment(value= EnvType.CLIENT)
    private void stationapi_onInit(C_08489468 data, String name, C_90532916 dimension, long seed, CallbackInfo info) {
        if (data.m_16306786() != null) {
            seed = data.m_16306786().m_57785247();
        }
        BiomeAPI.init(C_64041439.class.cast(this), seed);
    }
    
    @Inject(
        method = "<init>(Lnet/minecraft/world/World;Lnet/minecraft/world/dimension/Dimension;)V",
        at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/world/dimension/Dimension;setWorld(Lnet/minecraft/world/World;)V",
            shift = Shift.BEFORE
        )
    )
    @Environment(value= EnvType.CLIENT)
    private void stationapi_onInit(C_64041439 world, C_90532916 dimension, CallbackInfo info) {
        BiomeAPI.init(world, world.m_92966154());
    }
}
