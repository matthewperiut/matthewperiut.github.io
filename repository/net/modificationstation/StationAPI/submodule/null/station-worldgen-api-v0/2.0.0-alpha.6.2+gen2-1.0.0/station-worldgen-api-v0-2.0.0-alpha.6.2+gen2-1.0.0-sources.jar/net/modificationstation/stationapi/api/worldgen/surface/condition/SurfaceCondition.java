package net.modificationstation.stationapi.api.worldgen.surface.condition;

import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.api.block.BlockState;

@FunctionalInterface
public interface SurfaceCondition {
    boolean canApply(C_64041439 world, int x, int y, int z, BlockState state);
}
