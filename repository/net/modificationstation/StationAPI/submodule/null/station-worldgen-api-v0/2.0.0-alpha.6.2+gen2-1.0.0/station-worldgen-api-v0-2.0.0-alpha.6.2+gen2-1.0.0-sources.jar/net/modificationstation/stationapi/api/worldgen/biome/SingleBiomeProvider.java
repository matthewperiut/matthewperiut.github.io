package net.modificationstation.stationapi.api.worldgen.biome;

import java.util.Collection;
import java.util.Collections;
import net.minecraft.unmapped.C_28105876;

/**
 * Provides one biome independently on conditions
 */
public class SingleBiomeProvider implements BiomeProvider {
    private final C_28105876 biome;

    public SingleBiomeProvider(C_28105876 biome) {
        this.biome = biome;
    }

    @Override
    public C_28105876 getBiome(int x, int z, float temperature, float downfall) {
        return biome;
    }
    
    @Override
    public Collection<C_28105876> getBiomes() {
        return Collections.singleton(biome);
    }
}
