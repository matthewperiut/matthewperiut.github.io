package net.modificationstation.stationapi.api.event.worldgen.biome;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.mine_diver.unsafeevents.event.EventPhases;
import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.api.StationAPI;

@SuperBuilder
@EventPhases(StationAPI.INTERNAL_PHASE)
public class BiomeModificationEvent extends Event {
    public final C_64041439 world;
    public final C_28105876 biome;
}