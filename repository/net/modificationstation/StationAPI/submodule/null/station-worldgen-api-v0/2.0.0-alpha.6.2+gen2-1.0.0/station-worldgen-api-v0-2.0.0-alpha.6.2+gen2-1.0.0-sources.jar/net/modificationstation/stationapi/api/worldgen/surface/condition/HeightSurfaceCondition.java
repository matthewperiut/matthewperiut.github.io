package net.modificationstation.stationapi.api.worldgen.surface.condition;

public class HeightSurfaceCondition extends PositionSurfaceCondition {
    public HeightSurfaceCondition(int minY, int maxY) {
        super((pos) -> pos.f_08824702 >= minY && pos.f_08824702 <= maxY);
    }
}
