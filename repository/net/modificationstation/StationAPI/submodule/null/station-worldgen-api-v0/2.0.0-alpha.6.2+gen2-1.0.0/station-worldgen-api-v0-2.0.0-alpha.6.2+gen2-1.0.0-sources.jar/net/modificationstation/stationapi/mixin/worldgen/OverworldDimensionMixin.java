package net.modificationstation.stationapi.mixin.worldgen;

import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_45196643;
import net.minecraft.unmapped.C_90532916;
import net.modificationstation.stationapi.api.worldgen.BiomeAPI;
import org.spongepowered.asm.mixin.Mixin;

import java.util.Collection;

@Mixin(C_45196643.class)
class OverworldDimensionMixin extends C_90532916 {
    @Override
    public Collection<C_28105876> getBiomes() {
        return BiomeAPI.getOverworldProvider().getBiomes();
    }
}
