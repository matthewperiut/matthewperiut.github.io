package net.modificationstation.stationapi.api.worldgen.feature;

import net.minecraft.unmapped.C_01412318;
import net.minecraft.unmapped.C_30339133;
import net.minecraft.unmapped.C_31348372;
import net.minecraft.unmapped.C_48145476;
import net.minecraft.unmapped.C_55024697;
import net.minecraft.unmapped.C_67236759;
import net.minecraft.unmapped.C_67604311;
import net.minecraft.unmapped.C_71582209;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_93531514;
import net.minecraft.unmapped.C_97433012;
import net.minecraft.world.gen.feature.*;

public class DefaultFeatures {
    public static final C_30339133 OAK_TREE = new C_71582209();
    public static final C_30339133 SPRUCE_TREE = new C_01412318();
    public static final C_30339133 BIRCH_TREE = new C_97433012();
    public static final C_30339133 CACTUS = new C_48145476();
    public static final C_30339133 DEAD_BUSH = new C_55024697(C_81592558.f_99121891.f_84602679);

    public static final C_30339133 WATER_LAKE = new C_67604311(C_81592558.f_91830957.f_84602679);
    public static final C_30339133 LAVA_LAKE = new C_67604311(C_81592558.f_63585395.f_84602679);

    public static final C_30339133 CLAY_DEPOSIT = new C_31348372(32);

    public static final C_30339133 DUNGEON = new C_93531514();

    public static final C_30339133 DIRT_ORE = new C_67236759(C_81592558.f_05581995.f_84602679, 32);
    public static final C_30339133 GRAVEL_ORE = new C_67236759(C_81592558.f_38177074.f_84602679, 32);
    public static final C_30339133 COAL_ORE = new C_67236759(C_81592558.f_81094226.f_84602679, 16);
    public static final C_30339133 IRON_ORE = new C_67236759(C_81592558.f_19757556.f_84602679, 8);
    public static final C_30339133 GOLD_ORE = new C_67236759(C_81592558.f_91577743.f_84602679, 8);
    public static final C_30339133 REDSTONE_ORE = new C_67236759(C_81592558.f_68803305.f_84602679, 7);
    public static final C_30339133 DIAMOND_ORE = new C_67236759(C_81592558.f_35664400.f_84602679, 7);
    public static final C_30339133 LAPIS_LAZULI_ORE = new C_67236759(C_81592558.f_83073694.f_84602679, 6);

    public static final C_30339133 OAK_TREE_SCATTERED = new HeightScatterFeature(OAK_TREE, 3);
    public static final C_30339133 SPRUCE_TREE_SCATTERED = new HeightScatterFeature(SPRUCE_TREE, 3);
    public static final C_30339133 BIRCH_TREE_SCATTERED = new HeightScatterFeature(BIRCH_TREE, 3);
    public static final C_30339133 CACTUS_SCATTERED = new HeightScatterFeature(CACTUS, 3);
    public static final C_30339133 DEAD_BUSH_SCATTERED = new HeightScatterFeature(DEAD_BUSH, 3);

    public static final C_30339133 WATER_LAKE_SCATTERED = new VolumetricScatterFeature(new WeightedFeature(WATER_LAKE, 4), 1, 128);
    public static final C_30339133 LAVA_LAKE_SCATTERED = new BottomWeightedScatter(new WeightedFeature(LAVA_LAKE, 8), 1, 8, 128);

    public static final C_30339133 CLAY_DEPOSIT_SCATTERED = new VolumetricScatterFeature(DUNGEON, 10, 128);
    public static final C_30339133 DUNGEON_SCATTERED = new VolumetricScatterFeature(DUNGEON, 8, 128);

    public static final C_30339133 DIRT_ORE_SCATTERED = new VolumetricScatterFeature(DIRT_ORE, 20, 128);
    public static final C_30339133 GRAVEL_ORE_SCATTERED = new VolumetricScatterFeature(GRAVEL_ORE, 10, 128);
    public static final C_30339133 COAL_ORE_SCATTERED = new VolumetricScatterFeature(COAL_ORE, 20, 128);
    public static final C_30339133 IRON_ORE_SCATTERED = new VolumetricScatterFeature(IRON_ORE, 20, 64);
    public static final C_30339133 GOLD_ORE_SCATTERED = new VolumetricScatterFeature(GOLD_ORE, 2, 32);
    public static final C_30339133 REDSTONE_ORE_SCATTERED = new VolumetricScatterFeature(REDSTONE_ORE, 8, 16);
    public static final C_30339133 DIAMOND_ORE_SCATTERED = new VolumetricScatterFeature(DIAMOND_ORE, 1, 16);
    public static final C_30339133 LAPIS_LAZULI_ORE_SCATTERED = new VolumetricScatterFeature(LAPIS_LAZULI_ORE, 1, 32);
}
