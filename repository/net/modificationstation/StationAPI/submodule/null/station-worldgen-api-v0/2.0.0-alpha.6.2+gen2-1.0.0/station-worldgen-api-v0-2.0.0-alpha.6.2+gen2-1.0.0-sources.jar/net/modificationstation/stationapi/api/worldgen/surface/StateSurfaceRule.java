package net.modificationstation.stationapi.api.worldgen.surface;

import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.api.block.BlockState;

public class StateSurfaceRule extends SurfaceRule {
    private final BlockState state;

    public StateSurfaceRule(BlockState state) {
        this.state = state;
    }

    @Override
    public void apply(C_64041439 world, int x, int y, int z) {
        world.setBlockStateWithoutNotifyingNeighbors(x, y, z, state);
    }
}
