package net.modificationstation.stationapi.api.worldgen.surface.condition;

import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.tag.TagKey;

public class TagSurfaceCondition implements SurfaceCondition {
    private final TagKey<C_81592558> tag;

    public TagSurfaceCondition(TagKey<C_81592558> tag) {
        this.tag = tag;
    }

    @Override
    public boolean canApply(C_64041439 world, int x, int y, int z, BlockState state) {
        return state.isIn(tag);
    }
}
