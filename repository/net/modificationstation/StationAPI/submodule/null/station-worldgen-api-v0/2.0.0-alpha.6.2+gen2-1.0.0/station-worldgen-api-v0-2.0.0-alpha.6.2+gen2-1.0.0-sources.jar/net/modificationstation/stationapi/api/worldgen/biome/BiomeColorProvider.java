package net.modificationstation.stationapi.api.worldgen.biome;

import net.minecraft.unmapped.C_28112798;

@FunctionalInterface
public interface BiomeColorProvider {
    int getColor(C_28112798 source, int x, int z);
}

