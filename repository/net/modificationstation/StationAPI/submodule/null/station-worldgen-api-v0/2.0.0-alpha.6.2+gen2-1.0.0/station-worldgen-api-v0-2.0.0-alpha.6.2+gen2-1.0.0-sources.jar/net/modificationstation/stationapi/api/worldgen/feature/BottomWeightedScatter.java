package net.modificationstation.stationapi.api.worldgen.feature;

import java.util.Random;
import net.minecraft.unmapped.C_30339133;
import net.minecraft.unmapped.C_64041439;

public class BottomWeightedScatter extends VolumetricScatterFeature {
    public BottomWeightedScatter(C_30339133 feature, int iterations, int minHeight, int maxHeight) {
        super(feature, iterations, minHeight, maxHeight);
    }

    @Override
    protected int getHeight(C_64041439 world, Random random, int x, int y, int z) {
        return random.nextInt(minHeight + random.nextInt(deltaHeight));
    }
}
