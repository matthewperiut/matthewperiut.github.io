package net.modificationstation.stationapi.mixin.worldgen.client;

import net.minecraft.unmapped.C_44922783;
import net.minecraft.unmapped.C_46108969;
import net.modificationstation.stationapi.impl.worldgen.BiomeColorsImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_44922783.class)
class LeavesBlockMixin {
    @Inject(
            method = "getColorMultiplier",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/BlockView;getBiomeSource()Lnet/minecraft/world/biome/source/BiomeSource;",
                    ordinal = 0,
                    shift = Shift.BEFORE
            ),
            cancellable = true
    )
    private void stationapi_getBiomeColor(C_46108969 view, int x, int y, int z, CallbackInfoReturnable<Integer> info) {
        int color = BiomeColorsImpl.LEAVES_INTERPOLATOR.getColor(view.m_72354999(), x, z);
        info.setReturnValue(color);
    }
}
