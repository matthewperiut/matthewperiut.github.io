package net.modificationstation.stationapi.impl.worldgen;

import net.minecraft.unmapped.C_19632932;
import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_28112798;
import net.minecraft.unmapped.C_82336779;
import net.modificationstation.stationapi.api.worldgen.biome.BiomeColorProvider;

public class BiomeColorsImpl {
    public static final BiomeColorProvider DEFAULT_GRASS_COLOR = (C_28112798 source, int x, int z) -> {
        source.m_19075238(x, z, 1, 1);
        double t = source.f_57821734[0];
        double w = source.f_84133265[0];
        return C_19632932.m_60771122(t, w);
    };

    public static final BiomeColorProvider DEFAULT_LEAVES_COLOR = (C_28112798 source, int x, int z) -> {
        source.m_19075238(x, z, 1, 1);
        double t = source.f_57821734[0];
        double w = source.f_84133265[0];
        return C_82336779.m_31566293(t, w);
    };

    public static final BiomeColorProvider DEFAULT_FOG_COLOR = (C_28112798 source, int x, int z) -> 0xFFC3DAFF;

    public static final BiomeColorInterpolator GRASS_INTERPOLATOR = new BiomeColorInterpolator(C_28105876::getGrassColor, 8);
    public static final BiomeColorInterpolator LEAVES_INTERPOLATOR = new BiomeColorInterpolator(C_28105876::getLeavesColor, 8);
    public static final BiomeColorInterpolator FOG_INTERPOLATOR = new BiomeColorInterpolator(C_28105876::getFogColor, 16);
}
