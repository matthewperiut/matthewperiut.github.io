package net.modificationstation.stationapi.mixin.worldgen;

import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_49271388;
import net.minecraft.unmapped.C_90532916;
import net.modificationstation.stationapi.api.worldgen.BiomeAPI;
import net.modificationstation.stationapi.impl.worldgen.NetherBiomeSourceImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collection;

@Mixin(C_49271388.class)
class NetherDimensionMixin extends C_90532916 {
    @Inject(
            method = "initBiomeSource",
            at = @At("TAIL")
    )
    private void stationapi_setNetherBiomeSource(CallbackInfo info) {
        this.f_09398021 = NetherBiomeSourceImpl.getInstance();
    }
    
    @Override
    public Collection<C_28105876> getBiomes() {
        return BiomeAPI.getNetherProvider().getBiomes();
    }
}
