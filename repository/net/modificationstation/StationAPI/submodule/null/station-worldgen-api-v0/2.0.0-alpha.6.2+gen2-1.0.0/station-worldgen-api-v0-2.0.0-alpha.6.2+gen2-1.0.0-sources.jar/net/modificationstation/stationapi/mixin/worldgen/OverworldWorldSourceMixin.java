package net.modificationstation.stationapi.mixin.worldgen;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_28112798;
import net.minecraft.unmapped.C_44627882;
import net.minecraft.unmapped.C_49004282;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_77418302;
import net.modificationstation.stationapi.impl.worldgen.WorldDecoratorImpl;
import net.modificationstation.stationapi.impl.worldgen.WorldGeneratorImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(value = C_49004282.class, priority = 2000)
class OverworldWorldSourceMixin {
    @Shadow
    private C_64041439 world;
    @Shadow
    private double[] heightMap;

    @Inject(
            method = "decorate",
            at = @At("HEAD")
    )
    private void stationapi_decorateSurface(C_44627882 source, int cx, int cz, CallbackInfo info) {
        WorldDecoratorImpl.decorate(this.world, cx, cz);
    }
    
    @Inject(
        method = "decorate",
        at = @At(value = "INVOKE", target = "Ljava/util/Random;setSeed(J)V", ordinal = 0, shift = Shift.BEFORE),
        cancellable = true
    )
    private void stationapi_cancelFeatureGeneration(C_44627882 source, int cx, int cz, CallbackInfo info, @Local C_28105876 biome) {
        if (biome.isNoDimensionFeatures()) {
            C_77418302.f_03970181 = false;
            info.cancel();
        }
    }

    @ModifyExpressionValue(
            method = "buildSurfaces",
            at = @At(
                    value = "CONSTANT",
                    args = "intValue=127"
            )
    )
    private int stationapi_cancelSurfaceMaking(int constant, @Local C_28105876 biome) {
        return biome.noSurfaceRules() ? constant : Integer.MIN_VALUE;
    }

    @Inject(
            method = "buildTerrain",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/world/gen/chunk/OverworldChunkGenerator;generateHeightMap([DIIIIII)[D",
                    shift = Shift.AFTER
            )
    )
    private void stationapi_changeHeight(int cx, int cz, byte[] args, C_28105876[] biomes, double[] par5, CallbackInfo info) {
        C_28112798 biomeSource = world.m_72354999();
        biomeSource.f_57821734 = biomeSource.f_84133265 = biomeSource.f_92605078 = null;
        biomeSource.f_72961346 = null;
        WorldGeneratorImpl.updateNoise(world, cx, cz, this.heightMap);
    }
}
