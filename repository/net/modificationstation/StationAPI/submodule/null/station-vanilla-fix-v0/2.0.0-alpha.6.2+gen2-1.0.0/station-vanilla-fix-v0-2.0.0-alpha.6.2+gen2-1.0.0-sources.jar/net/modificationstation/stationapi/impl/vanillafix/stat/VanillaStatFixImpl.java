package net.modificationstation.stationapi.impl.vanillafix.stat;

import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.unmapped.C_62649600;
import net.minecraft.unmapped.C_95106612;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.registry.StatRegistryEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.registry.Registry;
import net.modificationstation.stationapi.api.registry.StatRegistry;

import java.lang.invoke.MethodHandles;

import static net.modificationstation.stationapi.api.util.Identifier.of;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class VanillaStatFixImpl {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void registerStats(StatRegistryEvent event) {
        StatRegistry registry = event.registry;

        register(registry, "start_game", C_95106612.f_01264567);
        register(registry, "create_world", C_95106612.f_24221419);
        register(registry, "load_world", C_95106612.f_81018270);
        register(registry, "join_multiplayer", C_95106612.f_23564034);
        register(registry, "leave_game", C_95106612.f_15892621);
        register(registry, "play_one_minute", C_95106612.f_84209338);
        register(registry, "walk_one_cm", C_95106612.f_57771915);
        register(registry, "swim_one_cm", C_95106612.f_79937119);
        register(registry, "fall_one_cm", C_95106612.f_79978314);
        register(registry, "climb_one_cm", C_95106612.f_97933381);
        register(registry, "fly_one_cm", C_95106612.f_26688556);
        register(registry, "dive_one_cm", C_95106612.f_62697526);
        register(registry, "minecart_one_cm", C_95106612.f_81483092);
        register(registry, "boat_one_cm", C_95106612.f_34445198);
        register(registry, "pig_one_cm", C_95106612.f_95226913);
        register(registry, "jump", C_95106612.f_91671218);
        register(registry, "drop", C_95106612.f_15479164);
        register(registry, "damage_dealt", C_95106612.f_14420982);
        register(registry, "damage_taken", C_95106612.f_75548874);
        register(registry, "deaths", C_95106612.f_70639821);
        register(registry, "mob_kills", C_95106612.f_41248419);
        register(registry, "player_kills", C_95106612.f_61826859);
        register(registry, "fish_caught", C_95106612.f_80218828);
    }

    private static void register(Registry<C_62649600> registry, String id, C_62649600 stat) {
        Registry.register(registry, stat.f_06721285, of(id), stat);
    }
}