package net.modificationstation.stationapi.mixin.vanillafix.client;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_85740840;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_85740840.class)
public interface ScreenAccessor {
    @Accessor
    Minecraft getMinecraft();
}
