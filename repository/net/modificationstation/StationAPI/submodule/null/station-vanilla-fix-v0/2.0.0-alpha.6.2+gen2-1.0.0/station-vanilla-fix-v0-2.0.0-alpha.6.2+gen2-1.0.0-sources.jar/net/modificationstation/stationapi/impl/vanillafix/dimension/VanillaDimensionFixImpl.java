package net.modificationstation.stationapi.impl.vanillafix.dimension;

import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.unmapped.C_08783725;
import net.minecraft.unmapped.C_45196643;
import net.minecraft.unmapped.C_49271388;
import net.minecraft.unmapped.C_90532916;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.registry.DimensionRegistryEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.registry.DimensionContainer;
import net.modificationstation.stationapi.api.util.Identifier;
import org.jetbrains.annotations.NotNull;

import java.lang.invoke.MethodHandles;
import java.util.function.Supplier;

import static net.modificationstation.stationapi.api.world.dimension.VanillaDimensions.*;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class VanillaDimensionFixImpl {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @FunctionalInterface
    interface DimensionRegister { void accept(final @NotNull Identifier id, final int serialID, final @NotNull Supplier<@NotNull C_90532916> factory); }
    @EventListener
    private static void registerDimensions(DimensionRegistryEvent event) {
        DimensionRegister r = (id, serialID, factory) -> event.registry.register(id, serialID, new DimensionContainer<>(factory));
        r.accept(THE_NETHER, -1, C_49271388::new);
        r.accept(OVERWORLD, 0, C_45196643::new);
        r.accept(SKYLANDS, 1, C_08783725::new);
    }
}
