package net.modificationstation.stationapi.impl.vanillafix.achievement;

import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.unmapped.C_90931970;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.achievement.AchievementRegisterEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.registry.Registry;
import net.modificationstation.stationapi.api.registry.StatRegistry;

import java.lang.invoke.MethodHandles;

import static net.minecraft.unmapped.C_95236836.*;
import static net.modificationstation.stationapi.api.util.Identifier.of;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class VanillaAchievementFixImpl {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void registerStats(AchievementRegisterEvent event) {
        register("open_inventory", f_71183985);
        register("mine_wood", f_51283857);
        register("craft_workbench", f_81090114);
        register("craft_pickaxe", f_62976738);
        register("craft_furnace", f_09819557);
        register("acquire_iron", f_12253188);
        register("craft_hoe", f_96171190);
        register("craft_bread", f_05472947);
        register("craft_cake", f_19399566);
        register("craft_stone_pickaxe", f_07509199);
        register("cook_fish", f_30785575);
        register("craft_rail", f_53458874);
        register("craft_sword", f_65467991);
        register("kill_enemy", f_00170670);
        register("kill_cow", f_81608636);
        register("fly_pig", f_85931098);
    }

    private static void register(String id, C_90931970 achievement) {
        Registry.register(StatRegistry.INSTANCE, achievement.f_06721285, of(id), achievement);
    }
}