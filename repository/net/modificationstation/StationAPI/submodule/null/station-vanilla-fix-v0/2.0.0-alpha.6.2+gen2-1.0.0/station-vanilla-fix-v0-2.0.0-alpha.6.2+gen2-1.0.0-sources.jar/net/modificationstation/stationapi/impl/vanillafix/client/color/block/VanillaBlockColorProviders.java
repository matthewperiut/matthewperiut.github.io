package net.modificationstation.stationapi.impl.vanillafix.client.color.block;

import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.unmapped.C_19632932;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.color.world.BiomeColors;
import net.modificationstation.stationapi.api.client.event.color.block.BlockColorsRegisterEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;

import java.lang.invoke.MethodHandles;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class VanillaBlockColorProviders {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void registerBlockColors(BlockColorsRegisterEvent event) {
        event.blockColors.registerColorProvider(
                (state, world, pos, tintIndex) -> world == null || pos == null ? C_19632932.m_60771122(0.5, 1.0) : BiomeColors.getGrassColor(world, pos),
                C_81592558.f_41096518, C_81592558.f_83907852
        );
        event.blockColors.registerColorProvider(
                (state, world, pos, tintIndex) -> world == null || pos == null ? state.getBlock().m_51470331(0) : state.getBlock().m_42775736(world, pos.f_06162490, pos.f_08824702, pos.f_31865394),
                C_81592558.f_00276986
        );
        event.blockColors.registerColorProvider(
                (state, world, pos, tintIndex) -> world == null || pos == null ? -1 : BiomeColors.getWaterColor(world, pos),
                C_81592558.f_12152349, C_81592558.f_91830957
        );
        event.blockColors.registerColorProvider(
                (state, world, pos, tintIndex) -> 0xFFAADB74,
                C_81592558.f_35874681
        );
    }
}