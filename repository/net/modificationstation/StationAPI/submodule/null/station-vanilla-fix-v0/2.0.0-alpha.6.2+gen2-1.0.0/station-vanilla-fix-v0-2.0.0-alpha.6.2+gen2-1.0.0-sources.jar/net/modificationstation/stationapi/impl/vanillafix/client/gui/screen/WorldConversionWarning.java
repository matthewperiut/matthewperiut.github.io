package net.modificationstation.stationapi.impl.vanillafix.client.gui.screen;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_87007645;
import net.modificationstation.stationapi.api.nbt.NbtHelper;
import net.modificationstation.stationapi.impl.world.storage.FlattenedWorldStorage;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class WorldConversionWarning {
    public static final String
            ROOT_KEY = "gui." + NAMESPACE + ".worldConversion",
            FROM_MCREGION_EXPLANATION_KEY = ROOT_KEY + ".fromMcRegionExplanation",
            TO_MCREGION_EXPLANATION_KEY = ROOT_KEY + ".toMcRegionExplanation",
            CONVERT_KEY = ROOT_KEY + ".convert";

    public static void warnIfMcRegion(Minecraft minecraft, C_85740840 parentScreen, C_87007645 worldData, Runnable loadWorld) {
        if (NbtHelper.getDataVersions(((FlattenedWorldStorage) minecraft.m_98129977()).getWorldTag(worldData.m_07607595())).m_97612750(NAMESPACE.toString()))
            loadWorld.run();
        else minecraft.m_52715402(new WarningScreen(parentScreen, loadWorld, FROM_MCREGION_EXPLANATION_KEY, CONVERT_KEY));
    }
}
