package net.modificationstation.stationapi.impl.vanillafix.client.gui.screen;

import com.mojang.serialization.Dynamic;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_76536438;
import net.minecraft.unmapped.C_85125467;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.event.gui.screen.EditWorldScreenEvent;
import net.modificationstation.stationapi.api.client.gui.widget.ButtonWidgetDetachedContext;
import net.modificationstation.stationapi.api.datafixer.DataFixers;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.nbt.NbtHelper;
import net.modificationstation.stationapi.api.nbt.NbtOps;
import net.modificationstation.stationapi.impl.vanillafix.datafixer.VanillaDataFixerImpl;
import net.modificationstation.stationapi.impl.world.storage.FlattenedWorldStorage;
import net.modificationstation.stationapi.mixin.vanillafix.client.ScreenAccessor;

import java.io.IOException;
import java.lang.invoke.MethodHandles;

import static net.mine_diver.unsafeevents.listener.ListenerPriority.LOW;
import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;

@Environment(EnvType.CLIENT)
@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class EditWorldScreenImpl {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    private static final String
            ROOT_KEY = "selectWorld." + NAMESPACE,
            CONVERT_TO_MCREGION_KEY = ROOT_KEY + ".convertToMcRegion";

    @EventListener(priority = LOW)
    private static void registerConversionButton(EditWorldScreenEvent.ScrollableButtonContextRegister event) {
        event.contexts.add(screen -> new ButtonWidgetDetachedContext(
                id -> {
                    C_85125467 button = new C_85125467(id, 0, 0, C_76536438.m_79832914(CONVERT_TO_MCREGION_KEY));
                    button.f_89460239 = NbtHelper.getDataVersions(((FlattenedWorldStorage) ((ScreenAccessor) screen).getMinecraft().m_98129977()).getWorldTag(screen.worldData.m_07607595())).m_97612750(NAMESPACE.toString());
                    return button;
                },
                button -> ((ScreenAccessor) screen).getMinecraft().m_52715402(new WarningScreen(screen, () -> {
                    Minecraft mc = ((ScreenAccessor) screen).getMinecraft();
                    mc.setScreen(null);
                    FlattenedWorldStorage worldStorage = (FlattenedWorldStorage) mc.getWorldStorageSource();
                    mc.progressRenderer.progressStart("Converting World to " + worldStorage.getPreviousWorldFormat());
                    mc.progressRenderer.progressStage("This may take a while :)");
                    try {
                        worldStorage.convertWorld(screen.worldData.getSaveName(), (type, compound) -> (NbtCompound) VanillaDataFixerImpl.DATA_DAMAGER.get().update(type, new Dynamic<>(NbtOps.INSTANCE, compound).remove(DataFixers.DATA_VERSIONS), VanillaDataFixerImpl.HIGHEST_VERSION - NbtHelper.getDataVersions(compound).getInt(NAMESPACE.toString()), VanillaDataFixerImpl.VANILLA_VERSION).getValue(), mc.progressRenderer);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    mc.setScreen(screen);
                }, WorldConversionWarning.TO_MCREGION_EXPLANATION_KEY, WorldConversionWarning.CONVERT_KEY))
        ));
    }
}
