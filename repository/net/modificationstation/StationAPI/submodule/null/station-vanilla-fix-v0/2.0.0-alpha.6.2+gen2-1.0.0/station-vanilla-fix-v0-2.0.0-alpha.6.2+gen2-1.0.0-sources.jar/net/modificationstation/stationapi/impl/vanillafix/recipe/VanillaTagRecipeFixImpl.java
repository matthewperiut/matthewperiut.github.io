package net.modificationstation.stationapi.impl.vanillafix.recipe;

import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import com.google.common.collect.ImmutableMap;
import lombok.val;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.registry.tag.ItemTags;
import net.modificationstation.stationapi.api.tag.TagKey;

public class VanillaTagRecipeFixImpl {
    private static final Supplier<ImmutableMap<C_98888256, TagKey<C_98888256>>> TAGIFICATION_MAP = Suppliers.memoize(() -> {
        val builder = ImmutableMap.<C_98888256, TagKey<C_98888256>>builder();
        builder.put(C_81592558.f_32493286.asItem(), ItemTags.PLANKS);
        builder.put(C_81592558.f_17981199.asItem(), ItemTags.NORMAL_COBBLESTONES);
        builder.put(C_81592558.f_27446762.asItem(), ItemTags.NORMAL_SANDS);
        builder.put(C_81592558.f_49828421.asItem(), ItemTags.WOODEN_CHESTS);
        builder.put(C_81592558.f_12629815.asItem(), ItemTags.WOOLS);
        builder.put(C_98888256.f_80480869, ItemTags.IRON_INGOTS);
        builder.put(C_98888256.f_73771168, ItemTags.GOLD_INGOTS);
        builder.put(C_98888256.f_88723374, ItemTags.GLOWSTONE_DUSTS);
        builder.put(C_98888256.f_52656331, ItemTags.REDSTONE_DUSTS);
        builder.put(C_98888256.f_18976102, ItemTags.DIAMOND_GEMS);
        builder.put(C_81592558.f_54760749.asItem(), ItemTags.GOLD_STORAGE_BLOCKS);
        builder.put(C_98888256.f_21279732, ItemTags.NORMAL_BRICKS);
        builder.put(C_98888256.f_94759491, ItemTags.STRINGS);
        builder.put(C_98888256.f_32150368, ItemTags.GUNPOWDERS);
        builder.put(C_98888256.f_08971169, ItemTags.LEATHERS);
        builder.put(C_98888256.f_56704454, ItemTags.FEATHERS);
        builder.put(C_98888256.f_46317332, ItemTags.SLIME_BALLS);
        builder.put(C_98888256.f_51993064, ItemTags.BONES);
        builder.put(C_98888256.f_03970011, ItemTags.EGGS);
        builder.put(C_98888256.f_60617725, ItemTags.WHEAT_CROPS);
        builder.put(C_98888256.f_59992682, ItemTags.BOWS);
        builder.put(C_98888256.f_70868303, ItemTags.WOODEN_STICKS);
        builder.put(C_81592558.f_30894038.asItem(), ItemTags.RED_MUSHROOMS);
        builder.put(C_81592558.f_55254929.asItem(), ItemTags.BROWN_MUSHROOMS);
        return builder.build();
    });

    public static boolean tagifyIngredients(Object[] input) {
        boolean tagified = false;
        int i = 1;
        while (!(input[i++] instanceof Character));
        for (; i < input.length; i += 2) {
            Object rawIngredient = input[i];

            C_98888256 ingredient;
            if (rawIngredient instanceof C_98888256 item) ingredient = item;
            else if (rawIngredient instanceof C_81592558 block) ingredient = block.asItem();
            else continue;

            val tagificationMap = TAGIFICATION_MAP.get();
            if (!tagificationMap.containsKey(ingredient)) continue;

            tagified = true;
            input[i] = tagificationMap.get(ingredient);
        }
        return tagified;
    }
}
