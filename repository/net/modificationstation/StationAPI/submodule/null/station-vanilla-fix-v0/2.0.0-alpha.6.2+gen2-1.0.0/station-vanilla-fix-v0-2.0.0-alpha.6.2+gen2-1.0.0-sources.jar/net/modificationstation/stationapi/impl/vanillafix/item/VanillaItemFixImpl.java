package net.modificationstation.stationapi.impl.vanillafix.item;

import net.mine_diver.unsafeevents.listener.EventListener;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.registry.ItemRegistryEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.util.Namespace;

import java.lang.invoke.MethodHandles;

import static net.minecraft.unmapped.C_98888256.*;
import static net.modificationstation.stationapi.api.StationAPI.LOGGER;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class VanillaItemFixImpl {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void registerItems(ItemRegistryEvent event) {
        event.register(item -> item.f_57562535, Namespace.MINECRAFT)
                .accept("iron_shovel", f_80805461)
                .accept("iron_pickaxe", f_98306436)
                .accept("iron_axe", f_89785708)
                .accept("flint_and_steel", f_96370468)
                .accept("apple", f_57144513)
                .accept("bow", f_59992682)
                .accept("arrow", f_67660833)
                .accept("coal", f_58154723)
                .accept("diamond", f_18976102)
                .accept("iron_ingot", f_80480869)
                .accept("gold_ingot", f_73771168)
                .accept("iron_sword", f_32125146)
                .accept("wooden_sword", f_96913276)
                .accept("wooden_shovel", f_38813183)
                .accept("wooden_pickaxe", f_50174679)
                .accept("wooden_axe", f_27888996)
                .accept("stone_sword", f_13344738)
                .accept("stone_shovel", f_18708761)
                .accept("stone_pickaxe", f_88921834)
                .accept("stone_axe", f_02912756)
                .accept("diamond_sword", f_29490209)
                .accept("diamond_shovel", f_04770191)
                .accept("diamond_pickaxe", f_43932574)
                .accept("diamond_axe", f_45386391)
                .accept("stick", f_70868303)
                .accept("bowl", f_21498627)
                .accept("mushroom_stew", f_94828714)
                .accept("golden_sword", f_56140732)
                .accept("golden_shovel", f_50429169)
                .accept("golden_pickaxe", f_68090982)
                .accept("golden_axe", f_08977302)
                .accept("string", f_94759491)
                .accept("feather", f_56704454)
                .accept("gunpowder", f_32150368)
                .accept("wooden_hoe", f_03688690)
                .accept("stone_hoe", f_98142733)
                .accept("iron_hoe", f_57678723)
                .accept("diamond_hoe", f_35880850)
                .accept("golden_hoe", f_31038121)
                .accept("wheat_seeds", f_84974010)
                .accept("wheat", f_60617725)
                .accept("bread", f_94155714)
                .accept("leather_helmet", f_92705060)
                .accept("leather_chestplate", f_60255230)
                .accept("leather_leggings", f_78687479)
                .accept("leather_boots", f_65686175)
                .accept("chainmail_helmet", f_20484061)
                .accept("chainmail_chestplate", f_92537726)
                .accept("chainmail_leggings", f_24275834)
                .accept("chainmail_boots", f_67341244)
                .accept("iron_helmet", f_84448376)
                .accept("iron_chestplate", f_56682976)
                .accept("iron_leggings", f_64671240)
                .accept("iron_boots", f_96568531)
                .accept("diamond_helmet", f_00953201)
                .accept("diamond_chestplate", f_54219088)
                .accept("diamond_leggings", f_42239243)
                .accept("diamond_boots", f_21328201)
                .accept("golden_helmet", f_06326883)
                .accept("golden_chestplate", f_58467061)
                .accept("golden_leggings", f_20229887)
                .accept("golden_boots", f_08730706)
                .accept("flint", f_08935226)
                .accept("porkchop", f_70512792)
                .accept("cooked_porkchop", f_40838509)
                .accept("painting", f_27056679)
                .accept("golden_apple", f_18291365)
                .accept("oak_sign", f_97502738)
                .accept("oak_door", f_92303073)
                .accept("bucket", f_91599154)
                .accept("water_bucket", f_94313583)
                .accept("lava_bucket", f_32467447)
                .accept("minecart", f_72559846)
                .accept("saddle", f_07293363)
                .accept("iron_door", f_40777991)
                .accept("redstone", f_52656331)
                .accept("snowball", f_10659101)
                .accept("oak_boat", f_67114151)
                .accept("leather", f_08971169)
                .accept("milk_bucket", f_62954975)
                .accept("brick", f_21279732)
                .accept("clay_ball", f_39465979)
                .accept("sugar_cane", f_55275152)
                .accept("paper", f_90966147)
                .accept("book", f_32576217)
                .accept("slime_ball", f_46317332)
                .accept("chest_minecart", f_20481988)
                .accept("furnace_minecart", f_49490949)
                .accept("egg", f_03970011)
                .accept("compass", f_53864758)
                .accept("fishing_rod", f_57012528)
                .accept("clock", f_10956141)
                .accept("glowstone_dust", f_88723374)
                .accept("cod", f_87025895)
                .accept("cooked_cod", f_87709655)
                .accept("dye", f_09260276)
                .accept("bone", f_51993064)
                .accept("sugar", f_79588801)
                .accept("cake", f_59726285)
                .accept("red_bed", f_08856223)
                .accept("repeater", f_98054602)
                .accept("cookie", f_91086089)
                .accept("map", f_69447318)
                .accept("shears", f_18374421)
                .accept("music_disc_13", f_30116592)
                .accept("music_disc_cat", f_33926157);

        LOGGER.info("Added vanilla items to the registry.");
    }

}
