package net.modificationstation.stationapi.mixin.vanillafix.client;

import net.minecraft.unmapped.C_43588014;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_87007645;
import net.modificationstation.stationapi.impl.vanillafix.client.gui.screen.WorldConversionWarning;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;

@Mixin(C_43588014.class)
class SelectWorldScreenMixin extends C_85740840 {
    @Shadow private List<C_87007645> saves;

    @Redirect(
            method = "buttonClicked",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screen/world/SelectWorldScreen;selectWorld(I)V"
            )
    )
    private void stationapi_warn(C_43588014 instance, int i) {
        WorldConversionWarning.warnIfMcRegion(f_78495264, instance, saves.get(i), () -> instance.m_15535998(i));
    }
}
