package net.modificationstation.stationapi.mixin.vanillafix.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.unmapped.C_43588014;
import net.minecraft.unmapped.C_87007645;

@Mixin(C_43588014.class)
public interface SelectWorldScreenAccessor {
    @Accessor
    List<C_87007645> getSaves();
}
