package net.modificationstation.stationapi.impl.vanillafix.client.gui.screen;

import lombok.RequiredArgsConstructor;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_76536438;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_96603444;
import net.modificationstation.stationapi.api.client.gui.screen.StationScreen;
import net.modificationstation.stationapi.api.client.gui.widget.ButtonWidgetAttachedContext;
import org.lwjgl.opengl.GL11;

import java.awt.*;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;

@RequiredArgsConstructor
public class WarningScreen extends StationScreen {
    public static final String
            WARNING_KEY = "gui." + NAMESPACE + ".warning";

    private static final int CONFIRMATION_TIMEOUT = FabricLoader.getInstance().isDevelopmentEnvironment() ? 3000 : 25000;

    private final C_85740840 parent;
    private final Runnable action;
    private final String
            explanationKey,
            confirmKey;
    private ButtonWidgetAttachedContext confirmButton;
    private final long createdTimestamp = System.currentTimeMillis();

    @Override
    public void m_41805697() {
        super.m_41805697();
        confirmButton = btns.attach(
                id -> {
                    C_85125467 button = new C_85125467(id, f_05230747 / 2 - 100, f_07021018 - f_07021018 / 10 - 44, C_76536438.m_79832914(confirmKey));
                    button.f_89460239 = false;
                    return button;
                },
                button -> action.run()
        );
        btns.attach(
                id -> new C_85125467(id, f_05230747 / 2 - 100, f_07021018 - f_07021018 / 10 - 20, C_76536438.m_79832914("gui.cancel")),
                button -> f_78495264.m_52715402(parent)
        );
    }

    private void renderDirtBackground(long time) {
        GL11.glDisable(2896);
        GL11.glDisable(2912);
        C_96603444 tessellator = C_96603444.f_99414865;
        GL11.glBindTexture(3553, f_78495264.f_45465196.m_33729172("/gui/background.png"));
        GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
        float f = 32.0f;
        int color = 48 + (int) (C_45510667.m_35585879(C_45510667.m_61414107((float) ((time % 50000L) / 50000D * Math.PI * 2))) * 32);
        color = color << 16 | color << 8 | color;
        double offsetU = C_45510667.m_61414107((float) ((time % 30000L) / 30000D * Math.PI * 2)) * 10;
        double offsetV = C_45510667.m_61414107((float) ((time % 5000L) / 5000D * Math.PI * 2));
        tessellator.m_35940071();
        tessellator.m_18881924(color);
        tessellator.m_75942980(0.0, f_07021018, 0.0, offsetU, f_07021018 / f + offsetV);
        tessellator.m_75942980(f_05230747, f_07021018, 0.0, f_05230747 / f + offsetU, f_07021018 / f + offsetV);
        tessellator.m_75942980(f_05230747, 0.0, 0.0, f_05230747 / f + offsetU, offsetV);
        tessellator.m_75942980(0.0, 0.0, 0.0, offsetU, offsetV);
        tessellator.m_70070273();
    }

    @Override
    public void m_93956703(int i, int j, float f) {
        long time = System.currentTimeMillis();
        renderDirtBackground(time);
        GL11.glPushMatrix();
        String warning = C_76536438.m_79832914(WARNING_KEY);
        double warningScale = 2 + C_45510667.m_61414107((float) ((time % 5000L) / 5000D * Math.PI * 2)) * 0.1F;
        GL11.glTranslated(f_05230747 / 2D - f_11884601.m_09235706(warning) * warningScale / 2D, f_07021018 / 10D, 0);
        GL11.glScaled(warningScale, warningScale, 1);
        m_62884682(f_11884601, warning, 0, 0, Color.YELLOW.hashCode());
        GL11.glPopMatrix();
        String[] info = C_76536438.m_79832914(explanationKey).split("\\n");
        int curHeight = f_07021018 / 3;
        for (String line : info) {
            int lineWidth = f_11884601.m_09235706(line);
            if (lineWidth > f_05230747 - 20) {
                int begin = 0;
                int lastSpace = -1;
                for (int cur = 0, lineLength = line.length(); cur < lineLength; cur++) {
                    boolean isSpace = line.charAt(cur) == ' ';
                    boolean isEnd = cur + 1 == lineLength;
                    if (isSpace || isEnd) {
                        String newLine = isEnd ? line.substring(begin) : line.substring(begin, cur);
                        int newLineWidth = f_11884601.m_09235706(newLine);
                        if (newLineWidth > f_05230747 - 20) {
                            m_50067982(f_11884601, line.substring(begin, lastSpace), f_05230747 / 2, curHeight, Color.WHITE.hashCode());
                            curHeight += 10;
                            begin = lastSpace + 1;
                        }
                        if (isSpace)
                            lastSpace = cur;
                        if (isEnd) {
                            m_50067982(f_11884601, line.substring(begin), f_05230747 / 2, curHeight, Color.WHITE.hashCode());
                            curHeight += 10;
                        }
                    }
                }
            } else {
                m_50067982(f_11884601, line, f_05230747 / 2, curHeight, Color.WHITE.hashCode());
                curHeight += 10;
            }
        }
        long confirmationTimeout = time - createdTimestamp;
        if (confirmationTimeout > CONFIRMATION_TIMEOUT) {
            if (!confirmButton.button().f_89460239) {
                confirmButton.button().f_89460239 = true;
                confirmButton.button().f_35112386 = C_76536438.m_79832914(confirmKey);
            }
        } else confirmButton.button().f_35112386 = C_76536438.m_79832914(confirmKey) + " (" + (CONFIRMATION_TIMEOUT - confirmationTimeout) / 1000 + "s)";
        super.m_93956703(i, j, f);
    }
}
