package net.modificationstation.stationapi.impl.vanillafix.block;

import com.google.common.base.Suppliers;
import it.unimi.dsi.fastutil.objects.ReferenceOpenHashSet;
import it.unimi.dsi.fastutil.objects.ReferenceSet;
import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.unmapped.C_71827890;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.block.StationBlockItemsBlock;
import net.modificationstation.stationapi.api.event.registry.BlockItemRegistryEvent;
import net.modificationstation.stationapi.api.event.registry.BlockRegistryEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.registry.BlockRegistry;
import net.modificationstation.stationapi.api.registry.ItemRegistry;
import net.modificationstation.stationapi.api.util.Namespace;
import net.modificationstation.stationapi.api.util.Util;

import java.lang.invoke.MethodHandles;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Supplier;

import static net.mine_diver.unsafeevents.listener.ListenerPriority.LOW;
import static net.minecraft.unmapped.C_81592558.*;
import static net.modificationstation.stationapi.api.StationAPI.LOGGER;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class VanillaBlockFixImpl {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    public static final Supplier<ReferenceSet<C_81592558>> COLLISION_BLOCKS = Suppliers.memoize(() -> Util.make(new ReferenceOpenHashSet<>(), s -> {
        s.add(f_10487872);
        s.add(f_09380838);
        s.add(f_30518711);
        s.add(f_84644959);
        s.add(f_91546482);
        s.add(f_35874681);
        s.add(f_98529173);
        s.add(f_77070700);
    }));

    @EventListener
    private static void registerBlocks(BlockRegistryEvent event) {
        event.register(block -> block.f_84602679, Namespace.MINECRAFT)
                .accept("stone", f_38442324)
                .accept("grass_block", f_41096518)
                .accept("dirt", f_05581995)
                .accept("cobblestone", f_17981199)
                .accept("oak_planks", f_32493286)
                .accept("sapling", f_77878473)
                .accept("bedrock", f_35695348)
                .accept("flowing_water", f_12152349)
                .accept("water", f_91830957)
                .accept("flowing_lava", f_42662644)
                .accept("lava", f_63585395)
                .accept("sand", f_27446762)
                .accept("gravel", f_38177074)
                .accept("gold_ore", f_91577743)
                .accept("iron_ore", f_19757556)
                .accept("coal_ore", f_81094226)
                .accept("log", f_78280144)
                .accept("leaves", f_00276986)
                .accept("sponge", f_36441950)
                .accept("glass", f_32420701)
                .accept("lapis_ore", f_83073694)
                .accept("lapis_block", f_99851615)
                .accept("dispenser", f_58920251)
                .accept("sandstone", f_94949418)
                .accept("note_block", f_82599628)
                .accept("red_bed", f_10487872)
                .accept("powered_rail", f_27559703)
                .accept("detector_rail", f_89685822)
                .accept("sticky_piston", f_85558300)
                .accept("cobweb", f_88550428)
                .accept("grass", f_83907852)
                .accept("dead_bush", f_99121891)
                .accept("piston", f_65735585)
                .accept("piston_head", f_95852348)
                .accept("wool", f_12629815)
                .accept("moving_piston", f_89678708)
                .accept("dandelion", f_38977206)
                .accept("rose", f_72900486)
                .accept("brown_mushroom", f_55254929)
                .accept("red_mushroom", f_30894038)
                .accept("gold_block", f_54760749)
                .accept("iron_block", f_41428926)
                .accept("double_slab", f_39350323)
                .accept("slab", f_66929948)
                .accept("bricks", f_73573195)
                .accept("tnt", f_69656505)
                .accept("bookshelf", f_22197047)
                .accept("mossy_cobblestone", f_87667057)
                .accept("obsidian", f_38591135)
                .accept("torch", f_23542568)
                .accept("fire", f_48624188)
                .accept("spawner", f_50662990)
                .accept("oak_stairs", f_31892463)
                .accept("chest", f_49828421)
                .accept("redstone_wire", f_08141062)
                .accept("diamond_ore", f_35664400)
                .accept("diamond_block", f_95737061)
                .accept("crafting_table", f_30918233)
                .accept("wheat", f_09380838)
                .accept("farmland", f_95757196)
                .accept("furnace", f_19785413)
                .accept("furnace_lit", f_78357199)
                .accept("oak_sign", f_30518711)
                .accept("oak_door", f_84644959)
                .accept("ladder", f_51448992)
                .accept("rail", f_86544900)
                .accept("cobblestone_stairs", f_38259672)
                .accept("oak_wall_sign", f_13293967)
                .accept("lever", f_82613228)
                .accept("stone_pressure_plate", f_90267132)
                .accept("iron_door", f_91546482)
                .accept("oak_pressure_plate", f_58356112)
                .accept("redstone_ore", f_68803305)
                .accept("redstone_ore_lit", f_88434840)
                .accept("redstone_torch", f_19964067)
                .accept("redstone_torch_lit", f_78503403)
                .accept("stone_button", f_40727126)
                .accept("snow", f_81695559)
                .accept("ice", f_28421768)
                .accept("snow_block", f_51102006)
                .accept("cactus", f_94556547)
                .accept("clay", f_86394960)
                .accept("sugar_cane", f_35874681)
                .accept("jukebox", f_25017736)
                .accept("oak_fence", f_98928673)
                .accept("carved_pumpkin", f_94091898)
                .accept("netherrack", f_14995882)
                .accept("soul_sand", f_84892602)
                .accept("glowstone", f_19295217)
                .accept("nether_portal", f_18320492)
                .accept("jack_o_lantern", f_49218653)
                .accept("cake", f_98529173)
                .accept("repeater", f_77070700)
                .accept("repeater_lit", f_02852022)
                .accept("locked_chest", f_69293475)
                .accept("oak_trapdoor", f_79966048);

        LOGGER.info("Added vanilla blocks to the registry.");
    }

    @EventListener(priority = LOW)
    private static void disableAutomaticBlockItemRegistration(BlockRegistryEvent event) {
        Consumer<C_81592558> c = StationBlockItemsBlock::disableAutoItemRegistration;
        c.accept(f_44428008[0]); // not supposed to have an item form
        COLLISION_BLOCKS.get().forEach(c); // item name collision
    }

    @EventListener
    private static void registerBlockItems(BlockItemRegistryEvent event) {
        Consumer<C_81592558> c = block -> event.register(BlockRegistry.INSTANCE.getId(block), C_98888256.f_38445253[block.f_84602679]);

        c.accept(C_81592558.f_12629815);
        c.accept(C_81592558.f_78280144);
        c.accept(C_81592558.f_66929948);
        c.accept(C_81592558.f_77878473);
        c.accept(C_81592558.f_00276986);
        c.accept(C_81592558.f_65735585);
        c.accept(C_81592558.f_85558300);

        COLLISION_BLOCKS.get().forEach(block -> event.register(Objects.requireNonNull(BlockRegistry.INSTANCE.getId(block)).withSuffixedPath("_unobtainable"), new C_71827890(ItemRegistry.SHIFTED_ID.get(block.f_84602679))));
    }
}
