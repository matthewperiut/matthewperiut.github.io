package net.modificationstation.stationapi.mixin.vanillafix.client;

import net.minecraft.unmapped.C_43588014;
import net.modificationstation.stationapi.impl.vanillafix.client.gui.screen.WorldConversionWarning;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(targets = "net.minecraft.client.gui.screen.world.SelectWorldScreen$WorldListWidget")
class WorldListWidgetMixin {
    @Redirect(
            method = "entryClicked(IZ)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screen/world/SelectWorldScreen;selectWorld(I)V"
            )
    )
    private void stationapi_warn(C_43588014 instance, int i) {
        WorldConversionWarning.warnIfMcRegion(((ScreenAccessor) instance).getMinecraft(), instance, ((SelectWorldScreenAccessor) instance).getSaves().get(i), () -> instance.m_15535998(i));
    }
}
