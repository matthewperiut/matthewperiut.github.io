package net.modificationstation.stationapi.impl.network.packet;

import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;

public abstract class PacketHelperImpl {
    public abstract void send(C_03562565 packet);

    public abstract void sendTo(C_40996800 player, C_03562565 packet);

    public abstract void dispatchLocallyAndSendTo(C_40996800 player, C_03562565 packet);

    public abstract void sendToAllTracking(C_42232651 entity, C_03562565 packet);

    public abstract void dispatchLocallyAndToAllTracking(C_42232651 entity, C_03562565 packet);
}
