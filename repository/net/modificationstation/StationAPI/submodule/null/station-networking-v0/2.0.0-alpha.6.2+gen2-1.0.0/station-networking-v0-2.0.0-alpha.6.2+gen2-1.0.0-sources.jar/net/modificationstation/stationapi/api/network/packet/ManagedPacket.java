package net.modificationstation.stationapi.api.network.packet;

import net.minecraft.unmapped.C_03562565;
import org.jetbrains.annotations.NotNull;

public interface ManagedPacket<T extends C_03562565 & ManagedPacket<T>> {
    int PACKET_ID = 254;

    @NotNull PacketType<T> getType();

    @FunctionalInterface
    interface Factory<T extends C_03562565 & ManagedPacket<T>> {
        @NotNull T create();
    }
}
