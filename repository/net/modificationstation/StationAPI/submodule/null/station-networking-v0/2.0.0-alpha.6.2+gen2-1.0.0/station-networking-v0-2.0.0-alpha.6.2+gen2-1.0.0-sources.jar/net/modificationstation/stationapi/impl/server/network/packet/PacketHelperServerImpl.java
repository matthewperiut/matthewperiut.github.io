package net.modificationstation.stationapi.impl.server.network.packet;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_49202226;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.impl.network.packet.PacketHelperImpl;

public class PacketHelperServerImpl extends PacketHelperImpl {
    @Override
    public void send(C_03562565 packet) {
        packet.m_04853589(
                packet instanceof ManagedPacket<?> managedPacket
                        ? managedPacket.getType().getHandler().orElse(null)
                        : null
        );
    }

    @Override
    public void sendTo(C_40996800 player, C_03562565 packet) {
        ((C_49202226) player).f_70275341.m_61088315(packet);
    }

    @Override
    public void dispatchLocallyAndSendTo(C_40996800 player, C_03562565 packet) {
        send(packet);
        sendTo(player, packet);
    }

    @Override
    public void sendToAllTracking(C_42232651 entity, C_03562565 packet) {
        //noinspection deprecation
        ((MinecraftServer) FabricLoader.getInstance().getGameInstance())
                .m_57714919(entity.f_94306729.f_00524883.f_09977150).m_04464298(entity, packet);
    }

    @Override
    public void dispatchLocallyAndToAllTracking(C_42232651 entity, C_03562565 packet) {
        send(packet);
        sendToAllTracking(entity, packet);
    }
}
