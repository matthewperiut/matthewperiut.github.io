package net.modificationstation.stationapi.impl.client.network.packet;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.impl.network.packet.PacketHelperImpl;

public class PacketHelperClientImpl extends PacketHelperImpl {
    @Override
    public void send(C_03562565 packet) {
        //noinspection deprecation
        Minecraft minecraft = (Minecraft) FabricLoader.getInstance().getGameInstance();
        if (minecraft.f_26407825.f_50876584)
            minecraft.m_55181026().m_43500316(packet);
        else packet.m_04853589(packet instanceof ManagedPacket<?> managedPacket ? managedPacket.getType().getHandler().orElse(null) : null);
    }

    @Override
    public void sendTo(C_40996800 player, C_03562565 packet) {
        if (!player.f_94306729.f_50876584)
            packet.m_04853589(packet instanceof ManagedPacket<?> managedPacket ? managedPacket.getType().getHandler().orElse(null) : null);
    }

    @Override
    public void dispatchLocallyAndSendTo(C_40996800 player, C_03562565 packet) {
        sendTo(player, packet);
    }

    @Override
    public void sendToAllTracking(C_42232651 entity, C_03562565 packet) {
        //noinspection deprecation
        sendTo(((Minecraft) FabricLoader.getInstance().getGameInstance()).f_28396371, packet);
    }

    @Override
    public void dispatchLocallyAndToAllTracking(C_42232651 entity, C_03562565 packet) {
        sendToAllTracking(entity, packet);
    }
}
