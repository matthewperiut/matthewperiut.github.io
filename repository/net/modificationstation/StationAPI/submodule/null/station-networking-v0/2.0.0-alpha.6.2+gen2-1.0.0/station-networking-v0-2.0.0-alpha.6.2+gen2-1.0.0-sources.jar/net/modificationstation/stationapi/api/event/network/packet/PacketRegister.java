package net.modificationstation.stationapi.api.event.network.packet;

import net.minecraft.unmapped.C_03562565;

public interface PacketRegister {
    void register(int packetId, boolean receivableOnClient, boolean receivableOnServer, Class<? extends C_03562565> packetClass);
}
