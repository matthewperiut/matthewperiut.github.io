package net.modificationstation.stationapi.impl.registry;

import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.unmapped.C_74087615;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.world.WorldPropertiesEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.registry.legacy.WorldLegacyRegistry;

import java.lang.invoke.MethodHandles;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;
import static net.modificationstation.stationapi.api.util.Identifier.of;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public class WorldRegistryRemapper {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void saveProperties(WorldPropertiesEvent.Save event) {
        C_74087615 registriesTag = new C_74087615();
        WorldLegacyRegistry.saveAll(registriesTag);
        event.nbt.m_18682924(of(NAMESPACE, "level_serial_registries").toString(), registriesTag);
    }

    @EventListener
    private static void loadProperties(WorldPropertiesEvent.LoadOnWorldInit event) {
        String lsr = of(NAMESPACE, "level_serial_registries").toString();
        if (event.nbt.m_97612750(lsr))
            WorldLegacyRegistry.loadAll(event.nbt.m_81819352(lsr));
    }
}
