package net.modificationstation.stationapi.api.client.color.world;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_82336779;
import net.modificationstation.stationapi.api.client.world.ColorResolver;
import net.modificationstation.stationapi.mixin.render.client.WaterColorAccessor;

public class BiomeColors {

    public static final ColorResolver.ByBlockCoordinates GRASS_COLOR = C_81592558.f_41096518::m_42775736;
    public static final ColorResolver.ByTemperatureAndRainfall FOLIAGE_COLOR = C_82336779::m_31566293;
    public static final ColorResolver.ByTemperatureAndRainfall WATER_COLOR = (temperature, rainfall) -> {
        rainfall *= temperature;
        int var4 = (int)((1.0D - temperature) * 255.0D);
        int var5 = (int)((1.0D - rainfall) * 255.0D);
        return WaterColorAccessor.stationapi$getMap()[(var5 << 8) | var4];
    };

    private static int getColor(C_46108969 world, C_32594356 pos, ColorResolver resolver) {
        return resolver.getColor(world, pos.f_06162490, pos.f_08824702, pos.f_31865394);
    }

    public static int getGrassColor(C_46108969 world, C_32594356 pos) {
        return getColor(world, pos, GRASS_COLOR);
    }

    public static int getFoliageColor(C_46108969 world, C_32594356 pos) {
        return getColor(world, pos, FOLIAGE_COLOR);
    }

    public static int getWaterColor(C_46108969 world, C_32594356 pos) {
        return getColor(world, pos, WATER_COLOR);
    }
}
