package net.modificationstation.stationapi.mixin.render.client;

import net.minecraft.unmapped.C_96603444;
import net.modificationstation.stationapi.api.client.render.StationTessellator;
import net.modificationstation.stationapi.api.client.render.model.BakedQuad;
import net.modificationstation.stationapi.impl.client.render.StationTessellatorImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_96603444.class)
class TessellatorMixin implements StationTessellator {
    @Unique
    private final StationTessellatorImpl stationapi$stationTessellatorImpl = new StationTessellatorImpl((C_96603444) (Object) this);

    @Override
    @Unique
    public void quad(BakedQuad quad, float x, float y, float z, int colour0, int colour1, int colour2, int colour3, float normalX, float normalY, float normalZ, boolean spreadUV) {
        stationapi$stationTessellatorImpl.quad(quad, x, y, z, colour0, colour1, colour2, colour3, normalX, normalY, normalZ, spreadUV);
    }

    @Override
    @Unique
    public void ensureBufferCapacity(int criticalCapacity) {
        stationapi$stationTessellatorImpl.ensureBufferCapacity(criticalCapacity);
    }
}
