package net.modificationstation.stationapi.mixin.render.client;

import net.minecraft.unmapped.C_06587063;
import net.modificationstation.stationapi.api.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_06587063.class)
public interface WaterColorAccessor {
    @Accessor("colorMap")
    static int[] stationapi$getMap() {
        return Util.assertMixin();
    }
}
