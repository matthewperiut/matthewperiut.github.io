package net.modificationstation.stationapi.api.client.texture;

import net.minecraft.unmapped.C_74530968;

public interface TexturePackDependent {

    void reloadFromTexturePack(C_74530968 newTexturePack);
}
