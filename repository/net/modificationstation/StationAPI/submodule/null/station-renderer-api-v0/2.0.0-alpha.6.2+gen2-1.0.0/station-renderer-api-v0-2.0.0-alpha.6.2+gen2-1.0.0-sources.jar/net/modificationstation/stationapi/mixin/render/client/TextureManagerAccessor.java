package net.modificationstation.stationapi.mixin.render.client;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.List;
import net.minecraft.unmapped.C_18996072;
import net.minecraft.unmapped.C_54686545;
import net.minecraft.unmapped.C_76792751;
import net.minecraft.unmapped.C_82920792;

@Mixin(C_82920792.class)
public interface TextureManagerAccessor {
    @Accessor
    C_76792751 getGameOptions();

    @Accessor
    List<C_54686545> getDynamicTextures();

    @Accessor
    HashMap<String, Integer> getTextures();

    @Accessor
    ByteBuffer getImageBuffer();

    @Accessor
    void setImageBuffer(ByteBuffer byteBuffer);

    @Invoker
    BufferedImage invokeReadImage(InputStream var1);

    @Accessor("blur")
    boolean stationapi$isBlurTexture();

    @Accessor("clamp")
    boolean stationapi$isClampTexture();

    @Invoker("crispBlend")
    int stationapi$crispBlend(int i, int j);

    @Accessor("texturePacks")
    C_18996072 stationapi$getTexturePackManager();
}
