package net.modificationstation.stationapi.api.client.model.item;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_88708284;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public interface ItemModelPredicateProvider {

   float call(C_88708284 stack, @Nullable C_46108969 world, @Nullable C_74425583 entity, int seed);
}
