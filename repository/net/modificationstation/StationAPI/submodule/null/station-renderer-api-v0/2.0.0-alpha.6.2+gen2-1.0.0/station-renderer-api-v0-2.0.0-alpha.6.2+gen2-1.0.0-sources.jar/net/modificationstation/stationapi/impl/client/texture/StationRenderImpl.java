package net.modificationstation.stationapi.impl.client.texture;

import com.mojang.datafixers.util.Pair;
import net.fabricmc.loader.api.FabricLoader;
import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_74530968;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.StationRenderAPI;
import net.modificationstation.stationapi.api.client.event.resource.AssetsReloadEvent;
import net.modificationstation.stationapi.api.client.event.resource.AssetsResourceReloaderRegisterEvent;
import net.modificationstation.stationapi.api.client.event.texture.TextureRegisterEvent;
import net.modificationstation.stationapi.api.client.render.item.ItemModels;
import net.modificationstation.stationapi.api.client.render.model.BakedModelManager;
import net.modificationstation.stationapi.api.client.render.model.ModelLoader;
import net.modificationstation.stationapi.api.client.texture.NativeImageBackedTexture;
import net.modificationstation.stationapi.api.client.texture.SpriteAtlasTexture;
import net.modificationstation.stationapi.api.client.texture.StationTextureManager;
import net.modificationstation.stationapi.api.client.texture.TextureUtil;
import net.modificationstation.stationapi.api.client.texture.atlas.Atlases;
import net.modificationstation.stationapi.api.client.texture.atlas.ExpandableAtlas;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.resource.*;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.api.util.Namespace;
import net.modificationstation.stationapi.api.util.profiler.Profiler;
import org.apache.logging.log4j.Logger;

import java.lang.invoke.MethodHandles;
import java.util.Collection;
import java.util.Objects;
import java.util.Set;

import static net.mine_diver.unsafeevents.listener.ListenerPriority.HIGH;
import static net.modificationstation.stationapi.api.util.Identifier.of;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public class StationRenderImpl {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    public static final Namespace NAMESPACE = Namespace.resolve();

    public static final Logger LOGGER = NAMESPACE.getLogger("StationRenderer|API");

    public static ExpandableAtlas getTerrain() {
        return TERRAIN;
    }

    public static ExpandableAtlas getGuiItems() {
        return GUI_ITEMS;
    }

    private static ExpandableAtlas
            TERRAIN,
            GUI_ITEMS;

    @EventListener(priority = HIGH)
    private static void ensureThread(AssetsReloadEvent event) {
        TextureUtil.maxSupportedTextureSize();
    }

    @EventListener
    private static void registerReloaders(AssetsResourceReloaderRegisterEvent event) {
        ResourceManagerHelper helper = ResourceManagerHelper.get(ResourceType.CLIENT_RESOURCES);
        helper.registerReloadListener(StationRenderAPI.getBakedModelManager());
        interface SIResourceReloader extends SynchronousResourceReloader, IdentifiableResourceReloadListener {}
        helper.registerReloadListener(new SIResourceReloader() {
            @Override
            public String getName() {
                return "ItemModels";
            }

            @Override
            public Identifier getId() {
                return StationAPI.NAMESPACE.id("private/item_models");
            }

            @Override
            public Collection<Identifier> getDependencies() {
                return Set.of(BakedModelManager.MODELS);
            }

            @Override
            public void reload(ResourceManager manager) {
                ItemModels.reloadModelsAll();
            }
        });
        helper.registerReloadListener(new SIResourceReloader() {
            @Override
            public String getName() {
                return "BlockDestructionTextures";
            }

            @Override
            public Identifier getId() {
                return StationAPI.NAMESPACE.id("private/block_destruction_stage_textures");
            }

            @Override
            public Collection<Identifier> getDependencies() {
                return Set.of(BakedModelManager.MODELS);
            }

            @Override
            public void reload(ResourceManager manager) {
                //noinspection deprecation
                StationTextureManager textureManager = StationTextureManager.get(((Minecraft) FabricLoader.getInstance().getGameInstance()).f_45465196);
                SpriteAtlasTexture atlas = StationRenderAPI.getBakedModelManager().getAtlas(Atlases.GAME_ATLAS_TEXTURE);
                for (int i = 0, size = ModelLoader.BLOCK_DESTRUCTION_STAGE_TEXTURES.size(); i < size; i++)
                    textureManager.registerTexture(ModelLoader.BLOCK_DESTRUCTION_STAGE_TEXTURES.get(i), new NativeImageBackedTexture(Objects.requireNonNull(atlas.getSprite(ModelLoader.BLOCK_DESTRUCTION_STAGES.get(i))).getContents().getBaseFrame()));
            }
        });
        abstract class SPIResourceReloader<T> extends SinglePreparationResourceReloader<T> implements IdentifiableResourceReloadListener {}
        helper.registerReloadListener(new SPIResourceReloader<Pair<ExpandableAtlas, ExpandableAtlas>>() {

            @Override
            public String getName() {
                return "ModTextures";
            }

            @Override
            public Identifier getId() {
                return StationAPI.NAMESPACE.id("private/mod_textures");
            }

            @Override
            public Collection<Identifier> getDependencies() {
                return Set.of(BakedModelManager.MODELS);
            }

            @Override
            protected Pair<ExpandableAtlas, ExpandableAtlas> prepare(ResourceManager manager, Profiler profiler) {
                profiler.startTick();
                profiler.push("legacy_atlases");
                ExpandableAtlas
                        terrain = new ExpandableAtlas(of("textures/atlas/terrain.png")),
                        guiItems = new ExpandableAtlas(of("textures/atlas/gui/items.png"));
                terrain.addSpritesheet(16, TerrainHelper.INSTANCE);
                guiItems.addSpritesheet(16, GuiItemsHelper.INSTANCE);
                profiler.pop();
                profiler.endTick();
                return Pair.of(terrain, guiItems);
            }

            @Override
            protected void apply(Pair<ExpandableAtlas, ExpandableAtlas> prepared, ResourceManager manager, Profiler profiler) {
                TERRAIN = prepared.getFirst();
                GUI_ITEMS = prepared.getSecond();
                profiler.startTick();
                profiler.push("mod_textures");
                StationAPI.EVENT_BUS.post(TextureRegisterEvent.builder().build());
                //noinspection deprecation
                Minecraft minecraft = (Minecraft) FabricLoader.getInstance().getGameInstance();
                C_74530968 texturePack = minecraft.f_20964140.f_25140974;
                profiler.swap("texture_binders");
                TERRAIN.registerTextureBinders(minecraft.f_45465196, texturePack);
                GUI_ITEMS.registerTextureBinders(minecraft.f_45465196, texturePack);
                profiler.pop();
                profiler.endTick();
            }
        });
    }
}
