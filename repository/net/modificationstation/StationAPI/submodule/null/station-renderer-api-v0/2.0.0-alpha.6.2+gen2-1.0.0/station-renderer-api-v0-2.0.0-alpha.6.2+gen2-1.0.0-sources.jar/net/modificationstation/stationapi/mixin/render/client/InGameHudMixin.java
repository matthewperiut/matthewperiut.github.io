package net.modificationstation.stationapi.mixin.render.client;

import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_29058632;
import net.minecraft.unmapped.C_43718703;
import net.minecraft.unmapped.C_97866173;
import net.modificationstation.stationapi.api.client.render.RendererAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Objects;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;

@Mixin(C_97866173.class)
class InGameHudMixin extends C_29058632 {
    @Inject(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/font/TextRenderer;drawWithShadow(Ljava/lang/String;III)V",
                    ordinal = 5,
                    shift = At.Shift.AFTER
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void stationapi_showCurrentRenderer(float flag, boolean i, int j, int par4, CallbackInfo ci, C_43718703 var5, int var6, int var7, C_23014920 textRenderer) {
        m_62884682(textRenderer, "[" + NAMESPACE.getName() + "] Active renderer: " + (RendererAccess.INSTANCE.hasRenderer() ? Objects.requireNonNull(RendererAccess.INSTANCE.getRenderer()).getClass().getSimpleName() : "none (vanilla)"), 2, 98, 14737632);
    }
}
