package net.modificationstation.stationapi.mixin.render.client;

import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_46108969;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_03670941.class)
public interface BlockRenderManagerAccessor {
    @Accessor
    C_46108969 getBlockView();

    @Accessor
    int getTextureOverride();

    @Accessor
    void setEastFaceRotation(int eastFaceRotation);

    @Accessor
    void setWestFaceRotation(int westFaceRotation);

    @Accessor
    void setSouthFaceRotation(int southFaceRotation);

    @Accessor
    void setNorthFaceRotation(int northFaceRotation);

    @Accessor
    void setTopFaceRotation(int topFaceRotation);

    @Accessor
    void setBottomFaceRotation(int bottomFaceRotation);
}
