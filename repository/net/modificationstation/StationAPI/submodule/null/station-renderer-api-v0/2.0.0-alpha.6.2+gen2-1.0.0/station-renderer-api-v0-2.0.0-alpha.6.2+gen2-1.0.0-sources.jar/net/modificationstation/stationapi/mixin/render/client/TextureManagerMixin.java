package net.modificationstation.stationapi.mixin.render.client;

import net.minecraft.unmapped.C_82920792;
import net.modificationstation.stationapi.impl.client.render.StationTextureManagerImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_82920792.class)
class TextureManagerMixin implements StationTextureManagerImpl.StationTextureManagerAccess {
    @SuppressWarnings("DataFlowIssue")
    @Unique
    private final StationTextureManagerImpl stationapi$stationTextureManagerImpl = new StationTextureManagerImpl((C_82920792) (Object) this);

    @Override
    @Unique
    public StationTextureManagerImpl stationapi$stationTextureManager() {
        return stationapi$stationTextureManagerImpl;
    }
}
