package net.modificationstation.stationapi.api.client.model.item;

import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_82920792;
import net.minecraft.unmapped.C_84615110;
import net.minecraft.unmapped.C_88708284;

@Deprecated
public interface ItemWithRenderer {

    @Deprecated
    void renderItemOnGui(C_84615110 itemRenderer, C_23014920 textRenderer, C_82920792 textureManager, int itemId, int damage, int textureIndex, int x, int y);

    @Deprecated
    default void renderItemOnGui(C_84615110 itemRenderer, C_23014920 textRenderer, C_82920792 textureManager, C_88708284 stack, int x, int y) {
        renderItemOnGui(itemRenderer, textRenderer, textureManager, stack.f_59294634, stack.m_21098843(), stack.m_98662398(), x, y);
    }
}
