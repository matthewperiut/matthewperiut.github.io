package net.modificationstation.stationapi.api.client.model.block;

import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_46108969;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.client.model.Model;
import net.modificationstation.stationapi.api.world.BlockStateView;

import java.util.Random;

import static net.modificationstation.stationapi.api.client.model.block.RendererHolder.BAKED_MODEL_RENDERER;

@Deprecated
public interface BlockWorldModelProvider extends BlockWithWorldRenderer {

    /**
     * The model to render in the world.
     */
    @Deprecated
    Model getCustomWorldModel(C_46108969 blockView, int x, int y, int z);

    @Override
    @Deprecated
    default boolean renderWorld(C_03670941 blockRenderer, C_46108969 blockView, int x, int y, int z) {
        BlockState state = ((BlockStateView) blockView).getBlockState(x, y, z);
        C_32594356 pos = new C_32594356(x, y, z);
        return BAKED_MODEL_RENDERER.get().render(blockView, getCustomWorldModel(blockView, x, y, z).getBaked(), state, pos, true, new Random(), state.getRenderingSeed(pos));
    }
}
