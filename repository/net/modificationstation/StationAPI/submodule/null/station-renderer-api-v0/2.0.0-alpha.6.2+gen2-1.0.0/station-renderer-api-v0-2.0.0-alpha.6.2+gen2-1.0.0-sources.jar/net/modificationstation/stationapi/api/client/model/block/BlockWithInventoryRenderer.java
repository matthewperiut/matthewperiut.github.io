package net.modificationstation.stationapi.api.client.model.block;

import net.minecraft.unmapped.C_03670941;

@Deprecated
public interface BlockWithInventoryRenderer {

    @Deprecated
    void renderInventory(C_03670941 tileRenderer, int meta);
}
