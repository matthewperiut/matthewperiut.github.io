package net.modificationstation.stationapi.api.client.color.block;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_46108969;
import net.modificationstation.stationapi.api.block.BlockState;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public interface BlockColorProvider {
   int getColor(BlockState state, @Nullable C_46108969 world, @Nullable C_32594356 pos, int tintIndex);
}
