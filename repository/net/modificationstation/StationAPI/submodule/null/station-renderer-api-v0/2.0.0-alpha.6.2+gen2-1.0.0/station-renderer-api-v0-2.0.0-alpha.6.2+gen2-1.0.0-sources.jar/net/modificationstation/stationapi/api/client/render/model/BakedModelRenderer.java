package net.modificationstation.stationapi.api.client.render.model;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.client.render.item.ItemModels;
import net.modificationstation.stationapi.api.client.render.model.json.ModelTransformation;
import org.jetbrains.annotations.Nullable;

import java.util.Random;

public interface BakedModelRenderer {

    boolean renderBlock(BlockState state, C_32594356 pos, C_46108969 world, boolean cull, Random random);

    boolean render(C_46108969 world, BakedModel model, BlockState state, C_32594356 pos, boolean cull, Random random, long seed);

    void renderDamage(BlockState state, C_32594356 pos, C_46108969 world, float progress);

    ItemModels getItemModels();

    void renderItem(C_88708284 stack, ModelTransformation.Mode renderMode, float brightness, BakedModel model);

    BakedModel getModel(C_88708284 stack, @Nullable C_64041439 world, @Nullable C_74425583 entity, int seed);

    void renderItem(@Nullable C_74425583 entity, C_88708284 item, ModelTransformation.Mode renderMode, @Nullable C_64041439 world, float brightness, int seed);

    void renderInGuiWithOverrides(C_88708284 stack, int x, int y);
}
