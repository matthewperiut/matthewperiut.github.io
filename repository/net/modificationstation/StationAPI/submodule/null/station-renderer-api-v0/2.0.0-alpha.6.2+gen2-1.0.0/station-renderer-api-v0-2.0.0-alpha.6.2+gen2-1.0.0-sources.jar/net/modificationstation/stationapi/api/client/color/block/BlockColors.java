package net.modificationstation.stationapi.api.client.color.block;

import com.google.common.collect.ImmutableSet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_13378080;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.client.event.color.block.BlockColorsRegisterEvent;
import net.modificationstation.stationapi.api.registry.BlockRegistry;
import net.modificationstation.stationapi.api.registry.sync.trackers.IdListTracker;
import net.modificationstation.stationapi.api.state.property.Property;
import net.modificationstation.stationapi.api.util.collection.IdList;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

@Environment(EnvType.CLIENT)
public class BlockColors {
    private final IdList<BlockColorProvider> providers = new IdList<>(32);
    private final Map<C_81592558, Set<Property<?>>> properties = new HashMap<>();

    public static BlockColors create() {
        BlockColors blockColors = new BlockColors();
        StationAPI.EVENT_BUS.post(BlockColorsRegisterEvent.builder().blockColors(blockColors).build());
        return blockColors;
    }

    public BlockColors() {
        IdListTracker.register(BlockRegistry.INSTANCE, "BlockColors.providers", providers);
    }

    public int getColor(BlockState state, C_46108969 world, C_32594356 pos) {
        BlockColorProvider blockColorProvider = this.providers.get(BlockRegistry.INSTANCE.getRawId(state.getBlock()));
        if (blockColorProvider != null) {
            return blockColorProvider.getColor(state, null, null, 0);
        } else {
            C_13378080 materialColor = state.getTopMaterialColor(world, pos);
            return materialColor != null ? materialColor.f_09233878 : -1;
        }
    }

    public int getColor(BlockState state, @Nullable C_46108969 world, @Nullable C_32594356 pos, int tint) {
        BlockColorProvider blockColorProvider = this.providers.get(BlockRegistry.INSTANCE.getRawId(state.getBlock()));
        return blockColorProvider == null ? -1 : blockColorProvider.getColor(state, world, pos, tint);
    }

    public void registerColorProvider(BlockColorProvider provider, C_81592558... blocks) {

        for (C_81592558 block : blocks) {
            this.providers.set(provider, BlockRegistry.INSTANCE.getRawId(block));
        }

    }

    public void registerColorProperties(Set<Property<?>> properties, C_81592558... blocks) {

        for (C_81592558 block : blocks) {
            this.properties.put(block, properties);
        }

    }

    public void registerColourProperty(Property<?> property, C_81592558... blocks) {
        this.registerColorProperties(ImmutableSet.of(property), blocks);
    }

    public Set<Property<?>> getProperties(C_81592558 block) {
        return this.properties.getOrDefault(block, ImmutableSet.of());
    }
}
