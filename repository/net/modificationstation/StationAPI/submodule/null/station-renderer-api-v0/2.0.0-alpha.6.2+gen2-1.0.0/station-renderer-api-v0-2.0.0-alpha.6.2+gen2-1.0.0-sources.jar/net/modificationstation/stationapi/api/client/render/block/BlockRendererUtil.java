package net.modificationstation.stationapi.api.client.render.block;

import net.minecraft.unmapped.C_03670941;
import net.modificationstation.stationapi.mixin.render.client.BlockRenderManagerAccessor;

public final class BlockRendererUtil {

    public static void setBottomFaceRotation(C_03670941 blockRenderer, int rotation) {
        ((BlockRenderManagerAccessor) blockRenderer).setBottomFaceRotation(rotation);
    }

    public static void setTopFaceRotation(C_03670941 blockRenderer, int rotation) {
        ((BlockRenderManagerAccessor) blockRenderer).setTopFaceRotation(rotation);
    }

    public static void setEastFaceRotation(C_03670941 blockRenderer, int rotation) {
        ((BlockRenderManagerAccessor) blockRenderer).setEastFaceRotation(rotation);
    }

    public static void setWestFaceRotation(C_03670941 blockRenderer, int rotation) {
        ((BlockRenderManagerAccessor) blockRenderer).setWestFaceRotation(rotation);
    }

    public static void setNorthFaceRotation(C_03670941 blockRenderer, int rotation) {
        ((BlockRenderManagerAccessor) blockRenderer).setNorthFaceRotation(rotation);
    }

    public static void setSouthFaceRotation(C_03670941 blockRenderer, int rotation) {
        ((BlockRenderManagerAccessor) blockRenderer).setSouthFaceRotation(rotation);
    }
}
