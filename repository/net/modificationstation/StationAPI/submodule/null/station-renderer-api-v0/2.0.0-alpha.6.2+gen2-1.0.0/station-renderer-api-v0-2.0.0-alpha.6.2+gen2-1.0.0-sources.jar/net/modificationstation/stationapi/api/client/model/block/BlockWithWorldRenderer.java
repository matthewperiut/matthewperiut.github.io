package net.modificationstation.stationapi.api.client.model.block;

import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_46108969;

@Deprecated
public interface BlockWithWorldRenderer {

    @Deprecated
    boolean renderWorld(C_03670941 tileRenderer, C_46108969 tileView, int x, int y, int z);
}
