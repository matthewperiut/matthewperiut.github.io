package net.modificationstation.stationapi.mixin.render.client;

import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.client.StationRenderAPI;
import net.modificationstation.stationapi.api.client.render.RendererAccess;
import net.modificationstation.stationapi.api.client.render.block.StationRendererBlockRenderManager;
import net.modificationstation.stationapi.api.client.render.model.VanillaBakedModel;
import net.modificationstation.stationapi.api.util.math.MutableBlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

import java.util.Random;

@Mixin(C_03670941.class)
abstract class BlockRenderManagerMixin implements StationRendererBlockRenderManager {
    @Unique
    private final MutableBlockPos stationapi_pos = new MutableBlockPos(0, 0, 0);
    @Unique
    private final Random stationapi_random = new Random();

    @Shadow public abstract void renderWithoutCulling(C_81592558 arg, int i, int j, int k);

    @Shadow private C_46108969 blockView;

    @SuppressWarnings("AddedMixinMembersNamePattern")
    @Override
    @Unique
    public void renderAllSides(BlockState state, int x, int y, int z) {
        if (StationRenderAPI.getBakedModelManager().getBlockModels().getModel(state) instanceof VanillaBakedModel)
            renderWithoutCulling(state.getBlock(), x, y, z);
        else if (RendererAccess.INSTANCE.hasRenderer())
            RendererAccess.INSTANCE.getRenderer().bakedModelRenderer().renderBlock(state, stationapi_pos.set(x, y, z), blockView, false, stationapi_random);
    }
}
