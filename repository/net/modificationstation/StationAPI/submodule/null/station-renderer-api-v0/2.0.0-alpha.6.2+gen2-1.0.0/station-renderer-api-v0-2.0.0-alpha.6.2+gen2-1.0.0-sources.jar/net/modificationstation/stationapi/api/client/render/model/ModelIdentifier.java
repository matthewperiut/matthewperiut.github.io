package net.modificationstation.stationapi.api.client.render.model;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.api.util.Namespace;

import java.util.concurrent.ExecutionException;

@SuppressWarnings("ClassCanBeRecord")
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
@Environment(EnvType.CLIENT)
public final class ModelIdentifier {

   private static final Cache<String, ModelIdentifier> CACHE = CacheBuilder.newBuilder().softValues().build();

   public final Identifier id;
   public final String variant;

   public static ModelIdentifier of(String string) {
      String[] strings = splitModelId(string);
      return of(Identifier.of(Namespace.of(strings[0]), strings[1]), strings[2]);
   }

   public static ModelIdentifier of(Identifier id, String variant) {
       try {
           return CACHE.get(variant.isEmpty() ? id.toString() : id + "#" + variant, () -> new ModelIdentifier(id, variant));
       } catch (ExecutionException e) {
           throw new RuntimeException(e);
       }
   }

   public static ModelIdentifier of(String string, String string2) {
      return of(Identifier.of(string), string2);
   }

   private static String[] splitModelId(String id) {
      String[] strings = new String[]{null, id, ""};
      int i = id.indexOf('#');
      String string = id;
      if (i >= 0) {
         strings[2] = id.substring(i + 1);
         if (i > 1) {
            string = id.substring(0, i);
         }
      }

      System.arraycopy(splitId(string), 0, strings, 0, 2);
      return strings;
   }

   private static String[] splitId(String id) {
      String[] strings = new String[]{Namespace.MINECRAFT.toString(), id};
      int i = id.indexOf(Identifier.NAMESPACE_SEPARATOR);
      if (i >= 0) {
         strings[1] = id.substring(i + 1);
         if (i >= 1) {
            strings[0] = id.substring(0, i);
         }
      }

      return strings;
   }

   public Identifier asIdentifier() {
      return Identifier.of(id.namespace, variant.isEmpty() ? id.path : id.path + '#' + variant);
   }

   @Override
   public boolean equals(Object object) {
      if (this == object) {
         return true;
      } else if (object instanceof ModelIdentifier modelIdentifier && id.equals(((ModelIdentifier) object).id)) {
         return this.variant.equals(modelIdentifier.variant);
      } else {
         return false;
      }
   }

   @Override
   public int hashCode() {
      return variant.isEmpty() ? id.hashCode() : 31 * id.hashCode() + this.variant.hashCode();
   }

   @Override
   public String toString() {
      return variant.isEmpty() ? id.toString() : id.toString() + '#' + this.variant;
   }
}
