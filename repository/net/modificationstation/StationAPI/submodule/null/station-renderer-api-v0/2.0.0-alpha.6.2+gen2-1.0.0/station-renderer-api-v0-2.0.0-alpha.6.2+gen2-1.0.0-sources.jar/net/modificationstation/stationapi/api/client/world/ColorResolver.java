package net.modificationstation.stationapi.api.client.world;

import net.minecraft.unmapped.C_28105876;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_46108969;

@FunctionalInterface
public interface ColorResolver {

    int getColor(C_46108969 blockView, double x, double y, double z);

    @FunctionalInterface
    interface ByTemperatureAndRainfall extends ColorResolver {

        @Override
        default int getColor(C_46108969 world, double x, double y, double z) {
            world.m_72354999().m_19075238(C_45510667.m_80489169(x), C_45510667.m_80489169(z), 1, 1);
            double temperature = world.m_72354999().f_57821734[0];
            double rainfall = world.m_72354999().f_84133265[0];
            return getColour(temperature, rainfall);
        }

        int getColour(double temperature, double rainfall);
    }

    @FunctionalInterface
    interface ByBiomeAndPosition extends ColorResolver {

        @Override
        default int getColor(C_46108969 blockView, double x, double y, double z) {
            return getColour(blockView.m_72354999().m_16975905(C_45510667.m_80489169(x), C_45510667.m_80489169(z)), x, z);
        }

        int getColour(C_28105876 biome, double x, double z);
    }

    interface ByBlockCoordinates extends ColorResolver {

        @Override
        default int getColor(C_46108969 world, double x, double y, double z) {
            return getColour(world, C_45510667.m_80489169(x), C_45510667.m_80489169(y), C_45510667.m_80489169(z));
        }

        int getColour(C_46108969 world, int x, int y, int z);
    }
}
