package net.modificationstation.stationapi.api.server.event.network;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_47909326;
import net.minecraft.unmapped.C_49202226;

@SuperBuilder
public class PlayerLoginEvent extends Event {
    public final C_47909326 loginHelloPacket;
    public final C_49202226 player;
}
