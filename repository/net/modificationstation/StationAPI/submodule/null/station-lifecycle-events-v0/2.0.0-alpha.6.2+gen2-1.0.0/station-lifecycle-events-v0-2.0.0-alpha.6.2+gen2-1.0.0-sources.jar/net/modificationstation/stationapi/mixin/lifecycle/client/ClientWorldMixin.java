package net.modificationstation.stationapi.mixin.lifecycle.client;

import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_34399650;
import net.minecraft.unmapped.C_67358769;
import net.minecraft.unmapped.C_88014908;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.event.network.MultiplayerLogoutEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_34399650.class)
class ClientWorldMixin {
    @Redirect(
            method = "disconnect",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientNetworkHandler;sendPacketAndDisconnect(Lnet/minecraft/network/packet/Packet;)V"
            )
    )
    private void stationapi_onDisconnect(C_88014908 clientPlayNetworkHandler, C_03562565 arg) {
        StationAPI.EVENT_BUS.post(
                MultiplayerLogoutEvent.builder()
                        .disconnectPacket((C_67358769) arg)
                        .stacktrace(null)
                        .dropped(false)
                        .build()
        );
        clientPlayNetworkHandler.m_39124930(arg);
    }
}
