package net.modificationstation.stationapi.api.client.event.network;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_67358769;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

@SuperBuilder
public class MultiplayerLogoutEvent extends Event {
    @NotNull public final C_67358769 disconnectPacket;
    @Nullable public final String[] stacktrace;
    public final boolean dropped;
}
