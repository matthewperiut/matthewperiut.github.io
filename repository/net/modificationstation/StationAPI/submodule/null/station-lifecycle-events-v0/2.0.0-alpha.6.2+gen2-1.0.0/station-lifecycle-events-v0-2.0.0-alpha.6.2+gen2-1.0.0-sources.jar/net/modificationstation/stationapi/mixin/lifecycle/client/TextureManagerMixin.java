package net.modificationstation.stationapi.mixin.lifecycle.client;

import net.minecraft.unmapped.C_18996072;
import net.minecraft.unmapped.C_82920792;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.event.resource.TexturePackLoadedEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_82920792.class)
class TextureManagerMixin {
    @Shadow private C_18996072 texturePacks;

    @Inject(
            method = "reload",
            at = @At("HEAD")
    )
    private void stationapi_beforeTextureRefresh(CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(
                TexturePackLoadedEvent.Before.builder()
                        .textureManager((C_82920792) (Object) this)
                        .newTexturePack(texturePacks.f_25140974)
                        .build()
        );
    }

    @Inject(
            method = "reload",
            at = @At("RETURN")
    )
    private void stationapi_texturesRefresh(CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(
                TexturePackLoadedEvent.After.builder()
                        .textureManager((C_82920792) (Object) this)
                        .newTexturePack(texturePacks.f_25140974)
                        .build()
        );
    }
}
