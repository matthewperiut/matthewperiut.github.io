package net.modificationstation.stationapi.mixin.lifecycle.client;

import net.minecraft.unmapped.C_47909326;
import net.minecraft.unmapped.C_67358769;
import net.minecraft.unmapped.C_88014908;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.event.network.MultiplayerLogoutEvent;
import net.modificationstation.stationapi.api.client.event.network.ServerLoginSuccessEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_88014908.class)
class ClientNetworkHandlerMixin {
    @Inject(
            method = "onHello",
            at = @At("HEAD"),
            cancellable = true
    )
    private void stationapi_onLoginSuccess(C_47909326 packet, CallbackInfo ci) {
        if (
                StationAPI.EVENT_BUS.post(
                        ServerLoginSuccessEvent.builder()
                                .clientNetworkHandler((C_88014908) (Object) this)
                                .loginHelloPacket(packet)
                                .build()
                ).isCanceled()
        ) ci.cancel();
    }

    @Inject(
            method = "onDisconnect",
            at = @At("HEAD")
    )
    private void stationapi_onKicked(C_67358769 packet, CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(
                MultiplayerLogoutEvent.builder()
                        .disconnectPacket(packet)
                        .stacktrace(null)
                        .dropped(false)
                        .build()
        );
    }

    @Inject(
            method = "onDisconnected",
            at = @At("HEAD")
    )
    private void stationapi_onDropped(String reason, Object[] stacktrace, CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(
                MultiplayerLogoutEvent.builder()
                        .disconnectPacket(new C_67358769(reason))
                        .stacktrace(stacktrace instanceof String[] strings ? strings : new String[0])
                        .dropped(true)
                        .build()
        );
    }
}
