package net.modificationstation.stationapi.mixin.lifecycle.server;

import net.minecraft.unmapped.C_47909326;
import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_58873528;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.server.event.network.PlayerAttemptLoginEvent;
import net.modificationstation.stationapi.api.server.event.network.PlayerLoginEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(C_58873528.class)
class ServerLoginNetworkHandlerMixin {
    @Inject(
            method = "accept",
            at = @At("HEAD")
    )
    private void stationapi_handleLogin(C_47909326 arg, CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(
                PlayerAttemptLoginEvent.builder()
                        .serverLoginNetworkHandler((C_58873528) (Object) this)
                        .loginHelloPacket(arg)
                        .build()
        );
    }

    @Inject(
            method = "accept",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/player/ServerPlayerEntity;initScreenHandler()V",
                    shift = At.Shift.AFTER
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void stationapi_afterLogin(C_47909326 arg, CallbackInfo ci, C_49202226 var2) {
        StationAPI.EVENT_BUS.post(
                PlayerLoginEvent.builder()
                        .loginHelloPacket(arg)
                        .player(var2).build()
        );
    }
}
