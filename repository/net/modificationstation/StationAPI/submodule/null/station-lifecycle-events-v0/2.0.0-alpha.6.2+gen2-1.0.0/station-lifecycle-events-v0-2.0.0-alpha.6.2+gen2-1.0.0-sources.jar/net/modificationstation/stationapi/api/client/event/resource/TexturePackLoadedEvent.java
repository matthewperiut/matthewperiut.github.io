package net.modificationstation.stationapi.api.client.event.resource;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.mine_diver.unsafeevents.event.EventPhases;
import net.minecraft.unmapped.C_74530968;
import net.minecraft.unmapped.C_82920792;
import net.modificationstation.stationapi.api.StationAPI;

@SuperBuilder
public abstract class TexturePackLoadedEvent extends Event {
    public final C_82920792 textureManager;
    public final C_74530968 newTexturePack;

    @SuperBuilder
    public static class Before extends TexturePackLoadedEvent {}

    @SuperBuilder
    @EventPhases(StationAPI.INTERNAL_PHASE)
    public static class After extends TexturePackLoadedEvent {}
}
