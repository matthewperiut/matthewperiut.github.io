package net.modificationstation.stationapi.api.client.event.network;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.mine_diver.unsafeevents.event.Cancelable;
import net.mine_diver.unsafeevents.event.EventPhases;
import net.minecraft.unmapped.C_47909326;
import net.minecraft.unmapped.C_88014908;
import net.modificationstation.stationapi.api.StationAPI;

@Cancelable
@SuperBuilder
@EventPhases(StationAPI.INTERNAL_PHASE)
public class ServerLoginSuccessEvent extends Event {
    public final C_88014908 clientNetworkHandler;
    public final C_47909326 loginHelloPacket;
}
