package net.modificationstation.stationapi.api.server.event.network;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.mine_diver.unsafeevents.event.EventPhases;
import net.minecraft.unmapped.C_47909326;
import net.minecraft.unmapped.C_58873528;
import net.modificationstation.stationapi.api.StationAPI;

@SuperBuilder
@EventPhases(StationAPI.INTERNAL_PHASE)
public class PlayerAttemptLoginEvent extends Event {
    public final C_58873528 serverLoginNetworkHandler;
    public final C_47909326 loginHelloPacket;
}
