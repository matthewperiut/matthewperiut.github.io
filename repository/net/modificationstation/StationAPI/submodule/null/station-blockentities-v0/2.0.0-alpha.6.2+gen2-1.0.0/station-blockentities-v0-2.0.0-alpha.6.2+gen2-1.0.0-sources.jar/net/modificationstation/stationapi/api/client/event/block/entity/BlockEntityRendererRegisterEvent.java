package net.modificationstation.stationapi.api.client.event.block.entity;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_40735137;
import net.minecraft.unmapped.C_62577213;
import java.util.Map;

@SuperBuilder
public class BlockEntityRendererRegisterEvent extends Event {
    public final Map<Class<? extends C_40735137>, C_62577213> renderers;
    
    public final void register(Class<? extends C_40735137> blockEntityClass, C_62577213 renderer) {
        renderers.put(blockEntityClass, renderer);
    }
}
