package net.modificationstation.stationapi.api.event.block.entity;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_40735137;
import net.modificationstation.stationapi.api.util.Identifier;

import java.util.function.BiConsumer;

@SuperBuilder
public class BlockEntityRegisterEvent extends Event {
    public final BiConsumer<Class<? extends C_40735137>, String> register;

    public final void register(String id, Class<? extends C_40735137> blockEntityClass) {
        register.accept(blockEntityClass, id);
    }

    public final void register(Identifier id, Class<? extends C_40735137> blockEntityClass) {
        register.accept(blockEntityClass, id.toString());
    }
}
