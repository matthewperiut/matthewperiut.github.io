package net.modificationstation.stationapi.mixin.armor.client;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import it.unimi.dsi.fastutil.objects.Object2ObjectOpenHashMap;
import it.unimi.dsi.fastutil.objects.Reference2ObjectOpenHashMap;
import net.minecraft.unmapped.C_34859172;
import net.minecraft.unmapped.C_36076665;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_71252617;
import net.minecraft.unmapped.C_97645581;
import net.modificationstation.stationapi.api.client.item.ArmorTextureProvider;
import net.modificationstation.stationapi.api.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

import java.util.Map;

@Mixin(C_34859172.class)
class PlayerRendererMixin extends C_71252617 {
    @Unique private static final Map<Identifier, String[]> STATIONAPI$ARMOR_CACHE = new Reference2ObjectOpenHashMap<>();
    
    public PlayerRendererMixin(C_36076665 model, float f) {
        super(model, f);
    }

    // TODO: refactor. this seems a bit off in some places
    @WrapOperation(
            method = "bindTexture(Lnet/minecraft/entity/player/PlayerEntity;IF)Z",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/entity/PlayerEntityRenderer;bindTexture(Ljava/lang/String;)V"
            )
    )
    private void stationapi_onArmorTexture(
            C_34859172 renderer, String texture,
            Operation<Void> fallback,
            C_40996800 player, int i, float f,
            @Local(index = 6) C_97645581 armor
    ) {
        if (armor instanceof ArmorTextureProvider provider) {
            Identifier id = provider.getTexture(armor);
            String[] textures = STATIONAPI$ARMOR_CACHE.computeIfAbsent(id, k -> new String[4]);
            if (textures[i] == null) textures[i] = stationapi_getTexturePath(id, i);
            fallback.call(renderer, textures[i]);
        }
        else fallback.call(renderer, texture);
    }

    @Unique
    private String stationapi_getTexturePath(Identifier identifier, int armorIndex) {
        return "/assets/" + identifier.namespace + "/stationapi/textures/armor/" + identifier.path + (armorIndex == 2 ? "_2.png" : "_1.png");
    }
}
