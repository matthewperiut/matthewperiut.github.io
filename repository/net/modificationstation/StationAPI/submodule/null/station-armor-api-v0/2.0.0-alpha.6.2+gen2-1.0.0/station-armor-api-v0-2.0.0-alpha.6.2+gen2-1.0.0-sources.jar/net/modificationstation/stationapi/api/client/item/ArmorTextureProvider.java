package net.modificationstation.stationapi.api.client.item;

import net.minecraft.unmapped.C_97645581;
import net.modificationstation.stationapi.api.util.Identifier;

public interface ArmorTextureProvider {
    Identifier getTexture(C_97645581 armor);
}
