package net.modificationstation.stationapi.mixin.template.item;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.unmapped.C_75021297;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.template.item.TemplateDoorItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(C_75021297.class)
class DoorItemMixin {
    @ModifyExpressionValue(
            method = "useOnBlock",
            at = {
                    @At(
                            value = "FIELD",
                            target = "Lnet/minecraft/block/Block;DOOR:Lnet/minecraft/block/Block;"
                    ),
                    @At(
                            value = "FIELD",
                            target = "Lnet/minecraft/block/Block;IRON_DOOR:Lnet/minecraft/block/Block;"
                    )
            }
    )
    private C_81592558 stationapi_hijackBlock(C_81592558 original) {
        return (C_75021297) (Object) this instanceof TemplateDoorItem doorItem ? doorItem.getDoorBlock() : original;
    }
}
