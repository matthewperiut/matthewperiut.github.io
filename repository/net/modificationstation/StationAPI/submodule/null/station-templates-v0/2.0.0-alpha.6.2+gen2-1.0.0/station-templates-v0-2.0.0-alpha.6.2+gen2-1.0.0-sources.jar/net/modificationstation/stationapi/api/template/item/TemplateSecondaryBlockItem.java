package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_92325241;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSecondaryBlockItem extends C_92325241 implements ItemTemplate {
    public TemplateSecondaryBlockItem(Identifier identifier, C_81592558 tile) {
        this(ItemTemplate.getNextId(), tile);
        ItemTemplate.onConstructor(this, identifier);
    }

    public TemplateSecondaryBlockItem(int id, C_81592558 tile) {
        super(id, tile);
    }
}
