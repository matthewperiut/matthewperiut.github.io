package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_75630531;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateDyeItem extends C_75630531 implements ItemTemplate {
    public TemplateDyeItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateDyeItem(int i) {
        super(i);
    }
}
