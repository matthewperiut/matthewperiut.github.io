package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_07874483;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSlabBlock extends C_07874483 implements BlockTemplate {
    public TemplateSlabBlock(Identifier identifier, boolean flag) {
        this(BlockTemplate.getNextId(), flag);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateSlabBlock(int i, boolean flag) {
        super(i, flag);
    }
}
