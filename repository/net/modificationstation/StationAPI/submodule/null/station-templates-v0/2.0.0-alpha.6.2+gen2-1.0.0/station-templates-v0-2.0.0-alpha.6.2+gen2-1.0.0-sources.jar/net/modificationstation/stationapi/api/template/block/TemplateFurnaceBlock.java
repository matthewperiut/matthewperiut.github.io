package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_83152105;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateFurnaceBlock extends C_83152105 implements BlockTemplate {
    public TemplateFurnaceBlock(Identifier identifier, boolean flag) {
        this(BlockTemplate.getNextId(), flag);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateFurnaceBlock(int i, boolean flag) {
        super(i, flag);
    }
}
