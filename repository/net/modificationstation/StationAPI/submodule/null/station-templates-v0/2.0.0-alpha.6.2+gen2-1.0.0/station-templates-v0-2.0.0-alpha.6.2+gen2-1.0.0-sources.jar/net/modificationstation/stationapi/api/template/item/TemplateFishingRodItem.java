package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_90405103;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateFishingRodItem extends C_90405103 implements ItemTemplate {
    public TemplateFishingRodItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateFishingRodItem(int i) {
        super(i);
    }
}
