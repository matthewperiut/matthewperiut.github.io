package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_76558927;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateFlintAndSteelItem extends C_76558927 implements ItemTemplate {
    public TemplateFlintAndSteelItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }

    public TemplateFlintAndSteelItem(int i) {
        super(i);
    }
}
