package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_62147686;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateCropBlock extends C_62147686 implements BlockTemplate {
    public TemplateCropBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateCropBlock(int i, int j) {
        super(i, j);
    }
}
