package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_51015902;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateTranslucentBlock extends C_51015902 implements BlockTemplate {
    public TemplateTranslucentBlock(Identifier identifier, int j, C_89604096 arg, boolean flag) {
        this(BlockTemplate.getNextId(), j, arg, flag);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateTranslucentBlock(int i, int j, C_89604096 arg, boolean flag) {
        super(i, j, arg, flag);
    }
}
