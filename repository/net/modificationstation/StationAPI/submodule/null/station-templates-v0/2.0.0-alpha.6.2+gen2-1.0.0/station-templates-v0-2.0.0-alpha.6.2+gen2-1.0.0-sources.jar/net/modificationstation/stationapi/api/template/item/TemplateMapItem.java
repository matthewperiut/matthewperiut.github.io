package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_75615713;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateMapItem extends C_75615713 implements ItemTemplate {
    public TemplateMapItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }

    public TemplateMapItem(int i) {
        super(i);
    }
}
