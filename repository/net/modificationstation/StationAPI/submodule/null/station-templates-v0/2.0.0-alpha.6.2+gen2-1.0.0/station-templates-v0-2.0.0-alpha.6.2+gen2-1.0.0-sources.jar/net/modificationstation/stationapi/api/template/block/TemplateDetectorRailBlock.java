package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_17388568;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateDetectorRailBlock extends C_17388568 implements BlockTemplate {
    public TemplateDetectorRailBlock(Identifier identifier, int texture) {
        this(BlockTemplate.getNextId(), texture);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateDetectorRailBlock(int id, int texture) {
        super(id, texture);
    }
}
