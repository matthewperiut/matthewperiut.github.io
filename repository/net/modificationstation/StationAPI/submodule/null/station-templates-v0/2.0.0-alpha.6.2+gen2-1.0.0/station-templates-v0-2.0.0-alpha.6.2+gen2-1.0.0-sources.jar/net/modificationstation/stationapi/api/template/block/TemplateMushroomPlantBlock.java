package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_90574280;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateMushroomPlantBlock extends C_90574280 implements BlockTemplate {
    public TemplateMushroomPlantBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateMushroomPlantBlock(int i, int j) {
        super(i, j);
    }
}
