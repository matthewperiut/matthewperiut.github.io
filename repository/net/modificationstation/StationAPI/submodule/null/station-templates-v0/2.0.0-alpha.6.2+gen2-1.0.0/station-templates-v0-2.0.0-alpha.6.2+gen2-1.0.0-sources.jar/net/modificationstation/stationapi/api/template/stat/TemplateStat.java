package net.modificationstation.stationapi.api.template.stat;

import net.minecraft.unmapped.C_17284174;
import net.minecraft.unmapped.C_62649600;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateStat extends C_62649600 implements StatTemplate {
    public TemplateStat(Identifier identifier, String stringId, C_17284174 statTypeProvider) {
        this(StatTemplate.getNextId(), stringId, statTypeProvider);
        StatTemplate.onConstructor(this, identifier);
    }

    public TemplateStat(Identifier identifier, String stringId) {
        this(StatTemplate.getNextId(), stringId);
        StatTemplate.onConstructor(this, identifier);
    }

    public TemplateStat(int id, String stringId, C_17284174 statTypeProvider) {
        super(id, stringId, statTypeProvider);
    }

    public TemplateStat(int id, String stringId) {
        super(id, stringId);
    }
}