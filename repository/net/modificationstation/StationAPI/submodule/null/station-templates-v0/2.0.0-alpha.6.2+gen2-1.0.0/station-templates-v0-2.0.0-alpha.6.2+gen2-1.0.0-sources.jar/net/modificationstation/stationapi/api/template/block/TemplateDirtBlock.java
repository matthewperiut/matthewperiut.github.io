package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_11340426;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateDirtBlock extends C_11340426 implements BlockTemplate {
    public TemplateDirtBlock(Identifier identifier, int texture) {
        this(BlockTemplate.getNextId(), texture);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateDirtBlock(int id, int texture) {
        super(id, texture);
    }
}
