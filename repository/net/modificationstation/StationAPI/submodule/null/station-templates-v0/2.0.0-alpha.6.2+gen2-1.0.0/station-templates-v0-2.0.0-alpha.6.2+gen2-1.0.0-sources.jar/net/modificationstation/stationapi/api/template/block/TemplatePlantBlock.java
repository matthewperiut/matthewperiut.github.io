package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_45448523;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplatePlantBlock extends C_45448523 implements BlockTemplate {
    public TemplatePlantBlock(Identifier identifier, int texture) {
        this(BlockTemplate.getNextId(), texture);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplatePlantBlock(int id, int texture) {
        super(id, texture);
    }
}
