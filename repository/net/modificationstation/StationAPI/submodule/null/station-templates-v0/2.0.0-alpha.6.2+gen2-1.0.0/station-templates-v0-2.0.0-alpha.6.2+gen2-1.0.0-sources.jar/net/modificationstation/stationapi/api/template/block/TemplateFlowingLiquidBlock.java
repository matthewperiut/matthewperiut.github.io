package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_65131087;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateFlowingLiquidBlock extends C_65131087 implements BlockTemplate {
    public TemplateFlowingLiquidBlock(Identifier identifier, C_89604096 material) {
        this(BlockTemplate.getNextId(), material);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateFlowingLiquidBlock(int i, C_89604096 arg) {
        super(i, arg);
    }
}
