package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_19265696;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSnowyBlock extends C_19265696 implements BlockTemplate {
    public TemplateSnowyBlock(Identifier identifier, int texUVStart) {
        this(BlockTemplate.getNextId(), texUVStart);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateSnowyBlock(int id, int texUVStart) {
        super(id, texUVStart);
    }
}
