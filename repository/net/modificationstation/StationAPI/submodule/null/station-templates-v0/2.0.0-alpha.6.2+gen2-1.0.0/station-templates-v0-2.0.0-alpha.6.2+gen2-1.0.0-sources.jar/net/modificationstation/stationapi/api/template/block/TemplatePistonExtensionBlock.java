package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_34413895;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplatePistonExtensionBlock extends C_34413895 implements BlockTemplate {
    public TemplatePistonExtensionBlock(Identifier identifier) {
        this(BlockTemplate.getNextId());
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplatePistonExtensionBlock(int id) {
        super(id);
    }
}
