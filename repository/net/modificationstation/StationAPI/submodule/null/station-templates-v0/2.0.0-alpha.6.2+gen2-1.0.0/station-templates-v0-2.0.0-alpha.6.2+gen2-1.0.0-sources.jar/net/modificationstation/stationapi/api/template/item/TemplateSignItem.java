package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_04110931;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSignItem extends C_04110931 implements ItemTemplate {
    public TemplateSignItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateSignItem(int i) {
        super(i);
    }
}
