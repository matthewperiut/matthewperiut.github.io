package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_13709197;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateLiquidBlock extends C_13709197 implements BlockTemplate {
    public TemplateLiquidBlock(Identifier identifier, C_89604096 arg) {
        this(BlockTemplate.getNextId(), arg);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateLiquidBlock(int i, C_89604096 arg) {
        super(i, arg);
    }
}
