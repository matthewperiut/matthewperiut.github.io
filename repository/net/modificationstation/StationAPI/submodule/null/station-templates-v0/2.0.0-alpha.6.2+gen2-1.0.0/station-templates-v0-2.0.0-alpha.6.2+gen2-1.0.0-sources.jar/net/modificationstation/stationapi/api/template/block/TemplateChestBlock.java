package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_57247398;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateChestBlock extends C_57247398 implements BlockTemplate {
    public TemplateChestBlock(Identifier identifier) {
        this(BlockTemplate.getNextId());
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateChestBlock(int id) {
        super(id);
    }
}
