package net.modificationstation.stationapi.api.template.stat;

import net.minecraft.unmapped.C_62649600;
import net.modificationstation.stationapi.api.registry.Registry;
import net.modificationstation.stationapi.api.registry.StatRegistry;
import net.modificationstation.stationapi.api.util.Identifier;

public interface StatTemplate {
    static int getNextId() {
        return StatRegistry.AUTO_ID;
    }

    static void onConstructor(C_62649600 stat, Identifier id) {
        Registry.register(StatRegistry.INSTANCE, stat.f_06721285, id, stat);
    }
}