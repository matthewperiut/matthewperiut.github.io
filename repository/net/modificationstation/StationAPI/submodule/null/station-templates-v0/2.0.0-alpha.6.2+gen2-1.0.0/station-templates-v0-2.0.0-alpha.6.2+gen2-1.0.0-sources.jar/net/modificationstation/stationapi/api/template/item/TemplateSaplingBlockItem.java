package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_69324029;

public class TemplateSaplingBlockItem extends C_69324029 implements ItemTemplate {
    public TemplateSaplingBlockItem(int i) {
        super(i);
    }
}
