package net.modificationstation.stationapi.api.template.stat;

import net.minecraft.unmapped.C_17284174;
import net.minecraft.unmapped.C_23058753;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSimpleStat extends C_23058753 implements StatTemplate {
    public TemplateSimpleStat(Identifier identifier, String stringId, C_17284174 statTypeProvider) {
        this(StatTemplate.getNextId(), stringId, statTypeProvider);
        StatTemplate.onConstructor(this, identifier);
    }

    public TemplateSimpleStat(Identifier identifier, String stringId) {
        this(StatTemplate.getNextId(), stringId);
        StatTemplate.onConstructor(this, identifier);
    }

    public TemplateSimpleStat(int id, String stringId, C_17284174 statTypeProvider) {
        super(id, stringId, statTypeProvider);
    }

    public TemplateSimpleStat(int id, String stringId) {
        super(id, stringId);
    }
}