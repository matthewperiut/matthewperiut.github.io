package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_03091284;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateIceBlock extends C_03091284 implements BlockTemplate {
    public TemplateIceBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateIceBlock(int i, int j) {
        super(i, j);
    }
}
