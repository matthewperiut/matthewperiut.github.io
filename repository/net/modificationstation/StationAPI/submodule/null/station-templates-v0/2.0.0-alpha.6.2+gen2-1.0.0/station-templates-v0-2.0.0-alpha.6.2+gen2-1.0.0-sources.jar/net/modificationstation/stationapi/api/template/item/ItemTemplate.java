package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.registry.ItemRegistry;
import net.modificationstation.stationapi.api.registry.Registry;
import net.modificationstation.stationapi.api.util.Identifier;

public interface ItemTemplate {
    static int getNextId() {
        return ItemRegistry.AUTO_ID;
    }

    static void onConstructor(C_98888256 item, Identifier id) {
        Registry.register(ItemRegistry.INSTANCE, item.f_57562535, id, item);
        item.setTranslationKey(id.namespace, id.path);
    }
}
