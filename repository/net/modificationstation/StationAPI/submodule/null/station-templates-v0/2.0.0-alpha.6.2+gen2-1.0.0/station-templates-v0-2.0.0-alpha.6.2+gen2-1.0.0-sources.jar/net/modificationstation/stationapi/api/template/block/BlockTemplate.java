package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.registry.BlockRegistry;
import net.modificationstation.stationapi.api.registry.Registry;
import net.modificationstation.stationapi.api.util.Identifier;

public interface BlockTemplate {
    static int getNextId() {
        return BlockRegistry.AUTO_ID;
    }

    static void onConstructor(C_81592558 block, Identifier id) {
        Registry.register(BlockRegistry.INSTANCE, block.f_84602679, id, block);
        block.setTranslationKey(id.namespace, id.path);
    }
}
