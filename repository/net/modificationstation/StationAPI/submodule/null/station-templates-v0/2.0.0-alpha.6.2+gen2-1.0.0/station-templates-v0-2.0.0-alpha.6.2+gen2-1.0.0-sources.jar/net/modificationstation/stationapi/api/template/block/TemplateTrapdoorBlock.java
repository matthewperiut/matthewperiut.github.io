package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_69835601;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateTrapdoorBlock extends C_69835601 implements BlockTemplate {
    public TemplateTrapdoorBlock(Identifier identifier, C_89604096 arg) {
        this(BlockTemplate.getNextId(), arg);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateTrapdoorBlock(int i, C_89604096 arg) {
        super(i, arg);
    }
}
