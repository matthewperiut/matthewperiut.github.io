package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_57199446;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateFarmlandBlock extends C_57199446 implements BlockTemplate {
    public TemplateFarmlandBlock(Identifier identifier) {
        this(BlockTemplate.getNextId());
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateFarmlandBlock(int id) {
        super(id);
    }
}
