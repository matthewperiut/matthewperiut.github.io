package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_45302099;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSpawnerBlock extends C_45302099 implements BlockTemplate {
    public TemplateSpawnerBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateSpawnerBlock(int i, int j) {
        super(i, j);
    }
}
