package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_94584382;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.event.block.BlockEvent;
import net.modificationstation.stationapi.api.event.block.IsBlockReplaceableEvent;
import net.modificationstation.stationapi.api.item.ItemPlacementContext;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.api.util.math.Direction;

public class BlockStateItem extends TemplateItem {
    private final BlockState blockState;

    public BlockStateItem(Identifier identifier, BlockState blockState) {
        super(identifier);
        this.blockState = blockState;
    }

    public BlockStateItem(int id, BlockState blockState) {
        super(id);
        this.blockState = blockState;
    }

    @Override
    public boolean m_93921076(C_88708284 itemStack, C_40996800 player, C_64041439 world, int clickX, int clickY, int clickZ, int side) {
        final Direction direction;
        final int x;
        final int y;
        final int z;
        if (world.m_33234383(clickX, clickY, clickZ) == C_81592558.f_81695559.f_84602679) {
            direction = Direction.DOWN;
            side = 0;
            x = clickX;
            y = clickY;
            z = clickZ;
        } else {
            direction = Direction.values()[side];
            x = clickX + direction.getOffsetX();
            y = clickY + direction.getOffsetY();
            z = clickZ + direction.getOffsetZ();
        }
        if (itemStack.f_60602012 == 0) return false;
        if (y == world.getTopY() - 1 && blockState.getMaterial().m_16301600()) return false;
        C_81592558 block = blockState.getBlock();

        C_82690114 box = block.m_03092609(world, x, y, z);
        if (
                (box == null || world.m_52719108(box)) && StationAPI.EVENT_BUS.post(
                        IsBlockReplaceableEvent.builder()
                                .context(new ItemPlacementContext(player, itemStack, new C_24654288(clickX, clickY, clickZ, side, C_94584382.m_35957932(x, y, z))))
                                .build()
                ).context.canPlace() && block.m_71180744(world, x, y, z, side)
        ) {
            if (StationAPI.EVENT_BUS.post(BlockEvent.BeforePlacedByItem.builder()
                    .world(world)
                    .player(player)
                    .x(x).y(y).z(z)
                    .side(direction)
                    .block(block)
                    .blockItem(itemStack)
                    .placeFunction(() -> world.setBlockState(x, y, z, blockState) != null)
                    .build()).placeFunction.getAsBoolean()
            ) {
                block.m_05287994(world, x, y, z, direction.getId());
                block.m_93454127(world, x, y, z, player);
                world.m_14911682((float)x + 0.5f, (float)y + 0.5f, (float)z + 0.5f, block.f_13889746.m_48793905(), (block.f_13889746.m_48828997() + 1.0f) / 2.0f, block.f_13889746.m_35890820() * 0.8f);
                --itemStack.f_60602012;
            }
            return true;
        }
        return false;
    }
}
