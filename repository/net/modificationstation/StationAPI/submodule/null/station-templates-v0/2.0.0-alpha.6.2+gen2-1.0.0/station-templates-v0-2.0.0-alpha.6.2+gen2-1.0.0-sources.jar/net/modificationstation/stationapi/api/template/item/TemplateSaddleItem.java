package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_27191077;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSaddleItem extends C_27191077 implements ItemTemplate {
    public TemplateSaddleItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateSaddleItem(int i) {
        super(i);
    }
}
