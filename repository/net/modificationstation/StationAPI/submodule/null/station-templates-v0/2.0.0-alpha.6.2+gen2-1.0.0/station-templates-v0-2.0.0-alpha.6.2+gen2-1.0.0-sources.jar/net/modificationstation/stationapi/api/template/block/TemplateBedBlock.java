package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_75957563;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateBedBlock extends C_75957563 implements BlockTemplate {
    public TemplateBedBlock(Identifier identifier) {
        this(BlockTemplate.getNextId());
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateBedBlock(int id) {
        super(id);
    }
}
