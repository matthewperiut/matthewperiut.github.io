package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_64607668;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplatePaintingItem extends C_64607668 implements ItemTemplate {
    public TemplatePaintingItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplatePaintingItem(int i) {
        super(i);
    }
}
