package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_89914243;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateFenceBlock extends C_89914243 implements BlockTemplate {
    public TemplateFenceBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateFenceBlock(int i, int j) {
        super(i, j);
    }
}
