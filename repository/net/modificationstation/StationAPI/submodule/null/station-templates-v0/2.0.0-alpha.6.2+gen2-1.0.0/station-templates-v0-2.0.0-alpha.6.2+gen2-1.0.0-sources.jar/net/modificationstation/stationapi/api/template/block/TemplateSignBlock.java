package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_40735137;
import net.minecraft.unmapped.C_55673389;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSignBlock extends C_55673389 implements BlockTemplate {
    public TemplateSignBlock(Identifier identifier, Class<? extends C_40735137> arg, boolean flag) {
        this(BlockTemplate.getNextId(), arg, flag);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateSignBlock(int i, Class<? extends C_40735137> arg, boolean flag) {
        super(i, arg, flag);
    }
}
