package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_80821451;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateCactusBlock extends C_80821451 implements BlockTemplate {
    public TemplateCactusBlock(Identifier identifier, int texture) {
        this(BlockTemplate.getNextId(), texture);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateCactusBlock(int id, int texture) {
        super(id, texture);
    }
}
