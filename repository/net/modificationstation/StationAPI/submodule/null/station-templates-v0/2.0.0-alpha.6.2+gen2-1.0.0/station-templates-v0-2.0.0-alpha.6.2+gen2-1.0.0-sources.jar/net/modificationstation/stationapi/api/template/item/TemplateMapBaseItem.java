package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_32510114;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateMapBaseItem extends C_32510114 implements ItemTemplate {
    public TemplateMapBaseItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }

    public TemplateMapBaseItem(int i) {
        super(i);
    }
}
