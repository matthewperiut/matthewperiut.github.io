package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_52610529;

public class TemplateLeavesBlockItem extends C_52610529 implements ItemTemplate {
    public TemplateLeavesBlockItem(int i) {
        super(i);
    }
}
