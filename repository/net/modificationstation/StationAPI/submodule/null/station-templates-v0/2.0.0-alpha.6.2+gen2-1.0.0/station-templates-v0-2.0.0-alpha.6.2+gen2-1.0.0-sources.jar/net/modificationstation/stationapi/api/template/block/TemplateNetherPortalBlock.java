package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_71940803;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateNetherPortalBlock extends C_71940803 implements BlockTemplate {
    public TemplateNetherPortalBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateNetherPortalBlock(int i, int j) {
        super(i, j);
    }
}
