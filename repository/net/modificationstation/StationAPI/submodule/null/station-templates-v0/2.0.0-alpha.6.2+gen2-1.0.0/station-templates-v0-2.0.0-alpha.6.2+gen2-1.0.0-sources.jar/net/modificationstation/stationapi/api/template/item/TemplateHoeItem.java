package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_50960081;
import net.minecraft.unmapped.C_98888256.net.minecraft.unmapped.C_74597326;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateHoeItem extends C_50960081 implements ItemTemplate {
    public TemplateHoeItem(Identifier identifier, C_74597326 arg) {
        this(ItemTemplate.getNextId(), arg);
        ItemTemplate.onConstructor(this, identifier);
    }

    public TemplateHoeItem(int i, C_74597326 arg) {
        super(i, arg);
    }
}
