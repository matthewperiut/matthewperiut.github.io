package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_17309128;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateShearsItem extends C_17309128 implements ItemTemplate {
    public TemplateShearsItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateShearsItem(int i) {
        super(i);
    }
}
