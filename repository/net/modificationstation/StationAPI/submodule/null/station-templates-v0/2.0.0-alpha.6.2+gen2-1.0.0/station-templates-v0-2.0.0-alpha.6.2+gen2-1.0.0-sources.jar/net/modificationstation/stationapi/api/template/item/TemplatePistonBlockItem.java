package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_41611298;

public class TemplatePistonBlockItem extends C_41611298 implements ItemTemplate {
    public TemplatePistonBlockItem(int i) {
        super(i);
    }
}
