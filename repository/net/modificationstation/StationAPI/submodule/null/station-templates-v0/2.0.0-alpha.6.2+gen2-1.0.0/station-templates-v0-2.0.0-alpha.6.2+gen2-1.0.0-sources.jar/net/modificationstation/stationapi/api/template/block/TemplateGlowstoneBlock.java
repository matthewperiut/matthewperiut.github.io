package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_89604096;
import net.minecraft.unmapped.C_90783128;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateGlowstoneBlock extends C_90783128 implements BlockTemplate {
    public TemplateGlowstoneBlock(Identifier identifier, int j, C_89604096 arg) {
        this(BlockTemplate.getNextId(), j, arg);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateGlowstoneBlock(int i, int j, C_89604096 arg) {
        super(i, j, arg);
    }
}
