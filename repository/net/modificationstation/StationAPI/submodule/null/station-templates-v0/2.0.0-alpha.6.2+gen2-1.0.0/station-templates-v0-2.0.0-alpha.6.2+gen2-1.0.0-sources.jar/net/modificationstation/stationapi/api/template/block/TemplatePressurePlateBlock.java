package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_89604096;
import net.minecraft.unmapped.C_92949082;
import net.minecraft.unmapped.C_92949082.net.minecraft.unmapped.C_58325677;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplatePressurePlateBlock extends C_92949082 implements BlockTemplate {
    public TemplatePressurePlateBlock(Identifier identifier, int j, C_58325677 arg, C_89604096 arg1) {
        this(BlockTemplate.getNextId(), j, arg, arg1);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplatePressurePlateBlock(int i, int j, C_58325677 arg, C_89604096 arg1) {
        super(i, j, arg, arg1);
    }
}
