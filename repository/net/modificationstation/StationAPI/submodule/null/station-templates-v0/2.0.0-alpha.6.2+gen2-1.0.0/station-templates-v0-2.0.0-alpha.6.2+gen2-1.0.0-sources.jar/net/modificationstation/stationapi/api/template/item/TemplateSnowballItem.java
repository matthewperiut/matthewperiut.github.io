package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_87686542;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSnowballItem extends C_87686542 implements ItemTemplate {
    public TemplateSnowballItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }

    public TemplateSnowballItem(int i) {
        super(i);
    }
}
