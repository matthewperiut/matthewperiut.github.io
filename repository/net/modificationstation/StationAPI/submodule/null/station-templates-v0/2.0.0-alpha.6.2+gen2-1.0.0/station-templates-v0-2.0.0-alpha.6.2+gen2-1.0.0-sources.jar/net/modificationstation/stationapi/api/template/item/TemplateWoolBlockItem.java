package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_42815791;

public class TemplateWoolBlockItem extends C_42815791 implements ItemTemplate {
    public TemplateWoolBlockItem(int i) {
        super(i);
    }
}
