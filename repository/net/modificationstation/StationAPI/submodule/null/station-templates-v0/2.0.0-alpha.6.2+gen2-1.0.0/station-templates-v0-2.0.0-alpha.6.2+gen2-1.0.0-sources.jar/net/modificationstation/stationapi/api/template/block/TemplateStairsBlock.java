package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_13231860;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateStairsBlock extends C_13231860 implements BlockTemplate {
    public TemplateStairsBlock(Identifier identifier, C_81592558 arg) {
        this(BlockTemplate.getNextId(), arg);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateStairsBlock(int i, C_81592558 arg) {
        super(i, arg);
    }
}
