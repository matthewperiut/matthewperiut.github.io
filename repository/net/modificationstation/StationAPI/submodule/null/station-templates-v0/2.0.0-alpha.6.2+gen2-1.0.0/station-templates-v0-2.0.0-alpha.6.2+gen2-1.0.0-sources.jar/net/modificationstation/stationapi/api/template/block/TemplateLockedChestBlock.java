package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_60728795;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateLockedChestBlock extends C_60728795 implements BlockTemplate {
    public TemplateLockedChestBlock(Identifier identifier) {
        this(BlockTemplate.getNextId());
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateLockedChestBlock(int i) {
        super(i);
    }
}
