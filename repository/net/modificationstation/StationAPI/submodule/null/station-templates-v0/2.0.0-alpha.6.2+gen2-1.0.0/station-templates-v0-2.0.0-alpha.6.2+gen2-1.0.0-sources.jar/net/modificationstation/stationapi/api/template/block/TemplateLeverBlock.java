package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_03839261;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateLeverBlock extends C_03839261 implements BlockTemplate {
    public TemplateLeverBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateLeverBlock(int i, int j) {
        super(i, j);
    }
}
