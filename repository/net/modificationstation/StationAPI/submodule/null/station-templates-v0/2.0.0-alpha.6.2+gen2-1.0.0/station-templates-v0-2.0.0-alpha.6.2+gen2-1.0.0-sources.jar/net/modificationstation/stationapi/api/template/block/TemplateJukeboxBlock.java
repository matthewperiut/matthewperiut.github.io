package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_88996113;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateJukeboxBlock extends C_88996113 implements BlockTemplate {
    public TemplateJukeboxBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateJukeboxBlock(int i, int j) {
        super(i, j);
    }
}
