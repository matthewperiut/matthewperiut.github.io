package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_42993438;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateDeadBushBlock extends C_42993438 implements BlockTemplate {
    public TemplateDeadBushBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateDeadBushBlock(int i, int j) {
        super(i, j);
    }
}
