package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_22534799;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateLadderBlock extends C_22534799 implements BlockTemplate {
    public TemplateLadderBlock(Identifier identifier, int texUVStart) {
        this(BlockTemplate.getNextId(), texUVStart);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateLadderBlock(int id, int texUVStart) {
        super(id, texUVStart);
    }
}
