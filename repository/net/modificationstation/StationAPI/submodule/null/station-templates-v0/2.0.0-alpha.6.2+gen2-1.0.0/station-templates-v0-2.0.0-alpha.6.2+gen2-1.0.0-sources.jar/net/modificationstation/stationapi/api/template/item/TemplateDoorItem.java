package net.modificationstation.stationapi.api.template.item;

import lombok.Getter;
import net.minecraft.unmapped.C_75021297;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.api.template.block.TemplateDoorBlock;
import net.modificationstation.stationapi.api.util.Identifier;

@Getter
public class TemplateDoorItem extends C_75021297 implements ItemTemplate {
    /**
     * Used in a mixin to override the door block placed.
     */
    protected final C_81592558 doorBlock;

    public TemplateDoorItem(Identifier identifier, C_89604096 arg, C_81592558 doorBlock) {
        this(ItemTemplate.getNextId(), arg, doorBlock);
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateDoorItem(int id, C_89604096 arg, C_81592558 doorBlock) {
        super(id, arg);
        this.doorBlock = doorBlock;
        if (doorBlock instanceof TemplateDoorBlock templateDoorBlock) {
            templateDoorBlock.doorItem = this;
        }
    }

}
