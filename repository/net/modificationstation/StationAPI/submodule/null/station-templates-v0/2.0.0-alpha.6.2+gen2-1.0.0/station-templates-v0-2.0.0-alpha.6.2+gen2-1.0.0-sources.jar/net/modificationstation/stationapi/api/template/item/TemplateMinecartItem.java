package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_20443579;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateMinecartItem extends C_20443579 implements ItemTemplate {
    public TemplateMinecartItem(Identifier identifier, int j) {
        this(ItemTemplate.getNextId(), j);
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateMinecartItem(int i, int j) {
        super(i, j);
    }
}
