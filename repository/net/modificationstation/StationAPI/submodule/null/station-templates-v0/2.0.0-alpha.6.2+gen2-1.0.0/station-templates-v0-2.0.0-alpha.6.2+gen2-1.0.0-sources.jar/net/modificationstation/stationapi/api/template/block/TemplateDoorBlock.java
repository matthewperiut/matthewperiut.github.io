package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_23969718;
import net.minecraft.unmapped.C_89604096;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.util.Identifier;
import org.jetbrains.annotations.ApiStatus;

import java.util.Random;

public class TemplateDoorBlock extends C_23969718 implements BlockTemplate {
    public int topTextureId = 0;
    public int bottomTextureId = 0;

    @ApiStatus.Internal
    public C_98888256 doorItem = null;

    public TemplateDoorBlock(Identifier identifier, C_89604096 material) {
        this(BlockTemplate.getNextId(), material);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateDoorBlock(int i, C_89604096 arg) {
        super(i, arg);
    }

    public boolean isTop(int meta) {
        return (meta & 8) != 0;
    }

    @Override
    public int m_07414817(int side, int meta) {
        if (side == 0 || side == 1) {
            return bottomTextureId;
        }

        if (!isTop(meta)) {
            return bottomTextureId;
        }

        int var3 = this.m_74750517(meta);
        if ((var3 == 0 || var3 == 2) ^ side <= 3) {
            return this.bottomTextureId;
        } else {
            return this.topTextureId;
        }
    }

    @Override
    public int m_78174230(int blockMeta, Random random) {
        if (isTop(blockMeta)) {
            return 0;
        } else {
            return doorItem.f_57562535;
        }
    }
}
