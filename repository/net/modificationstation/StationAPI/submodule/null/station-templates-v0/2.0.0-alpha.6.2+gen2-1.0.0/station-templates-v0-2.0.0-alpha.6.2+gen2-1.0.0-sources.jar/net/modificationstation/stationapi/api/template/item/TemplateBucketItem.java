package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_90901456;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateBucketItem extends C_90901456 implements ItemTemplate {
    public TemplateBucketItem(Identifier identifier, int j) {
        this(ItemTemplate.getNextId(), j);
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateBucketItem(int i, int j) {
        super(i, j);
    }
}
