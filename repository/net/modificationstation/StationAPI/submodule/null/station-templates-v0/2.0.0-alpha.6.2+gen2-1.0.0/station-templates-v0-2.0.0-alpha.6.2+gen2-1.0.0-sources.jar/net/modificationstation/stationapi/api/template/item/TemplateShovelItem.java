package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_75759956;
import net.minecraft.unmapped.C_98888256.net.minecraft.unmapped.C_74597326;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateShovelItem extends C_75759956 implements ItemTemplate {
    public TemplateShovelItem(Identifier identifier, C_74597326 arg) {
        this(ItemTemplate.getNextId(), arg);
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateShovelItem(int id, C_74597326 arg) {
        super(id, arg);
    }
}
