package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_34150852;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateClayBlock extends C_34150852 implements BlockTemplate {
    public TemplateClayBlock(Identifier identifier, int texture) {
        this(BlockTemplate.getNextId(), texture);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateClayBlock(int id, int texture) {
        super(id, texture);
    }
}
