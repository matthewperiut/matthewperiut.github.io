package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_53672520;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_98888256.net.minecraft.unmapped.C_74597326;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateToolItem extends C_53672520 implements ItemTemplate {
    public TemplateToolItem(Identifier identifier, int j, C_74597326 arg, C_81592558[] effectiveBlocks) {
        this(ItemTemplate.getNextId(), j, arg, effectiveBlocks);
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateToolItem(int id, int j, C_74597326 arg, C_81592558[] effectiveBlocks) {
        super(id, j, arg, effectiveBlocks);
    }
}
