package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_76154632;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateBowItem extends C_76154632 implements ItemTemplate {
    public TemplateBowItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateBowItem(int i) {
        super(i);
    }
}
