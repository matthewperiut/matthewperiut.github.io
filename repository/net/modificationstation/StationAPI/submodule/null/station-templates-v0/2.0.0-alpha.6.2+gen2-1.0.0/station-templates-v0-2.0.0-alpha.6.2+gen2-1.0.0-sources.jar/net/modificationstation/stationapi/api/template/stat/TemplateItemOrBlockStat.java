package net.modificationstation.stationapi.api.template.stat;

import net.minecraft.unmapped.C_89105241;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateItemOrBlockStat extends C_89105241 implements StatTemplate {
    public TemplateItemOrBlockStat(Identifier identifier, String translationKey, int itemIdOrBlockId) {
        this(StatTemplate.getNextId(), translationKey, itemIdOrBlockId);
        StatTemplate.onConstructor(this, identifier);
    }

    public TemplateItemOrBlockStat(int statId, String translationKey, int itemIdOrBlockId) {
        super(statId, translationKey, itemIdOrBlockId);
    }
}