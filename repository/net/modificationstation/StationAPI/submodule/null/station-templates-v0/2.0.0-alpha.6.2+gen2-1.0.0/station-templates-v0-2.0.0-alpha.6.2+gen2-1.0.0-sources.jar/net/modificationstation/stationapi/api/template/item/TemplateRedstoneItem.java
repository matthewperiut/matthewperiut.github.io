package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_48314562;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateRedstoneItem extends C_48314562 implements ItemTemplate {
    public TemplateRedstoneItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateRedstoneItem(int i) {
        super(i);
    }
}
