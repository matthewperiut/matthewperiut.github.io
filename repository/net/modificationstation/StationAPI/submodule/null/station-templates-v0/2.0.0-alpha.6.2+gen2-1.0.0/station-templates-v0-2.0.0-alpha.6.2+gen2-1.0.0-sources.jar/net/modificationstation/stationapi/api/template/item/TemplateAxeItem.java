package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_85721786;
import net.minecraft.unmapped.C_98888256.net.minecraft.unmapped.C_74597326;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateAxeItem extends C_85721786 implements ItemTemplate {
    public TemplateAxeItem(Identifier identifier, C_74597326 material) {
        this(ItemTemplate.getNextId(), material);
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateAxeItem(int id, C_74597326 material) {
        super(id, material);
    }
}
