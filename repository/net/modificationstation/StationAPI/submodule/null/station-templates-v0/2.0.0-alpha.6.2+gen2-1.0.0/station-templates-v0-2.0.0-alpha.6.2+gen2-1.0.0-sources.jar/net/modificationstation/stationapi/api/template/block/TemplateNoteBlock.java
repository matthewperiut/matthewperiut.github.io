package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_62418920;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateNoteBlock extends C_62418920 implements BlockTemplate {
    public TemplateNoteBlock(Identifier identifier) {
        this(BlockTemplate.getNextId());
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateNoteBlock(int i) {
        super(i);
    }
}
