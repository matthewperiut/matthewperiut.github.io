package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_18719811;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateGrassBlock extends C_18719811 implements BlockTemplate {
    public TemplateGrassBlock(Identifier identifier) {
        this(BlockTemplate.getNextId());
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateGrassBlock(int id) {
        super(id);
    }
}
