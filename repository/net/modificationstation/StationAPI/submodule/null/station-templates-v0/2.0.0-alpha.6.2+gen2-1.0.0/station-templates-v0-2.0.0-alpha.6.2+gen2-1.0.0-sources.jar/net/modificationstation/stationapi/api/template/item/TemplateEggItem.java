package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_54839583;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateEggItem extends C_54839583 implements ItemTemplate {
    public TemplateEggItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }

    public TemplateEggItem(int i) {
        super(i);
    }
}
