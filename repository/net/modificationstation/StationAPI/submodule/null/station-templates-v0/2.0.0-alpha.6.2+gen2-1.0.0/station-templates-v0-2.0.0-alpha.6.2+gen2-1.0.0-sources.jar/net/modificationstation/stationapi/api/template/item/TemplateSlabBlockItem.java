package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_47884049;

public class TemplateSlabBlockItem extends C_47884049 implements ItemTemplate {
    public TemplateSlabBlockItem(int i) {
        super(i);
    }
}
