package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_56739928;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateBoatItem extends C_56739928 implements ItemTemplate {
    public TemplateBoatItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateBoatItem(int i) {
        super(i);
    }
}
