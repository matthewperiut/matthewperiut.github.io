package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_67629120;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSugarCaneBlock extends C_67629120 implements BlockTemplate {
    public TemplateSugarCaneBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateSugarCaneBlock(int i, int j) {
        super(i, j);
    }
}
