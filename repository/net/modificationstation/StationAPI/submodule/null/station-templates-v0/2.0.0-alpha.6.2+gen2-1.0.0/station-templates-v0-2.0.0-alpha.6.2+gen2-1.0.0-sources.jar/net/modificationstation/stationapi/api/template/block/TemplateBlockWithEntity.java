package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_73452336;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.api.util.Identifier;

public abstract class TemplateBlockWithEntity extends C_73452336 implements BlockTemplate {
    public TemplateBlockWithEntity(Identifier identifier, C_89604096 material) {
        this(BlockTemplate.getNextId(), material);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateBlockWithEntity(Identifier identifier, int tex, C_89604096 material) {
        this(BlockTemplate.getNextId(), tex, material);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateBlockWithEntity(int i, C_89604096 arg) {
        super(i, arg);
    }

    public TemplateBlockWithEntity(int i, int j, C_89604096 arg) {
        super(i, j, arg);
    }
}
