package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_66522575;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateButtonBlock extends C_66522575 implements BlockTemplate {
    public TemplateButtonBlock(Identifier identifier, int texture) {
        this(BlockTemplate.getNextId(), texture);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateButtonBlock(int id, int texture) {
        super(id, texture);
    }
}
