package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_71827890;

public class TemplateBlockItem extends C_71827890 implements ItemTemplate {
    public TemplateBlockItem(int i) {
        super(i);
    }
}
