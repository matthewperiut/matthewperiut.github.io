package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_50456764;
import net.minecraft.unmapped.C_98888256.net.minecraft.unmapped.C_74597326;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplatePickaxeItem extends C_50456764 implements ItemTemplate {
    public TemplatePickaxeItem(Identifier identifier, C_74597326 material) {
        this(ItemTemplate.getNextId(), material);
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplatePickaxeItem(int id, C_74597326 material) {
        super(id, material);
    }
}
