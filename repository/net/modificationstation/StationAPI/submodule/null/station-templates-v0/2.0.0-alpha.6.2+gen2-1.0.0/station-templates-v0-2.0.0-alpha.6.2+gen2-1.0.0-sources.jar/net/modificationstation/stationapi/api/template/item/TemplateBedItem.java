package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_11019538;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateBedItem extends C_11019538 implements ItemTemplate {
    public TemplateBedItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }

    public TemplateBedItem(int i) {
        super(i);
    }
}
