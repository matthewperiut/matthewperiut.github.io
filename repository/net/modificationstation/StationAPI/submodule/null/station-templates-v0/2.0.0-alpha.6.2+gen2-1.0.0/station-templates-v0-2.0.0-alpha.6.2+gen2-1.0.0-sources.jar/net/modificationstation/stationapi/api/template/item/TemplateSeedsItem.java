package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_49594631;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSeedsItem extends C_49594631 implements ItemTemplate {
    public TemplateSeedsItem(Identifier identifier, int j) {
        this(ItemTemplate.getNextId(), j);
        ItemTemplate.onConstructor(this, identifier);
    }

    public TemplateSeedsItem(int id, int j) {
        super(id, j);
    }
}
