package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_05042406;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateStillLiquidBlock extends C_05042406 implements BlockTemplate {
    public TemplateStillLiquidBlock(Identifier identifier, C_89604096 arg) {
        this(BlockTemplate.getNextId(), arg);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateStillLiquidBlock(int i, C_89604096 arg) {
        super(i, arg);
    }
}
