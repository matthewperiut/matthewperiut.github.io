package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_11403679;

public class TemplateLogBlockItem extends C_11403679 implements ItemTemplate {
    public TemplateLogBlockItem(int i) {
        super(i);
    }
}
