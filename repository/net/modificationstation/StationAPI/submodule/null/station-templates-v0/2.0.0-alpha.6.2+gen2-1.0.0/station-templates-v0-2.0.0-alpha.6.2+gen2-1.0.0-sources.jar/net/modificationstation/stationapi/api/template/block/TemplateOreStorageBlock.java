package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_67133180;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateOreStorageBlock extends C_67133180 implements BlockTemplate {
    public TemplateOreStorageBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateOreStorageBlock(int i, int j) {
        super(i, j);
    }
}
