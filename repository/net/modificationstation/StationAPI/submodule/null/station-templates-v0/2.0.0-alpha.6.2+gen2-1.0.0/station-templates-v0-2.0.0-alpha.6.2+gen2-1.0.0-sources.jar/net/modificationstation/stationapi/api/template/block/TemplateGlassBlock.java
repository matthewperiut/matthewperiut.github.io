package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_89604096;
import net.minecraft.unmapped.C_89967701;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateGlassBlock extends C_89967701 implements BlockTemplate {
    public TemplateGlassBlock(Identifier identifier, int j, C_89604096 arg, boolean flag) {
        this(BlockTemplate.getNextId(), j, arg, flag);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateGlassBlock(int i, int j, C_89604096 arg, boolean flag) {
        super(i, j, arg, flag);
    }
}
