package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_21729986;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplatePistonBlock extends C_21729986 implements BlockTemplate {
    public TemplatePistonBlock(Identifier identifier, int j, boolean flag) {
        this(BlockTemplate.getNextId(), j, flag);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplatePistonBlock(int i, int j, boolean flag) {
        super(i, j, flag);
    }
}
