package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_70629407;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateWorkbenchBlock extends C_70629407 implements BlockTemplate {
    public TemplateWorkbenchBlock(Identifier identifier) {
        this(BlockTemplate.getNextId());
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateWorkbenchBlock(int i) {
        super(i);
    }
}
