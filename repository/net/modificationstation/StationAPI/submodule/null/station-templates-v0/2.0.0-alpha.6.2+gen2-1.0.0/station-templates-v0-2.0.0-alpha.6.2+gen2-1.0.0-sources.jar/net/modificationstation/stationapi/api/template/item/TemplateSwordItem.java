package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_64104387;
import net.minecraft.unmapped.C_98888256.net.minecraft.unmapped.C_74597326;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSwordItem extends C_64104387 implements ItemTemplate {
    public TemplateSwordItem(Identifier identifier, C_74597326 arg) {
        this(ItemTemplate.getNextId(), arg);
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateSwordItem(int i, C_74597326 arg) {
        super(i, arg);
    }
}
