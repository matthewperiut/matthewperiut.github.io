package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_50815387;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSnowBlock extends C_50815387 implements BlockTemplate {
    public TemplateSnowBlock(Identifier identifier, int texUVStart) {
        this(BlockTemplate.getNextId(), texUVStart);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateSnowBlock(int id, int texUVStart) {
        super(id, texUVStart);
    }
}
