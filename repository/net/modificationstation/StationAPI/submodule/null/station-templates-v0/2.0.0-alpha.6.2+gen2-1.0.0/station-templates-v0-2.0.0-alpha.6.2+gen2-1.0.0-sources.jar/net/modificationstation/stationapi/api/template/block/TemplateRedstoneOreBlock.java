package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_66846378;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateRedstoneOreBlock extends C_66846378 implements BlockTemplate {
    public TemplateRedstoneOreBlock(Identifier identifier, int j, boolean isLit) {
        this(BlockTemplate.getNextId(), j, isLit);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateRedstoneOreBlock(int i, int j, boolean isLit) {
        super(i, j, isLit);
    }
}
