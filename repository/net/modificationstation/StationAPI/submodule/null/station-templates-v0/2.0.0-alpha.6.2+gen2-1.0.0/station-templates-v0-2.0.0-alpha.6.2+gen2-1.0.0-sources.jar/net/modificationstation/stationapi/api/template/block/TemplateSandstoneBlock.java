package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_95568557;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSandstoneBlock extends C_95568557 implements BlockTemplate {
    public TemplateSandstoneBlock(Identifier identifier) {
        this(BlockTemplate.getNextId());
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateSandstoneBlock(int i) {
        super(i);
    }
}
