package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_82108633;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateNetherrackBlock extends C_82108633 implements BlockTemplate {
    public TemplateNetherrackBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateNetherrackBlock(int i, int j) {
        super(i, j);
    }
}
