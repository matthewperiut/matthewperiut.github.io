package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_23330260;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateLogBlock extends C_23330260 implements BlockTemplate {
    public TemplateLogBlock(Identifier identifier) {
        this(BlockTemplate.getNextId());
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateLogBlock(int i) {
        super(i);
    }
}
