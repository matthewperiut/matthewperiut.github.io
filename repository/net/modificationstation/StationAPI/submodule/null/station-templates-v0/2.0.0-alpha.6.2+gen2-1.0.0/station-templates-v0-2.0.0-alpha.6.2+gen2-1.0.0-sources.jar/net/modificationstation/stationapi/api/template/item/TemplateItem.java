package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateItem extends C_98888256 implements ItemTemplate {
    public TemplateItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }

    public TemplateItem(int id) {
        super(id);
    }
}
