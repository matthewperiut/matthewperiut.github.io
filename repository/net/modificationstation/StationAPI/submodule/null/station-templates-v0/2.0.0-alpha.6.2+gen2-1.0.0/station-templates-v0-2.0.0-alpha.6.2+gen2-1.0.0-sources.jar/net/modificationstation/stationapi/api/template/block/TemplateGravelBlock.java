package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_01975579;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateGravelBlock extends C_01975579 implements BlockTemplate {
    public TemplateGravelBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateGravelBlock(int i, int j) {
        super(i, j);
    }
}
