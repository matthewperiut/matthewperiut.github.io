package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_34225397;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSaplingBlock extends C_34225397 implements BlockTemplate {
    public TemplateSaplingBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateSaplingBlock(int i, int j) {
        super(i, j);
    }
}
