package net.modificationstation.stationapi.api.template.item;

import net.minecraft.unmapped.C_23619234;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateCoalItem extends C_23619234 implements ItemTemplate {
    public TemplateCoalItem(Identifier identifier) {
        this(ItemTemplate.getNextId());
        ItemTemplate.onConstructor(this, identifier);
    }
    
    public TemplateCoalItem(int i) {
        super(i);
    }
}
