package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_21700931;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateTallPlantBlock extends C_21700931 implements BlockTemplate {
    public TemplateTallPlantBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateTallPlantBlock(int i, int j) {
        super(i, j);
    }
}
