package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_18811114;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateSpongeBlock extends C_18811114 implements BlockTemplate {
    public TemplateSpongeBlock(Identifier identifier) {
        this(BlockTemplate.getNextId());
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateSpongeBlock(int i) {
        super(i);
    }
}
