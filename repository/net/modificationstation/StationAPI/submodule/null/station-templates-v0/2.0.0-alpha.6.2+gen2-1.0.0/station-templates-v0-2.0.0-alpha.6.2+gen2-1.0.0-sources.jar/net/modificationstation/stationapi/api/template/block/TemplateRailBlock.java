package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_02333628;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateRailBlock extends C_02333628 implements BlockTemplate {
    public TemplateRailBlock(Identifier identifier, int j, boolean flag) {
        this(BlockTemplate.getNextId(), j, flag);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateRailBlock(int i, int j, boolean flag) {
        super(i, j, flag);
    }
}
