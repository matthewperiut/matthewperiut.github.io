package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_94218005;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateTorchBlock extends C_94218005 implements BlockTemplate {
    public TemplateTorchBlock(Identifier identifier, int j) {
        this(BlockTemplate.getNextId(), j);
        BlockTemplate.onConstructor(this, identifier);
    }
    
    public TemplateTorchBlock(int i, int j) {
        super(i, j);
    }
}
