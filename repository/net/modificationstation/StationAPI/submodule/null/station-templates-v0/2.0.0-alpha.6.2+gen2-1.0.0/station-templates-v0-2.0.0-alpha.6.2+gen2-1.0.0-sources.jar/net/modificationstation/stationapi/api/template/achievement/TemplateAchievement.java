package net.modificationstation.stationapi.api.template.achievement;

import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_90931970;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateAchievement extends C_90931970 implements AchievementTemplate {
    public TemplateAchievement(Identifier identifier, String key, int column, int row, C_98888256 displayItem, C_90931970 parent) {
        this(AchievementTemplate.getNextId(), key, column, row, displayItem, parent);
        AchievementTemplate.onConstructor(this, identifier);
    }

    public TemplateAchievement(Identifier identifier, String key, int column, int row, C_81592558 displayBlock, C_90931970 parent) {
        this(AchievementTemplate.getNextId(), key, column, row, displayBlock, parent);
        AchievementTemplate.onConstructor(this, identifier);
    }

    public TemplateAchievement(Identifier identifier, String key, int column, int row, C_88708284 icon, C_90931970 parent) {
        this(AchievementTemplate.getNextId(), key, column, row, icon, parent);
        AchievementTemplate.onConstructor(this, identifier);
    }

    public TemplateAchievement(int id, String key, int column, int row, C_98888256 displayItem, C_90931970 parent) {
        super(id, key, column, row, displayItem, parent);
    }

    public TemplateAchievement(int id, String key, int column, int row, C_81592558 displayBlock, C_90931970 parent) {
        super(id, key, column, row, displayBlock, parent);
    }

    public TemplateAchievement(int id, String key, int column, int row, C_88708284 icon, C_90931970 parent) {
        super(id, key, column, row, icon, parent);
    }
}