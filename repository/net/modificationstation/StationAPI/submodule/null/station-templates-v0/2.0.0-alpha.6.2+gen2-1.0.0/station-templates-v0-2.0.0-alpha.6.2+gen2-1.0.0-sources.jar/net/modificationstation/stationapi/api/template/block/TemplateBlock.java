package net.modificationstation.stationapi.api.template.block;

import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.api.util.Identifier;

public class TemplateBlock extends C_81592558 implements BlockTemplate {
    public TemplateBlock(Identifier identifier, C_89604096 material) {
        this(BlockTemplate.getNextId(), material);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateBlock(Identifier identifier, int tex, C_89604096 material) {
        this(BlockTemplate.getNextId(), tex, material);
        BlockTemplate.onConstructor(this, identifier);
    }

    public TemplateBlock(int id, C_89604096 material) {
        super(id, material);
    }

    public TemplateBlock(int id, int tex, C_89604096 material) {
        super(id, tex, material);
    }
}
