package net.modificationstation.stationapi.api.event.world.biome;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_28105876;

@SuperBuilder
public class BiomeByClimateEvent extends Event {
    public final float temperature;
    public final float downfall;
    public C_28105876 currentBiome;
}
