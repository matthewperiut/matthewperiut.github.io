package net.modificationstation.stationapi.impl.packet;

import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_36877109;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.api.network.packet.PacketType;
import net.modificationstation.stationapi.impl.network.StationFlatteningPacketHandler;
import net.modificationstation.stationapi.impl.util.math.ChunkSectionPos;
import net.modificationstation.stationapi.impl.world.chunk.ChunkSection;
import net.modificationstation.stationapi.impl.world.chunk.FlattenedChunk;
import org.jetbrains.annotations.NotNull;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Objects;

public class FlattenedMultiBlockChangeS2CPacket extends C_36877109 implements ManagedPacket<FlattenedMultiBlockChangeS2CPacket> {
    public static final PacketType<FlattenedMultiBlockChangeS2CPacket> TYPE = PacketType.builder(true, false, FlattenedMultiBlockChangeS2CPacket::new).build();

    public int sectionIndex;
    public int[] stateArray;

    private FlattenedMultiBlockChangeS2CPacket() {}

    public FlattenedMultiBlockChangeS2CPacket(int chunkX, int chunkZ, int sectionIndex, short[] positions, int arraySize, C_64041439 world) {
        this.f_79481286 = chunkX;
        this.f_86949888 = chunkZ;
        this.sectionIndex = sectionIndex;
        this.f_01960917 = arraySize;
        this.f_04903120 = new short[arraySize];
        stateArray = new int[arraySize];
        f_91311726 = new byte[arraySize];
        ChunkSection section = Objects.requireNonNullElse(((FlattenedChunk) world.m_27928573(chunkX, chunkZ)).sections[sectionIndex], ChunkSection.EMPTY);
        for (int i = 0; i < arraySize; i++) {
            short position = positions[i];
            this.f_04903120[i] = position;
            int localX = ChunkSectionPos.unpackLocalX(position);
            int localY = ChunkSectionPos.unpackLocalY(position);
            int localZ = ChunkSectionPos.unpackLocalZ(position);
            stateArray[i] = C_81592558.STATE_IDS.getRawId(section.getBlockState(localX, localY, localZ));
            f_91311726[i] = (byte) section.getMeta(localX, localY, localZ);
        }
    }

    @Override
    public void m_13296744(DataInputStream in) {
        try {
            f_79481286 = in.readInt();
            f_86949888 = in.readInt();
            sectionIndex = in.read();
            f_01960917 = in.read();
            f_04903120 = new short[f_01960917];
            stateArray = new int[f_01960917];
            f_91311726 = new byte[f_01960917];
            for (int i = 0; i < f_01960917; i++) f_04903120[i] = in.readShort();
            for (int i = 0; i < f_01960917; i++) stateArray[i] = in.readInt();
            in.readFully(f_91311726);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_17566769(DataOutputStream out) {
        try {
            out.writeInt(f_79481286);
            out.writeInt(f_86949888);
            out.write(sectionIndex);
            out.write(f_01960917);
            for (short position : f_04903120) out.writeShort(position);
            for (int stateId : stateArray) out.writeInt(stateId);
            out.write(f_91311726);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_04853589(C_10918870 handler) {
        ((StationFlatteningPacketHandler) handler).onMultiBlockChange(this);
    }

    @Override
    public int m_85604015() {
        return 10 + f_01960917 * 7;
    }

    @Override
    public @NotNull PacketType<FlattenedMultiBlockChangeS2CPacket> getType() {
        return TYPE;
    }
}
