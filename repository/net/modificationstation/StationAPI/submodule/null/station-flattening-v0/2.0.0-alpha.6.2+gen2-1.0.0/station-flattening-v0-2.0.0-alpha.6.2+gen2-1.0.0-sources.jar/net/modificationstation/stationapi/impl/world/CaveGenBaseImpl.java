package net.modificationstation.stationapi.impl.world;

import net.minecraft.unmapped.C_64041439;

public interface CaveGenBaseImpl {
    void stationapi_setWorld(C_64041439 world);

    C_64041439 stationapi_getWorld();
}
