package net.modificationstation.stationapi.mixin.flattening.client.stats;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import it.unimi.dsi.fastutil.objects.Reference2IntMap;
import it.unimi.dsi.fastutil.objects.Reference2IntOpenHashMap;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_89105241;
import net.minecraft.unmapped.C_95106612;
import net.modificationstation.stationapi.api.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(targets = {
        "net.minecraft.client.gui.screen.StatsScreen$AbstractStatsListWidget",
        "net.minecraft.client.gui.screen.StatsScreen$BlockStatsListWidget"
})
class BlockItemFormTranslationMixin {
    @Unique
    private final Reference2IntMap<C_89105241> stationapi_idCache = Util.make(
            new Reference2IntOpenHashMap<>(),
            map -> map.defaultReturnValue(-1)
    );

    @WrapOperation(
            method = "*",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/stat/ItemOrBlockStat;getItemOrBlockId()I"
            ),
            require = 0
    )
    private int stationapi_translateToBlockItemForm(C_89105241 instance, Operation<Integer> original) {
        var cachedId = stationapi_idCache.getInt(instance);
        if (cachedId > -1)
            return cachedId;

        int id = original.call(instance);
        if (C_95106612.f_65452341.contains(instance)) {
            var item = C_81592558.f_44428008[id].asItem();
            if (item != null)
                id = item.f_57562535;
        }

        stationapi_idCache.put(instance, id);
        return id;
    }
}
