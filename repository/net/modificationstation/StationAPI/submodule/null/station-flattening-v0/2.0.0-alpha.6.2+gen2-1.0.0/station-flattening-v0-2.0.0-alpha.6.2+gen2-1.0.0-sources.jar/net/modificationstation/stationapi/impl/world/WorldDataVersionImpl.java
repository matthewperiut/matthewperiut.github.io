package net.modificationstation.stationapi.impl.world;

import com.google.common.collect.Iterators;
import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_97075175;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.world.WorldPropertiesEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.nbt.NbtHelper;
import net.modificationstation.stationapi.mixin.nbt.NbtCompoundAccessor;

import java.lang.invoke.MethodHandles;
import java.util.Map;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class WorldDataVersionImpl {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void addDataVersions(WorldPropertiesEvent.Save event) {
        Map.Entry<String, ? extends C_97075175> entry = Iterators.getOnlyElement(((NbtCompoundAccessor) NbtHelper.addDataVersions(new C_74087615())).stationapi$getEntries().entrySet().iterator());
        event.nbt.m_21770494(entry.getKey(), entry.getValue());
    }
}
