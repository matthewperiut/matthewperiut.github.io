package net.modificationstation.stationapi.api.item;

import it.unimi.dsi.fastutil.objects.Reference2ReferenceOpenHashMap;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.registry.RegistryEntry;
import net.modificationstation.stationapi.api.registry.RemappableRawIdHolder;
import net.modificationstation.stationapi.api.util.Util;
import org.jetbrains.annotations.ApiStatus;

import java.util.Map;

public interface StationFlatteningItem extends RemappableRawIdHolder, ItemConvertible, ItemStrengthWithBlockState {

    Map<C_81592558, C_98888256> BLOCK_ITEMS = new Reference2ReferenceOpenHashMap<>();

    @Override
    @ApiStatus.Internal
    default void setRawId(int rawId) {
        Util.assertImpl();
    }

    @Override
    default C_98888256 asItem() {
        return Util.assertImpl();
    }

    default RegistryEntry.Reference<C_98888256> getRegistryEntry() {
        return Util.assertImpl();
    }

    @Override
    default boolean isSuitableFor(C_40996800 player, C_88708284 itemStack, C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return Util.assertImpl();
    }

    @Override
    default float getMiningSpeedMultiplier(C_40996800 player, C_88708284 itemStack, C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return Util.assertImpl();
    }
}
