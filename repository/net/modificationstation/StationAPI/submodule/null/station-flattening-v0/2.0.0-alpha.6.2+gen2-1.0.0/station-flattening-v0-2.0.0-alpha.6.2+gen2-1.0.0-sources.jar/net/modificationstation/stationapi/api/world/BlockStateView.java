package net.modificationstation.stationapi.api.world;

import net.minecraft.unmapped.C_32594356;
import net.modificationstation.stationapi.api.block.BlockState;

public interface BlockStateView {

    BlockState getBlockState(int x, int y, int z);

    default BlockState getBlockState(C_32594356 pos) {
        return getBlockState(pos.getX(), pos.getY(), pos.getZ());
    }
}
