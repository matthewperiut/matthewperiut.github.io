package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_90532916;
import net.modificationstation.stationapi.api.world.dimension.StationDimension;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(C_90532916.class)
class DimensionMixin implements StationDimension {}
