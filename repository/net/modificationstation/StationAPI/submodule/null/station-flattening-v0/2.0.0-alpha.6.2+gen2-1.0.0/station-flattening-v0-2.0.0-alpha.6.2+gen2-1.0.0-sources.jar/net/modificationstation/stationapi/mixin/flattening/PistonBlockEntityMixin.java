package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_98403025;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.block.entity.StationFlatteningPistonBlockEntity;
import net.modificationstation.stationapi.api.nbt.FlatteningNbtHelper;
import net.modificationstation.stationapi.api.registry.BlockRegistry;
import net.modificationstation.stationapi.impl.block.StationFlatteningPistonBlockEntityImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_98403025.class)
class PistonBlockEntityMixin implements StationFlatteningPistonBlockEntity, StationFlatteningPistonBlockEntityImpl {
    @Unique
    private BlockState stationapi_pushedBlockState;

    @SuppressWarnings("AddedMixinMembersNamePattern")
    @Override
    @Unique
    public BlockState getPushedBlockState() {
        return stationapi_pushedBlockState;
    }

    @Override
    @Unique
    public void stationapi_setPushedBlockState(BlockState pushedBlockState) {
        stationapi_pushedBlockState = pushedBlockState;
    }

    @Redirect(
            method = {
                    "finish",
                    "tick"
            },
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/World;setBlock(IIIII)Z"
            )
    )
    private boolean stationapi_setPushedBlockState(C_64041439 world, int x, int y, int z, int blockId, int blockMeta) {
        return world.setBlockState(x, y, z, stationapi_pushedBlockState, blockMeta) != null;
    }

    @Redirect(
            method = "readNbt",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/nbt/NbtCompound;getInt(Ljava/lang/String;)I",
                    ordinal = 0
            )
    )
    private int stationapi_readPushedBlockState(C_74087615 nbt, String tag) {
        stationapi_pushedBlockState = FlatteningNbtHelper.toBlockState(BlockRegistry.INSTANCE.getReadOnlyWrapper(), nbt.m_81819352("blockState"));
        return stationapi_pushedBlockState.getBlock().f_84602679;
    }

    @Redirect(
            method = "writeNbt",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/nbt/NbtCompound;putInt(Ljava/lang/String;I)V",
                    ordinal = 0
            )
    )
    private void stationapi_writePushedBlockState(C_74087615 nbt, String tag, int value) {
        nbt.m_18682924("blockState", FlatteningNbtHelper.fromBlockState(stationapi_pushedBlockState));
    }
}
