package net.modificationstation.stationapi.mixin.flattening;

import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.impl.world.StationWorldProperties;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;
import static net.modificationstation.stationapi.api.util.Identifier.of;

import net.minecraft.unmapped.C_64676926;
import net.minecraft.unmapped.C_74087615;

@Mixin(C_64676926.class)
class WorldPropertiesMixin implements StationWorldProperties {
    @Unique private static final String STATIONAPI$DIMENSIONS_KEY = of(NAMESPACE, "dimensions").toString();
    @Unique private static C_74087615 stationapi_dimensionsRoot;

    @Inject(
            method = "<init>(Lnet/minecraft/nbt/NbtCompound;)V",
            at = @At("TAIL")
    )
    private void stationapi_onPropertiesLoad(C_74087615 worldTag, CallbackInfo info) {
        stationapi_dimensionsRoot = worldTag.m_81819352(STATIONAPI$DIMENSIONS_KEY);
    }

    @Inject(
            method = "<init>(JLjava/lang/String;)V",
            at = @At("TAIL")
    )
    private void stationapi_onPropertiesCreate(long seed, String name, CallbackInfo info) {
        stationapi_dimensionsRoot = new C_74087615();
    }

    @Inject(
            method = "updateProperties",
            at = @At("HEAD")
    )
    private void stationapi_updateProperties(C_74087615 worldTag, C_74087615 playerTag, CallbackInfo ci) {
        worldTag.m_18682924(STATIONAPI$DIMENSIONS_KEY, stationapi_dimensionsRoot);
    }

    @Override
    @Unique
    public C_74087615 getDimensionTag(Identifier id) {
        String key = id.toString();
        if (stationapi_dimensionsRoot.m_97612750(key)) {
            return stationapi_dimensionsRoot.m_81819352(key);
        }
        else {
            C_74087615 tag = new C_74087615();
            stationapi_dimensionsRoot.m_18682924(key, tag);
            return tag;
        }
    }
}
