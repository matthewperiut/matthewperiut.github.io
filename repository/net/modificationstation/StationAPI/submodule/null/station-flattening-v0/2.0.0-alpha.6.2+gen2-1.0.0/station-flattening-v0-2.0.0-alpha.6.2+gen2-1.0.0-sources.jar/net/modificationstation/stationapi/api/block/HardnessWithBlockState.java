package net.modificationstation.stationapi.api.block;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46108969;

public interface HardnessWithBlockState {

    float getHardness(BlockState state, C_46108969 blockView, C_32594356 pos);

    float calcBlockBreakingDelta(BlockState state, C_40996800 player, C_46108969 world, C_32594356 pos);
}
