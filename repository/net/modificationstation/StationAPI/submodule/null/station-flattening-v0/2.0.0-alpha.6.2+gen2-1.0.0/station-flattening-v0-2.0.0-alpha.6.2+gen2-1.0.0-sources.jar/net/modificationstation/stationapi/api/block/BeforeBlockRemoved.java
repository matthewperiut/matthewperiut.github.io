package net.modificationstation.stationapi.api.block;

import net.minecraft.unmapped.C_64041439;

@FunctionalInterface
public interface BeforeBlockRemoved {

    void beforeBlockRemoved(C_64041439 arg, int i, int j, int k);
}
