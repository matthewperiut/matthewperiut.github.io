package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.entity.player.StationFlatteningPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_40996800.class)
abstract class PlayerEntityMixin extends C_74425583 implements StationFlatteningPlayerEntity {
    @Shadow public C_87542771 inventory;

    private PlayerEntityMixin(C_64041439 arg) {
        super(arg);
    }

    @Override
    @Unique
    public boolean canHarvest(C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return inventory.canHarvest(blockView, blockPos, state);
    }

    @Override
    @Unique
    public float getBlockBreakingSpeed(C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        float f = inventory.getBlockBreakingSpeed(blockView, blockPos, state);
        if (m_52586232(C_89604096.f_99458234)) f /= 5.0f;
        if (!f_47825615) f /= 5.0f;
        return f;
    }
}
