package net.modificationstation.stationapi.api.event.block;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.mine_diver.unsafeevents.event.Cancelable;
import net.mine_diver.unsafeevents.event.EventPhases;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.util.math.Direction;

import java.util.function.BooleanSupplier;

@SuperBuilder
public abstract class BlockEvent extends Event {
    public final C_81592558 block;

    @SuperBuilder
    public static final class TranslationKeyChanged extends BlockEvent {
        public String currentTranslationKey;
    }

    @Cancelable
    @SuperBuilder
    @EventPhases(StationAPI.INTERNAL_PHASE)
    public static final class BeforeRemoved extends BlockEvent {
        public final C_64041439 world;
        public final int x, y, z;
    }

    @Cancelable
    @SuperBuilder
    public static final class BeforeDrop extends BlockEvent {
        public final C_64041439 world;
        public final int x, y, z, meta;
        public final float chance;
    }

    @SuperBuilder
    @EventPhases(StationAPI.INTERNAL_PHASE)
    public static final class BeforePlacedByItem extends BlockEvent {
        public final C_64041439 world;
        public final C_40996800 player;
        public final int x, y, z, meta;
        public final Direction side;
        public final C_88708284 blockItem;
        public BooleanSupplier placeFunction;
    }
}
