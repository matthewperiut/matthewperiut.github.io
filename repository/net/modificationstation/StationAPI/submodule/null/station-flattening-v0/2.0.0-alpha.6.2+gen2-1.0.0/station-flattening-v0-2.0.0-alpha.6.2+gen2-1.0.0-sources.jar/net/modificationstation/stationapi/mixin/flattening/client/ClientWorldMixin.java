package net.modificationstation.stationapi.mixin.flattening.client;

import net.minecraft.unmapped.C_08489468;
import net.minecraft.unmapped.C_34399650;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88014908;
import net.minecraft.unmapped.C_90532916;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.network.ModdedPacketHandler;
import net.modificationstation.stationapi.impl.client.world.ClientBlockChange;
import net.modificationstation.stationapi.impl.world.StationClientWorld;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.LinkedList;

@Mixin(C_34399650.class)
abstract class ClientWorldMixin extends C_64041439 implements StationClientWorld {
    @Unique boolean isModded = false;

    @Shadow private LinkedList blockResets;

    private ClientWorldMixin(C_08489468 arg, String string, C_90532916 arg2, long l) {
        super(arg, string, arg2, l);
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    void mpCrashWorkaround(C_88014908 handler, long l, int i, CallbackInfo ci) {
        isModded = ((ModdedPacketHandler) handler).isModded();
    }

    @Override
    public boolean stationAPI$isModded() {
        return isModded;
    }

    @ModifyConstant(method = "updateChunk(IIZ)V", constant = @Constant(intValue = 0))
    private int stationapi_changeMinHeight(int value) {
        return getBottomY();
    }

    @ModifyConstant(method = "updateChunk(IIZ)V", constant = @Constant(intValue = 128))
    private int stationapi_changeMaxHeight(int value) {
        return getTopY();
    }

    @Redirect(
            method = {
                    "setBlockMetaWithoutNotifyingNeighbors",
                    "setBlockWithoutNotifyingNeighbors(IIIII)Z",
                    "setBlockWithoutNotifyingNeighbors(IIII)Z"
            },
            at = @At(
                    value = "NEW",
                    target = "(Lnet/minecraft/world/ClientWorld;IIIII)Lnet/minecraft/world/ClientWorld$BlockReset;"
            )
    )
    private C_34399650.net/minecraft/unmapped/C_88323698 stationapi_storeBlockState(C_34399650 world, int x, int y, int z, int blockId, int metadata) {
        return new ClientBlockChange(world, x, y, z, world.getBlockState(x, y, z), metadata);
    }

    @Inject(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/World;setBlockWithoutNotifyingNeighbors(IIIII)Z"
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void stationapi_captureClientBlockChange(CallbackInfo ci, int var1, int var2, C_34399650.net/minecraft/unmapped/C_88323698 var3) {
        stationapi_clientBlockChange = var3;
    }

    @Unique
    private C_34399650.net/minecraft/unmapped/C_88323698 stationapi_clientBlockChange;

    @Redirect(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/World;setBlockWithoutNotifyingNeighbors(IIIII)Z"
            )
    )
    private boolean stationapi_useBlockState(C_64041439 instance, int x, int y, int z, int blockId, int metadata) {
        boolean result = super.setBlockStateWithoutNotifyingNeighbors(x, y, z, C_81592558.STATE_IDS.get(((ClientBlockChange) stationapi_clientBlockChange).stateId), metadata) != null;
        stationapi_clientBlockChange = null;
        return result;
    }

    @Override
    @Unique
    public BlockState setBlockState(int x, int y, int z, BlockState blockState) {
        BlockState n = this.getBlockState(x, y, z);
        int n2 = this.m_06541281(x, y, z);
        BlockState result = super.setBlockStateWithoutNotifyingNeighbors(x, y, z, blockState);
        if (result != null) {
            //noinspection unchecked,DataFlowIssue
            this.blockResets.add(new ClientBlockChange((C_34399650) (Object) this, x, y, z, n, n2));
        }
        return result;
    }
}
