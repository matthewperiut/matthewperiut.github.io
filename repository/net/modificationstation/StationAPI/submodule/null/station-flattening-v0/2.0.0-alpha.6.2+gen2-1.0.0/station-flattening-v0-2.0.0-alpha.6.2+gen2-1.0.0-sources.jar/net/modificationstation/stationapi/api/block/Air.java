package net.modificationstation.stationapi.api.block;

import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_89604096;
import net.minecraft.unmapped.C_94584382;
import net.modificationstation.stationapi.api.item.ItemPlacementContext;

import java.util.Random;

import static net.modificationstation.stationapi.api.util.Identifier.of;

final class Air extends C_81592558 {

    Air(int id) {
        super(id, C_89604096.f_74758574);
        m_85502623(0);
        m_61390596(0);
        m_73813284(C_81592558.f_65207438);
        m_73501903(of("air").toString());
        m_28617694();
        m_28432292();
    }

    @Override
    public boolean m_76696200() {
        return false;
    }

    @Override
    public boolean m_28922194(C_46108969 tileView, int x, int y, int z, int side) {
        return false;
    }

    @Override
    public C_82690114 m_25332652(C_64041439 world, int x, int y, int z) {
        return null;
    }

    @Override
    public C_82690114 m_03092609(C_64041439 world, int x, int y, int z) {
        return null;
    }

    @Override
    public boolean m_57757663() {
        return false;
    }

    @Override
    public boolean m_73649196(int meta, boolean flag) {
        return false;
    }

    @Override
    public int m_23574716(Random rand) {
        return 0;
    }

    @Override
    public C_24654288 m_18909995(C_64041439 arg, int x, int y, int z, C_94584382 arg1, C_94584382 arg2) {
        return null;
    }

    @Override
    public boolean canReplace(BlockState state, ItemPlacementContext context) {
        return true;
    }
}
