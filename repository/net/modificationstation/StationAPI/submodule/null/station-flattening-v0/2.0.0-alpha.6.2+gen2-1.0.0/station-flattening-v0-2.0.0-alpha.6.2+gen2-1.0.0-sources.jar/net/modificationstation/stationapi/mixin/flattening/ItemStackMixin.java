package net.modificationstation.stationapi.mixin.flattening;

import lombok.val;
import net.mine_diver.unsafeevents.listener.Listener;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.event.registry.RegistryIdRemapEvent;
import net.modificationstation.stationapi.api.item.StationFlatteningItemStack;
import net.modificationstation.stationapi.api.registry.ItemRegistry;
import net.modificationstation.stationapi.api.registry.RegistryEntry;
import net.modificationstation.stationapi.api.util.Util;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Collections;
import java.util.Objects;
import java.util.Set;
import java.util.WeakHashMap;

import static net.modificationstation.stationapi.api.StationAPI.LOGGER;
import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;
import static net.modificationstation.stationapi.api.util.Identifier.of;

@Mixin(C_88708284.class)
abstract class ItemStackMixin implements StationFlatteningItemStack {
    @Shadow public int itemId;

    @Shadow public abstract C_98888256 getItem();

    @Unique
    private static final String STATION_ID = of(NAMESPACE, "id").toString();

    @Unique
    private static final Set<C_88708284> STATION_ITEM_STACKS = Util.make(
            Collections.newSetFromMap(new WeakHashMap<>()),
            stacks -> ItemRegistry.INSTANCE.getEventBus().register(Listener.<RegistryIdRemapEvent<ItemRegistry>>simple()
                    .listener(event -> {
                        val remap = event.state.getRawIdChangeMap();
                        stacks.forEach(
                                stack -> stack.f_59294634 = remap.getOrDefault(stack.f_59294634, stack.f_59294634)
                        );
                    })
                    .build()
    ));
    
    @Inject(
            method = "<init>(Lnet/minecraft/block/Block;)V",
            at = @At("TAIL")
    )
    private void stationapi_onInitFromBlock(C_81592558 block, CallbackInfo info) {
        C_98888256 item = block.asItem();
        if (item != null) {
            this.itemId = item.f_57562535;
        }
    }
    
    @Inject(
            method = "<init>(Lnet/minecraft/block/Block;I)V",
            at = @At("TAIL")
    )
    private void stationapi_onInitFromBlock(C_81592558 block, int count, CallbackInfo info) {
        C_98888256 item = block.asItem();
        if (item != null) {
            this.itemId = item.f_57562535;
        }
    }
    
    @Inject(
            method = "<init>(Lnet/minecraft/block/Block;II)V",
            at = @At("TAIL")
    )
    private void stationapi_onInitFromBlock(C_81592558 block, int count, int meta, CallbackInfo info) {
        C_98888256 item = block.asItem();
        if (item != null) {
            this.itemId = item.f_57562535;
        }
    }

    @Redirect(
            method = "writeNbt",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/nbt/NbtCompound;putShort(Ljava/lang/String;S)V",
                    ordinal = 0
            )
    )
    private void stationapi_saveIdentifier(C_74087615 instance, String item, short i) {
        instance.m_91017064(STATION_ID, ItemRegistry.INSTANCE.getId(itemId).orElseThrow().toString());
    }

    @Inject(
            method = "readNbt",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;itemId:I",
                    opcode = Opcodes.PUTFIELD,
                    shift = At.Shift.AFTER
            )
    )
    private void stationapi_loadIdentifier(C_74087615 par1, CallbackInfo ci) {
        String id = par1.m_47517355(STATION_ID);
        if (id.isEmpty())
            LOGGER.warn("Attempted to load an item stack without Station Flattening ID! StationAPI will ignore this and accept the vanilla ID (" + itemId + "), but this should have been handled by DFU beforehand");
        else itemId = Objects.requireNonNull(ItemRegistry.INSTANCE.get(of(id))).f_57562535;
    }

    @Override
    @Unique
    public RegistryEntry.Reference<C_98888256> getRegistryEntry() {
        return getItem().getRegistryEntry();
    }

    @Override
    @Unique
    public boolean isSuitableFor(C_40996800 player, C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return getItem().isSuitableFor(player, C_88708284.class.cast(this), blockView, blockPos, state);
    }

    @Override
    @Unique
    public float getMiningSpeedMultiplier(C_40996800 player, C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return getItem().getMiningSpeedMultiplier(player, C_88708284.class.cast(this), blockView, blockPos, state);
    }

    @Override
    @Unique
    public boolean isOf(C_98888256 item) {
        return this.getItem() == item;
    }

    @Inject(
            method = {
                    "<init>(III)V",
                    "<init>(Lnet/minecraft/nbt/NbtCompound;)V"
            },
            at = @At("RETURN")
    )
    private void stationapi_trackItemStack(CallbackInfo ci) {
        STATION_ITEM_STACKS.add((C_88708284) (Object) this);
    }
}
