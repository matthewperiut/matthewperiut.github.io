package net.modificationstation.stationapi.mixin.flattening.client;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_30731159;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_97313606;
import net.modificationstation.stationapi.api.network.ModdedPacketHandler;
import net.modificationstation.stationapi.impl.world.StationClientWorld;
import net.modificationstation.stationapi.impl.world.chunk.FlattenedChunk;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;

@Mixin(C_30731159.class)
class MultiplayerChunkCacheMixin {
    @Shadow private Map<C_97313606, C_14917579> chunksByPos;

    @Shadow private C_64041439 world;

    @Inject(
            method = "loadChunk",
            at = @At("HEAD"),
            cancellable = true
    )
    public void stationapi_loadChunk(int i, int j, CallbackInfoReturnable<C_14917579> cir) {
        if (!((StationClientWorld) world).stationAPI$isModded())
            return;
        C_97313606 vec2i = new C_97313606(i, j);
        FlattenedChunk chunk = new FlattenedChunk(this.world, i, j);
        this.chunksByPos.put(vec2i, chunk);
        chunk.f_20966510 = true;
        cir.setReturnValue(chunk);
    }
}
