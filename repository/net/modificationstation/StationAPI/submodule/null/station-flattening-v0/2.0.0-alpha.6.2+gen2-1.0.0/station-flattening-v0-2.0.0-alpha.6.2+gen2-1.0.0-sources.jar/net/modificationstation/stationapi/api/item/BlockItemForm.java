package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_71827890;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.registry.ItemRegistry;

import java.util.Map;
import java.util.function.Supplier;

public interface BlockItemForm {

    static C_71827890 of(C_81592558 block) {
        return of(() -> new C_71827890(ItemRegistry.SHIFTED_ID.get(-1)), block);
    }

    static <T extends C_71827890> T of(Supplier<T> blockItemFactory, C_81592558 block) {
        T blockItem = blockItemFactory.get();
        blockItem.setBlock(block);
        return blockItem;
    }

    C_81592558 getBlock();

    default void appendBlocks(Map<C_81592558, C_98888256> blockItems, C_98888256 blockItem) {
        blockItems.put(getBlock(), blockItem);
    }
}
