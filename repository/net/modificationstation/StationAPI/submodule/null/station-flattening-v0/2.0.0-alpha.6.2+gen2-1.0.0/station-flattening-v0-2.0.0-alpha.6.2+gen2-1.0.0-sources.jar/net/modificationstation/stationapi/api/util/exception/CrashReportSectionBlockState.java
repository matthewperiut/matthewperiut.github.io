package net.modificationstation.stationapi.api.util.exception;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_46108969;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.util.crash.CrashReportSection;
import org.jetbrains.annotations.Nullable;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class CrashReportSectionBlockState {

    public static void addBlockInfo(CrashReportSection element, C_46108969 world, C_32594356 pos, @Nullable BlockState state) {
        if (state != null) {
            element.add("Block", state::toString);
        }
        element.add("Block location", () -> CrashReportSection.createPositionString(world, pos));
    }
}
