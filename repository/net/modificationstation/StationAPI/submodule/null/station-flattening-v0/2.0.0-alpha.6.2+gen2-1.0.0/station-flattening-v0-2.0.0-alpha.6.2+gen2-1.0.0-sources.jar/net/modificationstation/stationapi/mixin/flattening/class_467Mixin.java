package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_87391831;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(C_87391831.class)
class class_467Mixin {
    @ModifyConstant(
            method = {
                    "teleportToValidPortal",
                    "createPortal"
            },
            constant = @Constant(intValue = 127)
    )
    private int stationapi_changeInclusiveTopY(int constant, C_64041439 world, C_42232651 entity) {
        return world.getTopY() - 1;
    }

    @ModifyConstant(
            method = {
                    "teleportToValidPortal",
                    "createPortal"
            },
            constant = @Constant(
                    expandZeroConditions = Constant.Condition.LESS_THAN_ZERO,
                    ordinal = 0
            )
    )
    private int stationapi_changeBottomY1(int constant, C_64041439 world, C_42232651 entity) {
        return world.getBottomY();
    }

    @ModifyConstant(
            method = "createPortal",
            constant = @Constant(
                    expandZeroConditions = Constant.Condition.LESS_THAN_ZERO,
                    ordinal = 3
            )
    )
    private int stationapi_changeBottomY2(int constant, C_64041439 world, C_42232651 entity) {
        return world.getBottomY();
    }

    @ModifyConstant(
            method = "createPortal",
            constant = @Constant(intValue = 70)
    )
    private int stationapi_changeNearMidY(int constant, C_64041439 world, C_42232651 entity) {
        int topY = world.getTopY();
        return topY > constant + 10 ? constant : topY >> 1;
    }

    @ModifyConstant(
            method = "createPortal",
            constant = @Constant(intValue = 118)
    )
    private int stationapi_changeNearTopY(int constant, C_64041439 world, C_42232651 entity) {
        return world.getTopY() - 10;
    }
}
