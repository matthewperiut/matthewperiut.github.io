package net.modificationstation.stationapi.api.block;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.item.ItemConvertible;
import net.modificationstation.stationapi.api.item.ItemPlacementContext;
import net.modificationstation.stationapi.api.registry.RegistryEntry;
import net.modificationstation.stationapi.api.registry.RemappableRawIdHolder;
import net.modificationstation.stationapi.api.state.StateManager;
import net.modificationstation.stationapi.api.util.Util;
import net.modificationstation.stationapi.api.util.collection.IdList;
import org.jetbrains.annotations.ApiStatus;

import java.util.List;
import java.util.function.ToIntFunction;

public interface StationFlatteningBlock extends
        RemappableRawIdHolder,
        ItemConvertible,
        BlockStateHolder,
        DropWithBlockState,
        DropListProvider,
        AfterBreakWithBlockState,
        HardnessWithBlockState,
        ReplaceableBlock
{

    IdList<BlockState> STATE_IDS = new IdList();

    @Override
    @ApiStatus.Internal
    default void setRawId(int rawId) {
        Util.assertImpl();
    }

    default RegistryEntry.Reference<C_81592558> getRegistryEntry() {
        return Util.assertImpl();
    }

    @Override
    default C_98888256 asItem() {
        return Util.assertImpl();
    }

    @Override
    default StateManager<C_81592558, BlockState> getStateManager() {
        return Util.assertImpl();
    }

    @Override
    default BlockState getDefaultState() {
        return Util.assertImpl();
    }

    @Override
    default void appendProperties(StateManager.Builder<C_81592558, BlockState> builder) {
        Util.assertImpl();
    }

    @Override
    default void setDefaultState(BlockState state) {
        Util.assertImpl();
    }

    @Override
    default void afterBreak(C_64041439 world, C_40996800 player, int x, int y, int z, BlockState state, int meta) {
        Util.assertImpl();
    }

    @Override
    default List<C_88708284> getDropList(C_64041439 world, int x, int y, int z, BlockState state, int meta) {
        return Util.assertImpl();
    }

    @Override
    default void dropWithChance(C_64041439 world, int x, int y, int z, BlockState state, int meta, float chance) {
        Util.assertImpl();
    }

    @Override
    default float getHardness(BlockState state, C_46108969 blockView, C_32594356 pos) {
        return Util.assertImpl();
    }

    @Override
    default float calcBlockBreakingDelta(BlockState state, C_40996800 player, C_46108969 world, C_32594356 pos) {
        return Util.assertImpl();
    }

    default BlockState getPlacementState(ItemPlacementContext context) {
        return getDefaultState();
    }

    @Override
    default boolean canReplace(BlockState state, ItemPlacementContext context) {
        return Util.assertImpl();
    }

    default void onBlockPlaced(C_64041439 world, int x, int y, int z, BlockState replacedState) {
        Util.assertImpl();
    }

    default C_81592558 setLuminance(ToIntFunction<BlockState> provider) {
        return Util.assertImpl();
    }

    default void onStateReplaced(BlockState state, C_64041439 world, C_32594356 pos, BlockState newState) {
        Util.assertImpl();
    }
}
