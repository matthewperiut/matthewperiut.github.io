package net.modificationstation.stationapi.api.block;

import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;

public interface AfterBreakWithBlockState {

    void afterBreak(C_64041439 world, C_40996800 player, int x, int y, int z, BlockState state, int meta);
}
