package net.modificationstation.stationapi.impl.world.chunk;

import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_59053975;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_64676926;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_97075175;
import net.minecraft.unmapped.C_99656780;
import net.modificationstation.stationapi.api.datafixer.TypeReferences;
import net.modificationstation.stationapi.api.nbt.NbtHelper;
import net.modificationstation.stationapi.impl.world.FlattenedWorldManager;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;

import static net.modificationstation.stationapi.impl.world.FlattenedWorldManager.SECTIONS;

public class FlattenedWorldChunkLoader implements C_99656780 {

    protected final File dimFolder;

    public FlattenedWorldChunkLoader(File dimFolder) {
        this.dimFolder = dimFolder;
    }

    @Override
    public C_14917579 m_46119045(C_64041439 arg, int i, int j) throws IOException {
        DataInputStream dataInputStream = C_59053975.m_25811662(dimFolder, i, j);
        if (dataInputStream == null)
            return null;
        C_74087615 compoundTag = C_08565163.m_07155133(dataInputStream);
        if (!compoundTag.m_97612750("Level")) {
            System.out.println("Chunk file at " + i + "," + j + " is missing level data, skipping");
            return null;
        }
        compoundTag = NbtHelper.update(TypeReferences.CHUNK, compoundTag);
        if (!compoundTag.m_81819352("Level").m_97612750(SECTIONS)) {
            System.out.println("Chunk file at " + i + "," + j + " is missing section data, skipping");
            return null;
        }
        C_14917579 chunk = FlattenedWorldManager.loadChunk(arg, compoundTag.m_81819352("Level"));
        if (!chunk.m_64564568(i, j)) {
            System.out.println("Chunk file at " + i + "," + j + " is in the wrong location; relocating. (Expected " + i + ", " + j + ", got " + chunk.f_61945954 + ", " + chunk.f_46577147 + ")");
            compoundTag.m_20318863("xPos", i);
            compoundTag.m_20318863("zPos", j);
            chunk = FlattenedWorldManager.loadChunk(arg, compoundTag.m_81819352("Level"));
        }
        chunk.m_02358196();
        return chunk;
    }

    @Override
    public void m_65663774(C_64041439 world, C_14917579 oldChunk) throws IOException {
        if (!(oldChunk instanceof FlattenedChunk chunk)) throw new IllegalStateException(getClass().getSimpleName() + " can't save chunk of type \"" + oldChunk.getClass().getName() + "\"!");
        world.m_75538572();
        DataOutputStream dataOutputStream = C_59053975.m_20142597(dimFolder, chunk.f_61945954, chunk.f_46577147);
        C_74087615 compoundTag = new C_74087615();
        C_74087615 compoundTag2 = new C_74087615();
        compoundTag.m_21770494("Level", (C_97075175) compoundTag2);
        FlattenedWorldManager.saveChunk(chunk, world, compoundTag2);
        compoundTag = NbtHelper.addDataVersions(compoundTag);
        C_08565163.m_94300398(compoundTag, dataOutputStream);
        try {
            dataOutputStream.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        C_64676926 worldProperties = world.m_67440400();
        worldProperties.m_87736952(worldProperties.m_58203330() + (long) C_59053975.m_39379585(dimFolder, chunk.f_61945954, chunk.f_46577147));
    }

    @Override
    public void m_82632767(C_64041439 arg, C_14917579 arg2) {}

    @Override
    public void m_53385649() {}

    @Override
    public void m_69790753() {}
}
