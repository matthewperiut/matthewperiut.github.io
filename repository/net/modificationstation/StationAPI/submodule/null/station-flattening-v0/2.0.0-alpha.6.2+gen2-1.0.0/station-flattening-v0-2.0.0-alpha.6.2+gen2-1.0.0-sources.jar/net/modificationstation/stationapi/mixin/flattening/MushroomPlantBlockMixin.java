package net.modificationstation.stationapi.mixin.flattening;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_90574280;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(C_90574280.class)
class MushroomPlantBlockMixin {
    @ModifyConstant(
            method = "canGrow",
            constant = @Constant(expandZeroConditions = Constant.Condition.LESS_THAN_ZERO)
    )
    private int stationapi_changeBottomYCheck(
            int constant,
            @Local(index = 1, argsOnly = true) C_64041439 world
    ) {
        return world.getBottomY();
    }

    @ModifyExpressionValue(
            method = "canGrow",
            at = @At(
                    value = "CONSTANT",
                    args = "intValue=128"
            )
    )
    private int stationapi_changeTopYCheck(
            int original,
            @Local(index = 1, argsOnly = true) C_64041439 world
    ) {
        return world.getTopY();
    }
}
