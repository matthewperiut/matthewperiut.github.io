package net.modificationstation.stationapi.mixin.flattening.client;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_23014920;
import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_29058632;
import net.minecraft.unmapped.C_40735137;
import net.minecraft.unmapped.C_43718703;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_97866173;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.state.property.Property;
import net.modificationstation.stationapi.api.tag.TagKey;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

import java.util.Collection;

@Mixin(C_97866173.class)
abstract class InGameHudMixin extends C_29058632 {
    @Shadow private Minecraft minecraft;

    @Inject(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/lang/Runtime;maxMemory()J",
                    shift = Shift.BEFORE
            ),
            locals = LocalCapture.CAPTURE_FAILSOFT
    )
    private void stationapi_renderHud(float bl, boolean i, int j, int par4, CallbackInfo ci, C_43718703 scaler, int var6, int var7, C_23014920 var8) {
        C_24654288 hit = minecraft.f_81460813;
        int offset = 22;
        if (hit != null && hit.f_92820457 == C_24654288.net/minecraft/unmapped/C_25850426.f_13890456) {
            BlockState state = minecraft.f_26407825.getBlockState(hit.f_79497105, hit.f_09533029, hit.f_04223298);

            String text = "Block: " + state.getBlock().m_72526337();
            m_62884682(var8, text, var6 - var8.m_09235706(text) - 2, offset += 10, 16777215);

            text = "Meta: " + minecraft.f_26407825.m_06541281(hit.f_79497105, hit.f_09533029, hit.f_04223298);
            m_62884682(var8, text, var6 - var8.m_09235706(text) - 2, offset += 10, 16777215);

            Collection<Property<?>> properties = state.getProperties();
            if (!properties.isEmpty()) {
                text = "Properties:";
                m_62884682(var8, text, var6 - var8.m_09235706(text) - 2, offset += 10, 16777215);

                for (Property<?> property : properties) {
                    text = property.getName() + ": " + state.get(property);
                    m_62884682(var8, text, var6 - var8.m_09235706(text) - 2, offset += 10, 14737632);
                }
            }

            Collection<TagKey<C_81592558>> tags = state.streamTags().toList();
            if (!tags.isEmpty()) {
                text = "Tags:";
                m_62884682(var8, text, var6 - var8.m_09235706(text) - 2, offset += 10, 16777215);

                for (TagKey<C_81592558> property : tags) {
                    text = "#" + property.id();
                    m_62884682(var8, text, var6 - var8.m_09235706(text) - 2, offset += 10, 14737632);
                }
            }

            if (FabricLoader.getInstance().isDevelopmentEnvironment()) {
                C_40735137 entity = minecraft.f_26407825.m_40611090(hit.f_79497105, hit.f_09533029, hit.f_04223298);
                if (entity != null) {
                    String className = entity.getClass().getName();
                    text = "Tile Entity: " + className.substring(className.lastIndexOf('.') + 1);
                    m_62884682(var8, text, var6 - var8.m_09235706(text) - 2, offset + 20, 16777215);
                }
            }
        }
    }
}
