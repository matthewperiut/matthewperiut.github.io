package net.modificationstation.stationapi.mixin.flattening.server;

import net.minecraft.unmapped.C_17889813;
import net.minecraft.unmapped.C_40735137;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_17889813.net/minecraft/unmapped/C_38385548.class)
public interface TrackedChunkAccessor {
    @Invoker
    void invokeSendBlockEntityUpdate(C_40735137 tileEntity);
}
