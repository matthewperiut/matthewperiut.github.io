package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_14917579;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_14917579.class)
public interface ChunkAccessor {
    @Invoker
    void invokeLightGaps(int i, int j);
}
