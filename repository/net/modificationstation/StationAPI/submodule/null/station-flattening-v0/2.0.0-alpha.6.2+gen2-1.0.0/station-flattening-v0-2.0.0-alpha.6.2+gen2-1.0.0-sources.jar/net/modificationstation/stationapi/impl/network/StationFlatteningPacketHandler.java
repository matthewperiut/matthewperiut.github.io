package net.modificationstation.stationapi.impl.network;

import net.minecraft.unmapped.C_10918870;
import net.modificationstation.stationapi.impl.packet.FlattenedBlockChangeS2CPacket;
import net.modificationstation.stationapi.impl.packet.FlattenedChunkDataS2CPacket;
import net.modificationstation.stationapi.impl.packet.FlattenedChunkSectionDataS2CPacket;
import net.modificationstation.stationapi.impl.packet.FlattenedMultiBlockChangeS2CPacket;

public abstract class StationFlatteningPacketHandler extends C_10918870 {
    public void onMapChunk(FlattenedChunkDataS2CPacket packet) {
        m_10633301(packet);
    }

    public void onMultiBlockChange(FlattenedMultiBlockChangeS2CPacket arg) {
        m_10633301(arg);
    }

    public void onBlockChange(FlattenedBlockChangeS2CPacket packet) {
        m_10633301(packet);
    }

    public void onChunkSection(FlattenedChunkSectionDataS2CPacket packet) {
        m_10633301(packet);
    }
}
