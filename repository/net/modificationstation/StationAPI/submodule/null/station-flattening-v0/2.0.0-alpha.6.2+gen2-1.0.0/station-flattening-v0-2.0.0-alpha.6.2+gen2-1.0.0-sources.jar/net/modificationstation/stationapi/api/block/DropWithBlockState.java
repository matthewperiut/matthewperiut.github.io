package net.modificationstation.stationapi.api.block;

import net.minecraft.unmapped.C_64041439;

public interface DropWithBlockState {

    default void drop(C_64041439 world, int x, int y, int z, BlockState state, int meta) {
        dropWithChance(world, x, y, z, state, meta, 1);
    }

    void dropWithChance(C_64041439 world, int x, int y, int z, BlockState state, int meta, float chance);
}
