package net.modificationstation.stationapi.api.entity.player;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_46108969;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.util.Util;

public interface StationFlatteningPlayerInventory extends PlayerStrengthWithBlockState {

    @Override
    default boolean canHarvest(C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return Util.assertImpl();
    }

    @Override
    default float getBlockBreakingSpeed(C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return Util.assertImpl();
    }
}
