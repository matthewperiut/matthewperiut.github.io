package net.modificationstation.stationapi.impl.world;

import com.mojang.serialization.Codec;
import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_40735137;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_72103717;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_79370641;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_92766678;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.block.States;
import net.modificationstation.stationapi.api.nbt.NbtOps;
import net.modificationstation.stationapi.impl.world.chunk.ChunkSection;
import net.modificationstation.stationapi.impl.world.chunk.FlattenedChunk;
import net.modificationstation.stationapi.impl.world.chunk.PalettedContainer;

import static net.modificationstation.stationapi.api.StationAPI.LOGGER;
import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;
import static net.modificationstation.stationapi.api.util.Identifier.of;

public class FlattenedWorldManager {

    private static final Codec<PalettedContainer<BlockState>> CODEC = PalettedContainer.createCodec(C_81592558.STATE_IDS, BlockState.CODEC, PalettedContainer.PaletteProvider.BLOCK_STATE, States.AIR.get());
    public static final String SECTIONS = of(NAMESPACE, "sections").toString();
    private static final String METADATA_KEY = "data";
    private static final String SKY_LIGHT_KEY = "sky_light";
    private static final String BLOCK_LIGHT_KEY = "block_light";
    private static final String HEIGHTMAP_KEY = "height_map";
    private static final String HEIGHT_KEY = "y";

    public static void saveChunk(FlattenedChunk chunk, C_64041439 world, C_74087615 chunkTag) {
        world.m_75538572();
        chunkTag.m_20318863("xPos", chunk.f_61945954);
        chunkTag.m_20318863("zPos", chunk.f_46577147);
        chunkTag.m_94086206("LastUpdate", world.m_13949261());
        ChunkSection[] sections = chunk.sections;
        C_79370641 sectionTags = new C_79370641();
        for (int sectionY = world.getBottomSectionCoord(); sectionY < world.getTopSectionCoord() + 2; ++sectionY) {
            int index = world.sectionCoordToIndex(sectionY);
            if (index < 0 || index >= sections.length) continue;
            ChunkSection section = sections[index];
            if (!ChunkSection.isEmpty(section)) {
                C_74087615 sectionTag = new C_74087615();
                sectionTag.m_41884431(HEIGHT_KEY, (byte)sectionY);
                sectionTag.m_21770494("block_states", CODEC.encodeStart(NbtOps.INSTANCE, section.getBlockStateContainer()).getOrThrow());
                sectionTag.m_21770494(METADATA_KEY, section.getMetadataArray().toTag());
                sectionTag.m_21770494(SKY_LIGHT_KEY, section.getLightArray(C_92766678.f_02629467).toTag());
                sectionTag.m_21770494(BLOCK_LIGHT_KEY, section.getLightArray(C_92766678.f_19924308).toTag());
                sectionTags.m_43125067(sectionTag);
            }
        }
        chunkTag.m_21770494(SECTIONS, sectionTags);
        chunkTag.m_06603839(HEIGHTMAP_KEY, chunk.getStoredHeightmap());
        chunkTag.m_11270099("TerrainPopulated", chunk.f_88254484);
        chunk.f_39795280 = false;
        C_79370641 entityTags = new C_79370641();
        for (int i = 0; i < chunk.f_00508683.length; ++i) {
            for (Object object : chunk.f_00508683[i]) {
                chunk.f_39795280 = true;
                C_74087615 entityTag = new C_74087615();
                if (!((C_42232651)object).m_28732435(entityTag)) continue;
                entityTags.m_43125067(entityTag);
            }
        }
        chunkTag.m_21770494("Entities", entityTags);
        C_79370641 tileEntityTags = new C_79370641();
        for (Object object : chunk.f_39463725.values()) {
            C_74087615 tileEntityTag = new C_74087615();
            ((C_40735137)object).m_55164141(tileEntityTag);
            tileEntityTags.m_43125067(tileEntityTag);
        }
        chunkTag.m_21770494("TileEntities", tileEntityTags);
    }

    public static C_14917579 loadChunk(C_64041439 world, C_74087615 chunkTag) {
        int xPos = chunkTag.m_35587574("xPos");
        int zPos = chunkTag.m_35587574("zPos");
        FlattenedChunk chunk = new FlattenedChunk(world, xPos, zPos);
        ChunkSection[] sections = chunk.sections;
        if (chunkTag.m_97612750(SECTIONS)) {
            C_79370641 sectionTags = chunkTag.m_95654166(SECTIONS);
            for (int i = 0; i < sectionTags.m_89439680(); i++) {
                C_74087615 sectionTag = (C_74087615) sectionTags.m_59132367(i);
                int sectionY = sectionTag.m_84056038(HEIGHT_KEY);
                int index = world.sectionCoordToIndex(sectionY);
                if (index < 0 || index >= sections.length) continue;
                PalettedContainer<BlockState> blockStates = sectionTag.m_97612750("block_states") ? CODEC.parse(NbtOps.INSTANCE, sectionTag.m_81819352("block_states")).promotePartial(errorMessage -> logRecoverableError(xPos, zPos, sectionY, errorMessage)).getOrThrow() : new PalettedContainer<>(C_81592558.STATE_IDS, States.AIR.get(), PalettedContainer.PaletteProvider.BLOCK_STATE);
                ChunkSection chunkSection = new ChunkSection(sectionY, blockStates);
                chunkSection.getMetadataArray().copyArray(sectionTag.m_32985640(METADATA_KEY));
                chunkSection.getLightArray(C_92766678.f_02629467).copyArray(sectionTag.m_32985640(SKY_LIGHT_KEY));
                chunkSection.getLightArray(C_92766678.f_19924308).copyArray(sectionTag.m_32985640(BLOCK_LIGHT_KEY));
                sections[index] = chunkSection;
            }
        }
        chunk.loadStoredHeightmap(chunkTag.m_32985640(HEIGHTMAP_KEY));
        chunk.f_88254484 = chunkTag.m_25255788("TerrainPopulated");
        C_79370641 entityTags = chunkTag.m_95654166("Entities");
        if (entityTags != null) {
            for (int i = 0; i < entityTags.m_89439680(); ++i) {
                C_74087615 compoundTag = (C_74087615) entityTags.m_59132367(i);
                C_42232651 object = C_72103717.m_23901323(compoundTag, world);
                chunk.f_39795280 = true;
                if (object == null) continue;
                chunk.m_11127416(object);
            }
        }
        C_79370641 tileEntityTags = chunkTag.m_95654166("TileEntities");
        if (tileEntityTags != null) {
            for (int i = 0; i < tileEntityTags.m_89439680(); ++i) {
                C_74087615 object = (C_74087615) tileEntityTags.m_59132367(i);
                C_40735137 tileEntityBase = C_40735137.m_71831317(object);
                if (tileEntityBase == null) continue;
                chunk.m_12877624(tileEntityBase);
            }
        }
        return chunk;
    }

    private static void logRecoverableError(int chunkX, int chunkZ, int y, String message) {
        LOGGER.error("Recoverable errors when loading section [" + chunkX + ", " + y + ", " + chunkZ + "]: " + message);
    }
}
