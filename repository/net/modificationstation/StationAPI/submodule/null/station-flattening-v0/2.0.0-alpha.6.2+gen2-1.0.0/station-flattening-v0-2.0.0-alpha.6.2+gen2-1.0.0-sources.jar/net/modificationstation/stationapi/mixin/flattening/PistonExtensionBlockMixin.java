package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_34413895;
import net.minecraft.unmapped.C_40735137;
import net.modificationstation.stationapi.impl.block.StationFlatteningMovingPistonImpl;
import net.modificationstation.stationapi.impl.block.StationFlatteningPistonBlockEntityImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_34413895.class)
class PistonExtensionBlockMixin {
    @Inject(
            method = "createPistonBlockEntity",
            at = @At("RETURN")
    )
    private static void stationapi_setPushedBlockState(int blockId, int blockMeta, int k, boolean bl, boolean bl2, CallbackInfoReturnable<C_40735137> cir) {
        ((StationFlatteningPistonBlockEntityImpl) cir.getReturnValue()).stationapi_setPushedBlockState(StationFlatteningMovingPistonImpl.pushedBlockState);
        StationFlatteningMovingPistonImpl.pushedBlockState = null;
    }
}
