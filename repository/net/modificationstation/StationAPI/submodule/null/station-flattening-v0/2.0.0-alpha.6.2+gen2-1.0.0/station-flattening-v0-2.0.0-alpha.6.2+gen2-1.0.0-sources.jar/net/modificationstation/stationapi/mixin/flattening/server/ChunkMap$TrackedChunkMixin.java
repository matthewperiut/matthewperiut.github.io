package net.modificationstation.stationapi.mixin.flattening.server;

import net.minecraft.unmapped.C_17889813;
import net.modificationstation.stationapi.impl.server.network.ChunkSectionTracker;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_17889813.net/minecraft/unmapped/C_38385548.class)
abstract class TrackedChunkMixin {
    @Shadow
    private int chunkX;
    @Shadow
    private int chunkZ;

    @Unique
    private C_17889813 stationapi_chunkMap;

    @Unique
    private ChunkSectionTracker[] stationapi_sectionTrackers;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void stationapi_init(C_17889813 chunkMap, int chunkX, int chunkZ, CallbackInfo ci) {
        this.stationapi_chunkMap = chunkMap;
        this.stationapi_sectionTrackers = new ChunkSectionTracker[chunkMap.m_24200421().countVerticalSections()];
    }

    /**
     * @author mine_diver
     * @reason early version
     */
    @Overwrite
    public void updatePlayerChunks(int x, int y, int z) {
        int sectionIndex = stationapi_chunkMap.m_24200421().getSectionIndex(y);
        if (stationapi_sectionTrackers[sectionIndex] == null)
            //noinspection DataFlowIssue
            stationapi_sectionTrackers[sectionIndex] = new ChunkSectionTracker(stationapi_chunkMap, (C_17889813.net/minecraft/unmapped/C_38385548) (Object) this, chunkX, chunkZ, sectionIndex);
        stationapi_sectionTrackers[sectionIndex].queueUpdate(x, y & 15, z);
    }

    /**
     * @author mine_diver
     * @reason early version
     */
    @Overwrite
    public void updateChunk() {
        for (ChunkSectionTracker sectionTracker : stationapi_sectionTrackers)
            if (sectionTracker != null)
                sectionTracker.sendQueue();
    }
}
