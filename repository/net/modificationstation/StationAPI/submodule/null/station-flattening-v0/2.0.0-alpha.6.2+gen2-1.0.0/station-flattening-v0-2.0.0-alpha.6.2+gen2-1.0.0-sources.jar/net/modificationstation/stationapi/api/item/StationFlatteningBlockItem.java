package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.util.Util;
import org.jetbrains.annotations.ApiStatus;

public interface StationFlatteningBlockItem extends BlockItemForm {

    default C_81592558 getBlock() {
        return Util.assertImpl();
    }

    @ApiStatus.Internal
    default void setBlock(C_81592558 block) {
        Util.assertImpl();
    }
}
