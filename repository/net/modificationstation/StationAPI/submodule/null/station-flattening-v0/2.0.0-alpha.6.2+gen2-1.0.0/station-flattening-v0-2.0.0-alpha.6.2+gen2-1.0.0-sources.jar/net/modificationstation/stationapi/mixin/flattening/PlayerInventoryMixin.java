package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_87542771;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.entity.player.StationFlatteningPlayerInventory;
import net.modificationstation.stationapi.api.event.entity.player.IsPlayerUsingEffectiveToolEvent;
import net.modificationstation.stationapi.api.event.entity.player.PlayerStrengthOnBlockEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_87542771.class)
abstract class PlayerInventoryMixin implements StationFlatteningPlayerInventory {
    @Shadow public C_88708284[] main;

    @Shadow public int selectedSlot;

    @Shadow public abstract C_88708284 getStack(int i);

    @Shadow public C_40996800 player;

    @Override
    @Unique
    public float getBlockBreakingSpeed(C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return StationAPI.EVENT_BUS.post(PlayerStrengthOnBlockEvent.builder()
                .player(player)
                .blockView(blockView)
                .blockPos(blockPos)
                .blockState(state)
                .resultProvider(() -> {
                    float var2 = 1.0F;
                    if (main[selectedSlot] != null)
                        var2 *= main[this.selectedSlot].getMiningSpeedMultiplier(player, blockView, blockPos, state);
                    return var2;
                })
                .build()
        ).resultProvider.getAsFloat();
    }

    @Override
    @Unique
    public boolean canHarvest(C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return StationAPI.EVENT_BUS.post(IsPlayerUsingEffectiveToolEvent.builder()
                .player(player)
                .blockView(blockView)
                .blockPos(blockPos)
                .blockState(state)
                .resultProvider(() -> {
                    if (state.isToolRequired()) {
                        ItemStack var2 = getStack(this.selectedSlot);
                        return var2 != null && var2.isSuitableFor(player, blockView, blockPos, state);
                    } else return true;
                })
                .build()
        ).resultProvider.getAsBoolean();
    }
}
