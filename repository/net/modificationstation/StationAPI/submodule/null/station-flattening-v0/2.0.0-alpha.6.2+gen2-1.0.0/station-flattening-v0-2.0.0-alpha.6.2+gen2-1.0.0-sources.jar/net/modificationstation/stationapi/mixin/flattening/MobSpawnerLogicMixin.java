package net.modificationstation.stationapi.mixin.flattening;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import net.minecraft.unmapped.C_25501528;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_64041439;

@Mixin(C_25501528.class)
class MobSpawnerLogicMixin {
    @Unique private static C_64041439 currentWorld;

    @Inject(
            method = "spawnMonstersAndWakePlayers",
            at = @At("HEAD")
    )
    private static void stationapi_spawnMonstersAndWakePlayers(C_64041439 world, List<?> list, CallbackInfoReturnable<Boolean> info) {
        currentWorld = world;
    }

    @Inject(
            method = "getRandomPosInChunk",
            at = @At("HEAD")
    )
    private static void stationapi_spawnMonstersAndWakePlayers(C_64041439 world, int px, int pz, CallbackInfoReturnable<C_32594356> info) {
        currentWorld = world;
    }

    @ModifyConstant(method = {
            "spawnMonstersAndWakePlayers",
            "getRandomPosInChunk"
    }, constant = @Constant(intValue = 128))
    private static int stationapi_changeMaxHeight(int value) {
        return currentWorld.getHeight();
    }
}
