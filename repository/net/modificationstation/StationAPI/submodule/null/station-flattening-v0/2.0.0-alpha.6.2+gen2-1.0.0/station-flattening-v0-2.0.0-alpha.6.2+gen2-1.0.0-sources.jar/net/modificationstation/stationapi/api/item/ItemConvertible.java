package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_98888256;

/**
 * Represents an object that has an item form.
 */
public interface ItemConvertible {

    /**
     * Gets this object in its item form.
     */
    C_98888256 asItem();
}

