package net.modificationstation.stationapi.mixin.flattening;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

import java.util.Random;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_71582209;

@Mixin(C_71582209.class)
class OakTreeFeatureMixin {
    @ModifyConstant(
            method = "generate",
            constant = @Constant(
                    intValue = 1,
                    ordinal = 1
            )
    )
    private int stationapi_changeBottomYPlus1(int constant, C_64041439 world, Random random, int x, int y, int z) {
        return world.getBottomY() + 1;
    }

    @ModifyConstant(
            method = "generate",
            constant = @Constant(intValue = 128)
    )
    private int stationapi_changeMaxHeight(int constant, C_64041439 world, Random random, int x, int y, int z) {
        return world.getTopY();
    }

    @ModifyConstant(
            method = "generate",
            constant = @Constant(expandZeroConditions = Constant.Condition.LESS_THAN_ZERO)
    )
    private int stationapi_changeBottomYLT(int constant, C_64041439 world, Random random, int x, int y, int z) {
        return world.getBottomY();
    }
}
