package net.modificationstation.stationapi.mixin.flattening.client;

import net.minecraft.unmapped.C_03670941;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.world.BlockStateView;
import net.modificationstation.stationapi.impl.block.BlockBrightness;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value = C_03670941.class, priority = 500)
class BlockRenderManagerMixin {
    @Shadow private C_46108969 blockView;

    @Inject(
            method = "render(Lnet/minecraft/block/Block;III)Z",
            at = @At("HEAD")
    )
    private void stationapi_captureLightEmission(C_81592558 block, int x, int y, int z, CallbackInfoReturnable<Boolean> info) {
        BlockBrightness.light = blockView instanceof BlockStateView stateView ? stateView.getBlockState(x, y, z).getLuminance() : C_81592558.f_31279291[block.f_84602679];
    }
}
