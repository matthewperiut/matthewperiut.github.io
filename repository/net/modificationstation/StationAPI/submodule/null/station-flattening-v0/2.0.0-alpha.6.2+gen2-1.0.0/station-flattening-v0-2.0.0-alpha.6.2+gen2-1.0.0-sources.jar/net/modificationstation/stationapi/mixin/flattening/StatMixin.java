package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_62649600;
import net.modificationstation.stationapi.api.registry.RegistryEntry;
import net.modificationstation.stationapi.api.registry.StatRegistry;
import net.modificationstation.stationapi.api.stat.StationFlatteningStat;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(C_62649600.class)
class StatMixin implements StationFlatteningStat {
    @Mutable
    @Shadow @Final public int id;
    @Unique
    private RegistryEntry.Reference.IntrusiveReserved<C_62649600> stationapi_registryEntry;

    @ModifyVariable(
            method = "<init>(ILjava/lang/String;Lnet/minecraft/stat/StatFormatter;)V",
            index = 1,
            at = @At(
                    value = "CONSTANT",
                    args = "intValue=0",
                    ordinal = 0
            ),
            argsOnly = true
    )
    private int stationapi_ensureCapacity(int rawId) {
        return (stationapi_registryEntry = StatRegistry.INSTANCE.createReservedEntry(rawId, (C_62649600) (Object) this)).reservedRawId();
    }

    @SuppressWarnings("AddedMixinMembersNamePattern")
    @Override
    @Unique
    public void setRawId(int rawId) {
        id = rawId;
    }

    @SuppressWarnings("AddedMixinMembersNamePattern")
    @Override
    public RegistryEntry.Reference<C_62649600> getRegistryEntry() {
        return stationapi_registryEntry;
    }
}