package net.modificationstation.stationapi.api.block;

import java.util.List;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;

public interface DropListProvider {
    List<C_88708284> getDropList(C_64041439 world, int x, int y, int z, BlockState state, int meta);
}
