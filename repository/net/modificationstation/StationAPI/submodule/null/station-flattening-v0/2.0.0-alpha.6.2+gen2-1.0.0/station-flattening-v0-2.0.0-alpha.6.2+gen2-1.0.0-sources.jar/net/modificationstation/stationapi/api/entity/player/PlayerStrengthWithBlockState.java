package net.modificationstation.stationapi.api.entity.player;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_46108969;
import net.modificationstation.stationapi.api.block.BlockState;

public interface PlayerStrengthWithBlockState {

    boolean canHarvest(C_46108969 blockView, C_32594356 blockPos, BlockState state);

    float getBlockBreakingSpeed(C_46108969 blockView, C_32594356 blockPos, BlockState state);
}
