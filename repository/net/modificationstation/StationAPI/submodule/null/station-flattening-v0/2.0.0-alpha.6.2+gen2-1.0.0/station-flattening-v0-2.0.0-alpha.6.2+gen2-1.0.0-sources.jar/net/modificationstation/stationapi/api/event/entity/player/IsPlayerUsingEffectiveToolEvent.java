package net.modificationstation.stationapi.api.event.entity.player;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.block.BlockState;

import java.util.function.BooleanSupplier;

@SuperBuilder
public final class IsPlayerUsingEffectiveToolEvent extends Event {
    public final C_40996800 player;
    public final C_46108969 blockView;
    public final C_32594356 blockPos;
    public final BlockState blockState;
    /**
     * The function that determines whether the player is using an effective tool.
     *
     * <p>
     *     Initially, the field contains a reimplementation of the vanilla
     *     {@link net.minecraft.unmapped.C_87542771#m_01253514(C_81592558)}.
     * </p>
     * <p>
     *     The field is non-final to allow full control over the outcome of the event, including completely
     *     canceling the original chain of execution.
     * </p>
     * <p>
     *     The results can be chained by preserving the previous <code>resultProvider</code> instance
     *     and using it in your own implementation, for example:
     *     <pre>{@code
     *         var previousProvider = event.resultProvider;
     *         event.resultProvider = () -> doSomethingElse() && previousProvider.getAsBoolean()
     *     }</pre>
     * </p>
     */
    public BooleanSupplier resultProvider;
}
