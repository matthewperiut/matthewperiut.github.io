package net.modificationstation.stationapi.mixin.flattening;

import net.mine_diver.unsafeevents.listener.Listener;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_90901456;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.registry.RegistryIdRemapEvent;
import net.modificationstation.stationapi.api.registry.BlockRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_90901456.class)
class BucketItemMixin {
    @Shadow private int fluidBlockId;

    @Inject(
            method = "<init>",
            at = @At("RETURN")
    )
    private void stationapi_registerCallback(int i, int par2, CallbackInfo ci) {
        BlockRegistry.INSTANCE.getEventBus().register(Listener.<RegistryIdRemapEvent<C_81592558>>simple()
                .listener(event -> fluidBlockId = event.state.getRawIdChangeMap().getOrDefault(fluidBlockId, fluidBlockId))
                .phase(StationAPI.INTERNAL_PHASE)
                .build());
    }
}
