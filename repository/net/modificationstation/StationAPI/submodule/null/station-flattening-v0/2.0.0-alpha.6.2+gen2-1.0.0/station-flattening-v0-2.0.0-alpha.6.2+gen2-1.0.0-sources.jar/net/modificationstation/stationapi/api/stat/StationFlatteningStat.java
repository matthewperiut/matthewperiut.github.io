package net.modificationstation.stationapi.api.stat;

import net.minecraft.unmapped.C_62649600;
import net.modificationstation.stationapi.api.registry.RegistryEntry;
import net.modificationstation.stationapi.api.registry.RemappableRawIdHolder;
import net.modificationstation.stationapi.api.util.Util;

public interface StationFlatteningStat extends RemappableRawIdHolder {
    @Override
    default void setRawId(int rawId) {
        Util.assertImpl();
    }

    default RegistryEntry.Reference<C_62649600> getRegistryEntry() {
        return Util.assertImpl();
    }
}