package net.modificationstation.stationapi.mixin.flattening;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import lombok.val;
import net.minecraft.unmapped.C_62649600;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_89105241;
import net.minecraft.unmapped.C_95106612;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.registry.StatRegistryEvent;
import net.modificationstation.stationapi.api.item.BlockItemForm;
import net.modificationstation.stationapi.api.registry.BlockRegistry;
import net.modificationstation.stationapi.api.registry.ItemRegistry;
import net.modificationstation.stationapi.api.registry.Registry;
import net.modificationstation.stationapi.api.registry.StatRegistry;
import net.modificationstation.stationapi.api.registry.sync.trackers.Int2ObjectMapTracker;
import net.modificationstation.stationapi.api.registry.sync.trackers.ObjectArrayTracker;
import net.modificationstation.stationapi.api.util.Namespace;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;

@Mixin(C_95106612.class)
class StatsMixin {
    @Shadow public static C_62649600[] CRAFTED;

    @Shadow public static C_62649600[] MINE_BLOCK;

    @Shadow public static C_62649600[] USED;

    @Shadow public static C_62649600[] BROKEN;

    @Shadow private static boolean hasExtendedItemStatsInitialized;

    @Shadow private static boolean hasBasicItemStatsInitialized;

    @Shadow protected static Map<Integer, C_62649600> ID_TO_STAT;

    @Inject(
            method = "<clinit>",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/stat/Stats;ID_TO_STAT:Ljava/util/Map;",
                    opcode = Opcodes.PUTSTATIC,
                    shift = At.Shift.AFTER
            )
    )
    private static void stationapi_syncMap(CallbackInfo ci) {
        Int2ObjectMapTracker.register(StatRegistry.INSTANCE, "Stats.ID_TO_STAT", ID_TO_STAT, true);
    }

    @Inject(
            method = "<clinit>",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/stat/Stats;MINE_BLOCK:[Lnet/minecraft/stat/Stat;",
                    opcode = Opcodes.PUTSTATIC,
                    shift = At.Shift.AFTER
            )
    )
    private static void stationapi_syncMined(CallbackInfo ci) {
        ObjectArrayTracker.register(BlockRegistry.INSTANCE, () -> MINE_BLOCK, array -> MINE_BLOCK = array, false);
    }

    @Inject(
            method = "initializeItemStats",
            at = @At("HEAD")
    )
    private static void stationapi_syncUsedAndBroken(CallbackInfo ci) {
        if (!hasExtendedItemStatsInitialized) {
            ObjectArrayTracker.register(ItemRegistry.INSTANCE, () -> USED, array -> USED = array, false);
            ObjectArrayTracker.register(ItemRegistry.INSTANCE, () -> BROKEN, array -> BROKEN = array, false);
        }
    }

    @Redirect(
            method = "initializeItemStats",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/block/Block;BLOCKS:[Lnet/minecraft/block/Block;",
                    opcode = Opcodes.GETSTATIC,
                    args = "array=length",
                    ordinal = 0
            )
    )
    private static int stationapi_initAll(C_81592558[] blocks) {
        return C_98888256.f_38445253.length;
    }

    @Inject(
            method = "initializeExtendedItemStats",
            at = @At("HEAD")
    )
    private static void stationapi_syncUsedAndBrokenExtended(CallbackInfo ci) {
        if (!hasBasicItemStatsInitialized) {
            ObjectArrayTracker.register(ItemRegistry.INSTANCE, () -> USED, array -> USED = array, false);
            ObjectArrayTracker.register(ItemRegistry.INSTANCE, () -> BROKEN, array -> BROKEN = array, false);
        }
    }

    @WrapOperation(
            method = "initializeExtendedItemStats",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/stat/Stats;initItemsUsedStats([Lnet/minecraft/stat/Stat;Ljava/lang/String;III)[Lnet/minecraft/stat/Stat;"
            )
    )
    private static C_62649600[] stationapi_stopBlockUsedStats(C_62649600[] stats, String name, int id, int minId, int maxId, Operation<C_62649600[]> original) {
        return new C_62649600[maxId];
    }

    @Inject(
            method = "initializeCraftedItemStats",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/stat/Stats;CRAFTED:[Lnet/minecraft/stat/Stat;",
                    opcode = Opcodes.PUTSTATIC
            )
    )
    private static void stationapi_syncCrafted(CallbackInfo ci) {
        ObjectArrayTracker.register(ItemRegistry.INSTANCE, () -> CRAFTED, array -> CRAFTED = array, false);
    }

    @Inject(
            method = "<clinit>",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/stat/Stats;FISH_CAUGHT:Lnet/minecraft/stat/Stat;",
                    opcode = Opcodes.PUTSTATIC,
                    shift = At.Shift.AFTER
            )
    )
    private static void stationapi_afterStatRegister(CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(new StatRegistryEvent());
    }

    @Inject(
            method = "initializeCraftedItemStats",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/stat/ItemOrBlockStat;addStat()Lnet/minecraft/stat/Stat;",
                    shift = At.Shift.BY,
                    by = 2
            )
    )
    private static void stationapi_registerCraftedStats(
            CallbackInfo ci,
            @Local(index = 2) Integer index
    ) {
        val stat = CRAFTED[index];
        Registry.register(StatRegistry.INSTANCE, stat.id, C_98888256.f_38445253[index].getRegistryEntry().registryKey().getValue().withSuffixedPath("_crafted"), stat);
    }

    @Inject(
            method = "initBlocksMined",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/List;add(Ljava/lang/Object;)Z"
            )
    )
    private static void stationapi_registerMinedStats(
            String string, int i, CallbackInfoReturnable<C_62649600[]> cir,
            @Local(index = 2) C_62649600[] statArray, @Local(index = 3) int index
    ) {
        val stat = statArray[index];
        Registry.register(StatRegistry.INSTANCE, stat.id, C_81592558.f_44428008[index].getRegistryEntry().registryKey().getValue().withSuffixedPath("_mined"), stat);
    }

    @Inject(
            method = "initItemsUsedStats",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/stat/ItemOrBlockStat;addStat()Lnet/minecraft/stat/Stat;",
                    shift = At.Shift.BY,
                    by = 2
            )
    )
    private static void stationapi_registerUsedStats(
            C_62649600[] stats, String string, int i, int j, int k, CallbackInfoReturnable<C_62649600[]> cir,
            @Local(index = 5) int index
    ) {
        val stat = stats[index];
        Registry.register(StatRegistry.INSTANCE, stat.id, C_98888256.f_38445253[index].getRegistryEntry().registryKey().getValue().withSuffixedPath("_used"), stat);
    }

    @Inject(
            method = "initializeBrokenItemStats",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/stat/ItemOrBlockStat;addStat()Lnet/minecraft/stat/Stat;",
                    shift = At.Shift.BY,
                    by = 2
            )
    )
    private static void stationapi_registerBrokenStats(
            C_62649600[] stats, String string, int i, int j, int k, CallbackInfoReturnable<C_62649600[]> cir,
            @Local(index = 5) int index
    ) {
        val stat = stats[index];
        Registry.register(StatRegistry.INSTANCE, stat.id, C_98888256.f_38445253[index].getRegistryEntry().registryKey().getValue().withSuffixedPath("_broken"), stat);
    }

    @ModifyConstant(
            method = "initBlocksMined",
            constant = @Constant(intValue = 256)
    )
    private static int stationapi_getBlocksSize(int constant) {
        return C_81592558.f_44428008.length;
    }

    @ModifyConstant(
            method = {
                    "initializeItemStats",
                    "initializeExtendedItemStats",
                    "initializeCraftedItemStats",
                    "initItemsUsedStats",
                    "initializeBrokenItemStats"
            },
            constant = @Constant(intValue = 32000)
    )
    private static int stationapi_getItemsSize(int constant) {
        return C_98888256.f_38445253.length;
    }

    @WrapOperation(
            method = {
                    "initializeCraftedItemStats",
                    "initItemsUsedStats",
                    "initializeBrokenItemStats"
            },
            at = @At(
                    value = "NEW",
                    target = "(ILjava/lang/String;I)Lnet/minecraft/stat/ItemOrBlockStat;"
            )
    )
    private static C_89105241 stationapi_removeIdReservationFromModdedItemStats(
            int rawId, String translationKey, int itemIdOrBlockId, Operation<C_89105241> original
    ) {
        return original.call(
                ItemRegistry.INSTANCE.getId(itemIdOrBlockId).orElseThrow().getNamespace() == Namespace.MINECRAFT
                        ? rawId
                        : StatRegistry.AUTO_ID,
                translationKey,
                itemIdOrBlockId
        );
    }

    @WrapOperation(
            method = "initBlocksMined",
            at = @At(
                    value = "NEW",
                    target = "(ILjava/lang/String;I)Lnet/minecraft/stat/ItemOrBlockStat;"
            )
    )
    private static C_89105241 stationapi_removeIdReservationFromModdedBlockStats(
            int rawId, String translationKey, int itemIdOrBlockId, Operation<C_89105241> original
    ) {
        return original.call(
                BlockRegistry.INSTANCE.getId(itemIdOrBlockId).orElseThrow().getNamespace() == Namespace.MINECRAFT
                        ? rawId
                        : StatRegistry.AUTO_ID,
                translationKey,
                itemIdOrBlockId
        );
    }

    @Redirect(
            method = "initItemsUsedStats",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/block/Block;BLOCKS:[Lnet/minecraft/block/Block;",
                    opcode = Opcodes.GETSTATIC,
                    args = "array=length"
            )
    )
    private static int stationapi_fixBlockCheck(
            C_81592558[] array,
            @Local(index = 5) int id
    ) {
        return C_98888256.f_38445253[id] instanceof BlockItemForm ? id + 1 : id;
    }
}