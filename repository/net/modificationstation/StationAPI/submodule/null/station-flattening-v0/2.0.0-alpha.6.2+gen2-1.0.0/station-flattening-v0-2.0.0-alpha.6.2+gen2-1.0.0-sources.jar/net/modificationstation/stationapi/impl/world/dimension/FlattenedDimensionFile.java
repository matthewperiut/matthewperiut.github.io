package net.modificationstation.stationapi.impl.world.dimension;

import net.minecraft.unmapped.C_50240030;
import net.minecraft.unmapped.C_90532916;
import net.minecraft.unmapped.C_99656780;
import net.modificationstation.stationapi.api.registry.DimensionRegistry;
import net.modificationstation.stationapi.api.world.dimension.VanillaDimensions;
import net.modificationstation.stationapi.impl.world.chunk.FlattenedWorldChunkLoader;

import java.io.File;

public class FlattenedDimensionFile extends C_50240030 {

    public FlattenedDimensionFile(File file, String string, boolean bl) {
        super(file, string, bl);
    }

    @Override
    public C_99656780 m_47069612(C_90532916 dimension) {
        File worldFolder = this.m_52081685();
        if (!DimensionRegistry.INSTANCE.getIdByLegacyId(dimension.f_09977150).map(VanillaDimensions.OVERWORLD::equals).orElse(true)) {
            File dimFolder = new File(worldFolder, "DIM" + dimension.f_09977150);
            //noinspection ResultOfMethodCallIgnored
            dimFolder.mkdirs();
            return new FlattenedWorldChunkLoader(dimFolder);
        } else {
            return new FlattenedWorldChunkLoader(worldFolder);
        }
    }
}
