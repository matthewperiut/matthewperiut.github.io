package net.modificationstation.stationapi.impl.world.storage;

import com.mojang.datafixers.DSL;
import it.unimi.dsi.fastutil.ints.IntIterator;
import it.unimi.dsi.fastutil.ints.IntOpenHashSet;
import it.unimi.dsi.fastutil.ints.IntSet;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_08489468;
import net.minecraft.unmapped.C_08565163;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_59053975;
import net.minecraft.unmapped.C_64676926;
import net.minecraft.unmapped.C_71803183;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_87007645;
import net.minecraft.unmapped.C_89060550;
import net.minecraft.unmapped.C_92964787;
import net.modificationstation.stationapi.api.datafixer.TypeReferences;
import net.modificationstation.stationapi.api.nbt.NbtHelper;
import net.modificationstation.stationapi.api.util.Util;
import net.modificationstation.stationapi.impl.world.dimension.FlattenedDimensionFile;
import net.modificationstation.stationapi.mixin.flattening.RegionFileAccessor;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.function.BiFunction;

import static net.modificationstation.stationapi.api.StationAPI.LOGGER;

public class FlattenedWorldStorage extends C_92964787 {

    public FlattenedWorldStorage(File file) {
        super(file);
    }

    @Environment(value=EnvType.CLIENT)
    @Override
    public String m_91529029() {
        return "Modded " + super.m_91529029();
    }

    @Environment(value=EnvType.CLIENT)
    public String getPreviousWorldFormat() {
        return super.m_91529029();
    }

    @Environment(value=EnvType.CLIENT)
    public List<C_87007645> m_45201496() {
        ArrayList<C_87007645> worlds = new ArrayList<>();
        for (File worldPath : Objects.requireNonNull(this.f_90285215.listFiles())) {
            String worldFolder;
            C_64676926 data;
            if (!worldPath.isDirectory() || (data = this.m_18055305(worldFolder = worldPath.getName())) == null) continue;
            C_74087615 worldTag = getWorldTag(worldFolder);
            boolean requiresUpdating = data.m_77720702() != 19132 || NbtHelper.requiresUpdating(worldTag);
            String worldName = data.m_90700428();
            if (worldName == null || C_45510667.m_56718712(worldName)) worldName = worldFolder;
            worlds.add(new C_87007645(worldFolder, worldName, data.m_17895930(), data.m_58203330(), requiresUpdating));
        }
        return worlds;
    }

    public C_74087615 getWorldTag(String worldFolder) {
        File worldPath = new File(f_90285215, worldFolder);
        if (!worldPath.exists()) return null;
        File worldData = new File(worldPath, "level.dat");
        if (worldData.exists()) try {
            return C_08565163.m_38706312(new FileInputStream(worldData)).m_81819352("Data");
        } catch (Exception e) {
            e.printStackTrace();
        }
        if ((worldData = new File(worldPath, "level.dat_old")).exists()) try {
            return C_08565163.m_38706312(new FileInputStream(worldData)).m_81819352("Data");
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public C_08489468 m_46878601(String string, boolean bl) {
        return new FlattenedDimensionFile(this.f_90285215, string, bl);
    }

    @Override
    public boolean m_92336017(String string) {
        if (super.m_92336017(string))
            return true;
        C_74087615 worldTag = getWorldTag(string);
        return worldTag != null && NbtHelper.requiresUpdating(worldTag);
    }

    @Override
    public boolean m_49902149(String worldFolder, C_71803183 progress) {
        try {
            return convertWorld(worldFolder, (type, compound) -> NbtHelper.addDataVersions(NbtHelper.update(type, compound)), progress);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean convertWorld(String worldFolder, BiFunction<DSL.TypeReference, C_74087615, C_74087615> convertFunction, C_71803183 progress) throws IOException {
        C_59053975.m_83716436();
        LOGGER.info("Creating a backup of world \"" + worldFolder + "\"...");
        File worldFile = new File(f_90285215, worldFolder);
        try {
            Util.pack(worldFile.toPath(), new File(f_90285215, worldFolder + "-" + new SimpleDateFormat("yyyyMMddHHmmss").format(new Date()) + ".zip").toPath());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        if (super.m_92336017(worldFolder)) {
            LOGGER.info("Converting to \"" + super.m_91529029() + "\" first...");
            super.m_49902149(worldFolder, progress);
        }
        progress.m_97310843(0);
        List<C_89060550> regions = new ArrayList<>();
        LOGGER.info("Scanning folders...");
        scanDimensionDir(worldFile, regions);
        File[] dims = worldFile.listFiles((dir, name) -> new File(dir, name).isDirectory() && name.startsWith("DIM"));
        if (dims != null)
            for (File dim : dims)
                scanDimensionDir(dim, regions);
        convertChunks(regions, convertFunction, progress);
        C_74087615 newWorldTag = new C_74087615();
        C_74087615 newWorldDataTag = convertFunction.apply(TypeReferences.LEVEL, getWorldTag(worldFolder));
        LOGGER.info("Converting player inventory...");
        newWorldDataTag.m_18682924("Player", convertFunction.apply(TypeReferences.PLAYER, newWorldDataTag.m_81819352("Player")));
        newWorldTag.m_18682924("Data", newWorldDataTag);
        try {
            File file = new File(worldFile, "level.dat_new");
            File file2 = new File(worldFile, "level.dat_old");
            File file3 = new File(worldFile, "level.dat");
            C_08565163.m_39608025(newWorldTag, new FileOutputStream(file));
            if (file2.exists()) //noinspection ResultOfMethodCallIgnored
                file2.delete();
            //noinspection ResultOfMethodCallIgnored
            file3.renameTo(file2);
            if (file3.exists()) //noinspection ResultOfMethodCallIgnored
                file3.delete();
            //noinspection ResultOfMethodCallIgnored
            file.renameTo(file3);
            if (file.exists()) //noinspection ResultOfMethodCallIgnored
                file.delete();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    private void scanDimensionDir(File dimensionFolder, List<C_89060550> regions) {
        File regionFolder = new File(dimensionFolder, "region");
        File[] regionFiles = regionFolder.listFiles((dir, name) -> new File(dir, name).isFile() && name.endsWith(".mcr"));
        if (regionFiles != null)
            Arrays.stream(regionFiles).map(C_89060550::new).forEach(regions::add);
    }

    private void convertChunks(List<C_89060550> regions, BiFunction<DSL.TypeReference, C_74087615, C_74087615> convertFunction, C_71803183 progress) throws IOException {
        List<IntSet> existingChunks = new ArrayList<>();
        int totalChunks = 0;
        for (C_89060550 region : regions) {
            int[] offsets = ((RegionFileAccessor) region).getChunkBlockInfo();
            IntSet chunks = new IntOpenHashSet(offsets.length);
            for (int i = 0; i < offsets.length; i++)
                if (offsets[i] != 0)
                    chunks.add(i);
            existingChunks.add(chunks);
            totalChunks += chunks.size();
        }
        LOGGER.info("Total conversion count is " + totalChunks);
        int updatedChunks = 0;
        for (int i = 0; i < regions.size(); i++) {
            C_89060550 region = regions.get(i);
            IntSet chunks = existingChunks.get(i);
            IntIterator it = chunks.iterator();
            while (it.hasNext()) {
                int index = it.nextInt();
                int x = index & 0b11111;
                int z = index >> 5;
                DataInputStream stream = region.m_88766766(x, z);
                if (stream != null) {
                    C_74087615 chunkTag = C_08565163.m_07155133(stream);
                    try {
                        stream.close();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    C_74087615 updatedChunkTag = convertFunction.apply(TypeReferences.CHUNK, chunkTag);
                    try (DataOutputStream outStream = region.m_68205534(x, z)) {
                        C_08565163.m_94300398(updatedChunkTag, outStream);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                }
                progress.m_97310843(++updatedChunks * 100 / totalChunks);
            }
            region.m_16177213();
        }
    }
}
