package net.modificationstation.stationapi.mixin.flattening.client;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_34267874;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_54765678;
import net.minecraft.unmapped.C_57778754;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.util.math.MutableBlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_54765678.class)
class SingleplayerInteractionManagerMixin extends C_34267874 {
    @Unique
    private BlockState stationapi_breakBlock_state;
    @Unique
    private final MutableBlockPos stationapi_blockPos = new MutableBlockPos();

    private SingleplayerInteractionManagerMixin(Minecraft minecraft) {
        super(minecraft);
    }

    @Redirect(
            method = {
                    "attackBlock(IIII)V",
                    "processBlockBreakingAction(IIII)V"
            },
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/Block;getHardness(Lnet/minecraft/entity/player/PlayerEntity;)F"
            )
    )
    private float stationapi_getHardnessPerMeta(C_81592558 block, C_40996800 arg, int i, int j, int k, int i1) {
        return f_17565231.f_26407825.getBlockState(i, j, k).calcBlockBreakingDelta(arg, f_17565231.f_26407825, new C_32594356(i, j, k));
    }

    @Inject(
            method = "breakBlock(IIII)Z",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/InteractionManager;breakBlock(IIII)Z",
                    shift = At.Shift.BEFORE
            )
    )
    private void stationapi_cacheBlockState(int x, int y, int z, int distance, CallbackInfoReturnable<Boolean> cir) {
        stationapi_breakBlock_state = f_17565231.f_26407825.getBlockState(x, y, z);
    }

    @Redirect(
            method = "breakBlock(IIII)Z",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/player/ClientPlayerEntity;canHarvest(Lnet/minecraft/block/Block;)Z"
            )
    )
    private boolean stationapi_canRemoveBlock(C_57778754 abstractClientPlayer, C_81592558 arg, int i, int j, int k, int l) {
        return abstractClientPlayer.canHarvest(f_17565231.f_26407825, stationapi_blockPos.set(i, j, k), stationapi_breakBlock_state);
    }

    @Redirect(
            method = "breakBlock(IIII)Z",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/Block;afterBreak(Lnet/minecraft/world/World;Lnet/minecraft/entity/player/PlayerEntity;IIII)V"
            )
    )
    private void stationapi_redirectAfterBreak(C_81592558 block, C_64041439 world, C_40996800 player, int x, int y, int z, int meta) {
        block.afterBreak(world, player, x, y, z, stationapi_breakBlock_state, meta);
    }

    @Inject(
            method = "breakBlock(IIII)Z",
            at = @At("RETURN")
    )
    private void stationapi_clearCache(int x, int y, int z, int distance, CallbackInfoReturnable<Boolean> cir) {
        stationapi_breakBlock_state = null;
    }
}
