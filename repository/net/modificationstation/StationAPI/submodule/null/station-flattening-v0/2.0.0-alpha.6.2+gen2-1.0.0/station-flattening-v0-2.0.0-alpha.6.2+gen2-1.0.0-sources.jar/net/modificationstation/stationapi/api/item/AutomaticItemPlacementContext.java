package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_94584382;
import net.modificationstation.stationapi.api.util.math.Direction;

public class AutomaticItemPlacementContext
extends ItemPlacementContext {

    private final C_32594356 pos;
    private final Direction facing;

    public AutomaticItemPlacementContext(C_64041439 world, C_32594356 pos, Direction facing, C_88708284 stack, Direction side) {
        super(world, null, stack, new C_24654288(pos.getX(), pos.getY(), pos.getZ(), side.getId(), C_94584382.m_35957932(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5)));
        this.pos = pos;
        this.facing = facing;
    }

    @Override
    public C_32594356 getBlockPos() {
        return pos;
    }

    @Override
    public boolean canPlace() {
        return this.getWorld().getBlockState(pos).canReplace(this);
    }

    @Override
    public boolean canReplaceExisting() {
        return this.canPlace();
    }

    @Override
    public Direction getPlayerLookDirection() {
        return Direction.DOWN;
    }

    @Override
    public Direction[] getPlacementDirections() {
        switch (this.facing) {
            default: {
                return new Direction[]{Direction.DOWN, Direction.WEST, Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.UP};
            }
            case UP: {
                return new Direction[]{Direction.DOWN, Direction.UP, Direction.WEST, Direction.NORTH, Direction.EAST, Direction.SOUTH};
            }
            case WEST: {
                return new Direction[]{Direction.DOWN, Direction.WEST, Direction.NORTH, Direction.SOUTH, Direction.UP, Direction.EAST};
            }
            case EAST: {
                return new Direction[]{Direction.DOWN, Direction.EAST, Direction.NORTH, Direction.SOUTH, Direction.UP, Direction.WEST};
            }
            case SOUTH: {
                return new Direction[]{Direction.DOWN, Direction.SOUTH, Direction.EAST, Direction.UP, Direction.WEST, Direction.NORTH};
            }
            case NORTH:
        }
        return new Direction[]{Direction.DOWN, Direction.NORTH, Direction.EAST, Direction.UP, Direction.WEST, Direction.SOUTH};
    }

    @Override
    public Direction getHorizontalPlayerFacing() {
        return this.facing.getAxis() == Direction.Axis.Y ? Direction.WEST : this.facing;
    }

    @Override
    public boolean shouldCancelInteraction() {
        return false;
    }

    @Override
    public float getPlayerYaw() {
        return this.facing.getHorizontal() * 90;
    }
}

