package net.modificationstation.stationapi.impl.client.world;

import net.minecraft.unmapped.C_34399650;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.block.BlockState;

public class ClientBlockChange extends C_34399650.net/minecraft/unmapped/C_88323698 {
    public int stateId;

    public ClientBlockChange(C_34399650 world, int x, int y, int z, BlockState state, int metadata) {
        world.super(x, y, z, state.getBlock().f_84602679, metadata);
        stateId = C_81592558.STATE_IDS.getRawId(state);
    }
}
