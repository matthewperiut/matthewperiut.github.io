package net.modificationstation.stationapi.api.event.registry;

import net.mine_diver.unsafeevents.event.EventPhases;
import net.minecraft.unmapped.C_62649600;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.registry.StatRegistry;

@EventPhases(StationAPI.INTERNAL_PHASE)
public class StatRegistryEvent extends RegistryEvent.EntryTypeBound<C_62649600, StatRegistry> {
    public StatRegistryEvent() {
        super(StatRegistry.INSTANCE);
    }
}