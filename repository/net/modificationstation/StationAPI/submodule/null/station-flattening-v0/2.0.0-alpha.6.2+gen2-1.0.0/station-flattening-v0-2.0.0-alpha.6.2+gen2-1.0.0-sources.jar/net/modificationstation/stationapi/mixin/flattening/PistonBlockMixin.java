package net.modificationstation.stationapi.mixin.flattening;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import net.minecraft.unmapped.C_21729986;
import net.minecraft.unmapped.C_40735137;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_89604096;
import net.minecraft.unmapped.C_98403025;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.impl.block.StationFlatteningMovingPistonImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(C_21729986.class)
class PistonBlockMixin extends C_81592558 {
    private PistonBlockMixin(int id, C_89604096 material) {
        super(id, material);
    }

    @Inject(
            method = "onBlockAction",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/World;getBlockId(III)I"
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void stationapi_getPushedBlockState1(
            C_64041439 world, int x, int y, int z, int direction, int meta, CallbackInfo ci,
            int var7, C_40735137 var8, int pushedX, int pushedY, int pushedZ,
            @Share("blockState") LocalRef<BlockState> blockStateRef
    ) {
        blockStateRef.set(world.getBlockState(pushedX, pushedY, pushedZ));
    }

    @Inject(
            method = "onBlockAction",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/entity/PistonBlockEntity;getPushedBlockId()I"
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void stationapi_getPushedBlockState2(
            C_64041439 world, int x, int y, int z, int direction, int meta, CallbackInfo ci,
            int var7, C_40735137 var8, int pushedX, int pushedY, int pushedZ, int var12, int var13, int var14, C_40735137 var15, C_98403025 pistonBlockEntity,
            @Share("blockState") LocalRef<BlockState> blockStateRef
    ) {
        blockStateRef.set(pistonBlockEntity.getPushedBlockState());
    }

    @Inject(
            method = "onBlockAction",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/PistonExtensionBlock;createPistonBlockEntity(IIIZZ)Lnet/minecraft/block/entity/BlockEntity;",
                    ordinal = 0
            )
    )
    private void stationapi_passPushedBlockState1(
            C_64041439 world, int x, int y, int z, int direction, int meta, CallbackInfo ci
    ) {
        StationFlatteningMovingPistonImpl.pushedBlockState = getDefaultState();
    }

    @Inject(
            method = "onBlockAction",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/PistonExtensionBlock;createPistonBlockEntity(IIIZZ)Lnet/minecraft/block/entity/BlockEntity;",
                    ordinal = 1
            )
    )
    private void stationapi_passPushedBlockState2(
            C_64041439 world, int x, int y, int z, int direction, int meta, CallbackInfo ci,
            @Share("blockState") LocalRef<BlockState> blockStateRef
    ) {
        StationFlatteningMovingPistonImpl.pushedBlockState = blockStateRef.get();
    }

    @Inject(
            method = "push",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/World;getBlockId(III)I",
                    ordinal = 1
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void stationapi_getPushedBlockState3(
            C_64041439 world, int x, int y, int z, int direction, CallbackInfoReturnable<Boolean> cir,
            int var6, int var7, int var8, int pushedX, int pushedY, int pushedZ,
            @Share("blockState") LocalRef<BlockState> blockStateRef
    ) {
        blockStateRef.set(world.getBlockState(pushedX, pushedY, pushedZ));
    }

    @Inject(
            method = "push",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/PistonExtensionBlock;createPistonBlockEntity(IIIZZ)Lnet/minecraft/block/entity/BlockEntity;",
                    ordinal = 0
            )
    )
    private void stationapi_passPushedBlockState3(C_64041439 world, int x, int y, int z, int direction, CallbackInfoReturnable<Boolean> cir) {
        StationFlatteningMovingPistonImpl.pushedBlockState = C_81592558.f_95852348.getDefaultState();
    }

    @Inject(
            method = "push",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/PistonExtensionBlock;createPistonBlockEntity(IIIZZ)Lnet/minecraft/block/entity/BlockEntity;",
                    ordinal = 1
            )
    )
    private void stationapi_passPushedBlockState4(
            C_64041439 world, int x, int y, int z, int direction, CallbackInfoReturnable<Boolean> cir,
            @Share("blockState") LocalRef<BlockState> blockStateRef
    ) {
        StationFlatteningMovingPistonImpl.pushedBlockState = blockStateRef.get();
    }

    // Not ModifyExpressionValue because MixinExtras apparently doesn't support expandZeroConditions
    @ModifyConstant(
            method = "canExtend",
            constant = @Constant(expandZeroConditions = Constant.Condition.LESS_THAN_OR_EQUAL_TO_ZERO)
    )
    private static int stationapi_canExtend_changeBottomYCheck(
            int original,
            @Local(index = 0, argsOnly = true) C_64041439 world
    ) {
        return world.getBottomY();
    }

    @ModifyExpressionValue(
            method = "canExtend",
            at = @At(
                    value = "CONSTANT",
                    args = "intValue=127"
            )
    )
    private static int stationapi_canExtend_changeTopYCheck(
            int original,
            @Local(index = 0, argsOnly = true) C_64041439 world
    ) {
        return world.getTopY() - 1;
    }

    // Not ModifyExpressionValue because MixinExtras apparently doesn't support expandZeroConditions
    @ModifyConstant(
            method = "push",
            constant = @Constant(expandZeroConditions = Constant.Condition.LESS_THAN_OR_EQUAL_TO_ZERO)
    )
    private int stationapi_push_changeBottomYCheck(
            int original,
            @Local(index = 1, argsOnly = true) C_64041439 world
    ) {
        return world.getBottomY();
    }

    @ModifyExpressionValue(
            method = "push",
            at = @At(
                    value = "CONSTANT",
                    args = "intValue=127"
            )
    )
    private int stationapi_push_changeTopYCheck(
            int original,
            @Local(index = 1, argsOnly = true) C_64041439 world
    ) {
        return world.getTopY() - 1;
    }
}
