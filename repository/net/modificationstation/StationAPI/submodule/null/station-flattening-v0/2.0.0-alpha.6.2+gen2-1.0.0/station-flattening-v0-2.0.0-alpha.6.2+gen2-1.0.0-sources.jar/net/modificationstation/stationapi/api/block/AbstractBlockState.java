package net.modificationstation.stationapi.api.block;

import com.google.common.collect.ImmutableMap;
import com.mojang.serialization.MapCodec;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_13378080;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.api.item.ItemPlacementContext;
import net.modificationstation.stationapi.api.registry.RegistryEntryList;
import net.modificationstation.stationapi.api.state.State;
import net.modificationstation.stationapi.api.state.property.Property;
import net.modificationstation.stationapi.api.tag.TagKey;
import net.modificationstation.stationapi.api.util.math.MathHelper;
import net.modificationstation.stationapi.impl.block.StationFlatteningBlockInternal;

import java.util.function.Predicate;
import java.util.stream.Stream;

public abstract class AbstractBlockState extends State<C_81592558, BlockState> {
    private final boolean isAir;
    private final C_89604096 material;
    private final C_13378080 materialColor;
    private final boolean toolRequired;
    private final boolean opaque;
    private int luminance = -1;

    protected AbstractBlockState(C_81592558 block, ImmutableMap<Property<?>, Comparable<?>> propertyMap, MapCodec<BlockState> mapCodec) {
        super(block, propertyMap, mapCodec);
        this.isAir = block.f_22724416 == C_89604096.f_74758574;
        this.material = block.f_22724416;
        this.materialColor = block.f_22724416.f_88520632;
        this.toolRequired = !block.f_22724416.m_84337147();
        this.opaque = block.m_57757663();
    }

    public C_81592558 getBlock() {
        return this.owner;
    }

    public C_89604096 getMaterial() {
        return this.material;
    }

    /**
     * Returns the light level emitted by this block state.
     */
    public int getLuminance() {
        return luminance == -1 ?
                luminance = ((StationFlatteningBlockInternal) owner).stationapi_getLuminanceProvider().applyAsInt(asBlockState()) :
                luminance;
    }

    public boolean isAir() {
        return this.isAir;
    }

    public C_13378080 getTopMaterialColor(C_46108969 world, C_32594356 pos) {
        return this.materialColor;
    }

    public float getHardness(C_46108969 world, C_32594356 pos) {
        return getBlock().getHardness(asBlockState(), world, pos);
    }

    public float calcBlockBreakingDelta(C_40996800 player, C_46108969 world, C_32594356 pos) {
        return getBlock().calcBlockBreakingDelta(asBlockState(), player, world, pos);
    }

    public boolean isOpaque() {
        return this.opaque;
    }

    public void onStateReplaced(C_64041439 world, C_32594356 pos, BlockState state) {
        this.getBlock().onStateReplaced(this.asBlockState(), world, pos, state);
    }

    public boolean canReplace(ItemPlacementContext context) {
        return this.getBlock().canReplace(this.asBlockState(), context);
    }

    public boolean isIn(TagKey<C_81592558> tag) {
        return getBlock().getRegistryEntry().isIn(tag);
    }

    public boolean isIn(TagKey<C_81592558> tag, Predicate<AbstractBlockState> predicate) {
        return this.isIn(tag) && predicate.test(this);
    }

    public boolean isIn(RegistryEntryList<C_81592558> blocks) {
        return blocks.contains(getBlock().getRegistryEntry());
    }

    public Stream<TagKey<C_81592558>> streamTags() {
        return getBlock().getRegistryEntry().streamTags();
    }

    public boolean isOf(C_81592558 block) {
        return this.getBlock() == block;
    }

    public boolean hasRandomTicks() {
        return C_81592558.f_08006312[getBlock().f_84602679];
    }

    @Environment(EnvType.CLIENT)
    public long getRenderingSeed(C_32594356 pos) {
        return MathHelper.hashCode(pos.f_06162490, pos.f_08824702, pos.f_31865394);
    }

    protected abstract BlockState asBlockState();

    public boolean isToolRequired() {
        return this.toolRequired;
    }
}