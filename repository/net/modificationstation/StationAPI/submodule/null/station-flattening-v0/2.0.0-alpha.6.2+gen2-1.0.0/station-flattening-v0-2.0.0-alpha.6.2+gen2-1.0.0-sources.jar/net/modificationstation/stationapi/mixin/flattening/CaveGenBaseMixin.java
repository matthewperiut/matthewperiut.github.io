package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_31728388;
import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.impl.world.CaveGenBaseImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(C_31728388.class)
class CaveGenBaseMixin implements CaveGenBaseImpl {
    @Unique
    private C_64041439 stationapi_world;

    @Override
    @Unique
    public void stationapi_setWorld(C_64041439 world) {
        stationapi_world = world;
    }

    @Override
    @Unique
    public C_64041439 stationapi_getWorld() {
        if (stationapi_world == null) {
            throw new RuntimeException("stationapi_world is null, use CaveGenBaseImpl.stationapi_setWorld in your custom ChunkSource constructor to fix.");
        }
        return stationapi_world;
    }
}
