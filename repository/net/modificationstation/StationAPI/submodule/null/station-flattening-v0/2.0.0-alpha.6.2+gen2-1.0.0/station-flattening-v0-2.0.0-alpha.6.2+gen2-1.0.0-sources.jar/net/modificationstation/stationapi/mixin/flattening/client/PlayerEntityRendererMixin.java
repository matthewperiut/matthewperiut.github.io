package net.modificationstation.stationapi.mixin.flattening.client;

import net.minecraft.unmapped.C_34859172;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.item.BlockItemForm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_34859172.class)
class PlayerEntityRendererMixin {
    @Unique
    private BlockItemForm stationapi_blockItemForm;

    @Redirect(
            method = "renderMore(Lnet/minecraft/entity/player/PlayerEntity;F)V",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/Item;id:I"
            )
    )
    private int stationapi_isBlockItemForm(C_98888256 instance) {
        if (instance instanceof BlockItemForm blockItemForm){
            stationapi_blockItemForm = blockItemForm;
            return 255;
        }
        return 256;
    }

    @Redirect(
            method = "renderMore(Lnet/minecraft/entity/player/PlayerEntity;F)V",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;itemId:I",
                    ordinal = 1
            )
    )
    private int stationapi_isBlockItemForm(C_88708284 instance) {
        if (instance.m_23235460() instanceof BlockItemForm blockItemForm) {
            stationapi_blockItemForm = blockItemForm;
            return 255;
        }
        return 256;
    }

    @Redirect(
            method = "renderMore(Lnet/minecraft/entity/player/PlayerEntity;F)V",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/block/Block;BLOCKS:[Lnet/minecraft/block/Block;",
                    args = "array=get"
            )
    )
    private C_81592558 stationapi_getBlockItemForm(C_81592558[] array, int index) {
        return stationapi_blockItemForm.getBlock();
    }
}
