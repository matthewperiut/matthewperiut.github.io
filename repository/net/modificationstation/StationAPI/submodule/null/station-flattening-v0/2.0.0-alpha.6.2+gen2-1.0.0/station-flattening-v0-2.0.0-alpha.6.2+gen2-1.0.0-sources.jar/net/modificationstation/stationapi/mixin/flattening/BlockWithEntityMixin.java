package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_73452336;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_89604096;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(C_73452336.class)
class BlockWithEntityMixin extends C_81592558 {
    private BlockWithEntityMixin(int i, C_89604096 arg) {
        super(i, arg);
    }

    @ModifyVariable(
            method = "<init>(ILnet/minecraft/block/material/Material;)V",
            index = 1,
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/Block;<init>(ILnet/minecraft/block/material/Material;)V",
                    shift = At.Shift.AFTER
            ),
            argsOnly = true
    )
    private int stationapi_modifyId1(int value) {
        return f_84602679;
    }

    @ModifyVariable(
            method = "<init>(IILnet/minecraft/block/material/Material;)V",
            index = 1,
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/Block;<init>(IILnet/minecraft/block/material/Material;)V",
                    shift = At.Shift.AFTER
            ),
            argsOnly = true
    )
    private int stationapi_modifyId2(int value) {
        return f_84602679;
    }
}
