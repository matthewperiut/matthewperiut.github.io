package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.event.registry.ItemRegistryEvent;
import net.modificationstation.stationapi.api.item.StationFlatteningItem;
import net.modificationstation.stationapi.api.registry.ItemRegistry;
import net.modificationstation.stationapi.api.registry.RegistryEntry;
import net.modificationstation.stationapi.api.registry.sync.trackers.ObjectArrayTracker;
import net.modificationstation.stationapi.api.registry.sync.trackers.RemappableEntryArrayTracker;
import net.modificationstation.stationapi.api.registry.sync.trackers.vanilla.BlockItemTracker;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_98888256.class)
abstract class ItemMixin implements StationFlatteningItem {
    @Shadow public abstract boolean isSuitableFor(C_81592558 arg);

    @Shadow public abstract float getMiningSpeedMultiplier(C_88708284 arg, C_81592558 arg2);

    @Shadow public static C_98888256[] ITEMS;

    @Mutable
    @Shadow @Final public int id;

    @Unique
    private RegistryEntry.Reference.IntrusiveReserved<C_98888256> stationapi_registryEntry;

    @Override
    @Unique
    public RegistryEntry.Reference<C_98888256> getRegistryEntry() {
        return stationapi_registryEntry;
    }

    @Override
    @Unique
    public final void setRawId(int rawId) {
        id = rawId;
    }

    @Override
    @Unique
    public C_98888256 asItem() {
        return C_98888256.class.cast(this);
    }

    @Inject(
            method = "<clinit>",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/stat/Stats;initializeExtendedItemStats()V",
                    shift = At.Shift.BEFORE
            )
    )
    private static void stationapi_afterItemRegister(CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(new ItemRegistryEvent());
    }

    @Override
    @Unique
    public boolean isSuitableFor(C_40996800 player, C_88708284 itemStack, C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return isSuitableFor(state.getBlock());
    }

    @Override
    @Unique
    public float getMiningSpeedMultiplier(C_40996800 player, C_88708284 itemStack, C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return getMiningSpeedMultiplier(itemStack, state.getBlock());
    }

    @Inject(
            method = "<clinit>",
            at = @At("HEAD")
    )
    private static void stationapi_setupRegistry(CallbackInfo ci) {
        ItemRegistry registry = ItemRegistry.INSTANCE;
        RemappableEntryArrayTracker.register(registry, () -> ITEMS, array -> ITEMS = array);
        BlockItemTracker.register(registry);
    }

    @ModifyVariable(
            method = "<init>",
            index = 1,
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/lang/Object;<init>()V",
                    shift = At.Shift.AFTER
            ),
            argsOnly = true
    )
    private int stationapi_ensureCapacity(int rawId) {
        //noinspection DataFlowIssue
        rawId = (stationapi_registryEntry = ItemRegistry.INSTANCE.createReservedEntry(rawId + ItemRegistry.ID_SHIFT, (C_98888256) (Object) this)).reservedRawId();
        // unfortunately, this array is accessed
        // too early for the tracker to resize it,
        // so we have to do it manually here
        if (ObjectArrayTracker.shouldGrow(ITEMS, rawId)) ITEMS = ObjectArrayTracker.grow(ITEMS, rawId);
        return ItemRegistry.SHIFTED_ID.get(rawId);
    }
}
