package net.modificationstation.stationapi.impl.block;

import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.block.DropListProvider;
import net.modificationstation.stationapi.api.event.block.BlockEvent;

import java.util.List;

public class BlockDropListImpl {

    @FunctionalInterface
    public interface DropInvoker {
        void drop(C_64041439 world, int x, int y, int z, C_88708284 drop);
    }

    public static boolean drop(
            C_64041439 world, int x, int y, int z,
            BlockState state, int meta,
            float chance,
            DropInvoker dropFunc, DropListProvider dropProvider
    ) {
        if (!world.f_50876584) {
            List<C_88708284> drops = dropProvider.getDropList(world, x, y, z, state, meta);
            if (drops != null) {
                if (
                        !StationAPI.EVENT_BUS.post(
                                BlockEvent.BeforeDrop.builder()
                                        .world(world)
                                        .x(x).y(y).z(z)
                                        .block(state.getBlock()).meta(meta)
                                        .chance(chance)
                                        .build()
                        ).isCanceled()
                ) drops.forEach(drop -> {
                    if (!(world.f_33453426.nextFloat() > chance) && drop.f_59294634 > 0) dropFunc.drop(world, x, y, z, drop);
                });
                return true;
            }
        }
        return false;
    }
}
