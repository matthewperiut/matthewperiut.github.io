package net.modificationstation.stationapi.impl.world.chunk;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40735137;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_92766678;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.block.States;
import net.modificationstation.stationapi.api.event.block.BlockEvent;
import net.modificationstation.stationapi.api.event.world.BlockSetEvent;
import net.modificationstation.stationapi.api.event.world.MetaSetEvent;
import net.modificationstation.stationapi.api.util.math.MutableBlockPos;
import net.modificationstation.stationapi.mixin.flattening.ChunkAccessor;

import java.util.ArrayList;
import java.util.List;

public class FlattenedChunk extends C_14917579 {
    private static final ThreadLocal<MutableBlockPos> CACHED_BLOCK_POS = ThreadLocal.withInitial(MutableBlockPos::new);

    public final ChunkSection[] sections;
    public final short firstBlock;
    public final short lastBlock;
    private final short[] stationHeightmap = new short[256];

    public FlattenedChunk(C_64041439 world, int xPos, int zPos) {
        super(world, xPos, zPos);
        int countSections = world.countVerticalSections();
        sections = new ChunkSection[countSections];
        firstBlock = (short) world.getBottomY();
        lastBlock = (short) (world.getTopY() - 1);
        f_00508683 = new List[countSections];
        for(short i = 0; i < f_00508683.length; i++) {
            this.f_00508683[i] = new ArrayList<>();
        }
    }

    public void fromLegacy(byte[] tiles) {
        int mask = (tiles.length >> 8) - 1;
        int offsetZ = mask == 127 ? 7 : net.modificationstation.stationapi.api.util.math.MathHelper.ceilLog2(mask + 1);
        int offsetX = offsetZ + 4;
        int bottom = this.f_46737896.getBottomY();
        int id, bx, by, bz;
        for(int i = 0; i < tiles.length; i++) {
            id = Byte.toUnsignedInt(tiles[i]);
            if (id == 0 || id >= C_81592558.f_44428008.length) continue;
            by = (i & mask) + bottom;
            ChunkSection section = getOrCreateSection(by, false);
            if (section == null) continue;
            bx = (i >> offsetX) & 15;
            bz = (i >> offsetZ) & 15;
            section.setBlockState(bx, by & 15, bz, C_81592558.f_44428008[id].getDefaultState());
        }
    }

    public byte[] getStoredHeightmap() {
        byte[] heightmap = new byte[512];
        for (short i = 0; i < 512; i++) {
            short value = stationHeightmap[i >> 1];
            byte val = (i & 1) == 0 ? (byte) (value & 255) : (byte) ((value >> 8) & 255);
            heightmap[i] = val;
        }
        return heightmap;
    }

    public void loadStoredHeightmap(byte[] heightmap) {
        if (heightmap.length == 256) {
            for (short i = 0; i < 256; i++) {
                stationHeightmap[i] = (short) (heightmap[i] & 255);
            }
        }
        else {
            for (short i = 0; i < 256; i++) {
                int index = i << 1;
                stationHeightmap[i] = (short) (Byte.toUnsignedInt(heightmap[index]) | (heightmap[index | 1] << 8));
            }
        }
    }

    private short getShortHeight(int x, int z) {
        return stationHeightmap[z << 4 | x];
    }

    @Override
    public int m_15889799(int x, int z) {
        return getShortHeight(x, z);
    }

    @Override
    public boolean m_48453024(int relX, int y, int relZ) {
        return y >= getShortHeight(relX, relZ);
    }

    private ChunkSection getSection(int y) {
        if (y < firstBlock || y > lastBlock) {
            return null;
        }
        return sections[f_46737896.sectionCoordToIndex(y >> 4)];
    }

    @Override
    public int m_47480762(C_92766678 type, int x, int y, int z) {
        ChunkSection section = getSection(y);
        return section == null ?
                type == C_92766678.f_02629467 && f_46737896.f_00524883.f_98952613 ?
                        0 :
                        type.f_69975077 :
                section.getLight(type, x, y & 15, z);
    }

    public ChunkSection getOrCreateSection(int y, boolean fillSkyLight) {
        if (y < firstBlock || y > lastBlock) {
            return null;
        }
        int index = f_46737896.sectionCoordToIndex(y >> 4);
        ChunkSection section = sections[index];
        if (section == null) {
            section = new ChunkSection(f_46737896.sectionIndexToCoord(index));
            if (!f_46737896.f_00524883.f_98952613 && fillSkyLight) {
                section.initSkyLight();
            }
            sections[index] = section;
        }
        return section;
    }

    @Override
    public void m_90793839(C_92766678 type, int x, int y, int z, int light) {
        this.f_12808704 = true;
        ChunkSection section = getOrCreateSection(y, true);
        if (section != null) {
            section.setLight(type, x, y & 15, z, light);
        }
    }

    @Override
    public int m_87988310(int x, int y, int z, int light) {
        ChunkSection section = getSection(y);
        int lightLevel = section == null ? (f_46737896.f_00524883.f_98952613 /* hasCeiling */ ? 0 : 15) : section.getLight(C_92766678.f_02629467, x, y & 15, z);
        if (lightLevel > 0) {
            f_35767484 = true;
        }

        lightLevel -= light;
        int blockLight = section == null ? 0 : section.getLight(C_92766678.f_19924308, x, y & 15, z);
        if (blockLight > lightLevel) {
            lightLevel = blockLight;
        }

        return lightLevel;
    }

    private void setShortHeight(int x, int z, short height) {
        stationHeightmap[z << 4 | x] = height;
    }

    @Override
    @Environment(EnvType.CLIENT)
    public void m_71750474() {
        int chunkHeight = lastBlock;

        for(int x = 0; x < 16; ++x) {
            for(int z = 0; z < 16; ++z) {
                short height;
                for (height = lastBlock; height > firstBlock; height--) {
                    if (C_81592558.f_43623251[m_55540380(x, height - 1, z)] != 0) break;
                }
                setShortHeight(x, z, height);
                if (height < chunkHeight) {
                    chunkHeight = height;
                }
            }
        }

        this.f_12867888 = chunkHeight;
        this.f_12808704 = true;
    }

    @Override
    public void m_55482979() {
        int minHeight = lastBlock;
        for(int x = 0; x < 16; ++x) {
            for(int z = 0; z < 16; ++z) {
                short height = lastBlock;

                while (height > firstBlock) {
                    if (C_81592558.f_43623251[m_55540380(x, height - 1, z)] != 0) break;
                    --height;
                }

                setShortHeight(x, z, height);
                if (height < minHeight) {
                    minHeight = height;
                }

                if (!this.f_46737896.f_00524883.f_98952613) {
                    int light = 15;
                    int lightY = lastBlock;

                    do {
                        light -= C_81592558.f_43623251[m_55540380(x, lightY, z)];
                        if (light > 0) {
                            ChunkSection section = getSection(lightY);
                            if (section != null) {
                                section.setLight(C_92766678.f_02629467, x, lightY & 15, z, light);
                            }
                        }

                        --lightY;
                    } while (lightY > firstBlock && light > 0);
                }
            }
        }

        this.f_12867888 = minHeight;

        for (short i = 0; i < 256; i++) {
            ((ChunkAccessor) this).invokeLightGaps(i & 15, i >> 4);
        }

        this.f_12808704 = true;
    }

    private void m_05909487(int x, int y, int z) {
        short height = getShortHeight(x, z);
        short maxHeight = (short) Math.max(y, height);
        if (maxHeight > lastBlock) {
            maxHeight = lastBlock;
        }

        while (maxHeight > firstBlock && C_81592558.f_43623251[m_55540380(x, maxHeight - 1, z)] == 0) {
            --maxHeight;
        }

        if (maxHeight != height) {
            this.f_46737896.m_37012105(x, z, maxHeight, height);
            setShortHeight(x, z, maxHeight);
            if (maxHeight < this.f_12867888) {
                this.f_12867888 = maxHeight;
            }
            else {
                int var7 = lastBlock;

                for (int i = 0; i < 256; i++) {
                    short mapHeight = stationHeightmap[i];
                    if (mapHeight < var7) {
                        var7 = mapHeight;
                    }
                }

                this.f_12867888 = var7;
            }

            int posX = this.f_61945954 << 4 | x;
            int posZ = this.f_46577147 << 4 | z;

            if (maxHeight < height) {
                for (int h = maxHeight; h < height; ++h) {
                    ChunkSection section = getSection(h);
                    if (section != null) {
                        section.setLight(C_92766678.f_02629467, x, h & 15, z, 15);
                    }
                }
            }
            else {
                this.f_46737896.m_54335440(C_92766678.f_02629467, posX, height, posZ, posX, maxHeight, posZ);
                for (int h = height; h < maxHeight; ++h) {
                    ChunkSection section = getSection(h);
                    if (section != null) {
                        section.setLight(C_92766678.f_02629467, x, h & 15, z, 0);
                    }
                }
            }

            int h;
            int light = 15;
            for(h = maxHeight; maxHeight > firstBlock && light > 0;) {
                --maxHeight;
                int var11 = C_81592558.f_43623251[this.m_55540380(x, maxHeight, z)];
                if (var11 == 0) {
                    var11 = 1;
                }

                light -= var11;
                if (light < 0) {
                    light = 0;
                }
                ChunkSection section = getSection(maxHeight);
                if (section != null) {
                    section.setLight(C_92766678.f_02629467, x, maxHeight & 15, z, light);
                }
            }

            while(maxHeight > firstBlock && C_81592558.f_43623251[this.m_55540380(x, maxHeight - 1, z)] == 0) {
                --maxHeight;
            }

            if (maxHeight != h) {
                this.f_46737896.m_54335440(C_92766678.f_02629467, posX - 1, maxHeight, posZ - 1, posX + 1, h, posZ + 1);
            }

            this.f_12808704 = true;
        }
    }

    @Override
    public int m_55540380(int x, int y, int z) {
        return getBlockState(x, y, z).getBlock().f_84602679;
    }

    @Override
    public boolean m_09335939(int x, int y, int z, int blockId, int meta) {
        return setBlockState(x, y, z, C_81592558.f_44428008[blockId].getDefaultState(), meta) != null;
    }

    @Override
    public boolean m_94848226(int x, int y, int z, int blockId) {
        return setBlockState(x, y, z, C_81592558.f_44428008[blockId].getDefaultState()) != null;
    }

    @Override
    public int m_41075785(int x, int y, int z) {
        ChunkSection section = getSection(y);
        return section == null ? 0 : section.getMeta(x, y & 15, z);
    }

    @Override
    public void m_71444197(int x, int y, int z, int meta) {
        MetaSetEvent event =
                MetaSetEvent.builder()
                        .world(f_46737896).chunk(this)
                        .x(this.f_61945954 << 4 | x).y(y).z(this.f_46577147 << 4 | z)
                        .blockMeta(meta)
                        .overrideMeta(meta)
                        .build();
        if (event.isCanceled()) return;
        meta = event.overrideMeta;
        ChunkSection section = getSection(y);
        if (section != null) {
            section.setMeta(x, y & 15, z, meta);
        }
    }

    @Override
    public BlockState getBlockState(int x, int y, int z) {
        ChunkSection section = getSection(y);
        if (section == null) return States.AIR.get();
        BlockState blockState = section.getBlockState(x, y & 15, z);
        if (blockState == null)
            throw new RuntimeException();
        return blockState;
    }

    @Override
    public BlockState setBlockState(int x, int y, int z, BlockState state, int meta) {
        int worldX = this.f_61945954 << 4 | x;
        int worldZ = this.f_46577147 << 4 | z;
        BlockSetEvent event =
                BlockSetEvent.builder()
                        .world(f_46737896).chunk(this)
                        .x(worldX).y(y).z(worldZ)
                        .blockState(state).blockMeta(meta)
                        .overrideState(state).overrideMeta(meta)
                        .build();
        if (StationAPI.EVENT_BUS.post(event).isCanceled()) return null;
        state = event.overrideState;
        meta = event.overrideMeta;
        ChunkSection section = getOrCreateSection(y, true);
        if (section == null) return null;
        boolean sameMeta = section.getMeta(x, y & 15, z) == meta;
        short var6 = getShortHeight(x, z);
        BlockState oldState = section.getBlockState(x, y & 15, z);
        if (oldState == state && sameMeta) return null;

        C_81592558 oldBlock = oldState.getBlock();
        if (
                StationAPI.EVENT_BUS.post(BlockEvent.BeforeRemoved.builder()
                        .block(oldBlock)
                        .world(f_46737896)
                        .x(worldX).y(y).z(worldZ)
                        .build()
                ).isCanceled()
        ) return null;
        section.setBlockState(x, y & 15, z, state);
        if (!f_46737896.f_50876584)
            oldState.onStateReplaced(f_46737896, CACHED_BLOCK_POS.get().set(worldX, y, worldZ), state);
        section.setMeta(x, y & 15, z, meta);

        if (!this.f_46737896.f_00524883.f_98952613) {
            if (C_81592558.f_43623251[state.getBlock().f_84602679] != 0) {
                if (y >= var6)
                    this.m_05909487(x, y + 1, z);
            } else if (y == var6 - 1)
                this.m_05909487(x, y, z);

            this.f_46737896.m_54335440(C_92766678.f_02629467, worldX, y, worldZ, worldX, y, worldZ);
        }

        this.f_46737896.m_54335440(C_92766678.f_19924308, worldX, y, worldZ, worldX, y, worldZ);
        ((ChunkAccessor) this).invokeLightGaps(x, z);
        section.setMeta(x, y & 15, z, meta);
        state.getBlock().onBlockPlaced(this.f_46737896, worldX, y, worldZ, oldState);

        this.f_12808704 = true;
        return oldState;
    }

    @Override
    public BlockState setBlockState(int x, int y, int z, BlockState state) {
        int worldX = this.f_61945954 << 4 | x;
        int worldZ = this.f_46577147 << 4 | z;
        if (
                StationAPI.EVENT_BUS.post(
                        BlockSetEvent.builder()
                                .world(f_46737896).chunk(this)
                                .x(worldX).y(y).z(worldZ)
                                .blockState(state)
                                .build()
                ).isCanceled()
        ) return null;
        ChunkSection section = getOrCreateSection(y, true);
        if (section == null) return null;
        BlockState oldState = section.getBlockState(x, y & 15, z);
        if (oldState == state) return null;

        short topY = getShortHeight(x, z);
        C_81592558 oldBlock = oldState.getBlock();
        if (
                StationAPI.EVENT_BUS.post(BlockEvent.BeforeRemoved.builder()
                        .block(oldBlock)
                        .world(f_46737896)
                        .x(worldX).y(y).z(worldZ)
                        .build()
                ).isCanceled()
        ) return null;
        section.setBlockState(x, y & 15, z, state);
        oldState.onStateReplaced(f_46737896, CACHED_BLOCK_POS.get().set(worldX, y, worldZ), state);
        section.setMeta(x, y & 15, z, 0);
        if (C_81592558.f_43623251[state.getBlock().f_84602679] != 0) {
            if (y >= topY)
                this.m_05909487(x, y + 1, z);
        } else if (y == topY - 1)
            this.m_05909487(x, y, z);
        this.f_46737896.m_54335440(C_92766678.f_02629467, worldX, y, worldZ, worldX, y, worldZ);
        this.f_46737896.m_54335440(C_92766678.f_19924308, worldX, y, worldZ, worldX, y, worldZ);
        ((ChunkAccessor) this).invokeLightGaps(x, z);
        if (!this.f_46737896.f_50876584) {
            state.getBlock().onBlockPlaced(this.f_46737896, worldX, y, worldZ, oldState);
        }

        this.f_12808704 = true;
        return oldState;
    }

    @Override
    public void m_11127416(C_42232651 entity) {
        int n;
        this.f_39795280 = true;
        int n2 = C_45510667.m_80489169(entity.f_78826675 / 16.0);
        int n3 = C_45510667.m_80489169(entity.f_97691941 / 16.0);
        if (n2 != this.f_61945954 || n3 != this.f_46577147) {
            System.out.println("Wrong location! " + entity);
            Thread.dumpStack();
        }
        if ((n = C_45510667.m_80489169((entity.f_31030949 - f_46737896.getBottomY()) / 16.0)) < 0) {
            n = 0;
        }
        if (n >= this.f_00508683.length) {
            n = this.f_00508683.length - 1;
        }
        entity.f_68256007 = true;
        entity.f_04365121 = this.f_61945954;
        entity.f_41825647 = n;
        entity.f_49167582 = this.f_46577147;
        //noinspection unchecked
        this.f_00508683[n].add(entity);
    }

    @Override
    public void m_98719212(C_42232651 entity, C_82690114 box, List entities) {
        int n = C_45510667.m_80489169((box.f_80314167 - f_46737896.getBottomY() - 2.0) / 16.0);
        int n2 = C_45510667.m_80489169((box.f_98553650 - f_46737896.getBottomY() + 2.0) / 16.0);
        if (n < 0) {
            n = 0;
        }
        if (n2 >= this.f_00508683.length) {
            n2 = this.f_00508683.length - 1;
        }
        for (int i = n; i <= n2; ++i) {
            //noinspection unchecked
            List<C_42232651> list2 = this.f_00508683[i];
            for (int j = 0; j < list2.size(); ++j) {
                C_42232651 entityBase = list2.get(j);
                if (entityBase == entity || !entityBase.f_00583773.m_39770760(box)) continue;
                //noinspection unchecked
                entities.add(entityBase);
            }
        }
    }

    @Override
    public void m_27520804(Class class_, C_82690114 arg, List list) {
        int n = C_45510667.m_80489169((arg.f_80314167 - f_46737896.getBottomY() - 2.0) / 16.0);
        int n2 = C_45510667.m_80489169((arg.f_98553650 - f_46737896.getBottomY() + 2.0) / 16.0);
        if (n < 0) {
            n = 0;
        }
        if (n2 >= this.f_00508683.length) {
            n2 = this.f_00508683.length - 1;
        }
        for (int i = n; i <= n2; ++i) {
            //noinspection unchecked
            List<C_42232651> list2 = this.f_00508683[i];
            for (int j = 0; j < list2.size(); ++j) {
                C_42232651 entityBase = list2.get(j);
                //noinspection unchecked
                if (!class_.isAssignableFrom(entityBase.getClass()) || !entityBase.f_00583773.m_39770760(arg)) continue;
                //noinspection unchecked
                list.add(entityBase);
            }
        }
    }

    @Override
    public void m_02358196() {}

    @Override
    public void m_74010736(int relX, int relY, int relZ, C_40735137 arg) {
        C_32594356 tilePos = new C_32594356(relX, relY, relZ);
        arg.f_18133822 = this.f_46737896;
        arg.f_07118142 = this.f_61945954 * 16 + relX;
        arg.f_33969464 = relY;
        arg.f_77944174 = this.f_46577147 * 16 + relZ;
        if (this.m_55540380(relX, relY, relZ) == 0 || !C_81592558.f_72646756[this.m_55540380(relX, relY, relZ)]) {
            System.out.println("Attempted to place a tile entity where there was no entity tile!");
            return;
        }
        arg.m_70502155();
        //noinspection unchecked
        this.f_39463725.put(tilePos, arg);
    }
}
