package net.modificationstation.stationapi.api.nbt;

import com.google.common.collect.ImmutableMap;
import net.minecraft.unmapped.C_74087615;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.block.States;
import net.modificationstation.stationapi.api.registry.*;
import net.modificationstation.stationapi.api.state.State;
import net.modificationstation.stationapi.api.state.StateManager;
import net.modificationstation.stationapi.api.state.property.Property;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.mixin.nbt.NbtCompoundAccessor;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static net.modificationstation.stationapi.api.StationAPI.LOGGER;

public class FlatteningNbtHelper {
    /**
     * {@return the block state from the {@code nbt}}
     *
     * <p>This returns the default state for {@link States#AIR}
     * if the block name is not present.
     *
     * @see #fromBlockState(BlockState)
     */
    public static BlockState toBlockState(RegistryEntryLookup<C_81592558> blockLookup, C_74087615 nbt) {
        if (!nbt.m_97612750("Name")) return States.AIR.get();
        Identifier identifier = Identifier.of(nbt.m_47517355("Name"));
        Optional<RegistryEntry.Reference<C_81592558>> optional = blockLookup.getOptional(RegistryKey.of(BlockRegistry.KEY, identifier));
        if (optional.isEmpty()) {
            return States.AIR.get();
        }
        C_81592558 block = optional.get().value();
        BlockState blockState = block.getDefaultState();
        if (nbt.m_97612750("Properties")) {
            C_74087615 nbtCompound = nbt.m_81819352("Properties");
            StateManager<C_81592558, BlockState> stateManager = block.getStateManager();
            for (String string : ((NbtCompoundAccessor) nbtCompound).stationapi$getEntries().keySet()) {
                Property<?> property = stateManager.getProperty(string);
                if (property == null) continue;
                blockState = withProperty(blockState, property, string, nbtCompound, nbt);
            }
        }
        return blockState;
    }

    private static <S extends State<?, S>, T extends Comparable<T>> S withProperty(S state, Property<T> property, String key, C_74087615 properties, C_74087615 root) {
        Optional<T> optional = property.parse(properties.m_47517355(key));
        if (optional.isPresent()) return state.with(property, optional.get());
        LOGGER.warn("Unable to read property: {} with value: {} for blockstate: {}", key, properties.m_47517355(key), root.toString());
        return state;
    }

    /**
     * {@return the serialized block state}
     *
     * @see #toBlockState(RegistryEntryLookup, C_74087615)
     */
    public static C_74087615 fromBlockState(BlockState state) {
        C_74087615 nbtCompound = new C_74087615();
        nbtCompound.m_91017064("Name", Objects.requireNonNull(BlockRegistry.INSTANCE.getId(state.getBlock())).toString());
        ImmutableMap<Property<?>, Comparable<?>> immutableMap = state.getEntries();
        if (!immutableMap.isEmpty()) {
            C_74087615 nbtCompound2 = new C_74087615();
            for (Map.Entry<Property<?>, Comparable<?>> entry : immutableMap.entrySet()) {
                Property<?> property = entry.getKey();
                nbtCompound2.m_91017064(property.getName(), nameValue(property, entry.getValue()));
            }
            nbtCompound.m_18682924("Properties", nbtCompound2);
        }
        return nbtCompound;
    }

    private static <T extends Comparable<T>> String nameValue(Property<T> property, Comparable<?> value) {
        //noinspection unchecked
        return property.name((T) value);
    }
}
