package net.modificationstation.stationapi.mixin.flattening.server;

import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_92666871;
import net.minecraft.unmapped.C_99660737;
import net.modificationstation.stationapi.impl.packet.FlattenedBlockChangeS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_99660737.class)
class ServerPlayNetworkHandlerMixin {
    @Redirect(
            method = {
                    "handlePlayerAction",
                    "onPlayerInteractBlock"
            },
            at = @At(
                    value = "NEW",
                    target = "(IIILnet/minecraft/world/World;)Lnet/minecraft/network/packet/s2c/play/BlockUpdateS2CPacket;"
            )
    )
    private C_92666871 stationapi_flatten(int x, int y, int z, C_64041439 world) {
        return new FlattenedBlockChangeS2CPacket(x, y, z, world);
    }
}
