package net.modificationstation.stationapi.mixin.flattening;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.unmapped.C_23969718;
import net.minecraft.unmapped.C_64041439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(C_23969718.class)
class DoorBlockMixin {
    @ModifyExpressionValue(
            method = "canPlaceAt",
            at = @At(
                    value = "CONSTANT",
                    args = "intValue=127"
            )
    )
    private int stationapi_changeTopYCheck(
            int original,
            @Local(index = 1, argsOnly = true) C_64041439 world
    ) {
        return world.getTopY() - 1;
    }
}
