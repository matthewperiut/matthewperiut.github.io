package net.modificationstation.stationapi.impl.client.network;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_14917579;
import net.minecraft.unmapped.C_34399650;
import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.impl.network.StationFlatteningPacketHandler;
import net.modificationstation.stationapi.impl.packet.FlattenedBlockChangeS2CPacket;
import net.modificationstation.stationapi.impl.packet.FlattenedChunkDataS2CPacket;
import net.modificationstation.stationapi.impl.packet.FlattenedChunkSectionDataS2CPacket;
import net.modificationstation.stationapi.impl.packet.FlattenedMultiBlockChangeS2CPacket;
import net.modificationstation.stationapi.impl.util.math.ChunkSectionPos;
import net.modificationstation.stationapi.impl.world.chunk.FlattenedChunk;

import java.nio.ByteBuffer;

public class FlattenedClientPlayNetworkHandler extends StationFlatteningPacketHandler {

    @Override
    public boolean m_95861517() {
        return false;
    }

    @Override
    public void onMapChunk(FlattenedChunkDataS2CPacket packet) {
        //noinspection deprecation
        C_34399650 world = (C_34399650) ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_26407825;
        int fromX = packet.chunkX << 4;
        int fromZ = packet.chunkZ << 4;
        world.m_67579540(fromX, world.getBottomY(), fromZ, fromX + 15, world.getTopY() - 1, fromZ + 15);
        C_14917579 chunk = world.m_27928573(packet.chunkX, packet.chunkZ);
        if (chunk instanceof FlattenedChunk flatteningChunk) {
            ByteBuffer buf = ByteBuffer.wrap(packet.sectionsData);
            for (int i = 0; i < world.countVerticalSections(); i++)
                flatteningChunk.getOrCreateSection(world.sectionIndexToCoord(i) << 4, true).readDataPacket(buf);
        }
        chunk.m_71750474();
        world.m_76770021(fromX, world.getBottomY(), fromZ, fromX + 16, world.getTopY(), fromZ + 16);
    }

    @Override
    public void onBlockChange(FlattenedBlockChangeS2CPacket packet) {
        //noinspection deprecation
        C_34399650 world = (C_34399650) ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_26407825;
        world.m_67579540(packet.f_33309623, packet.f_67860754, packet.f_09955199, packet.f_33309623, packet.f_67860754, packet.f_09955199);
        world.setBlockState(packet.f_33309623, packet.f_67860754, packet.f_09955199, C_81592558.STATE_IDS.get(packet.stateId), packet.f_47833273);
    }

    @Override
    public void onMultiBlockChange(FlattenedMultiBlockChangeS2CPacket packet) {
        //noinspection deprecation
        C_34399650 world = (C_34399650) ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_26407825;
        C_14917579 chunk = world.m_27928573(packet.f_79481286, packet.f_86949888);
        if (chunk instanceof FlattenedChunk flatteningChunk) {
            flatteningChunk.getOrCreateSection(world.sectionIndexToCoord(packet.sectionIndex), true);
            int
                    x = packet.f_79481286 * 16,
                    y = world.sectionIndexToCoord(packet.sectionIndex) * 16,
                    z = packet.f_86949888 * 16;
            for (int i = 0; i < packet.f_01960917; i++) {
                int localX, localY, localZ;
                {
                    short position = packet.f_04903120[i];
                    localX = ChunkSectionPos.unpackLocalX(position);
                    localY = ChunkSectionPos.unpackLocalY(position);
                    localZ = ChunkSectionPos.unpackLocalZ(position);
                }
                int stateId = packet.stateArray[i];
                byte metadata = packet.f_91311726[i];
                chunk.setBlockState(localX, y + localY, localZ, C_81592558.STATE_IDS.get(stateId), metadata);
                int
                        updateX = x + localX,
                        updateY = y + localY,
                        updateZ = z + localZ;
                world.m_67579540(updateX, updateY, updateZ, updateX, updateY, updateZ);
                world.m_76770021(updateX, updateY, updateZ, updateX, updateY, updateZ);
            }
        }
    }

    @Override
    public void onChunkSection(FlattenedChunkSectionDataS2CPacket packet) {
        //noinspection deprecation
        C_34399650 world = (C_34399650) ((Minecraft) FabricLoader.getInstance().getGameInstance()).f_26407825;
        int fromX = packet.chunkX << 4;
        int fromY = world.sectionIndexToCoord(packet.sectionIndex) << 4;
        int fromZ = packet.chunkZ << 4;
        world.m_67579540(fromX, fromY, fromZ, fromX + 15, fromY + 15, fromZ + 15);
        C_14917579 chunk = world.m_27928573(packet.chunkX, packet.chunkZ);
        if (chunk instanceof FlattenedChunk flatteningChunk) {
            ByteBuffer buf = ByteBuffer.wrap(packet.sectionData);
            flatteningChunk.getOrCreateSection(fromY, true).readDataPacket(buf);
        }
        chunk.m_71750474();
        world.m_76770021(fromX, fromY, fromZ, fromX + 16, fromY + 16, fromZ + 16);
    }
}
