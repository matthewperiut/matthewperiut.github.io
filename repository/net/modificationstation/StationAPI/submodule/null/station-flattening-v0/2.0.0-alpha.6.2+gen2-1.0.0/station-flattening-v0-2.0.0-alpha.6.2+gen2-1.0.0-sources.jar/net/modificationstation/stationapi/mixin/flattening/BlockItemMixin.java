package net.modificationstation.stationapi.mixin.flattening;

import net.mine_diver.unsafeevents.listener.Listener;
import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_71827890;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_82690114;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_94584382;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.block.IsBlockReplaceableEvent;
import net.modificationstation.stationapi.api.event.registry.RegistryIdRemapEvent;
import net.modificationstation.stationapi.api.item.ItemPlacementContext;
import net.modificationstation.stationapi.api.item.StationFlatteningBlockItem;
import net.modificationstation.stationapi.api.registry.BlockRegistry;
import net.modificationstation.stationapi.api.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(C_71827890.class)
class BlockItemMixin extends C_98888256 implements StationFlatteningBlockItem {
    @Shadow private int blockId;
    @Unique private short maxHeight;

    protected BlockItemMixin(int i) {
        super(i);
    }

    @Inject(
            method = "useOnBlock",
            at = @At("HEAD")
    )
    private void stationapi_storeWorld(C_88708284 item, C_40996800 player, C_64041439 world, int x, int y, int z, int facing, CallbackInfoReturnable<Boolean> info) {
        maxHeight = (short) (world.getTopY() - 1);
    }

    @ModifyConstant(
            method = "useOnBlock",
            constant = @Constant(intValue = 127)
    )
    private int stationapi_changeMaxHeight(int value) {
        return maxHeight;
    }

    @Redirect(
            method = "useOnBlock",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/world/World;canPlace(IIIIZI)Z"
            )
    )
    private boolean stationapi_canReplace(
            C_64041439 argWorld, int blockID, int argX, int argY, int argZ, boolean checkCollision, int argSide,
            C_88708284 itemStack, C_40996800 player, C_64041439 world, int x, int y, int z, int side
    ) {
        Direction direction = Direction.byId(side);
        C_82690114 box = C_81592558.f_44428008[blockID].m_03092609(world, x, y, z);
        return (box == null || world.m_52719108(box)) && StationAPI.EVENT_BUS.post(
                IsBlockReplaceableEvent.builder()
                        .context(new ItemPlacementContext(
                                player,
                                itemStack,
                                new C_24654288(
                                        x - direction.getOffsetX(),
                                        y - direction.getOffsetY(),
                                        z - direction.getOffsetZ(),
                                        side, C_94584382.m_35957932(x, y, z)
                                )
                        ))
                        .build()
        ).context.canPlace() && C_81592558.f_44428008[blockID].m_71180744(world, x, y, z, side);
    }

    @Inject(
            method = "<init>",
            at = @At("RETURN")
    )
    private void stationapi_registerCallback(int par1, CallbackInfo ci) {
        BlockRegistry.INSTANCE.getEventBus().register(Listener.<RegistryIdRemapEvent<C_81592558>>simple()
                .listener(event -> blockId = event.state.getRawIdChangeMap().getOrDefault(blockId, blockId))
                .phase(StationAPI.INTERNAL_PHASE)
                .build());
    }

    @Override
    @Unique
    public C_81592558 getBlock() {
        return C_81592558.f_44428008[blockId];
    }

    @Override
    @Unique
    public void setBlock(C_81592558 block) {
        blockId = block.f_84602679;
        m_03402388(block.m_79262324(2));
    }

    @Redirect(
            method = "<init>",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/block/Block;BLOCKS:[Lnet/minecraft/block/Block;",
                    args = "array=get"
            )
    )
    private C_81592558 stationapi_failsafeBlock(C_81592558[] array, int index) {
        return index < 0 ? null : array[index];
    }

    @Redirect(
            method = "<init>",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/Block;getTexture(I)I"
            )
    )
    private int stationapi_failsafeTexture(C_81592558 instance, int i) {
        return instance == null ? 0 : instance.m_79262324(i);
    }
}
