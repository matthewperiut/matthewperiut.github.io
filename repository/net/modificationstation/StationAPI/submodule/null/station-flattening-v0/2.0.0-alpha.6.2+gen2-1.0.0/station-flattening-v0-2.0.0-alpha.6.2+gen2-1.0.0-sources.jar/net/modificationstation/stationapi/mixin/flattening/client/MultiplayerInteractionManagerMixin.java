package net.modificationstation.stationapi.mixin.flattening.client;

import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_34267874;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_45175654;
import net.minecraft.unmapped.C_81592558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_45175654.class)
class MultiplayerInteractionManagerMixin extends C_34267874 {
    private MultiplayerInteractionManagerMixin(Minecraft minecraft) {
        super(minecraft);
    }

    @Redirect(
            method = {
                    "attackBlock(IIII)V",
                    "processBlockBreakingAction(IIII)V"
            },
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/block/Block;getHardness(Lnet/minecraft/entity/player/PlayerEntity;)F"
            )
    )
    private float stationapi_getHardnessPerMeta(C_81592558 block, C_40996800 arg, int i, int j, int k, int i1) {
        return f_17565231.f_26407825.getBlockState(i, j, k).calcBlockBreakingDelta(arg, f_17565231.f_26407825, new C_32594356(i, j, k));
    }
}
