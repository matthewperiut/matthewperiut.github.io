package net.modificationstation.stationapi.mixin.flattening;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.unmapped.C_75615713;
import net.minecraft.unmapped.C_81592558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(C_75615713.class)
class MapItemMixin {
    @ModifyExpressionValue(
            method = "update",
            at = @At(
                    value = "CONSTANT",
                    args = "intValue=256"
            )
    )
    private int stationapi_adjustArray(int constant) {
        return C_81592558.f_44428008.length;
    }
}
