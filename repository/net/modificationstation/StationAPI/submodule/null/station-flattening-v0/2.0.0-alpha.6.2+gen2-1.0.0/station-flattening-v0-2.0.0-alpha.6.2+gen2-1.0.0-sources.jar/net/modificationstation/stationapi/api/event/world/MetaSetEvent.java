package net.modificationstation.stationapi.api.event.world;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.event.Cancelable;
import net.minecraft.unmapped.C_14917579;

@Cancelable
@SuperBuilder
public class MetaSetEvent extends WorldEvent {
    public final C_14917579 chunk;
    public final int
            x, y, z,
            blockMeta;
    public int overrideMeta;
}
