package net.modificationstation.stationapi.api.block;

import net.minecraft.unmapped.C_81592558;
import net.modificationstation.stationapi.api.state.StateManager;

public interface BlockStateHolder {

    StateManager<C_81592558, BlockState> getStateManager();

    BlockState getDefaultState();

    void appendProperties(StateManager.Builder<C_81592558, BlockState> builder);

    void setDefaultState(BlockState state);
}
