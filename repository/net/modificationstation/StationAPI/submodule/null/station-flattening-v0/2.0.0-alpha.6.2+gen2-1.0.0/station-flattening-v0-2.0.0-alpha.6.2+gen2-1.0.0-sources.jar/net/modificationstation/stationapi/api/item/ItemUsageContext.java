package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.block.States;
import net.modificationstation.stationapi.api.util.math.Direction;
import net.modificationstation.stationapi.api.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

public class ItemUsageContext {
    @Nullable
    private final C_40996800 player;
    private final C_24654288 hit;
    private final C_64041439 world;
    private final C_88708284 stack;

    public ItemUsageContext(C_40996800 player, C_24654288 hit) {
        this(player.f_94306729, player, player.m_01577449(), hit);
    }

    protected ItemUsageContext(C_64041439 world, @Nullable C_40996800 player, C_88708284 stack, C_24654288 hit) {
        this.player = player;
        this.hit = hit;
        this.stack = stack;
        this.world = world;
    }

    protected final C_24654288 getHitResult() {
        return this.hit;
    }

    public C_32594356 getBlockPos() {
        return new C_32594356(hit.f_79497105, hit.f_09533029, hit.f_04223298);
    }

    public Direction getSide() {
        return Direction.byId(this.hit.f_72698539);
    }

    public Vec3d getHitPos() {
        return new Vec3d(hit.f_94083482.f_96140729, hit.f_94083482.f_95060918, hit.f_94083482.f_88390642);
    }

    public boolean hitsInsideBlock() {
        return world.getBlockState(C_45510667.m_80489169(hit.f_94083482.f_96140729), C_45510667.m_80489169(hit.f_94083482.f_95060918), C_45510667.m_80489169(hit.f_94083482.f_88390642)) == States.AIR.get();
    }

    public C_88708284 getStack() {
        return this.stack;
    }

    @Nullable
    public C_40996800 getPlayer() {
        return this.player;
    }

    public C_64041439 getWorld() {
        return this.world;
    }

    public Direction getHorizontalPlayerFacing() {
        return this.player == null ? Direction.WEST : Direction.fromRotation(player.f_80130373);
    }

    public boolean shouldCancelInteraction() {
        return this.player != null && this.player.m_40164672();
    }

    public float getPlayerYaw() {
        return this.player == null ? 0.0f : this.player.f_80130373;
    }
}

