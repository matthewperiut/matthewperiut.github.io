package net.modificationstation.stationapi.impl.world;

import net.minecraft.unmapped.C_74087615;
import net.modificationstation.stationapi.api.util.Identifier;

public interface StationWorldProperties {
    C_74087615 getDimensionTag(Identifier id);
}
