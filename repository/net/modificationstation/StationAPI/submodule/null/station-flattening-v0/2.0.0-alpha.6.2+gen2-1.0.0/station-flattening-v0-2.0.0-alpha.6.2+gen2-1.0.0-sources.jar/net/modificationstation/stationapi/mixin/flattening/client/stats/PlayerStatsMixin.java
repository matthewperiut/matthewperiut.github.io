package net.modificationstation.stationapi.mixin.flattening.client.stats;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import net.minecraft.unmapped.C_00535600;
import net.minecraft.unmapped.C_35971787;
import net.minecraft.unmapped.C_49105368;
import net.minecraft.unmapped.C_62649600;
import net.minecraft.unmapped.C_65175111;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.registry.StatRegistry;
import net.modificationstation.stationapi.api.util.Identifier;
import net.modificationstation.stationapi.impl.stat.ModdedStatsSerializingIterator;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.*;

@Mixin(C_00535600.class)
class PlayerStatsMixin {
    @Inject(
            method = "deserialize",
            at = @At(
                    value = "NEW",
                    target = "(Ljava/lang/String;)Lnet/minecraft/util/MD5MessageDigest;"
            )
    )
    private static void stationapi_deserializeModdedStats(
            String data, CallbackInfoReturnable<Map<C_62649600, Integer>> cir,
            @Local(index = 1) HashMap<C_62649600, Integer> statCounts, @Local(index = 4) C_35971787 statsRoot
    ) {
        //noinspection unchecked
        if (
                ((Map<C_65175111, C_49105368>) statsRoot.m_13397220()).keySet()
                        .stream()
                        .map(C_65175111::m_87380439)
                        .noneMatch(ModdedStatsSerializingIterator.STATIONAPI_STATS_CHANGE_KEY::equals)
        ) {
            StationAPI.LOGGER.warn(
                    "Could not find StationAPI stats field. " +
                            "This is fine if it's the first time StationAPI is run on this instance of Minecraft"
            );
            return;
        }
        //noinspection unchecked
        for (final C_49105368 node : (List<C_49105368>) statsRoot.m_10011587(ModdedStatsSerializingIterator.STATIONAPI_STATS_CHANGE_KEY)) {
            @SuppressWarnings("unchecked") final Map<C_65175111, C_49105368> statCountNodes = node.m_13397220();
            final Map.Entry<C_65175111, C_49105368> statCountNode = statCountNodes.entrySet().iterator().next();
            final Identifier statId = Identifier.tryParse(statCountNode.getKey().m_87380439());
            final C_62649600 stat = StatRegistry.INSTANCE.get(statId);
            final int count = Integer.parseInt(statCountNode.getValue().m_87380439());
            if (stat == null)
                System.out.println(statId + " is not a valid stat");
            else
                statCounts.put(stat, count);
        }
    }

    @WrapOperation(
            method = "serialize",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/util/Set;iterator()Ljava/util/Iterator;"
            )
    )
    private static Iterator<C_62649600> stationapi_filterOutModdedStats(
            Set<C_62649600> instance, Operation<Iterator<C_62649600>> original,
            @Local(index = 2, argsOnly = true) Map<C_62649600, Integer> statCounts,
            @Share("moddedStats") LocalRef<StringBuilder> moddedStatsRef
    ) {
        final StringBuilder moddedStats = new StringBuilder();
        moddedStatsRef.set(moddedStats);

        return new ModdedStatsSerializingIterator(original.call(instance), moddedStats, statCounts);
    }

    @Inject(
            method = "serialize",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/lang/StringBuilder;append(Ljava/lang/String;)Ljava/lang/StringBuilder;",
                    ordinal = 17,
                    shift = At.Shift.AFTER
            )
    )
    private static void stationapi_appendModdedStats(
            String playerName, String sessionId, Map<C_62649600, Integer> stats, CallbackInfoReturnable<String> cir,
            @Local(index = 3) StringBuilder statsJson,
            @Share("moddedStats") LocalRef<StringBuilder> moddedStatsRef
    ) {
        statsJson.append(moddedStatsRef.get());
    }
}
