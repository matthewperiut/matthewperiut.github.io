package net.modificationstation.stationapi.impl.block;

import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_94584382;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.event.block.BlockEvent;
import net.modificationstation.stationapi.api.item.ItemPlacementContext;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;

import java.lang.invoke.MethodHandles;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class PlacementStateImpl {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void handleBlockPlacement(BlockEvent.BeforePlacedByItem event) {
        BlockState placementState = event.block.getPlacementState(new ItemPlacementContext(
                event.player,
                event.blockItem,
                new C_24654288(
                        event.x - event.side.getOffsetX(),
                        event.y - event.side.getOffsetY(),
                        event.z - event.side.getOffsetZ(),
                        event.side.getId(), C_94584382.m_35957932(event.x, event.y, event.z)
                )
        ));
        if (placementState != event.block.getDefaultState()) event.placeFunction = () -> event.world.setBlockState(event.x, event.y, event.z, placementState, event.meta) != null;
    }
}
