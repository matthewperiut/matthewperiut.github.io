package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46108969;
import net.modificationstation.stationapi.api.block.BlockState;

public interface ItemStackStrengthWithBlockState {

    boolean isSuitableFor(C_40996800 player, C_46108969 blockView, C_32594356 blockPos, BlockState state);

    float getMiningSpeedMultiplier(C_40996800 player, C_46108969 blockView, C_32594356 blockPos, BlockState state);
}
