package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_24654288;
import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_94584382;
import net.modificationstation.stationapi.api.util.math.Direction;
import org.jetbrains.annotations.Nullable;

public class ItemPlacementContext
extends ItemUsageContext {
    private final C_32594356 placementPos;
    protected boolean canReplaceExisting;

    public ItemPlacementContext(C_40996800 player, C_88708284 stack, C_24654288 hitResult) {
        this(player.f_94306729, player, stack, hitResult);
    }

    public ItemPlacementContext(ItemUsageContext context) {
        this(context.getWorld(), context.getPlayer(), context.getStack(), context.getHitResult());
    }

    protected ItemPlacementContext(C_64041439 world, @Nullable C_40996800 playerEntity, C_88708284 itemStack, C_24654288 blockHitResult) {
        super(world, playerEntity, itemStack, blockHitResult);
        this.placementPos = new C_32594356(blockHitResult.f_79497105, blockHitResult.f_09533029, blockHitResult.f_04223298).offset(Direction.byId(blockHitResult.f_72698539));
        this.canReplaceExisting = world.getBlockState(blockHitResult.f_79497105, blockHitResult.f_09533029, blockHitResult.f_04223298).canReplace(this);
    }

    public static ItemPlacementContext offset(ItemPlacementContext context, C_32594356 pos, Direction side) {
        return new ItemPlacementContext(context.getWorld(), context.getPlayer(), context.getStack(), new C_24654288(pos.getX(), pos.getY(), pos.getZ(), side.getId(), C_94584382.m_35957932(pos.getX() + 0.5 + (double)side.getOffsetX() * 0.5, (double)pos.getY() + 0.5 + (double)side.getOffsetY() * 0.5, (double)pos.getZ() + 0.5 + (double)side.getOffsetZ() * 0.5)));
    }

    @Override
    public C_32594356 getBlockPos() {
        return this.canReplaceExisting ? super.getBlockPos() : this.placementPos;
    }

    public boolean canPlace() {
        return this.canReplaceExisting || this.getWorld().getBlockState(this.getBlockPos()).canReplace(this);
    }

    public boolean canReplaceExisting() {
        return this.canReplaceExisting;
    }

    public Direction getPlayerLookDirection() {
        return Direction.getEntityFacingOrder(this.getPlayer())[0];
    }

    public Direction getVerticalPlayerLookDirection() {
        return Direction.getLookDirectionForAxis(this.getPlayer(), Direction.Axis.Y);
    }

    public Direction[] getPlacementDirections() {
        int i;
        Direction[] directions = Direction.getEntityFacingOrder(this.getPlayer());
        if (this.canReplaceExisting) {
            return directions;
        }
        Direction direction = this.getSide();
        i = 0;
        while (i < directions.length && directions[i] != direction.getOpposite()) {
            ++i;
        }
        if (i > 0) {
            System.arraycopy(directions, 0, directions, 1, i);
            directions[0] = direction.getOpposite();
        }
        return directions;
    }
}

