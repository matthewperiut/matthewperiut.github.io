package net.modificationstation.stationapi.api.world;

import net.minecraft.unmapped.C_32594356;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.util.Util;

public interface StationFlatteningWorld extends BlockStateView, HeightLimitView {

    @Override
    default BlockState getBlockState(int x, int y, int z) {
        return Util.assertImpl();
    }

    default BlockState setBlockStateWithoutNotifyingNeighbors(int x, int y, int z, BlockState blockState) {
        return Util.assertImpl();
    }

    default BlockState setBlockState(int x, int y, int z, BlockState blockState) {
        return Util.assertImpl();
    }

    default BlockState setBlockStateWithoutNotifyingNeighbors(int x, int y, int z, BlockState blockState, int meta) {
        return Util.assertImpl();
    }

    default BlockState setBlockStateWithoutNotifyingNeighbors(C_32594356 pos, BlockState blockState) {
        return setBlockStateWithoutNotifyingNeighbors(pos.f_06162490, pos.f_08824702, pos.f_31865394, blockState);
    }

    default BlockState setBlockState(C_32594356 pos, BlockState blockState) {
        return setBlockState(pos.f_06162490, pos.f_08824702, pos.f_31865394, blockState);
    }

    default BlockState setBlockState(int x, int y, int z, BlockState blockState, int meta) {
        return Util.assertImpl();
    }

    @Override
    default int getHeight() {
        return Util.assertImpl();
    }

    @Override
    default int getBottomY() {
        return Util.assertImpl();
    }
}
