package net.modificationstation.stationapi.api.item;

import net.minecraft.unmapped.C_32594356;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_46108969;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.block.BlockState;
import net.modificationstation.stationapi.api.registry.RegistryEntry;
import net.modificationstation.stationapi.api.tag.TagKey;
import net.modificationstation.stationapi.api.util.Util;

public interface StationFlatteningItemStack extends ItemStackStrengthWithBlockState {

    default RegistryEntry.Reference<C_98888256> getRegistryEntry() {
        return Util.assertImpl();
    }

    default boolean isIn(TagKey<C_98888256> tag) {
        return getRegistryEntry().isIn(tag);
    }

    @Override
    default boolean isSuitableFor(C_40996800 player, C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return Util.assertImpl();
    }

    @Override
    default float getMiningSpeedMultiplier(C_40996800 player, C_46108969 blockView, C_32594356 blockPos, BlockState state) {
        return Util.assertImpl();
    }

    /**
     * {@return whether the item is {@code item}}
     */
    default boolean isOf(C_98888256 item) {
        return Util.assertImpl();
    }
}
