package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(C_42232651.class)
class EntityMixin {
    @Shadow public C_64041439 world;

    @ModifyConstant(
            method = "baseTick()V",
            constant = @Constant(doubleValue = -64)
    )
    private double stationapi_modifyVoidDamage(double constant) {
        return constant + world.getBottomY();
    }
}
