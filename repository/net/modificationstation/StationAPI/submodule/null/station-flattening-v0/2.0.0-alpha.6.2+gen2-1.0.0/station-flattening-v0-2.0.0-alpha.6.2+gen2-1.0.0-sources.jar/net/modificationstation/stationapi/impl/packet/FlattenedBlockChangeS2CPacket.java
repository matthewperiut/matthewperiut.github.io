package net.modificationstation.stationapi.impl.packet;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.unmapped.C_10918870;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_92666871;
import net.modificationstation.stationapi.api.network.packet.ManagedPacket;
import net.modificationstation.stationapi.api.network.packet.PacketType;
import net.modificationstation.stationapi.impl.network.StationFlatteningPacketHandler;
import org.jetbrains.annotations.NotNull;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class FlattenedBlockChangeS2CPacket extends C_92666871 implements ManagedPacket<FlattenedBlockChangeS2CPacket> {
    public static final PacketType<FlattenedBlockChangeS2CPacket> TYPE = PacketType.builder(true, false, FlattenedBlockChangeS2CPacket::new).build();

    public int stateId;

    private FlattenedBlockChangeS2CPacket() {}

    @Environment(EnvType.SERVER)
    public FlattenedBlockChangeS2CPacket(int x, int y, int z, C_64041439 world) {
        this.f_33309623 = x;
        this.f_67860754 = y;
        this.f_09955199 = z;
        stateId = C_81592558.STATE_IDS.getRawId(world.getBlockState(x, y, z));
        f_47833273 = (byte) world.m_06541281(x, y, z);
    }

    @Override
    public void m_13296744(DataInputStream in) {
        try {
            f_33309623 = in.readInt();
            f_67860754 = in.readShort();
            f_09955199 = in.readInt();
            stateId = in.readInt();
            f_47833273 = in.read();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_17566769(DataOutputStream out) {
        try {
            out.writeInt(f_33309623);
            out.writeShort(f_67860754);
            out.writeInt(f_09955199);
            out.writeInt(stateId);
            out.write(f_47833273);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void m_04853589(C_10918870 handler) {
        ((StationFlatteningPacketHandler) handler).onBlockChange(this);
    }

    @Override
    public int m_85604015() {
        return 15;
    }

    @Override
    public @NotNull PacketType<FlattenedBlockChangeS2CPacket> getType() {
        return TYPE;
    }
}
