package net.modificationstation.stationapi.mixin.flattening;

import net.minecraft.unmapped.C_89060550;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(C_89060550.class)
public interface RegionFileAccessor {
    @Accessor
    int[] getChunkBlockInfo();
}
