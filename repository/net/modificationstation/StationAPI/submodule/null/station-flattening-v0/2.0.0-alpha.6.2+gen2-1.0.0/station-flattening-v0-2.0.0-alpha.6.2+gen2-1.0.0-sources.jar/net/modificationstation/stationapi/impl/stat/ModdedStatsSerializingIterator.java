package net.modificationstation.stationapi.impl.stat;

import net.minecraft.unmapped.C_62649600;
import net.modificationstation.stationapi.api.util.Namespace;

import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;

/**
 * Iterates over a set of stats, filtering out modded ones and serializing them separately.
 */
public final class ModdedStatsSerializingIterator implements Iterator<C_62649600> {
    public static final String STATIONAPI_STATS_CHANGE_KEY = NAMESPACE.id("stats-change").toString();

    private final Iterator<C_62649600> source;
    private final StringBuilder moddedStatsSerialized;
    private final Map<C_62649600, Integer> statCounts;

    private C_62649600 nextVanillaStat;
    private boolean firstModdedStat = true;

    public ModdedStatsSerializingIterator(
            Iterator<C_62649600> source, StringBuilder moddedStatsSerialized, Map<C_62649600, Integer> statCounts
    ) {
        this.source = source;
        this.moddedStatsSerialized = moddedStatsSerialized;
        this.statCounts = statCounts;

        moddedStatsSerialized.append("  \"").append(STATIONAPI_STATS_CHANGE_KEY).append("\":[");

        advance();
    }

    /**
     * Searches for the next vanilla stat in the set and serializes all modded stats found on the way.
     */
    private void advance() {
        nextVanillaStat = null;

        // Searching for the next vanilla stat in the set
        // and serializing all modded stats found on the way
        while (source.hasNext()) {
            C_62649600 candidate = source.next();

            if (candidate.getRegistryEntry().registryKey().getValue().namespace == Namespace.MINECRAFT) {
                nextVanillaStat = candidate;
                return;
            }

            serializeModded(candidate);
        }
    }

    /**
     * Serializes the given stat under the modded stats array.
     *
     * @param stat the stat to serialize under the modded stats array
     */
    private void serializeModded(C_62649600 stat) {
        if (!firstModdedStat) moddedStatsSerialized.append("},");
        else firstModdedStat = false;

        moddedStatsSerialized.append("\r\n    {\"");
        moddedStatsSerialized.append(stat.getRegistryEntry().registryKey().getValue()).append("\":").append(statCounts.get(stat));
    }

    @Override
    public boolean hasNext() {
        if (nextVanillaStat != null)
            return true;

        // If there are no more stats from the source iterator,
        // finish serializing modded stats and terminate the loop
        if (!firstModdedStat)
            moddedStatsSerialized.append("}");
        moddedStatsSerialized.append("\r\n  ],\r\n");
        return false;
    }

    /**
     * Returns the next vanilla {@link C_62649600} and advances the source iterator via {@link #advance()}.
     *
     * @return the next vanilla {@link C_62649600} from the source iterator
     * @throws NoSuchElementException if there are no more vanilla stats
     */
    @Override
    public C_62649600 next() {
        if (nextVanillaStat == null) throw new NoSuchElementException();

        final C_62649600 stat = nextVanillaStat;
        advance();
        return stat;
    }
}
