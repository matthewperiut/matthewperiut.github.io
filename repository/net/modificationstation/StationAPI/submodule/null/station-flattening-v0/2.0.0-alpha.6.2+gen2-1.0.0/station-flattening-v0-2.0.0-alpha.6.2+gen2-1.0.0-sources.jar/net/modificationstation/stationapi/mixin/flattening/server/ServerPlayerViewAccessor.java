package net.modificationstation.stationapi.mixin.flattening.server;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.List;
import net.minecraft.unmapped.C_17889813;

@Mixin(C_17889813.class)
public interface ServerPlayerViewAccessor {
    @Accessor
    List<C_17889813.net/minecraft/unmapped/C_38385548> getChunksToUpdate();
}
