package net.modificationstation.stationapi.api.registry.sync.trackers.vanilla;

import net.mine_diver.unsafeevents.listener.EventListener;
import net.mine_diver.unsafeevents.listener.Listener;
import net.minecraft.unmapped.C_71827890;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.event.registry.RegistryEntryAddedEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.registry.ListenableRegistry;
import net.modificationstation.stationapi.api.registry.Registry;

import java.lang.invoke.MethodHandles;

public final class BlockItemTracker {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    private BlockItemTracker() { }

    public static <R extends Registry<C_98888256> & ListenableRegistry> void register(R registry) {
        BlockItemTracker tracker = new BlockItemTracker();
        registry.getEventBus().register(Listener.object().listener(tracker).build());
    }

    @EventListener
    private void onEntryAdded(RegistryEntryAddedEvent<C_98888256> event) {
        if (event.object instanceof C_71827890 blockItem)
            blockItem.appendBlocks(C_98888256.BLOCK_ITEMS, event.object);
    }
}
