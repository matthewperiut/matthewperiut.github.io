package net.modificationstation.stationapi.mixin.flattening.server;

import net.minecraft.unmapped.C_49202226;
import net.minecraft.unmapped.C_62858513;
import net.minecraft.unmapped.C_64041439;
import net.modificationstation.stationapi.impl.packet.FlattenedChunkDataS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(C_49202226.class)
class ServerPlayerEntityMixin {
    @Redirect(
            method = "playerTick",
            at = @At(
                    value = "NEW",
                    target = "(IIIIIILnet/minecraft/world/World;)Lnet/minecraft/network/packet/s2c/play/ChunkDataS2CPacket;"
            )
    )
    private C_62858513 stationapi_catchParams(int i, int j, int k, int l, int m, int n, C_64041439 arg) {
        return new FlattenedChunkDataS2CPacket(arg, i >> 4, k >> 4);
    }
}
