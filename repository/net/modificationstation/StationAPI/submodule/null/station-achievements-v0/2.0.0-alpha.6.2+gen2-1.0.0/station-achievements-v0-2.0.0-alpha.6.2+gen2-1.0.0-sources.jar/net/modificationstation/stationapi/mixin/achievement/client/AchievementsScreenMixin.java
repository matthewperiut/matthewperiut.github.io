package net.modificationstation.stationapi.mixin.achievement.client;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.unmapped.C_15891356;
import net.minecraft.unmapped.C_76536438;
import net.minecraft.unmapped.C_85125467;
import net.minecraft.unmapped.C_85740840;
import net.minecraft.unmapped.C_90931970;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.event.gui.screen.achievement.AchievementsScreenEvent;
import net.modificationstation.stationapi.api.client.gui.screen.achievement.AchievementPage;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Random;

import static net.minecraft.unmapped.C_95236836.f_26482299;
import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;

@Mixin(C_15891356.class)
class AchievementsScreenMixin extends C_85740840 {
    @Unique
    private static final int
            STATIONAPI$PREV_BUTTON_ID = NAMESPACE.id("prev").hashCode(),
            STATIONAPI$NEXT_BUTTON_ID = NAMESPACE.id("next").hashCode();


    @SuppressWarnings("unchecked")
    @Inject(
            method = "init",
            at = @At("TAIL")
    )
    private void stationapi_initPrevNext(CallbackInfo ci) {
        // Prev and next buttons.
        if (AchievementPage.getPageCount() <= 1) return;
        this.f_78519977.add(new C_85125467(STATIONAPI$PREV_BUTTON_ID, this.f_05230747 / 2 - 113, this.f_07021018 / 2 + 74, 20, 20, "<"));
        this.f_78519977.add(new C_85125467(STATIONAPI$NEXT_BUTTON_ID, this.f_05230747 / 2 - 93, this.f_07021018 / 2 + 74, 20, 20, ">"));
    }

    @Inject(
            method = "buttonClicked",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screen/Screen;buttonClicked(Lnet/minecraft/client/gui/widget/ButtonWidget;)V"
            )
    )
    private void stationapi_buttonClickedNextPrev(C_85125467 button, CallbackInfo ci) {
        if (button.f_92999450 == STATIONAPI$PREV_BUTTON_ID) AchievementPage.prevPage();
        else if (button.f_92999450 == STATIONAPI$NEXT_BUTTON_ID) AchievementPage.nextPage();
    }

    @Inject(
            method = "setTitle",
            at = @At("TAIL")
    )
    private void stationapi_doDrawTitle(CallbackInfo ci) {
        if (AchievementPage.getPageCount() > 1) this.f_11884601.m_72964882(
                C_76536438.m_79832914("gui." + NAMESPACE + ".achievementPage." + AchievementPage.getCurrentPageName()),
                this.f_05230747 / 2 - 69, this.f_07021018 / 2 + 80, 0
        );
    }

    @ModifyVariable(
            method = "renderIcons",
            index = 26,
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/block/Block;textureId:I",
                    opcode = Opcodes.GETFIELD,
                    ordinal = 7,
                    shift = At.Shift.BY,
                    by = 3
            )
    )
    private int stationapi_renderBackgroundTexture(
            int var26,
            @Local(index = 21) Random random,
            @Local(index = 12) int baseColumn, @Local(index = 24) int deltaColumn,
            @Local(index = 13) int baseRow, @Local(index = 22) int deltaRow,
            @Local(index = 25) int randomizedRow
    ) {
        //noinspection DataFlowIssue
        return StationAPI.EVENT_BUS.post(
                AchievementsScreenEvent.BackgroundTextureRender.builder()
                        .achievementsScreen((C_15891356) (Object) this)
                        .random(random)
                        .column(baseColumn + deltaColumn)
                        .row(baseRow + deltaRow)
                        .randomizedRow(randomizedRow)
                        .backgroundTexture(var26)
                        .build()
        ).backgroundTexture;
    }

    @Redirect(
            method = "renderIcons",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/achievement/Achievement;parent:Lnet/minecraft/achievement/Achievement;",
                    opcode = Opcodes.GETFIELD,
                    ordinal = 0
            )
    )
    private C_90931970 stationapi_overrideLineRender(C_90931970 achievement) {
        //noinspection DataFlowIssue
        return StationAPI.EVENT_BUS.post(
                AchievementsScreenEvent.LineRender.builder()
                        .achievementsScreen((C_15891356) (Object) this)
                        .achievement(achievement)
                        .build()
        ).isCanceled() ? null : achievement.f_26077448;
    }

    @ModifyConstant(
            method = "renderIcons",
            constant = @Constant(
                    intValue = 0,
                    ordinal = 4
            )
    )
    private int stationapi_onForLoopStart(int i) {
        return stationapi_onRenderAchievement(i);
    }

    @ModifyVariable(
            method = "renderIcons",
            index = 14,
            at = @At(
                    value = "INVOKE",
                    target = "Lorg/lwjgl/opengl/GL11;glDisable(I)V",
                    ordinal = 4,
                    shift = At.Shift.BY,
                    by = -4,
                    remap = false
            )
    )
    private int stationapi_onNextForIteration(int i) {
        return stationapi_onRenderAchievement(i);
    }

    @Unique
    private int stationapi_onRenderAchievement(int achievementOrdinal) {
        //noinspection DataFlowIssue
        while (
                achievementOrdinal < f_26482299.size() && StationAPI.EVENT_BUS.post(
                        AchievementsScreenEvent.AchievementIconRender.builder()
                                .achievementsScreen((C_15891356) (Object) this)
                                .achievement((C_90931970) f_26482299.get(achievementOrdinal))
                                .build()
                ).isCanceled()
        )
            achievementOrdinal++;
        return achievementOrdinal;
    }
}
