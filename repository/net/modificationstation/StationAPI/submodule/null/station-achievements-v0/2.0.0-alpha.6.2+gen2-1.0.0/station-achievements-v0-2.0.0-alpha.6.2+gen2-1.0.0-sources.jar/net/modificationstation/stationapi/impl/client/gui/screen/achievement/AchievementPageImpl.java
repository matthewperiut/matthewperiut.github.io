package net.modificationstation.stationapi.impl.client.gui.screen.achievement;

import net.fabricmc.loader.api.FabricLoader;
import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_90931970;
import net.minecraft.unmapped.C_95236836;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.event.gui.screen.achievement.AchievementsScreenEvent;
import net.modificationstation.stationapi.api.client.gui.screen.achievement.AchievementPage;
import net.modificationstation.stationapi.api.event.achievement.AchievementRegisterEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;

import java.lang.invoke.MethodHandles;
import java.util.List;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public class AchievementPageImpl {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void replaceBackgroundTexture(AchievementsScreenEvent.BackgroundTextureRender event) {
        event.backgroundTexture = AchievementPage.getCurrentPage().getBackgroundTexture(event.random, event.column, event.row, event.randomizedRow, event.backgroundTexture);
    }

    @EventListener
    private static void registerAchievements(AchievementRegisterEvent event) {
        AchievementPage page = new AchievementPage(NAMESPACE.id("minecraft"));
        //noinspection unchecked
        page.addAchievements(((List<C_90931970>) C_95236836.f_26482299).toArray(C_90931970[]::new));
    }

    @EventListener
    private static void renderAchievementIcon(AchievementsScreenEvent.AchievementIconRender event) {
        if (!isVisibleAchievement(event.achievement)) event.cancel();
    }

    private static boolean isVisibleAchievement(C_90931970 achievement) {
        return !checkHidden(achievement) && AchievementPage.getCurrentPage().getAchievements().contains(achievement);
    }

    @EventListener
    private static void renderAchievementsLine(AchievementsScreenEvent.LineRender event) {
        if (!(event.achievement.f_26077448 != null && isVisibleAchievement(event.achievement) && isVisibleAchievement(event.achievement.f_26077448)))
            event.cancel();
    }

    private static boolean checkHidden(C_90931970 achievement) {
        //noinspection deprecation
        return !((Minecraft) FabricLoader.getInstance().getGameInstance()).f_25215102.m_46015567(achievement)
                && achievement.f_26077448 != null && checkHidden(achievement.f_26077448);
    }
}
