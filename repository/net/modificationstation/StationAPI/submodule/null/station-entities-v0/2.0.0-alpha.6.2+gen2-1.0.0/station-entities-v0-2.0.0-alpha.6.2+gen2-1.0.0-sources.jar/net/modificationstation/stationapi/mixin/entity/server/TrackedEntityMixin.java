package net.modificationstation.stationapi.mixin.entity.server;

import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_77505663;
import net.modificationstation.stationapi.api.server.entity.CustomSpawnDataProvider;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.io.IOException;

@Mixin(C_77505663.class)
class TrackedEntityMixin {
    @Shadow
    public C_42232651 currentTrackedEntity;

    @Inject(
            method = "createAddEntityPacket",
            at = @At("HEAD"),
            cancellable = true
    )
    private void stationapi_getSpawnData(CallbackInfoReturnable<C_03562565> cir) {
        if (this.currentTrackedEntity instanceof CustomSpawnDataProvider provider)
            cir.setReturnValue(provider.getSpawnData());
    }
}
