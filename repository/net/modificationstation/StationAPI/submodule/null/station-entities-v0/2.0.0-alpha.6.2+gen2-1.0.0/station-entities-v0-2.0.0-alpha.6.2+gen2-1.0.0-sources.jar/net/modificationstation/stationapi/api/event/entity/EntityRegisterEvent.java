package net.modificationstation.stationapi.api.event.entity;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_42232651;
import net.modificationstation.stationapi.api.util.Identifier;

@SuperBuilder
public class EntityRegisterEvent extends Event {
    @FunctionalInterface
    public interface RegisterFunction {
        void register(Class<? extends C_42232651> entityClass, Identifier entityIdentifier);
    }

    public final RegisterFunction register;

    public final void register(Identifier entityIdentifier, Class<? extends C_42232651> entityClass) {
        register.register(entityClass, entityIdentifier);
    }
}
