package net.modificationstation.stationapi.mixin.entity.server;

import net.minecraft.unmapped.C_31402669;
import net.minecraft.unmapped.C_42042215;
import net.minecraft.unmapped.C_42232651;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.server.event.entity.TrackEntityEvent;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_42042215.class)
class ServerEntityTrackerMixin {
    @Shadow private C_31402669 entriesById;

    @Inject(
            method = "onEntityAdded",
            at = @At("RETURN")
    )
    private void stationapi_afterVanillaEntries(C_42232651 arg, CallbackInfo ci) {
        //noinspection DataFlowIssue
        StationAPI.EVENT_BUS.post(
                TrackEntityEvent.builder()
                        .entityTracker((C_42042215) (Object) this)
                        .trackedEntities(entriesById)
                        .entityToTrack(arg)
                        .build()
        );
    }
}
