package net.modificationstation.stationapi.api.client.entity.factory;

import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_64041439;

public interface EntityWorldAndPosFactory {
    C_42232651 create(C_64041439 world, double x, double y, double z);
}
