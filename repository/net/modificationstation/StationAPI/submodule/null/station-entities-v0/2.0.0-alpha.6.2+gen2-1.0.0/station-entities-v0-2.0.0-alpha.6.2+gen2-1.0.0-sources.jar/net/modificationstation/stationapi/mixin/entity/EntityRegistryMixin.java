package net.modificationstation.stationapi.mixin.entity;

import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_72103717;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.entity.EntityRegisterEvent;
import net.modificationstation.stationapi.api.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;

@Mixin(C_72103717.class)
class EntityRegistryMixin {

    @Shadow private static Map<String, Class<? extends C_42232651>> idToClass;

    @Shadow private static Map<Class<? extends C_42232651>, String> classToId;

    @Inject(method = "<clinit>", at = @At("RETURN"))
    private static void stationapi_onEntityRegister(CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(
                EntityRegisterEvent.builder()
                        .register((entityClass, entityIdentifier) -> {
                            if (idToClass.containsKey(entityIdentifier.toString())) {
                                throw new RuntimeException("Duplicate entity identifier " + entityIdentifier);
                            }

                            classToId.put(entityClass, entityIdentifier.toString());
                            idToClass.put(entityIdentifier.toString(), entityClass);
                        })
                        .build()
        );
    }
}
