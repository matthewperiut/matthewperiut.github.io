package net.modificationstation.stationapi.mixin.entity;

import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_70943525;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.api.util.Util;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_70943525.class)
public interface EntityTypeAccessor {
    @Invoker("<init>")
    static C_70943525 stationapi_create(String typeName, int id, Class<? extends C_42232651> typeSuperClass, int unusedInt, C_89604096 spawnMaterial, boolean unusedBoolean) {
        return Util.assertMixin();
    }
}
