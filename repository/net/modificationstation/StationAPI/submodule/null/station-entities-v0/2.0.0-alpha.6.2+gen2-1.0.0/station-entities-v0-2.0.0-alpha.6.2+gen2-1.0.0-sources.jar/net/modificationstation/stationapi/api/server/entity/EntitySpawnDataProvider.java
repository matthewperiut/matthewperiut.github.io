package net.modificationstation.stationapi.api.server.entity;

import com.google.common.primitives.Doubles;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_45510667;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.entity.HasOwner;
import net.modificationstation.stationapi.api.network.packet.MessagePacket;
import net.modificationstation.stationapi.api.util.Identifier;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public interface EntitySpawnDataProvider extends StationSpawnDataProvider {

    @Override
    default C_03562565 getSpawnData() {
        C_42232651 entity = (C_42232651) this;
        int ownerId = 0;
        if (entity instanceof HasOwner hasOwner) {
            C_42232651 owner = hasOwner.getOwner();
            owner = owner == null ? entity : owner;
            ownerId = owner.f_11112215;
        }
        MessagePacket message = new MessagePacket(Identifier.of(StationAPI.NAMESPACE, "spawn_entity"));
        message.strings = new String[] { getHandlerIdentifier().toString() };
        message.ints = new int[] { entity.f_11112215, C_45510667.m_80489169(entity.f_78826675 * 32), C_45510667.m_80489169(entity.f_31030949 * 32), C_45510667.m_80489169(entity.f_97691941 * 32), ownerId };
        if (ownerId > 0) {
            double var10 = 3.9D;
            message.shorts = new short[] { (short) (Doubles.constrainToRange(entity.f_24826402, -var10, var10) * 8000), (short) (Doubles.constrainToRange(entity.f_35148123, -var10, var10) * 8000), (short) (Doubles.constrainToRange(entity.f_21201587, -var10, var10) * 8000) };
        }
        if (syncTrackerAtSpawn()) {
            var stream = new ByteArrayOutputStream();
            try {
                entity.m_82885919().m_08569472(new DataOutputStream(stream));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            message.bytes = stream.toByteArray();
        }
        writeToMessage(message);
        return message;
    }

    default boolean syncTrackerAtSpawn() {
        return false;
    }
}
