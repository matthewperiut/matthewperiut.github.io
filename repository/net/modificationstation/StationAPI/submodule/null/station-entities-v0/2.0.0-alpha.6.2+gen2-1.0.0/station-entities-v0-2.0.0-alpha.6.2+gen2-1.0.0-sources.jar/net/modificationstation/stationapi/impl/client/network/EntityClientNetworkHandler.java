package net.modificationstation.stationapi.impl.client.network;

import net.fabricmc.loader.api.FabricLoader;
import net.mine_diver.unsafeevents.listener.EventListener;
import net.minecraft.client.Minecraft;
import net.minecraft.unmapped.C_34399650;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_61027059;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.client.entity.factory.EntityWorldAndPosFactory;
import net.modificationstation.stationapi.api.client.registry.EntityHandlerRegistry;
import net.modificationstation.stationapi.api.client.registry.MobHandlerRegistry;
import net.modificationstation.stationapi.api.entity.HasOwner;
import net.modificationstation.stationapi.api.event.registry.EntityHandlerRegistryEvent;
import net.modificationstation.stationapi.api.event.registry.MessageListenerRegistryEvent;
import net.modificationstation.stationapi.api.event.registry.MobHandlerRegistryEvent;
import net.modificationstation.stationapi.api.mod.entrypoint.Entrypoint;
import net.modificationstation.stationapi.api.mod.entrypoint.EntrypointManager;
import net.modificationstation.stationapi.api.mod.entrypoint.EventBusPolicy;
import net.modificationstation.stationapi.api.network.packet.MessagePacket;
import net.modificationstation.stationapi.api.server.entity.StationSpawnDataProvider;
import net.modificationstation.stationapi.mixin.entity.client.ClientNetworkHandlerAccessor;

import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.IOException;
import java.lang.invoke.MethodHandles;
import java.util.Arrays;
import java.util.List;
import java.util.function.Function;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;
import static net.modificationstation.stationapi.api.util.Identifier.of;

@Entrypoint(eventBus = @EventBusPolicy(registerInstance = false))
@EventListener(phase = StationAPI.INTERNAL_PHASE)
public final class EntityClientNetworkHandler {
    static {
        EntrypointManager.registerLookup(MethodHandles.lookup());
    }

    @EventListener
    private static void registerMessageListeners(MessageListenerRegistryEvent event) {
        event.register(NAMESPACE.id("spawn_entity"), EntityClientNetworkHandler::handleEntitySpawn);
        StationAPI.EVENT_BUS.post(new EntityHandlerRegistryEvent());
        event.register(NAMESPACE.id("spawn_mob"), EntityClientNetworkHandler::handleMobSpawn);
        StationAPI.EVENT_BUS.post(new MobHandlerRegistryEvent());
    }

    private static void handleEntitySpawn(C_40996800 player, MessagePacket message) {
        EntityWorldAndPosFactory entityHandler = EntityHandlerRegistry.INSTANCE.get(of(message.strings[0]));

        if (entityHandler == null) {
            throw new RuntimeException("Got entity handler id " + message.strings[0] + ", but found no registered entity handler!");
        }

        double
                x = message.ints[1] / 32D,
                y = message.ints[2] / 32D,
                z = message.ints[3] / 32D;
        //noinspection deprecation
        ClientNetworkHandlerAccessor networkHandler = (ClientNetworkHandlerAccessor) ((Minecraft) FabricLoader.getInstance().getGameInstance()).m_55181026();
        C_34399650 world = networkHandler.getWorld();
        C_42232651 entity = entityHandler.create(world, x, y, z);
        if (entity != null) {
            entity.f_16319839 = message.ints[1];
            entity.f_59722398 = message.ints[2];
            entity.f_79826809 = message.ints[3];
            entity.f_80130373 = 0.0F;
            entity.f_03549461 = 0.0F;
            entity.f_11112215 = message.ints[0];
            world.m_34714727(message.ints[0], entity);
            if (message.ints[4] > 0) {
                if (entity instanceof HasOwner hasOwner)
                    hasOwner.setOwner(networkHandler.invokeGetEntity(message.ints[4]));
                entity.m_04637244((double) message.shorts[0] / 8000.0D, (double) message.shorts[1] / 8000.0D, (double) message.shorts[2] / 8000.0D);
            }
            if (message.bytes != null) {
                try {
                    entity.m_82885919().m_47989627(C_61027059.m_63048531(new DataInputStream(new ByteArrayInputStream(message.bytes))));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            if (entity instanceof StationSpawnDataProvider provider)
                provider.readFromMessage(message);
        }
    }

    private static void handleMobSpawn(C_40996800 player, MessagePacket message) {
        Function<C_64041439, C_74425583> mobHandler = MobHandlerRegistry.INSTANCE.get(of(message.strings[0]));

        if (mobHandler == null) {
            throw new RuntimeException("Got mob handler id " + message.strings[0] + ", but found no registered entity handler!");
        }

        double
                x = message.ints[1] / 32D,
                y = message.ints[2] / 32D,
                z = message.ints[3] / 32D;
        float yaw = (float)(message.bytes[0] * 360) / 256.0F;
        float pitch = (float)(message.bytes[1] * 360) / 256.0F;
        //noinspection deprecation
        ClientNetworkHandlerAccessor networkHandler = (ClientNetworkHandlerAccessor) ((Minecraft) FabricLoader.getInstance().getGameInstance()).m_55181026();
        C_34399650 world = networkHandler.getWorld();
        C_74425583 mob = mobHandler.apply(world);
        if (mob != null) {
            mob.f_16319839 = message.ints[1];
            mob.f_59722398 = message.ints[2];
            mob.f_79826809 = message.ints[3];
            mob.f_11112215 = message.ints[0];
            mob.m_03000503(x, y, z, yaw, pitch);
            mob.f_08305162 = true;
            world.m_34714727(message.ints[0], mob);
            //noinspection unchecked
            List<C_61027059.net/minecraft/unmapped/C_95179189> data = null;
            try {
                data = C_61027059.m_63048531(new DataInputStream(new ByteArrayInputStream(Arrays.copyOfRange(message.bytes, 2, message.bytes.length))));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            if (data != null)
                mob.m_82885919().m_47989627(data);
            if (mob instanceof StationSpawnDataProvider provider)
                provider.readFromMessage(message);
        }
    }
}
