package net.modificationstation.stationapi.api.entity;

import lombok.AccessLevel;
import lombok.NoArgsConstructor;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_70943525;
import net.minecraft.unmapped.C_89604096;
import net.modificationstation.stationapi.mixin.entity.EntityTypeAccessor;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public final class EntityTypeFactory {
    private static int nextId = C_70943525.values().length;

    public static C_70943525 create(String typeName, Class<? extends C_42232651> typeSuperClass, int unusedInt, C_89604096 spawnMaterial, boolean unusedBoolean) {
        return EntityTypeAccessor.stationapi_create(typeName, nextId++, typeSuperClass, unusedInt, spawnMaterial, unusedBoolean);
    }
}
