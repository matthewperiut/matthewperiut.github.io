package net.modificationstation.stationapi.api.server.entity;

import net.minecraft.unmapped.C_03408293;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_42232651;
import net.modificationstation.stationapi.api.entity.HasOwner;

public interface VanillaSpawnDataProvider extends CustomSpawnDataProvider {

    @Override
    default C_03562565 getSpawnData() {
        C_42232651 entityBase = (C_42232651) this;
        int ownerId = 0;
        if (entityBase instanceof HasOwner hasOwner) {
            C_42232651 owner = hasOwner.getOwner();
            owner = owner == null ? entityBase : owner;
            ownerId = owner.f_11112215;
        }
        return new C_03408293(entityBase, getSpawnID(), ownerId);
    }

    short getSpawnID();
}
