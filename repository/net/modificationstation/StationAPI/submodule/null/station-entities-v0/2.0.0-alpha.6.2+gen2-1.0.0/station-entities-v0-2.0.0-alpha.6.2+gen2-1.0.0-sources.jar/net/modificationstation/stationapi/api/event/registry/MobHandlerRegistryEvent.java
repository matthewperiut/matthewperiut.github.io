package net.modificationstation.stationapi.api.event.registry;

import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;
import net.modificationstation.stationapi.api.client.registry.MobHandlerRegistry;

import java.util.function.Function;

public class MobHandlerRegistryEvent extends RegistryEvent.EntryTypeBound<Function<C_64041439, C_74425583>, MobHandlerRegistry> {
    public MobHandlerRegistryEvent() {
        super(MobHandlerRegistry.INSTANCE);
    }
}
