package net.modificationstation.stationapi.api.server.entity;

import net.minecraft.unmapped.C_03562565;

public interface CustomSpawnDataProvider {

    C_03562565 getSpawnData();
}
