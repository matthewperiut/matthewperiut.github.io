package net.modificationstation.stationapi.api.server.entity;

import com.google.common.primitives.Bytes;
import net.minecraft.unmapped.C_03562565;
import net.minecraft.unmapped.C_45510667;
import net.minecraft.unmapped.C_74425583;
import net.modificationstation.stationapi.api.network.packet.MessagePacket;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;
import static net.modificationstation.stationapi.api.util.Identifier.of;

public interface MobSpawnDataProvider extends StationSpawnDataProvider {

    @Override
    default C_03562565 getSpawnData() {
        C_74425583 mob = (C_74425583) this;
        MessagePacket message = new MessagePacket(of(NAMESPACE, "spawn_mob"));
        message.strings = new String[] { getHandlerIdentifier().toString() };
        message.ints = new int[] {
                mob.f_11112215,
                C_45510667.m_80489169(mob.f_78826675 * 32.0D),
                C_45510667.m_80489169(mob.f_31030949 * 32.0D),
                C_45510667.m_80489169(mob.f_97691941 * 32.0D)
        };
        byte[] rotations = new byte[] {
                (byte)((int)(mob.f_80130373 * 256.0F / 360.0F)),
                (byte)((int)(mob.f_03549461 * 256.0F / 360.0F))
        };
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        try {
            mob.m_82885919().m_08569472(new DataOutputStream(outputStream));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        byte[] data = outputStream.toByteArray();
        message.bytes = Bytes.concat(rotations, data);
        writeToMessage(message);
        return message;
    }
}
