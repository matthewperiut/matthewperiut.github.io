package net.modificationstation.stationapi.mixin.entity.client;

import net.minecraft.unmapped.C_34399650;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_88014908;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(C_88014908.class)
public interface ClientNetworkHandlerAccessor {
    @Accessor
    C_34399650 getWorld();

    @Invoker
    C_42232651 invokeGetEntity(int entityId);
}
