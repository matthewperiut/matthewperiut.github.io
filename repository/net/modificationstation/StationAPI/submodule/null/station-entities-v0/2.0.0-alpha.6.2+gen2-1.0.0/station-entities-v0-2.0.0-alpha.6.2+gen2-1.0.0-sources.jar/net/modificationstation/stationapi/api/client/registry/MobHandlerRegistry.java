package net.modificationstation.stationapi.api.client.registry;

import com.mojang.serialization.Lifecycle;
import net.minecraft.unmapped.C_64041439;
import net.minecraft.unmapped.C_74425583;
import net.modificationstation.stationapi.api.registry.Registries;
import net.modificationstation.stationapi.api.registry.RegistryKey;
import net.modificationstation.stationapi.api.registry.SimpleRegistry;

import java.util.function.Function;

import static net.modificationstation.stationapi.api.StationAPI.NAMESPACE;

public final class MobHandlerRegistry extends SimpleRegistry<Function<C_64041439, C_74425583>> {

    public static final RegistryKey<MobHandlerRegistry> KEY = RegistryKey.ofRegistry(NAMESPACE.id("mob_handlers"));
    public static final MobHandlerRegistry INSTANCE = Registries.create(KEY, new MobHandlerRegistry(), Lifecycle.experimental());

    private MobHandlerRegistry() {
        super(KEY, Lifecycle.experimental(), false);
    }
}
