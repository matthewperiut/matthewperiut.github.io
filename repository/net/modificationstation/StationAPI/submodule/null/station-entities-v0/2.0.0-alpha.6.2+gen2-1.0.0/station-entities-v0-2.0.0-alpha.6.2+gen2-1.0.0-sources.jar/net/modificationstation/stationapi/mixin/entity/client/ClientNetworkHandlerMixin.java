package net.modificationstation.stationapi.mixin.entity.client;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.unmapped.C_03408293;
import net.minecraft.unmapped.C_34399650;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_88014908;
import net.modificationstation.stationapi.api.client.entity.factory.EntityWorldAndPosFactory;
import net.modificationstation.stationapi.api.client.registry.EntityHandlerRegistry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import static net.modificationstation.stationapi.api.util.Identifier.of;

@Mixin(C_88014908.class)
class ClientNetworkHandlerMixin {
    @Shadow
    private C_34399650 world;

    @ModifyVariable(
            method = "onEntitySpawn",
            index = 8,
            at = @At(
                    value = "LOAD",
                    ordinal = 0
            )
    )
    private C_42232651 stationapi_onEntitySpawn(
            C_42232651 entity, C_03408293 packet,
            @Local(index = 2) double trackedPosX,
            @Local(index = 4) double trackedPosY,
            @Local(index = 6) double trackedPosZ
    ) {
        EntityWorldAndPosFactory entityHandler = EntityHandlerRegistry.INSTANCE.get(of(String.valueOf(packet.f_31315440)));
        if (entityHandler != null)
            entity = entityHandler.create(world, trackedPosX, trackedPosY, trackedPosZ);
        return entity;
    }
}
