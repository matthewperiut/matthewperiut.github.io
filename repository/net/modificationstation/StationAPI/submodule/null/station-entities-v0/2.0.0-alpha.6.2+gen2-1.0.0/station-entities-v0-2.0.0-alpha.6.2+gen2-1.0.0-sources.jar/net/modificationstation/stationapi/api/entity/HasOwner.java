package net.modificationstation.stationapi.api.entity;

import net.minecraft.unmapped.C_42232651;

public interface HasOwner {

    C_42232651 getOwner();

    void setOwner(C_42232651 entityBase);
}
