package net.modificationstation.stationapi.api.client.event.render.entity;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_42232651;
import net.minecraft.unmapped.C_53593123;
import java.util.Map;

@SuperBuilder
public class EntityRendererRegisterEvent extends Event {
    public final Map<Class<? extends C_42232651>, C_53593123> renderers;

    public final void register(Class<? extends C_42232651> entityClass,  C_53593123 renderer) {
        renderers.put(entityClass, renderer);
    }
}
