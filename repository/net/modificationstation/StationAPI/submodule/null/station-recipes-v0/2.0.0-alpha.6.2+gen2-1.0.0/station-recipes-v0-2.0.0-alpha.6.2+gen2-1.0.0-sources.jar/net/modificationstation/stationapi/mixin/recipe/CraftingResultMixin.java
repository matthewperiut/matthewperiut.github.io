package net.modificationstation.stationapi.mixin.recipe;

import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_53724168;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.StationAPI;
import net.modificationstation.stationapi.api.event.container.slot.ItemCraftedEvent;
import net.modificationstation.stationapi.api.event.container.slot.ItemUsedInCraftingEvent;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(C_53724168.class)
class CraftingResultMixin {
    @Shadow
    private C_40996800 player;

    @Shadow
    @Final
    private C_43616774 input;

    @Inject(
            method = "onTakeItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/inventory/Inventory;setStack(ILnet/minecraft/item/ItemStack;)V",
                    shift = At.Shift.BY,
                    by = 2
            )
    )
    private void stationapi_onCrafted(
            C_88708284 arg, CallbackInfo ci,
            @Local(index = 2) int var2, @Local(index = 3) C_88708284 var3
    ) {
        if (var3 != null) {
            StationAPI.EVENT_BUS.post(
                    ItemUsedInCraftingEvent.builder()
                            .player(player)
                            .craftingMatrix(input)
                            .itemOrdinal(var2)
                            .itemCrafted(arg)
                            .itemUsed(var3)
                            .build()
            );
        }
    }

    @Inject(
            method = "onTakeItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/item/ItemStack;onCraft(Lnet/minecraft/world/World;Lnet/minecraft/entity/player/PlayerEntity;)V",
                    shift = At.Shift.AFTER
            )
    )
    private void stationapi_onTake(C_88708284 stack, CallbackInfo ci) {
        StationAPI.EVENT_BUS.post(
                ItemCraftedEvent.builder()
                        .player(player)
                        .craftingMatrix(input)
                        .itemCrafted(stack).build()
        );
    }

}
