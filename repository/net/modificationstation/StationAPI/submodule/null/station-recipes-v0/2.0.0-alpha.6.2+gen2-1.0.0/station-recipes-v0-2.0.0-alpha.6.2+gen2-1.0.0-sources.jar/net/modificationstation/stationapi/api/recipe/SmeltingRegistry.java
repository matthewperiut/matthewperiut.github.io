package net.modificationstation.stationapi.api.recipe;

import net.minecraft.unmapped.C_13858042;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.tag.TagKey;
import net.modificationstation.stationapi.api.util.API;
import net.modificationstation.stationapi.mixin.recipe.SmeltingRecipeManagerAccessor;

import java.util.Map;

public final class SmeltingRegistry {

    @API
    public static void addSmeltingRecipe(int input, C_88708284 output) {
        ((SmeltingRecipeManagerAccessor) C_13858042.m_49255699()).getRecipes().put(input, output);
    }

    @API
    public static void addSmeltingRecipe(C_88708284 input, C_88708284 output) {
        ((SmeltingRecipeManagerAccessor) C_13858042.m_49255699()).getRecipes().put(input, output);
    }

    @API
    public static void addSmeltingRecipe(TagKey<C_98888256> input, C_88708284 output) {
        ((SmeltingRecipeManagerAccessor) C_13858042.m_49255699()).getRecipes().put(input, output);
    }

    @API
    public static C_88708284 getResultFor(C_88708284 input) {
        for (Map.Entry<Object, C_88708284> entry : ((SmeltingRecipeManagerAccessor) C_13858042.m_49255699()).getRecipes().entrySet()) {
            Object o = entry.getKey();
            //noinspection unchecked,ConstantConditions
            if (o instanceof C_88708284 item && input.m_52048659(item) || o instanceof TagKey<?> tag && input.isIn((TagKey<C_98888256>) tag))
                return entry.getValue();
        }
        return C_13858042.m_49255699().m_22042144(input.m_23235460().f_57562535);
    }
}
