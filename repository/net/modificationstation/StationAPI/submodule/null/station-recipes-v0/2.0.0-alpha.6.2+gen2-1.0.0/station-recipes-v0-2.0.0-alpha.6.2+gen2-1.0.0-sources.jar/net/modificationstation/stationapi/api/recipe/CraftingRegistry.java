package net.modificationstation.stationapi.api.recipe;

import com.mojang.datafixers.util.Either;
import it.unimi.dsi.fastutil.chars.Char2ReferenceMap;
import it.unimi.dsi.fastutil.chars.Char2ReferenceOpenHashMap;
import net.minecraft.unmapped.C_70737137;
import net.minecraft.unmapped.C_81592558;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.registry.ItemRegistry;
import net.modificationstation.stationapi.api.tag.TagKey;
import net.modificationstation.stationapi.api.util.API;
import net.modificationstation.stationapi.impl.recipe.StationShapedRecipe;
import net.modificationstation.stationapi.impl.recipe.StationShapelessRecipe;

import java.util.Optional;

public class CraftingRegistry {

    @API
    public static void addShapedRecipe(C_88708284 output, Object... recipe) {
        StringBuilder ingredients = new StringBuilder();
        int currentElement = 0;
        int width = 0;
        int height = 0;
        if (recipe[currentElement] instanceof String[] grid) {
            currentElement++;
            for (int i = 0; i < grid.length; ++i) {
                String ingredientsLine = grid[i];
                ++height;
                width = ingredientsLine.length();
                ingredients.append(ingredientsLine);
            }
        } else while (recipe[currentElement] instanceof String ingredientsLine) {
            currentElement++;
            ++height;
            width = ingredientsLine.length();
            ingredients.append(ingredientsLine);
        }
        Char2ReferenceMap<Either<TagKey<C_98888256>, C_88708284>> keyToIngredient = new Char2ReferenceOpenHashMap<>();
        for (; currentElement < recipe.length; currentElement += 2) {
            char c = (char) recipe[currentElement];
            Either<TagKey<C_98888256>, C_88708284> ingredient = null;
            Object element = recipe[currentElement + 1];
            if (element instanceof TagKey<?> tag) {
                Optional<TagKey<C_98888256>> itemTagOpt = tag.tryCast(ItemRegistry.KEY);
                if (itemTagOpt.isPresent()) ingredient = Either.left(itemTagOpt.get());
            } else if (element instanceof C_81592558 block) ingredient = Either.right(new C_88708284(block, 1, -1));
            else if (element instanceof C_88708284 stack) ingredient = Either.right(stack);
            else if (element instanceof C_98888256 item) ingredient = Either.right(new C_88708284(item));
            keyToIngredient.put(c, ingredient);
        }
        //noinspection unchecked
        Either<TagKey<C_98888256>, C_88708284>[] grid = new Either[width * height];
        for (int i = 0; i < width * height; ++i) {
            char c = ingredients.charAt(i);
            grid[i] = keyToIngredient.containsKey(c) ? keyToIngredient.get(c).mapRight(C_88708284::m_73216943) : null;
        }
        //noinspection unchecked
        C_70737137.m_32081319().m_34508213().add(new StationShapedRecipe(width, height, grid, output));
    }

    @API
    public static void addShapelessRecipe(C_88708284 output, Object... ingredients) {
        //noinspection unchecked
        Either<TagKey<C_98888256>, C_88708284>[] checkedIngredients = new Either[ingredients.length];
        for (int i = 0, ingredientsLength = ingredients.length; i < ingredientsLength; i++) {
            Object ingredient = ingredients[i];
            if (ingredient instanceof C_88708284 stack) checkedIngredients[i] = Either.right(stack.m_73216943());
            else if (ingredient instanceof C_98888256 item) checkedIngredients[i] = Either.right(new C_88708284(item));
            else if (ingredient instanceof C_81592558 block) checkedIngredients[i] = Either.right(new C_88708284(block));
            else if (ingredient instanceof TagKey<?> tag) {
                Optional<TagKey<C_98888256>> itemTagOpt = tag.tryCast(ItemRegistry.KEY);
                if (itemTagOpt.isPresent())
                    checkedIngredients[i] = Either.left(itemTagOpt.get());
            } else throw new RuntimeException("Invalid shapeless recipe ingredient of type " + ingredient.getClass().getName() + "!");
        }
        //noinspection unchecked
        C_70737137.m_32081319().m_34508213().add(new StationShapelessRecipe(output, checkedIngredients));
    }
}
