package net.modificationstation.stationapi.api.recipe;

import it.unimi.dsi.fastutil.ints.Int2IntMap;
import it.unimi.dsi.fastutil.ints.Int2IntOpenHashMap;
import it.unimi.dsi.fastutil.objects.*;
import lombok.val;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.registry.ItemRegistry;
import net.modificationstation.stationapi.api.registry.RegistryEntry;
import net.modificationstation.stationapi.api.tag.TagKey;
import net.modificationstation.stationapi.api.util.API;

import java.util.Map;
import java.util.OptionalInt;

public class FuelRegistry {

    private static final Reference2IntMap<TagKey<C_98888256>> TAG_FUEL_TIME = new Reference2IntOpenHashMap<>();
    /**
     * Item > Metadata, which returns the smelt time.
     */
    private static final Reference2ObjectMap<C_98888256, Int2IntMap> ITEM_FUEL_TIME = new Reference2ObjectOpenHashMap<>();

    private static final Reference2IntMap<C_88708284> FUELS = new Reference2IntOpenHashMap<>();
    private static final Reference2IntMap<C_88708284> FUELS_VIEW = Reference2IntMaps.unmodifiable(FUELS);
    private static boolean viewInvalidated;

    @API
    public static int getFuelTime(C_88708284 stack) {
        if (stack == null)
            return 0;

        // First see if a tag matches, and if so, use that
        OptionalInt foundKey = stack.getRegistryEntry().streamTags().mapToInt(TAG_FUEL_TIME::getInt).filter(value -> value > 0).findFirst();
        if (foundKey.isPresent())
            return foundKey.getAsInt();

        // Then check if the item has an entry
        val metaToFuel = ITEM_FUEL_TIME.get(stack.m_23235460());
        if (metaToFuel == null)
            return 0;

        // And then check if there's a meta-specific entry
        int fuelTime = metaToFuel.get(stack.m_21098843());
        if (fuelTime != 0)
            return fuelTime;

        // Finally check if there's a wildcard
        return metaToFuel.get(-1);
    }

    @API
    public static void addFuelTag(TagKey<C_98888256> tag, int fuelTime) {
        viewInvalidated = true;
        TAG_FUEL_TIME.put(tag, fuelTime);
    }

    @API
    public static void addFuelItem(C_98888256 item, int fuelTime) {
        addFuelItem(item, -1, fuelTime);
    }

    @API
    public static void addFuelItem(C_98888256 item, int metadata, int fuelTime) {
        viewInvalidated = true;
        ITEM_FUEL_TIME.computeIfAbsent(item, (o) -> new Int2IntOpenHashMap()).put(metadata, fuelTime);
    }

    @API
    public static Reference2IntMap<C_88708284> getFuelsView() {
        if (viewInvalidated) {
            FUELS.clear();
            for (Reference2IntMap.Entry<TagKey<C_98888256>> entry : TAG_FUEL_TIME.reference2IntEntrySet())
                for (RegistryEntry<C_98888256> item : ItemRegistry.INSTANCE.getOrCreateEntryList(entry.getKey()))
                    FUELS.put(new C_88708284(item.value()), entry.getIntValue());
            for (Map.Entry<C_98888256, Int2IntMap> item2Meta2FuelValues : ITEM_FUEL_TIME.reference2ObjectEntrySet())
                for (Int2IntMap.Entry meta2FuelValues : item2Meta2FuelValues.getValue().int2IntEntrySet())
                    FUELS.put(new C_88708284(item2Meta2FuelValues.getKey(), 1, meta2FuelValues.getIntKey()), meta2FuelValues.getIntValue());
            viewInvalidated = false;
        }
        return FUELS_VIEW;
    }
}
