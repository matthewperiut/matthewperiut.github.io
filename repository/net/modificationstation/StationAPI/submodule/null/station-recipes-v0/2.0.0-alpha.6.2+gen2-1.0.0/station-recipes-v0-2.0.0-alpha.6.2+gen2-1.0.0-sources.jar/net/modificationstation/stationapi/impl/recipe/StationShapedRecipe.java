package net.modificationstation.stationapi.impl.recipe;

import com.mojang.datafixers.util.Either;
import net.minecraft.unmapped.C_11727459;
import net.minecraft.unmapped.C_30892219;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.tag.TagKey;

import java.util.*;

public class StationShapedRecipe implements C_30892219 {
    public final int width, height;
    private final Either<TagKey<C_98888256>, C_88708284>[] grid;
    public final C_88708284 output;

    public StationShapedRecipe(int width, int height, Either<TagKey<C_98888256>, C_88708284>[] grid, C_88708284 output) {
        this.width = width;
        this.height = height;
        this.grid = grid;
        this.output = output;
    }

    @Override
    public boolean m_52363298(C_11727459 grid) {
        for(int x = 0; x <= 3 - this.width; ++x)
            for (int y = 0; y <= 3 - this.height; ++y) {
                if (this.matches(grid, x, y, true)) return true;

                if (this.matches(grid, x, y, false)) return true;
            }
        return false;
    }

    private boolean matches(C_11727459 grid, int startX, int startY, boolean mirror) {
        for(int x = 0; x < 3; ++x)
            for (int y = 0; y < 3; ++y) {
                int dx = x - startX;
                int dy = y - startY;
                Either<TagKey<C_98888256>, C_88708284> ingredient = null;
                if (dx >= 0 && dy >= 0 && dx < this.width && dy < this.height)
                    ingredient = this.grid[(mirror ? this.width - dx - 1 : dx) + dy * this.width];
                C_88708284 itemToTest = grid.m_50913241(x, y);
                if (itemToTest != null || ingredient != null) {
                    if (itemToTest == null || ingredient == null) return false;
                    Optional<TagKey<C_98888256>> tagOpt = ingredient.left();
                    if (tagOpt.isPresent()) {
                        if (!itemToTest.isIn(tagOpt.get()))
                            return false;
                    } else {
                        Optional<C_88708284> itemOpt = ingredient.right();
                        if (itemOpt.isPresent()) {
                            C_88708284 item = itemOpt.get();
                            boolean ignoreDamage = item.m_21098843() == -1;
                            if (ignoreDamage) item.m_88755881(itemToTest.m_21098843());
                            boolean equals = areItemsEqual(item, itemToTest);
                            if (ignoreDamage) item.m_88755881(-1);
                            if (!equals) return false;
                        }
                    }
                }
            }
        return true;
    }

    public boolean areItemsEqual(C_88708284 stack, C_88708284 other) {
        return stack.m_52048659(other);
    }

    @Override
    public C_88708284 m_10985002(C_11727459 arg) {
        return output.m_73216943();
    }

    @Override
    public int m_36691583() {
        return width * height;
    }

    @Override
    public C_88708284 m_66362834() {
        return output.m_73216943();
    }

    public Either<TagKey<C_98888256>, C_88708284>[] getGrid() {
        //noinspection unchecked
        return (Either<TagKey<C_98888256>, C_88708284>[]) Arrays.stream(grid).map(entry -> entry == null ? null : entry.mapRight(C_88708284::m_73216943)).toArray(Either[]::new);
    }
}
