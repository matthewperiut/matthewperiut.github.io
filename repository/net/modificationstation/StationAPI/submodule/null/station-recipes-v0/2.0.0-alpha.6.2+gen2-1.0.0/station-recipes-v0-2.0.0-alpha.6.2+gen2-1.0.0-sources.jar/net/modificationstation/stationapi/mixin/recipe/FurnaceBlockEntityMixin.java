package net.modificationstation.stationapi.mixin.recipe;

import net.minecraft.unmapped.C_13858042;
import net.minecraft.unmapped.C_53504297;
import net.minecraft.unmapped.C_88708284;
import net.modificationstation.stationapi.api.recipe.FuelRegistry;
import net.modificationstation.stationapi.api.recipe.SmeltingRegistry;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.LocalCapture;

@Mixin(C_53504297.class)
class FurnaceBlockEntityMixin {
    @Shadow
    private C_88708284[] inventory;

    @Redirect(
            method = {
                    "canAcceptRecipeOutput",
                    "craftRecipe"
            },
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/recipe/SmeltingRecipeManager;craft(I)Lnet/minecraft/item/ItemStack;"
            )
    )
    private C_88708284 stationapi_getResult(C_13858042 smeltingRecipeRegistry, int i) {
        return SmeltingRegistry.getResultFor(inventory[0]);
    }

    @Inject(
            method = "getFuelTime",
            at = @At("HEAD"),
            cancellable = true
    )
    private void stationapi_getCustomBurnTime(C_88708284 arg, CallbackInfoReturnable<Integer> cir) {
        cir.setReturnValue(FuelRegistry.getFuelTime(arg));
    }

    @Inject(
            method = "craftRecipe",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;count:I",
                    opcode = Opcodes.GETFIELD,
                    ordinal = 0,
                    shift = At.Shift.AFTER
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void stationapi_captureLocals(CallbackInfo ci, C_88708284 var1) {
        capturedItemStack = var1;
    }

    @Unique
    private C_88708284 capturedItemStack;

    @ModifyConstant(
            method = "craftRecipe",
            constant = @Constant(
                    intValue = 1,
                    ordinal = 0
            )
    )
    private int stationapi_modifyStackIncrement(int constant) {
        return capturedItemStack.f_60602012;
    }

    @Inject(
            method = "canAcceptRecipeOutput",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;count:I",
                    opcode = Opcodes.GETFIELD,
                    shift = At.Shift.BEFORE
            ),
            locals = LocalCapture.CAPTURE_FAILHARD
    )
    private void stationapi_captureLocals2(CallbackInfoReturnable<Boolean> cir, C_88708284 var1) {
        capturedItemStack2ElectricBoogaloo = var1;
    }

    @Unique
    private C_88708284 capturedItemStack2ElectricBoogaloo;

    @Redirect(
            method = "canAcceptRecipeOutput",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/item/ItemStack;count:I",
                    opcode = Opcodes.GETFIELD
            )
    )
    private int stationapi_fixOverstack(C_88708284 stack) {
        return stack.f_60602012 + capturedItemStack2ElectricBoogaloo.f_60602012 - 1;
    }
}
