package net.modificationstation.stationapi.mixin.recipe;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import net.minecraft.unmapped.C_55756098;
import net.minecraft.unmapped.C_84171032;
import net.modificationstation.stationapi.impl.recipe.StationShapedRecipe;
import net.modificationstation.stationapi.impl.recipe.StationShapelessRecipe;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;

@Mixin(targets = "net.minecraft.recipe.CraftingRecipeManager$57536588")
class RecipeComparatorMixin {
    @WrapOperation(
            method = "compare(Lnet/minecraft/recipe/CraftingRecipe;Lnet/minecraft/recipe/CraftingRecipe;)I",
            constant = @Constant(classValue = C_84171032.class)
    )
    private boolean stationapi_accountForStationShapelessRecipe(Object recipe, Operation<Boolean> otherConditions) {
        return recipe instanceof StationShapelessRecipe || otherConditions.call(recipe);
    }

    @WrapOperation(
            method = "compare(Lnet/minecraft/recipe/CraftingRecipe;Lnet/minecraft/recipe/CraftingRecipe;)I",
            constant = @Constant(classValue = C_55756098.class)
    )
    private boolean stationapi_accountForStationShapedRecipe(Object recipe, Operation<Boolean> otherConditions) {
        return recipe instanceof StationShapedRecipe || otherConditions.call(recipe);
    }
}
