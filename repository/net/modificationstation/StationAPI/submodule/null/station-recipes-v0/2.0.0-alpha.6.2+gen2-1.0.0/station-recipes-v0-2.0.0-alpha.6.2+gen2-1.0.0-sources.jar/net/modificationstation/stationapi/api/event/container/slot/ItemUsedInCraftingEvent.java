package net.modificationstation.stationapi.api.event.container.slot;

import lombok.experimental.SuperBuilder;
import net.mine_diver.unsafeevents.Event;
import net.minecraft.unmapped.C_40996800;
import net.minecraft.unmapped.C_43616774;
import net.minecraft.unmapped.C_88708284;

/**
 * This is fired for <b>each ingredient</b> when an item is taken from the result slot.
 */
@SuperBuilder
public class ItemUsedInCraftingEvent extends Event {
    public final C_40996800 player;
    public final C_43616774 craftingMatrix;
    public final int itemOrdinal;
    public final C_88708284 itemUsed;
    public final C_88708284 itemCrafted;
}
