package net.modificationstation.stationapi.impl.recipe;

import com.mojang.datafixers.util.Either;
import net.minecraft.unmapped.C_11727459;
import net.minecraft.unmapped.C_30892219;
import net.minecraft.unmapped.C_88708284;
import net.minecraft.unmapped.C_98888256;
import net.modificationstation.stationapi.api.tag.TagKey;

import java.util.*;

public class StationShapelessRecipe implements C_30892219 {

    private static final Random RANDOM = new Random();

    private final Either<TagKey<C_98888256>, C_88708284>[] ingredients;
    public final C_88708284 output;
    private final BitSet matchedIngredients;

    public StationShapelessRecipe(C_88708284 output, Either<TagKey<C_98888256>, C_88708284>[] ingredients) {
        this.ingredients = ingredients;
        this.output = output;
        matchedIngredients = new BitSet(ingredients.length);
    }

    @Override
    public boolean m_52363298(C_11727459 arg) {
        matchedIngredients.clear();
        for (int y = 0; y < 3; ++y) {
            for (int x = 0; x < 3; ++x) {
                C_88708284 itemToTest = arg.m_50913241(x, y);
                if (itemToTest == null) continue;
                boolean noMatch = true;
                for (int i = 0, ingredientsLength = ingredients.length; i < ingredientsLength; i++) {
                    if (matchedIngredients.get(i)) continue;
                    Either<TagKey<C_98888256>, C_88708284> ingredient = ingredients[i];
                    Optional<TagKey<C_98888256>> tagOpt = ingredient.left();
                    boolean equals = false;
                    if (tagOpt.isPresent()) {
                        equals = itemToTest.isIn(tagOpt.get());
                    } else {
                        Optional<C_88708284> itemOpt = ingredient.right();
                        if (itemOpt.isPresent()) {
                            C_88708284 item = itemOpt.get();
                            boolean ignoreDamage = item.m_21098843() == -1;
                            if (ignoreDamage) item.m_88755881(itemToTest.m_21098843());
                            equals = areItemsEqual(item, itemToTest);
                            if (ignoreDamage) item.m_88755881(-1);
                        }
                    }
                    if (equals) {
                        matchedIngredients.set(i);
                        noMatch = false;
                        break;
                    }
                }
                if (noMatch) return false;
            }
        }
        return matchedIngredients.nextClearBit(0) >= ingredients.length;
    }

    public boolean areItemsEqual(C_88708284 stack, C_88708284 other) {
        return stack.m_52048659(other);
    }

    @Override
    public C_88708284 m_10985002(C_11727459 arg) {
        return output.m_73216943();
    }

    @Override
    public int m_36691583() {
        return ingredients.length;
    }

    @Override
    public C_88708284 m_66362834() {
        return output.m_73216943();
    }

    public Either<TagKey<C_98888256>, C_88708284>[] getIngredients() {
        //noinspection unchecked
        return (Either<TagKey<C_98888256>, C_88708284>[]) Arrays.stream(ingredients).map(entry -> entry == null ? null : entry.mapRight(C_88708284::m_73216943)).toArray(Either[]::new);
    }
}
