# Feature Showcase RetroAPI Template

Every RetroAPI feature, fully built and heavily commented, in one **Minecraft Beta 1.7.3** mod (Ornithe gen2 + biny mappings). This is the companion to the [bare template](https://matthewperiut.github.io/retroapi/), start bare, then come here whenever you want to see a feature done end-to-end.

The full guide, written as a walkthrough of this exact code, lives at **https://matthewperiut.github.io/retroapi/**.

## Run it

```bash
./gradlew runClient     # singleplayer: everything works here
./gradlew runServer     # dedicated server (set online-mode=false in run/server.properties!)
```

On first join you get a starter kit with one of everything, plus an example mob at your feet.

## What's demonstrated where

| Feature | Files |
|---|---|
| Basic block (texture, sounds, strength) | `ExampleMod.init()` → `EXAMPLE_BLOCK` |
| Multi-sided block textures | `ExampleSidedBlock` |
| Non-cube bounds + custom render type | `ExampleMod` → `PIPE_BLOCK`, `PIPE_RENDER_TYPE` |
| Basic item | `ExampleMod.init()` → `EXAMPLE_ITEM` |
| Custom item class + right-click | `JumpStickItem` (the Jump Stick) |
| Block entity + NBT persistence + custom sound | `ExampleCounterBlock`, `ExampleCounterBlockEntity` |
| Block entity with a container GUI | `ExampleCrateBlock`, `ExampleCrateBlockEntity`, `ExampleCrateContainer`, `ExampleCrateScreen` |
| Furnace-style machine + SYNCED progress variables | `ExampleFreezerBlock`, `ExampleFreezerBlockEntity`, `ExampleFreezerContainer`, `ExampleFreezerScreen` |
| Custom mob + client renderer + MP spawn sync | `ExampleEntity`, `ExampleModClient` |
| Achievements + custom achievement page | `ExampleAchievements`, granted in `ExamplePlayerSetup` / `ExamplePortalBlock` / `LivingEntityJumpMixin` |
| Custom dimension + walk-in portal | `ExampleDimension`, `ExamplePortalBlock` |
| Recipes: shaped, shapeless, smelting, fuel | `ExampleMod.registerRecipes()` |
| Custom packets (OSL networking) | `ExampleNetworking`, `ExampleModClient`, `ExampleModServer` |
| Entrypoints: `init` / `client-init` / `server-init` | `ExampleMod` / `ExampleModClient` / `ExampleModServer` + `fabric.mod.json` |
| Lang files, textures, sounds | `src/main/resources/assets/example_mod/` |
| Mineable tags (modern data format) | `ExampleMod` → `RUBY_ORE` + `data/example_mod/tags/block/mineable/pickaxe.json` |
| Custom drops | `RubyOreBlock` (getDroppedItemId/Count) |
| Tool tiers (needs_iron_tool, both ways) | `data/example_mod/tags/block/needs_iron_tool.json` + `RUBY_PICK` (`.tool(PICKAXE).tier(IRON)`) |
| Flattened blockstates (20 states, xmeta) | `ExampleLampBlock` + `.states(LIT, AGE)` |
| Connection states + multipart (162 states) | `ExampleWallBlock` + `retroapi/blockstates/stone_wall.json` (ported from stonewalls-fabric-b1.7.3) |
| VoxelShapes (multi-box outline/collision) | `ExampleWallBlock` voxel shapes section (HasVoxelShape + HasCollisionVoxelShape) |
| JSON block models + blockstate variants | `assets/example_mod/retroapi/blockstates/lamp.json` + `models/block/lamp_*.json` |
| Complex multi-element model + tint | `PEDESTAL` + `retroapi/models/block/pedestal.json` + `RetroBlockColors` |
| Vanilla textures by name in models | wall models reference `minecraft:block/cobblestone` |
| First block (fabric-docs style) | `CONDENSED_DIRT` (cube_all + 26.1.2 item def + shapeless recipe) |
| Directional block (axis) | `ExampleLogBlock` (`PACKED_LOG`) + cube_column rotations |
| Directional machine (facing) | `ExampleFreezerBlock` FACING state + orientable model (aether freezer art) |
| Vanilla item texture layering | `CANDIED_APPLE` (26.1.2 composite over `minecraft:item/apple`) |
| Animated textures (mcmeta, zero code) | `EMBER_BLOCK` + `textures/block/ember_block.png(.mcmeta)` |
| Layered item models | `RUBY` + `retroapi/models/item/ruby.json` |
| Vanilla item texture layering (26.1.2) | `CANDIED_APPLE` (composite over `minecraft:item/apple`) |
| Custom sounds + subfolders | `sounds/sound/**` (example mob hurt = slider collide) |
| Streaming music autoplay on load | `RetroMusic.playOnWorldLoad` + `sounds/streaming/aether1.ogg` |
| Jukebox record (lang-named) | `SAMPLE_DISC` (`RetroRecordItem`) + `record.@.sample_disc` lang |
| Custom entity render-state sync | `AerbunnyEntity`/`AerbunnyModel`/`AerbunnyRenderer` (DataTracker puff + tilt) |
| Fully custom dimension (equation) | `CurvyDimension` + `CurvyChunkSource` (sin x + cos z) |
| Fully custom dimension (noise) | `NoisyDimension` + `NoisyChunkSource` (Perlin, ores, worm caves, trees, lakes) |
| Two biomes + orange grass | `NoisyBiomeSource` + `BiomeBuilder` tints |
| Mod-friendly biome spawns | `RetroBiomes.addPassiveSpawn` (Aerbunnies in Noisy, animals in Curvy) |
| Modded mobs obey the spawn cap | `RetroSpawnGroups` + `WorldSpawnCountMixin` (no per-mob population code) |
| Dimension travel messages | `ExampleDimension implements TravelMessageProvider` + `dimension.@.example_dim.*` lang |
| Custom cross-block flower + patch feature | `ExampleFlowerBlock` (`PINK_FLOWER`) + flower-patch decoration |
| Per-dimension portal blocks | `DimensionPortalBlock` (green/orange glass) |
| Data components (modern-style item data) | `CounterItem` + `CLICK_COUNT` (fabric-docs counter example) |
| Item tooltips (beta has none) | `RetroTooltipProvider` on Counter / Mood Gem |
| Component-driven dynamic texture | `MoodGemItem` (`RetroDynamicTexture`, 4 tinted sprites by component) |
| **12 mixin examples, easy → advanced** | `mixin/examples/Example01...Example12` (each file is self-contained, delete one to remove its effect) |

## The mixin course

`mixin/examples/` is a graded course: `@Inject` (HEAD / constructor / cancellable / RETURN), `@Shadow`, `@Invoker`, `@ModifyArg`, `@Redirect` (with a giant warning), `@ModifyConstant`, duck interfaces + `@Unique` + NBT persistence, and two MixinExtras bonus chapters (`@WrapOperation`, `@ModifyReturnValue`). Read them in order.

## License

CC0, copy anything into your own mod, no credit required.
