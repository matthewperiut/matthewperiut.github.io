package com.example.example_mod;

import com.periut.retroapi.component.RetroLayeredTexture;
import com.periut.retroapi.component.RetroTextureLayer;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import java.util.List;

/**
 * The Sticked Apple, the SIMPLEST layered item: two untinted layers, a vanilla stick on the
 * bottom and a vanilla apple on top. No components, no tint, no math, just two atlas sprites
 * stacked back to front.
 *
 * It shows that {@link RetroLayeredTexture} is not only for component-driven looks. Any item
 * can hand back a fixed list of layers, and the sprites can be VANILLA ones: {@code
 * Item.getTextureId(0)} returns an item's atlas slot, so this needs no PNG of its own. The
 * Mood Gem (in the same mod) is the component-driven, tinted version of the same idea.
 */
public class StickedAppleItem extends Item implements RetroLayeredTexture {

	public StickedAppleItem(int id) {
		super(id);
	}

	@Override
	public List<RetroTextureLayer> getTextureLayers(ItemStack stack) {
		return List.of(
			RetroTextureLayer.plain(Item.STICK.getTextureId(0)),   // bottom layer: a stick
			RetroTextureLayer.plain(Item.APPLE.getTextureId(0)));   // top layer: an apple
	}
}
