package com.example.example_mod;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

/**
 * The Pink Flower, a CROSS block: two flat quads in an X, the shape every beta flower,
 * sapling and mushroom uses.
 *
 * There are two ways to get a cross block, and the difference is ALL about how the ITEM
 * looks in your hand and hotbar:
 *
 *   1. A JSON model with the {@code minecraft:block/cross} parent. RetroAPI then renders
 *      that 3D model everywhere, including the inventory, so the item shows a full-size
 *      3D cross. Right for a decorative block you want to preview in 3D, wrong for a
 *      flower, which should read as a flat icon like every vanilla flower.
 *
 *   2. Vanilla render type 1 (this class). beta draws type 1 as the crossed squares in
 *      the world, but as a FLAT 2D sprite in the inventory and hand, exactly like the
 *      dandelion. RetroAPI does not touch non-custom render types, so this is pure
 *      vanilla behaviour, you just need a terrain sprite (set with {@code .texture(...)}
 *      at registration) for the cross and the icon to share.
 *
 * We use option 2 so the Pink Flower's icon matches the vanilla flowers. The flower is
 * scattered by NoisyChunkSource's flower-patch decoration.
 */
public class ExampleFlowerBlock extends Block {

	public ExampleFlowerBlock(int id) {
		super(id, Material.PLANT);
		this.setBoundingBox(0.3F, 0.0F, 0.3F, 0.7F, 0.6F, 0.7F);
	}

	@Override
	public int getRenderType() {
		return 1; // the vanilla cross render: 3D X in the world, flat sprite in the slot
	}

	@Override
	public Box getCollisionShape(World world, int x, int y, int z) {
		return null; // walk through it
	}

	@Override
	public boolean isOpaque() {
		return false;
	}

	@Override
	public boolean isFullCube() {
		return false;
	}

	/** A plant can only sit on a solid top face (grass/dirt), like vanilla flowers. */
	@Override
	public boolean canPlaceAt(World world, int x, int y, int z) {
		int below = world.getBlockId(x, y - 1, z);
		return below == Block.GRASS_BLOCK.id || below == Block.DIRT.id;
	}
}
