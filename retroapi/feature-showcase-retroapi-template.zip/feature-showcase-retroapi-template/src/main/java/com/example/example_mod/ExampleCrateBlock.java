package com.example.example_mod;

import com.periut.retroapi.gui.RetroGuis;

import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

/**
 * A block entity WITH a container GUI: a 27-slot crate. Right-click to open it,
 * store items, close, contents persist with the world (and sync in multiplayer).
 *
 * The three pieces and where they live:
 *   server + client | ExampleCrateBlockEntity  the inventory + NBT persistence
 *   server + client | ExampleCrateContainer    the slots/click logic (ScreenHandler)
 *   client only     | ExampleCrateScreen       the drawn window
 *
 * RetroGuis.openGUI is side-independent: in singleplayer it opens the screen
 * registered for "example_mod:crate" in ExampleModClient directly; on a dedicated
 * server it sends RetroAPI's open_gui packet and the client builds the screen
 * from that same registration.
 */
public class ExampleCrateBlock extends BlockWithEntity {

	public ExampleCrateBlock(int id) {
		super(id, Material.WOOD);
	}

	@Override
	protected BlockEntity createBlockEntity() {
		return new ExampleCrateBlockEntity();
	}

	@Override
	public boolean onUse(World world, int x, int y, int z, PlayerEntity player) {
		BlockEntity be = world.getBlockEntity(x, y, z);
		if (be instanceof ExampleCrateBlockEntity) {
			ExampleCrateBlockEntity crate = (ExampleCrateBlockEntity) be;
			RetroGuis.openGUI(player, ExampleMod.id("crate"), crate,
				new ExampleCrateContainer(player.inventory, crate));
		}
		return true;
	}
}
