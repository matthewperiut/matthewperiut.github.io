package com.example.example_mod.worldgen;

import com.periut.retroapi.dimension.CustomPortal;
import com.periut.retroapi.dimension.HasTeleportationManager;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import net.minecraft.world.dimension.PortalForcer;

import net.ornithemc.osl.core.api.util.NamespacedIdentifier;

import java.util.function.Supplier;

/**
 * A walk-into-it portal block, generalised so the Curvy and Noisy dimensions can each
 * have their OWN portal block from one class. It is the same CustomPortal pattern as
 * ExamplePortalBlock, but the destination dimension and the block to place at the far
 * end are passed in, so each registered instance leads somewhere different.
 *
 * The destination is a Supplier because the dimension registration object does not
 * exist yet when the block is constructed (blocks register before dimensions); the
 * supplier is read later, on collision, by which time everything exists.
 */
public class DimensionPortalBlock extends Block implements CustomPortal {

	private final Supplier<NamespacedIdentifier> destination;
	private final Supplier<Integer> portalBlockId;

	public DimensionPortalBlock(int id, Supplier<NamespacedIdentifier> destination, Supplier<Integer> portalBlockId) {
		super(id, Material.GLASS);
		this.destination = destination;
		this.portalBlockId = portalBlockId;
	}

	@Override
	public Box getCollisionShape(World world, int x, int y, int z) {
		return null; // walk straight in
	}

	@Override
	public boolean isOpaque() {
		return false;
	}

	@Override
	public void onEntityCollision(World world, int x, int y, int z, Entity entity) {
		if (entity instanceof PlayerEntity && entity.vehicle == null && entity.passenger == null) {
			PlayerEntity player = (PlayerEntity) entity;
			((HasTeleportationManager) player).setTeleportationManager(this);
			player.tickPortalCooldown();
		}
	}

	@Override
	public NamespacedIdentifier getDimension(PlayerEntity player) {
		return this.destination.get();
	}

	@Override
	public PortalForcer getTravelAgent(PlayerEntity player) {
		// Place this same portal block on the ground at the destination, so the return
		// trip works through an identical block (RetroAPI flips the direction for us).
		return new GroundPortalForcer(this.portalBlockId.get());
	}
}
