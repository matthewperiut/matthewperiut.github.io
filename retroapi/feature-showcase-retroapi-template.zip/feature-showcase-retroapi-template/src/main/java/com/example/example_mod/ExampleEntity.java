package com.example.example_mod;

import com.periut.retroapi.entity.spawn.RetroMobSpawnData;

import net.minecraft.entity.LivingEntity;
import net.minecraft.world.World;

import net.ornithemc.osl.core.api.util.NamespacedIdentifier;

/**
 * A minimal custom mob. Extending LivingEntity directly gives you health, gravity
 * and idle behaviour but no AI, extend a vanilla mob (e.g. ZombieEntity) or add
 * your own tick logic for actual behaviour.
 *
 * Implementing RetroMobSpawnData (just getHandlerId()) lets RetroAPI spawn this mob
 * on multiplayer clients over the OSL mob-spawn channel: the server sends the id,
 * and the client reconstructs the mob with the MobFactory registered in ExampleMod.
 */
public class ExampleEntity extends LivingEntity implements RetroMobSpawnData {

	public static final NamespacedIdentifier ID = ExampleMod.id("example_mob");

	public ExampleEntity(World world) {
		super(world);
		// Skins are plain texture paths; this reuses the vanilla zombie skin.
		// Ship your own at assets/example_mod/... and point to it here if you like.
		this.texture = "/mob/zombie.png";
	}

	@Override
	protected boolean canDespawn() {
		return false; // stick around so you can find it again after re-logging
	}

	@Override
	protected String getHurtSound() {
		// A sound from a SUBFOLDER: the file lives at
		// sounds/sound/bosses/slider/slidercollide.ogg, and the autoloader turns that
		// nested path into the dotted event id below. Borrowed from the Slider boss in
		// github.com/matthewperiut/aether-fabric-b1.7.3.
		return "example_mod:bosses.slider.slidercollide";
	}

	@Override
	public NamespacedIdentifier getHandlerId() {
		return ID; // ties multiplayer spawn packets back to the registration
	}
}
