package com.example.example_mod;

/**
 * The four horizontal directions a block can face, the beta equivalent of modern
 * Minecraft's HorizontalFacingBlock property. Enum constants serialize as their
 * lowercase names, which is what the freezer blockstate's "facing=north" keys match.
 */
public enum Facing {
	NORTH,
	SOUTH,
	WEST,
	EAST;

	/**
	 * The direction a block should face when placed by an entity looking along {@code yaw}.
	 * A block faces the player, so this is the OPPOSITE of the way they look: the furnace
	 * and chest do exactly this. Yaw 0 is south in beta, so the quadrants land as below.
	 */
	public static Facing fromYaw(float yaw) {
		int quadrant = Math.round(yaw / 90.0F) & 3;
		switch (quadrant) {
			case 0: return NORTH; // looking south, face north
			case 1: return EAST;
			case 2: return SOUTH;
			default: return WEST;
		}
	}
}
