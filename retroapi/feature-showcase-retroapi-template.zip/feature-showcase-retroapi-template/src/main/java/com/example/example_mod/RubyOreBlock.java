package com.example.example_mod;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

import java.util.Random;

/**
 * Ruby ore drops rubies, not itself, the same way diamond ore drops diamonds:
 * override getDroppedItemId (and optionally getDroppedItemCount). Because the
 * block is in the mineable/pickaxe tag, the drop only happens when a pickaxe
 * does the breaking; the wrong tool breaks the block and yields nothing.
 */
public class RubyOreBlock extends Block {

	public RubyOreBlock(int id) {
		super(id, Material.STONE);
	}

	@Override
	public int getDroppedItemId(int meta, Random random) {
		return ExampleMod.RUBY.id;
	}

	@Override
	public int getDroppedItemCount(Random random) {
		return 1 + random.nextInt(2); // 1 or 2 rubies
	}
}
