package com.example.example_mod.worldgen;

import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.source.BiomeSource;

import java.util.Arrays;

/**
 * A BiomeSource that returns one biome everywhere, the minimum a custom dimension
 * needs. A BiomeSource answers "what biome is at (x, z)?" for mob spawning, grass and
 * sky tints, and temperature; the terrain shape itself comes from the ChunkSource, not
 * from here. The Noisy dimension swaps this for a TWO-biome source that picks by noise.
 */
public class SingleBiomeSource extends BiomeSource {

	private final Biome biome;
	private final double temperature;

	public SingleBiomeSource(Biome biome, double temperature) {
		this.biome = biome;
		this.temperature = temperature;
	}

	@Override
	public Biome getBiome(ChunkPos pos) {
		return this.biome;
	}

	@Override
	public Biome getBiome(int x, int z) {
		return this.biome;
	}

	@Override
	public double getTemperature(int x, int z) {
		return this.temperature;
	}

	@Override
	public double[] create(double[] temperatures, int x, int z, int xSize, int zSize) {
		if (temperatures == null || temperatures.length < xSize * zSize) {
			temperatures = new double[xSize * zSize];
		}
		Arrays.fill(temperatures, 0, xSize * zSize, this.temperature);
		return temperatures;
	}

	@Override
	public Biome[] getBiomesInArea(Biome[] biomes, int x, int z, int xSize, int zSize) {
		if (biomes == null || biomes.length < xSize * zSize) {
			biomes = new Biome[xSize * zSize];
		}
		if (temperatureMap == null || temperatureMap.length < xSize * zSize) {
			temperatureMap = new double[xSize * zSize];
			downfallMap = new double[xSize * zSize];
		}
		Arrays.fill(biomes, 0, xSize * zSize, this.biome);
		return biomes;
	}
}
