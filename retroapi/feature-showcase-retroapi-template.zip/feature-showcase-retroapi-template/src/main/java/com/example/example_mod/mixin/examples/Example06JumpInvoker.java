package com.example.example_mod.mixin.examples;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import net.minecraft.entity.LivingEntity;

/**
 * MIXIN EXAMPLE 6/10, @Invoker: calling a protected/private method from outside.
 *
 * LivingEntity.jump() is protected, only subclasses may call it. An @Invoker is
 * an INTERFACE mixin: mixin makes LivingEntity implement this interface, and the
 * annotated method becomes a public bridge to the real one. Cast any living
 * entity to the interface and call it:
 *
 *   ((Example06JumpInvoker) player).example_mod$jump();
 *
 * ExampleCounterBlock does exactly that, clicking the counter makes you hop.
 * The sibling tool @Accessor does the same for fields:
 *
 *   @Accessor("fuse") int example_mod$getFuse();        // read a private field
 *   @Accessor("fuse") void example_mod$setFuse(int v);  // write it
 *
 * A design note from this very mod: if the private member you're exposing is
 * API-shaped (e.g. "what's this item's furnace burn time?"), the bridge belongs
 * in the shared library, not copy-pasted into every mod, that's why our freezer
 * calls RetroRecipes.getTotalFuelTime(...) instead of carrying its own invoker.
 */
@Mixin(LivingEntity.class)
public interface Example06JumpInvoker {

	@Invoker("jump")
	void example_mod$jump();
}
