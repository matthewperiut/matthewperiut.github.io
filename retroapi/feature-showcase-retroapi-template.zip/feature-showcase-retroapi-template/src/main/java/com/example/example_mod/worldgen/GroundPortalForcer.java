package com.example.example_mod.worldgen;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.dimension.PortalForcer;

/**
 * A reusable "single block on the ground" travel agent, the same idea as the example
 * portal's forcer but parameterised by which portal block to place, so the Curvy and
 * Noisy portals can share one class. Reuse a portal placed on an earlier trip if one is
 * near the arrival point, otherwise drop one fresh portal block on the surface.
 */
public class GroundPortalForcer extends PortalForcer {

	private static final int SEARCH_RADIUS = 16;
	private final int portalBlockId;

	public GroundPortalForcer(int portalBlockId) {
		this.portalBlockId = portalBlockId;
	}

	@Override
	public void moveToPortal(World world, Entity entity) {
		int ex = MathHelper.floor(entity.x);
		int ez = MathHelper.floor(entity.z);

		for (int x = ex - SEARCH_RADIUS; x <= ex + SEARCH_RADIUS; x++) {
			for (int z = ez - SEARCH_RADIUS; z <= ez + SEARCH_RADIUS; z++) {
				for (int y = 127; y >= 0; y--) {
					if (world.getBlockId(x, y, z) == this.portalBlockId) {
						entity.setPositionAndAngles(x + 0.5, y + 1.5, z + 0.5, entity.yaw, entity.pitch);
						return;
					}
				}
			}
		}

		int y = world.getTopY(ex, ez);
		world.setBlock(ex, y, ez, this.portalBlockId);
		entity.setPositionAndAngles(ex + 0.5, y + 1.5, ez + 0.5, entity.yaw, entity.pitch);
	}
}
