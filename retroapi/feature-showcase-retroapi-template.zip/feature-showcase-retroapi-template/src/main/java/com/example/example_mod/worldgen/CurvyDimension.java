package com.example.example_mod.worldgen;

import com.example.example_mod.ExampleMod;

import net.minecraft.world.chunk.ChunkSource;
import net.minecraft.world.dimension.Dimension;

/**
 * The Curvy dimension. A Dimension ties together a ChunkSource (terrain) and a
 * BiomeSource (biomes), plus environment knobs (sky, fog, spawn rules). Everything
 * here is the minimum: hand back our sin+cos generator and a single-biome source.
 *
 * The {@code id} (serial id assigned by RetroAPI) decides the {@code DIM<id>/} save
 * folder, so we just store it. {@code setWorld} is called by the engine before
 * {@code initBiomeSource}/{@code createChunkGenerator}, so {@code this.world} is valid
 * by the time the generator is built.
 */
public class CurvyDimension extends Dimension {

	public CurvyDimension(int serialId) {
		this.id = serialId;
	}

	@Override
	protected void initBiomeSource() {
		// One gentle biome: friendly animals only (wired in ExampleMod.registerSpawns).
		this.biomeSource = new SingleBiomeSource(ExampleMod.CURVY_BIOME, 0.7);
	}

	@Override
	public ChunkSource createChunkGenerator() {
		return new CurvyChunkSource(this.world);
	}

	@Override
	public boolean hasWorldSpawn() {
		return true;
	}

	@Override
	public boolean isValidSpawnPoint(int x, int z) {
		return true;
	}
}
