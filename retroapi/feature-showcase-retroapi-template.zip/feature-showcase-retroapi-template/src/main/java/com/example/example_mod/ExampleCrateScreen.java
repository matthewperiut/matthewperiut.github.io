package com.example.example_mod;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;

/**
 * The crate's screen, CLIENT-ONLY (it extends a client class, so it must never
 * be classloaded on a dedicated server; it's only referenced from the lambda
 * registered in ExampleModClient, which is safe). Based on
 * matthewperiut/crates-fabric-b1.7.3.
 *
 * The window art is a mod asset: textures/gui/crategui.png. GUI textures are
 * NOT atlased like block/item textures, you bind them directly by their
 * classpath path through the vanilla texture manager, as drawBackground shows.
 */
public class ExampleCrateScreen extends HandledScreen {

	private static final String TEXTURE = "/assets/example_mod/textures/gui/crategui.png";

	private final String name;

	public ExampleCrateScreen(PlayerInventory playerInventory, ExampleCrateBlockEntity crate) {
		super(new ExampleCrateContainer(playerInventory, crate));
		this.name = crate.getName();
		this.backgroundWidth = 176;
		this.backgroundHeight = 222;
	}

	@Override
	protected void drawForeground() {
		// Drawn relative to the window's top-left corner.
		this.textRenderer.draw(this.name, 53, 14, 0x121212);
		this.textRenderer.draw("Inventory", 8, this.backgroundHeight - 122, 0x404040);
	}

	@Override
	protected void drawBackground(float tickDelta) {
		int texture = this.minecraft.textureManager.getTextureId(TEXTURE);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.minecraft.textureManager.bindTexture(texture);
		int left = (this.width - this.backgroundWidth) / 2;
		int top = (this.height - this.backgroundHeight) / 2;
		this.drawTexture(left, top, 0, 0, this.backgroundWidth, this.backgroundHeight);
	}
}
