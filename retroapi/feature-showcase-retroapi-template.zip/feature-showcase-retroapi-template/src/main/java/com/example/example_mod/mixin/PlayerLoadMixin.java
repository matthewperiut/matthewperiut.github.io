package com.example.example_mod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.example_mod.ExamplePlayerSetup;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;

/**
 * Marks a player whose data is being LOADED from disk, so the one-shot starter setup in
 * {@link ExamplePlayerSetup} can tell a returning player from a brand-new one. readNbt only
 * runs when there is saved data to read (an existing player / world); a freshly created
 * player never goes through it, so it stays unmarked and is the only one that gets the kit.
 */
@Mixin(PlayerEntity.class)
public class PlayerLoadMixin {

	@Inject(method = "readNbt", at = @At("HEAD"))
	private void exampleMod$markLoadedFromDisk(NbtCompound nbt, CallbackInfo ci) {
		ExamplePlayerSetup.markLoadedFromDisk((PlayerEntity) (Object) this);
	}
}
