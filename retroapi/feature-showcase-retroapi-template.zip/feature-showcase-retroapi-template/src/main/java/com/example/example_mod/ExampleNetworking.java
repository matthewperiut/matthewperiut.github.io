package com.example.example_mod;

import net.ornithemc.osl.core.api.util.NamespacedIdentifier;
import net.ornithemc.osl.networking.api.ChannelIdentifiers;
import net.ornithemc.osl.networking.api.ChannelRegistry;

/**
 * Custom packets via OSL networking (osl-networking), a tiny welcome/ping round trip:
 *
 *   1. When a player joins a dedicated server, the server sends a WELCOME packet
 *      (sent from ExampleModServer.welcomeOnceReady, driven by ServerPlayerTickMixin).
 *   2. The client listener (in ExampleModClient) logs it and replies with a PING.
 *   3. The server listener (in ExampleModServer) logs the reply.
 *
 * Only the channel ids live here, because this class must be loadable on BOTH sides:
 * client-only code (ClientPlayNetworking) stays in ExampleModClient and server-only
 * code (ServerPlayNetworking) stays in ExampleModServer.
 *
 * Note: Beta 1.7.3 has no integrated server, so custom packets only flow when playing
 * on a dedicated server, in singleplayer these channels simply stay quiet.
 */
public final class ExampleNetworking {
	private ExampleNetworking() {}

	// register(id, serverToClient, clientToServer), directions a channel allows.
	public static final NamespacedIdentifier WELCOME = ChannelRegistry.register(
		ChannelIdentifiers.from(ExampleMod.MOD_ID, "welcome"), true, false);

	public static final NamespacedIdentifier PING = ChannelRegistry.register(
		ChannelIdentifiers.from(ExampleMod.MOD_ID, "ping"), false, true);

	/**
	 * The channels above are registered by this class's static initializer; calling
	 * this from ExampleMod.init() just forces that to happen at a predictable time.
	 */
	public static void registerChannels() {
	}
}
