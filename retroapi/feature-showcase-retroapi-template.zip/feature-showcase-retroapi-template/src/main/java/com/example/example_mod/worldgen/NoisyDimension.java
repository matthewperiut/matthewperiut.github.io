package com.example.example_mod.worldgen;

import com.example.example_mod.ExampleMod;

import net.minecraft.world.chunk.ChunkSource;
import net.minecraft.world.dimension.Dimension;

/**
 * The Noisy dimension: a two-biome, Perlin-driven world. Same Dimension shape as
 * CurvyDimension, but it hands back the noise generator and a TWO-biome source, so the
 * grass tint changes from green to orange as you cross between regions.
 */
public class NoisyDimension extends Dimension {

	public NoisyDimension(int serialId) {
		this.id = serialId;
	}

	@Override
	protected void initBiomeSource() {
		this.biomeSource = new NoisyBiomeSource(this.world.getSeed(),
			ExampleMod.NOISY_AMPLIFIED_BIOME, ExampleMod.NOISY_LUSH_BIOME);
	}

	@Override
	public ChunkSource createChunkGenerator() {
		return new NoisyChunkSource(this.world);
	}

	@Override
	public boolean hasWorldSpawn() {
		return true;
	}

	@Override
	public boolean isValidSpawnPoint(int x, int z) {
		return true;
	}
}
