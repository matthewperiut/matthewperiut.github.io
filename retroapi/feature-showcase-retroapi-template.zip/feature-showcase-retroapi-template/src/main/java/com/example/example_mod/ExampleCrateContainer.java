package com.example.example_mod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;

/**
 * The crate's container (ScreenHandler), the server-authoritative object that
 * owns the slots and moves items between the player's inventory and the crate.
 * Based on matthewperiut/crates-fabric-b1.7.3.
 *
 * Slots are added in a fixed order, and their x/y coordinates line up with the
 * art in textures/gui/crategui.png:
 *   slots 0-11   the crate (4 wide x 3 tall)
 *   slots 12-38  the player's main inventory
 *   slots 39-47  the player's hotbar
 */
public class ExampleCrateContainer extends ScreenHandler {

	/** A slot that refuses certain items, here: no crates inside crates. */
	private static class CrateSlot extends Slot {
		public CrateSlot(Inventory inventory, int index, int x, int y) {
			super(inventory, index, x, y);
		}

		@Override
		public boolean canInsert(ItemStack stack) {
			return allowedInCrate(stack);
		}
	}

	private static boolean allowedInCrate(ItemStack stack) {
		return stack.itemId != ExampleMod.CRATE_BLOCK.id;
	}

	private static final int CRATE_SLOTS = 12;

	public ExampleCrateContainer(PlayerInventory playerInventory, ExampleCrateBlockEntity crate) {
		// The crate's 4x3 grid.
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 4; col++) {
				this.addSlot(new CrateSlot(crate, row * 4 + col, 53 + col * 18, 26 + row * 18));
			}
		}

		// The player's main inventory (3 rows of 9; indices 9-35)...
		int offset = 28;
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, offset + 84 + row * 18));
			}
		}
		// ...and the hotbar (indices 0-8).
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInventory, col, 8 + col * 18, offset + 142));
		}
	}

	@Override
	public boolean canUse(PlayerEntity player) {
		return true;
	}

	/** Shift-click: crate slots dump into the inventory, inventory dumps into the crate. */
	@Override
	public ItemStack quickMove(int slotIndex) {
		ItemStack moved = null;
		Slot clicked = this.slots.get(slotIndex);

		if (clicked != null && clicked.hasStack()) {
			ItemStack stack = clicked.getStack();
			moved = stack.copy();
			if (slotIndex < CRATE_SLOTS) {
				this.insertItem(stack, CRATE_SLOTS, this.slots.size(), true);
			} else if (allowedInCrate(stack)) {
				this.insertItem(stack, 0, CRATE_SLOTS, false);
			}

			if (stack.count == 0) {
				clicked.setStack(null);
			} else {
				clicked.markDirty();
			}
		}

		return moved;
	}
}
