package com.example.example_mod.mixin.examples;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.example_mod.ExampleMod;

import net.minecraft.client.gui.screen.TitleScreen;

/**
 * MIXIN EXAMPLE 1/10, @Inject at HEAD: run your code when a method runs.
 *
 * Beta Minecraft has no event bus, no hooks, no extension points, the way you
 * change ANYTHING vanilla does is a mixin: a class that the loader merges into
 * a vanilla class at launch. That makes beta modding extremely mixin-heavy,
 * and it makes writing SAFE mixins the core skill: prefer @Inject (additive,
 * can coexist with other mods) over @Overwrite/@Redirect (exclusive, two mods
 * doing it to the same target = one of them breaks).
 *
 * This is the gentlest possible mixin: when TitleScreen.init() is called, our
 * method is called too. We change nothing, we only observe.
 *
 *   @Mixin(TitleScreen.class)    which vanilla class to merge into
 *   method = "init"              which of its methods to hook
 *   at = @At("HEAD")             where in that method (HEAD = the very top)
 *
 * The CallbackInfo parameter is required by every @Inject. This mixin is listed
 * under "client" in example_mod.mixins.json because TitleScreen only exists on
 * the client, putting it in the common list would crash a dedicated server.
 */
@Mixin(TitleScreen.class)
public class Example01TitleScreenLogMixin {

	@Inject(method = "init", at = @At("HEAD"))
	private void example_mod$onInit(CallbackInfo ci) {
		ExampleMod.LOGGER.info("[mixin example 1] the title screen is opening!");
	}
}
