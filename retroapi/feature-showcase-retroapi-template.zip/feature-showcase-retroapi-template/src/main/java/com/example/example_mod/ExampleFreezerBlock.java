package com.example.example_mod;

import com.periut.retroapi.gui.RetroGuis;
import com.periut.retroapi.register.rendertype.RenderType;
import com.periut.retroapi.register.rendertype.RenderTypes;
import com.periut.retroapi.state.RetroEnumProperty;
import com.periut.retroapi.state.RetroStates;

import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

/**
 * The freezer block, same skeleton as ExampleCrateBlock, different machine behind
 * the door. The interesting parts are in:
 *   ExampleFreezerBlockEntity  (the freezing logic + fuel via mixin @Invoker)
 *   ExampleFreezerContainer    (slots + SYNCED progress variables)
 *   ExampleFreezerScreen       (drawing the progress bars from those variables)
 *
 * This class adds the fabric-docs DIRECTIONAL pattern (a HorizontalFacingBlock):
 * a single FACING state, set from the placer's yaw, that the blockstate JSON turns
 * into a y-rotated orientable model so the frosted door always faces the player.
 * The textures are aether-fabric-b1.7.3's freezer art (top/side) plus a derived
 * front; the model parent is the embedded minecraft:block/orientable.
 *
 * GOTCHA worth knowing: a plain RetroAPI block gets the MODEL render type wired up for
 * it automatically when it has a blockstate JSON. A block with a BLOCK ENTITY does not,
 * because {@code BlockWithEntity} OVERRIDES {@code getRenderType()}, which shadows the
 * value RetroAPI set on the base Block. So a block-entity block that wants to render a
 * JSON model (rather than a plain cube) has to return the model render type itself,
 * exactly the override below. Without it, the freezer would fall back to a featureless
 * cube and the front face would never appear in the world OR the inventory icon.
 */
public class ExampleFreezerBlock extends BlockWithEntity {

	public static final RetroEnumProperty<Facing> FACING = RetroEnumProperty.of("facing", Facing.class);

	public ExampleFreezerBlock(int id) {
		super(id, Material.STONE);
	}

	@Override
	public int getRenderType() {
		// Render the orientable JSON model (in the world AND the inventory icon), not the
		// block-entity default. See the class note on why this override is required here.
		return RenderType.resolve(RenderTypes.MODEL);
	}

	@Override
	protected BlockEntity createBlockEntity() {
		return new ExampleFreezerBlockEntity();
	}

	@Override
	public void onPlaced(World world, int x, int y, int z, LivingEntity placer) {
		super.onPlaced(world, x, y, z, placer);
		// State, not raw meta: store the facing the placer should see. RetroStates.set
		// re-renders and notifies, so the door is correctly oriented the instant it lands.
		RetroStates.set(world, x, y, z,
			RetroStates.getDefault(this).with(FACING, Facing.fromYaw(placer.yaw)));
	}

	@Override
	public boolean onUse(World world, int x, int y, int z, PlayerEntity player) {
		BlockEntity be = world.getBlockEntity(x, y, z);
		if (be instanceof ExampleFreezerBlockEntity) {
			ExampleFreezerBlockEntity freezer = (ExampleFreezerBlockEntity) be;
			RetroGuis.openGUI(player, ExampleMod.id("freezer"), freezer,
				new ExampleFreezerContainer(player.inventory, freezer));
		}
		return true;
	}
}
