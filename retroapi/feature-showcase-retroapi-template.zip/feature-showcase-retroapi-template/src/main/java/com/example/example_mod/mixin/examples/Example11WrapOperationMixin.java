package com.example.example_mod.mixin.examples;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import net.minecraft.block.TallPlantBlock;

/**
 * MIXIN EXAMPLE 11 (bonus), MixinExtras @WrapOperation: @Redirect done right.
 *
 * Effect in game: tall grass and ferns get a golden autumn tint.
 *
 * Same vanilla pattern as example 8 (a block asking GrassColors for its tint),
 * but wrapped instead of redirected. The differences that matter:
 *
 *   - You receive an Operation<Integer> handle: original.call(...) runs what
 *     the call site would have done, vanilla's code OR the next mod's wrap.
 *     A @Redirect erases that choice; here we blend WITH vanilla's answer.
 *   - Wraps from different mods NEST instead of crashing: each mod's handler
 *     wraps the previous one, onion-style. Two @Redirects on this call would
 *     refuse to launch.
 *
 * MixinExtras docs: https://github.com/LlamaLad7/MixinExtras/wiki/WrapOperation
 * (MixinExtras is already on the classpath in this stack, just import it.)
 *
 * Client-only mixin: plant coloring is rendering code.
 */
@Mixin(TallPlantBlock.class)
public class Example11WrapOperationMixin {

	@WrapOperation(
		method = "getColorMultiplier",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/color/world/GrassColors;getColor(DD)I"
		)
	)
	private int example_mod$autumnPlants(double temperature, double humidity, Operation<Integer> original) {
		// First let vanilla (and any other mod's wrap) compute the real color...
		int color = original.call(temperature, humidity);
		// ...then blend each channel halfway toward gold (0xFFD700).
		int r = (((color >> 16) & 0xFF) + 0xFF) / 2;
		int g = (((color >> 8) & 0xFF) + 0xD7) / 2;
		int b = ((color & 0xFF) + 0x00) / 2;
		return (r << 16) | (g << 8) | b;
	}
}
