package com.example.example_mod;

import com.periut.retroapi.component.RetroComponentType;

import net.minecraft.nbt.NbtCompound;

/**
 * A RECORD component value: more than one field, stored as a structured sub-compound.
 * This is the beta port of the fabric-docs "advanced" data component
 * (https://docs.fabricmc.net/develop/items/custom-data-components), which is a record
 * with a float and a boolean. Components are not limited to single primitives, the
 * {@code compound(...)} serializer (see CODEC below) packs the whole record into nbt and
 * back, the way a {@code RecordCodecBuilder} does in modern Minecraft.
 */
public record GemAttunement(int level, boolean awakened) {

	public static final GemAttunement EMPTY = new GemAttunement(0, false);

	/** The serializer: writes the two fields into a sub-compound and reads them back. */
	public static final RetroComponentType.Serializer<GemAttunement> CODEC =
		RetroComponentType.compound(
			(nbt, value) -> {
				nbt.putInt("level", value.level);
				nbt.putBoolean("awakened", value.awakened);
			},
			(NbtCompound nbt) -> new GemAttunement(nbt.getInt("level"), nbt.getBoolean("awakened")));

	/** A copy with the level bumped, awakening once it crosses the threshold. */
	public GemAttunement leveledUp() {
		int next = this.level + 1;
		return new GemAttunement(next, next >= 4);
	}
}
