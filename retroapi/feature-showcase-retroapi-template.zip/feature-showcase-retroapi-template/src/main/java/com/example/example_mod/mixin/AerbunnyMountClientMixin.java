package com.example.example_mod.mixin;

import com.example.example_mod.AerbunnyEntity;
import com.example.example_mod.ExampleNetworking;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.entity.player.PlayerEntity;
import net.ornithemc.osl.networking.api.client.ClientPlayNetworking;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * The client half of Aerbunny riding. Beta simulates the player's own movement on the
 * client, so the slow-fall a rider FEELS has to be applied here, the server can't move the
 * player for them. Every tick the player is carrying an Aerbunny:
 *
 *   on a dedicated server (world.isRemote): ship the jump key up so the server can fire the
 *     glide boost authoritatively, and predict the glide locally so it feels instant.
 *   in singleplayer (the one world is authoritative): just feed the jump key to the bunny
 *     and let its tickLiving apply the glide, so it is never applied twice.
 */
@Mixin(PlayerEntity.class)
@Environment(EnvType.CLIENT)
public class AerbunnyMountClientMixin {

	@Inject(method = "tick", at = @At("TAIL"))
	private void example_mod$aerbunnyRide(CallbackInfo ci) {
		PlayerEntity self = (PlayerEntity) (Object) this;
		if (!(self.passenger instanceof AerbunnyEntity bunny)) {
			return;
		}
		boolean jumping = ((LivingEntityJumpAccessor) self).getJumping();
		if (self.world.isRemote) {
			ClientPlayNetworking.send(ExampleNetworking.AERBUNNY_JUMP, buf -> buf.writeBoolean(jumping));
			if (!self.onGround) {
				((EntityFallDistanceAccessor) self).setFallDistance(0.0F);
				self.velocityY += 0.05;
				if (self.velocityY < -0.225 && jumping) {
					self.velocityY = 0.125; // jump while gliding: a soft upward boost
					bunny.cloudPoop();
					bunny.puffiness = 1.15F;
				}
			}
		} else {
			bunny.vehicleJumping = jumping;
		}
	}
}
