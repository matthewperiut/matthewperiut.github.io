package com.example.example_mod;

import org.lwjgl.opengl.GL11;

import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.entity.player.PlayerInventory;

/**
 * The freezer's screen, CLIENT-ONLY. This is where the synced variables pay
 * off: drawBackground reads the block entity's progress/fuel fields, which the
 * container keeps up to date (ExampleFreezerContainer.setProperty), and turns
 * them into a filling arrow and a draining flame. The machine looks alive.
 *
 * The bar art lives in the same texture as the window, to the right of the
 * window area (u >= 176), same trick as vanilla's furnace.png.
 */
public class ExampleFreezerScreen extends HandledScreen {

	private static final String TEXTURE = "/assets/example_mod/textures/gui/freezer.png";

	private final ExampleFreezerBlockEntity freezer;

	public ExampleFreezerScreen(PlayerInventory playerInventory, ExampleFreezerBlockEntity freezer) {
		super(new ExampleFreezerContainer(playerInventory, freezer));
		this.freezer = freezer;
	}

	@Override
	protected void drawForeground() {
		this.textRenderer.draw(this.freezer.getName(), 60, 6, 0x404040);
		this.textRenderer.draw("Inventory", 8, this.backgroundHeight - 96 + 2, 0x404040);
	}

	@Override
	protected void drawBackground(float tickDelta) {
		int texture = this.minecraft.textureManager.getTextureId(TEXTURE);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		this.minecraft.textureManager.bindTexture(texture);
		int left = (this.width - this.backgroundWidth) / 2;
		int top = (this.height - this.backgroundHeight) / 2;
		this.drawTexture(left, top, 0, 0, this.backgroundWidth, this.backgroundHeight);

		// The flame: drains downward as fuel runs out (12px tall sprite at u=176,v=0).
		if (this.freezer.isBurning()) {
			int flame = this.freezer.getFuelRemainingScaled(12);
			this.drawTexture(left + 57, top + 47 - flame, 176, 12 - flame, 14, flame + 2);
		}

		// The arrow: fills rightward as freezing progresses (24px wide sprite at u=176,v=14).
		int arrow = this.freezer.getProgressScaled(24);
		this.drawTexture(left + 79, top + 35, 176, 14, arrow + 1, 16);
	}
}
