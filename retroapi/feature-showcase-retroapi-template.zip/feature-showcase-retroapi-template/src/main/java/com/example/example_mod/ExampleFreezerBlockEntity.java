package com.example.example_mod;

import com.periut.retroapi.register.recipe.RetroRecipes;

import net.minecraft.block.Block;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;

/**
 * A furnace-style machine (based on the Aether's Freezer, aether-fabric-b1.7.3):
 * put a WATER BUCKET in the top slot and ANY fuel in the bottom slot, and it
 * freezes the water into ICE, leaving the empty bucket behind in the input slot.
 *
 * Slots: 0 = input (water bucket), 1 = fuel, 2 = output (ice).
 *
 * The three public int fields are the machine's live state. They are NOT synced
 * by normal world saving or chunk packets, the open container syncs them every
 * tick (see ExampleFreezerContainer.sendContentUpdates). That's what lets the
 * GUI draw a smoothly filling arrow and a draining flame; without synced
 * variables a remote player's GUI would sit frozen at 0 the whole time. If you
 * build a machine, budget a synced property for everything you visualize.
 *
 * "Any fuel" comes from RetroRecipes.getTotalFuelTime, the full furnace fuel
 * table: coal, wood, sticks, lava buckets, and anything registered with
 * RetroRecipes.addFuel (so our Suspicious Substance burns here too).
 */
public class ExampleFreezerBlockEntity extends BlockEntity implements Inventory {

	/** Ticks of freezing needed to turn one water bucket into ice (10 seconds). */
	public static final int FREEZE_TICKS = 200;

	/** How far the current item has frozen (0..FREEZE_TICKS). Synced as property 0. */
	public int progress = 0;
	/** Fuel ticks left in the tank. Synced as property 1. */
	public int fuelRemaining = 0;
	/** Size of the last fuel item, so the flame can drain proportionally. Synced as property 2. */
	public int fuelTotal = 0;

	private ItemStack[] contents = new ItemStack[3];

	/** Burn ticks for a stack: vanilla fuels + RetroRecipes.addFuel fuels, 0 if not fuel. */
	public static int fuelTime(ItemStack stack) {
		return RetroRecipes.getTotalFuelTime(stack);
	}

	public void tick() {
		boolean wasBurning = this.isBurning();

		if (this.fuelRemaining > 0) {
			this.fuelRemaining--;
			if (this.canFreeze()) {
				this.progress++;
			} else {
				this.progress = 0;
			}
		} else {
			this.progress = 0;
		}

		if (this.world.isRemote) {
			return; // the server decides everything below; clients only animate
		}

		// Finished: ice appears in the output, the input becomes an empty bucket.
		if (this.progress >= FREEZE_TICKS && this.canFreeze()) {
			ItemStack out = this.contents[2];
			if (out == null) {
				this.contents[2] = new ItemStack(Block.ICE, 1);
			} else {
				out.count++;
			}
			this.contents[0] = new ItemStack(Item.BUCKET); // leave the bucket behind
			this.progress = 0;
			this.markDirty();
		}

		// Tank empty but there's work to do and fuel to eat? Consume one fuel item.
		if (this.fuelRemaining <= 0 && this.canFreeze()) {
			int time = fuelTime(this.contents[1]);
			if (time > 0) {
				this.fuelRemaining = time;
				this.fuelTotal = time;
				this.removeStack(1, 1);
				this.markDirty();
			}
		}

		if (wasBurning != this.isBurning()) {
			this.markDirty();
		}
	}

	/** Input is a water bucket and the output has room for more ice. */
	private boolean canFreeze() {
		ItemStack in = this.contents[0];
		if (in == null || in.itemId != Item.WATER_BUCKET.id) {
			return false;
		}
		ItemStack out = this.contents[2];
		return out == null || (out.itemId == Block.ICE.id && out.count < this.getMaxCountPerStack());
	}

	public boolean isBurning() {
		return this.fuelRemaining > 0;
	}

	// ------------------------------------------------------- GUI progress bars --
	// Scaled for drawing: map the tick counts onto a bar that is `pixels` long.

	public int getProgressScaled(int pixels) {
		return this.progress * pixels / FREEZE_TICKS;
	}

	public int getFuelRemainingScaled(int pixels) {
		if (this.fuelTotal == 0) {
			return 0;
		}
		return this.fuelRemaining * pixels / this.fuelTotal;
	}

	// ------------------------------------------------------ Inventory interface --

	@Override
	public int size() {
		return this.contents.length;
	}

	@Override
	public ItemStack getStack(int slot) {
		return this.contents[slot];
	}

	@Override
	public ItemStack removeStack(int slot, int amount) {
		ItemStack stack = this.contents[slot];
		if (stack == null) {
			return null;
		}
		if (stack.count <= amount) {
			this.contents[slot] = null;
			this.markDirty();
			return stack;
		}
		ItemStack taken = stack.split(amount);
		if (stack.count == 0) {
			this.contents[slot] = null;
		}
		this.markDirty();
		return taken;
	}

	@Override
	public void setStack(int slot, ItemStack stack) {
		this.contents[slot] = stack;
		if (stack != null && stack.count > this.getMaxCountPerStack()) {
			stack.count = this.getMaxCountPerStack();
		}
		this.markDirty();
	}

	@Override
	public String getName() {
		return "Freezer";
	}

	@Override
	public int getMaxCountPerStack() {
		return 64;
	}

	@Override
	public boolean canPlayerUse(PlayerEntity player) {
		if (this.world.getBlockEntity(this.x, this.y, this.z) != this) {
			return false;
		}
		return player.getSquaredDistance(this.x + 0.5, this.y + 0.5, this.z + 0.5) <= 64.0;
	}

	// ---------------------------------------------------------------- save/load --

	@Override
	public void writeNbt(NbtCompound nbt) {
		super.writeNbt(nbt);
		nbt.putShort("Progress", (short) this.progress);
		nbt.putShort("Fuel", (short) this.fuelRemaining);
		nbt.putShort("FuelTotal", (short) this.fuelTotal);
		NbtList items = new NbtList();
		for (int slot = 0; slot < this.contents.length; slot++) {
			if (this.contents[slot] != null) {
				NbtCompound entry = new NbtCompound();
				entry.putByte("Slot", (byte) slot);
				this.contents[slot].writeNbt(entry);
				items.add(entry);
			}
		}
		nbt.put("Items", items);
	}

	@Override
	public void readNbt(NbtCompound nbt) {
		super.readNbt(nbt);
		this.progress = nbt.getShort("Progress");
		this.fuelRemaining = nbt.getShort("Fuel");
		this.fuelTotal = nbt.getShort("FuelTotal");
		NbtList items = nbt.getList("Items");
		this.contents = new ItemStack[this.size()];
		for (int i = 0; i < items.size(); i++) {
			NbtCompound entry = (NbtCompound) items.get(i);
			int slot = entry.getByte("Slot") & 255;
			if (slot >= 0 && slot < this.contents.length) {
				this.contents[slot] = new ItemStack(entry);
			}
		}
	}
}
