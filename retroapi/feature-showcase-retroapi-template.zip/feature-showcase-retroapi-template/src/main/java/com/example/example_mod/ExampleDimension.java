package com.example.example_mod;

import com.periut.retroapi.dimension.TravelMessageProvider;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.EnvironmentInterface;
import net.minecraft.world.dimension.OverworldDimension;

/**
 * A minimal custom dimension (the "purple grass" world). Extending OverworldDimension
 * reuses the overworld's chunk generator and biome source, so terrain actually
 * generates; replace the parent class (or override createChunkGenerator and friends)
 * for custom terrain (see CurvyDimension/NoisyDimension for fully custom worldgen).
 *
 * The IntFunction factory passed to RetroDimensions.register(...) receives the
 * serial id RetroAPI assigned; it decides the DIM&lt;serialId&gt;/ save folder and is
 * what gets written into player NBT, so just store it in the id field.
 *
 * It also implements {@link TravelMessageProvider} to show the "between worlds"
 * loading-screen message while travelling in and out. RetroAPI reads the two
 * translation KEYS below and looks them up in the lang file, so the text localises.
 * The interface is client-only, hence the {@code @EnvironmentInterface}.
 */
@EnvironmentInterface(value = EnvType.CLIENT, itf = TravelMessageProvider.class)
public class ExampleDimension extends OverworldDimension implements TravelMessageProvider {

	public ExampleDimension(int serialId) {
		this.id = serialId;
	}

	@Override
	public String getEnteringTranslationKey() {
		return "dimension.example_mod.example_dim.entering";
	}

	@Override
	public String getLeavingTranslationKey() {
		return "dimension.example_mod.example_dim.leaving";
	}
}
