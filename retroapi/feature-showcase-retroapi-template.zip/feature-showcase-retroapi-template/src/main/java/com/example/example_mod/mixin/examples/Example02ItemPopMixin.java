package com.example.example_mod.mixin.examples;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.entity.ItemEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

/**
 * MIXIN EXAMPLE 2/10, @Inject into a CONSTRUCTOR, and touching `this`.
 *
 * Effect in game: dropped items pop upward with a little flourish.
 *
 * Two new ideas over example 1:
 *   - method = "<init>(...)" targets a constructor. You must give the full
 *     descriptor when a class has several constructors, and constructor
 *     injections are only allowed at TAIL/RETURN (the object must be fully
 *     constructed before you touch it).
 *   - `(ItemEntity) (Object) this`, inside a mixin, `this` is the mixin class,
 *     but at runtime the code lives inside ItemEntity. The double cast is the
 *     standard idiom to get a usable reference to the instance.
 *
 * Note the mixin matches the constructor's PARAMETERS too, handy when you
 * only care about one of several overloads (here: the World+pos+stack one
 * used for actual drops, not the NBT-loading one).
 */
@Mixin(ItemEntity.class)
public class Example02ItemPopMixin {

	@Inject(
		method = "<init>(Lnet/minecraft/world/World;DDDLnet/minecraft/item/ItemStack;)V",
		at = @At("TAIL")
	)
	private void example_mod$pop(World world, double x, double y, double z, ItemStack stack, CallbackInfo ci) {
		ItemEntity self = (ItemEntity) (Object) this;
		self.velocityY += 0.25; // a little extra upward kick
	}
}
