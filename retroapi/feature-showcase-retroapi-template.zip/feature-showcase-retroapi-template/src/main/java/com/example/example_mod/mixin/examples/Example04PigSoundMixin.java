package com.example.example_mod.mixin.examples;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import net.minecraft.entity.passive.PigEntity;

/**
 * MIXIN EXAMPLE 4/10, changing a RETURN VALUE with CallbackInfoReturnable.
 *
 * Effect in game: pigs make our custom "click" sound instead of oinking
 * (the same .ogg the counter block plays, see assets/.../sounds/).
 *
 * When the target method returns something, your handler receives a
 * CallbackInfoReturnable<T> instead of a CallbackInfo, and
 * cir.setReturnValue(...) both sets the value and cancels the rest of the
 * method (no separate cancellable flag needed for that).
 *
 * Injecting at RETURN (instead of HEAD) means vanilla computes its answer
 * first and you get the final word, at HEAD you'd be making the decision
 * before vanilla even runs, which matters once other mods are also injecting.
 * (You can read vanilla's answer first via cir.getReturnValue().)
 *
 * PREFER THE MIXINEXTRAS VERSION of this pattern in real mods , 
 * @ModifyReturnValue chains cleanly between mods where setReturnValue can
 * fight. See Example12ModifyReturnValueMixin for the side-by-side, and
 * https://github.com/LlamaLad7/MixinExtras/wiki/ModifyReturnValue
 */
@Mixin(PigEntity.class)
public class Example04PigSoundMixin {

	@Inject(method = "getRandomSound", at = @At("RETURN"), cancellable = true)
	private void example_mod$clickyPigs(CallbackInfoReturnable<String> cir) {
		// Sound event ids are strings in beta; modded ones are "<modid>:<path>".
		cir.setReturnValue("example_mod:counter.click");
	}
}
