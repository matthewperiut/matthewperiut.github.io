package com.example.example_mod.worldgen;

import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.biome.source.BiomeSource;

import java.util.Random;

/**
 * Picks between TWO biomes by noise, the multi-biome counterpart to SingleBiomeSource.
 * A wide, low-frequency noise field is thresholded at zero: above it is the "amplified"
 * biome (orange grass, sparse), below it the "lush" biome (green, foresty). Because the
 * field is smooth, the two biomes form large contiguous regions with a soft boundary,
 * exactly how vanilla lays out biomes.
 *
 * IMPORTANT: this must agree with NoisyChunkSource.isAmplifiedBiome so the grass colour
 * (decided here, via which biome) matches the terrain decoration (decided there). Both
 * sample the same seeded noise at the same frequency, so they always agree.
 */
public class NoisyBiomeSource extends BiomeSource {

	private final Biome amplified;
	private final Biome lush;
	private final net.minecraft.util.math.noise.OctavePerlinNoiseSampler biomeNoise;

	public NoisyBiomeSource(long seed, Biome amplified, Biome lush) {
		this.amplified = amplified;
		this.lush = lush;
		this.biomeNoise = new net.minecraft.util.math.noise.OctavePerlinNoiseSampler(new Random(seed + 3), 2);
	}

	private Biome pick(int x, int z) {
		return this.biomeNoise.sample(x / 220.0, z / 220.0) > 0.0 ? this.amplified : this.lush;
	}

	@Override
	public Biome getBiome(ChunkPos pos) {
		return pick(pos.x * 16, pos.z * 16);
	}

	@Override
	public Biome getBiome(int x, int z) {
		return pick(x, z);
	}

	@Override
	public double getTemperature(int x, int z) {
		return 0.7;
	}

	@Override
	public double[] create(double[] temperatures, int x, int z, int xSize, int zSize) {
		if (temperatures == null || temperatures.length < xSize * zSize) {
			temperatures = new double[xSize * zSize];
		}
		for (int i = 0; i < xSize * zSize; i++) {
			temperatures[i] = 0.7;
		}
		return temperatures;
	}

	@Override
	public Biome[] getBiomesInArea(Biome[] biomes, int x, int z, int xSize, int zSize) {
		if (biomes == null || biomes.length < xSize * zSize) {
			biomes = new Biome[xSize * zSize];
		}
		if (temperatureMap == null || temperatureMap.length < xSize * zSize) {
			temperatureMap = new double[xSize * zSize];
			downfallMap = new double[xSize * zSize];
		}
		for (int dz = 0; dz < zSize; dz++) {
			for (int dx = 0; dx < xSize; dx++) {
				biomes[dz * xSize + dx] = pick(x + dx, z + dz);
			}
		}
		return biomes;
	}
}
