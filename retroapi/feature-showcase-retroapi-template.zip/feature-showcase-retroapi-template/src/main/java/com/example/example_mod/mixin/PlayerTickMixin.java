package com.example.example_mod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.example_mod.ExamplePlayerSetup;

import net.minecraft.entity.player.PlayerEntity;

/**
 * Singleplayer hook for the one-shot starter kit. Listed under "client" in
 * example_mod.mixins.json: in Beta 1.7.3 the singleplayer world runs inside the
 * client, so PlayerEntity.tick() is the reliable per-tick hook there. The
 * dedicated-server equivalent is ServerPlayerTickMixin.
 */
@Mixin(PlayerEntity.class)
public class PlayerTickMixin {

	@Inject(method = "tick", at = @At("HEAD"))
	private void example_mod$onTick(CallbackInfo ci) {
		ExamplePlayerSetup.run((PlayerEntity) (Object) this);
	}
}
