package com.example.example_mod;

import com.periut.retroapi.achievement.RetroAchievements;
import com.periut.retroapi.dimension.CustomPortal;
import com.periut.retroapi.dimension.HasTeleportationManager;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;
import net.minecraft.world.dimension.PortalForcer;

import net.ornithemc.osl.core.api.util.NamespacedIdentifier;

/**
 * A "walk into it" portal block that teleports the player to the example dimension.
 *
 * RetroAPI's CustomPortal interface does the heavy lifting: implement getDimension()
 * (where to go) and getTravelAgent() (how to find/build the arrival portal), then in
 * onEntityCollision attach yourself to the player as their teleportation manager and
 * tick the portal cooldown, exactly like vanilla nether portals work.
 */
public class ExamplePortalBlock extends Block implements CustomPortal {

	public ExamplePortalBlock(int id) {
		super(id, Material.GLASS);
	}

	@Override
	public Box getCollisionShape(World world, int x, int y, int z) {
		return null; // no collision box, the player can walk into the block
	}

	@Override
	public boolean isOpaque() {
		return false; // don't suffocate/black-out the player standing inside it
	}

	@Override
	public void onEntityCollision(World world, int x, int y, int z, Entity entity) {
		if (entity instanceof PlayerEntity && entity.vehicle == null && entity.passenger == null) {
			PlayerEntity player = (PlayerEntity) entity;

			// A gameplay-triggered achievement grant (see ExampleAchievements).
			if (!world.isRemote) {
				RetroAchievements.grant(ExampleAchievements.DIMENSIONAL_TRAVELER, player);
			}

			// Standing in the portal: register ourselves as the thing that will switch
			// the player's dimension once the (vanilla) portal timer fills up.
			((HasTeleportationManager) player).setTeleportationManager(this);
			player.tickPortalCooldown();
		}
	}

	@Override
	public NamespacedIdentifier getDimension(PlayerEntity player) {
		// Where this portal leads. From the example dimension the same portal leads
		// back to the overworld automatically (RetroAPI flips the travel direction).
		return ExampleMod.EXAMPLE_DIMENSION.getId();
	}

	@Override
	public PortalForcer getTravelAgent(PlayerEntity player) {
		// Our own travel agent: finds or places a single Example Portal block on the
		// ground at the destination, instead of building a vanilla nether portal frame.
		return new ExamplePortalForcer();
	}
}
