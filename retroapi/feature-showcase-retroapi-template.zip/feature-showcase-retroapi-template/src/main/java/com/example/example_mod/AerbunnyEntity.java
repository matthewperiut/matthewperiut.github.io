package com.example.example_mod;

import com.example.example_mod.mixin.EntityFallDistanceAccessor;
import com.example.example_mod.mixin.LivingEntityJumpAccessor;
import com.periut.retroapi.entity.spawn.RetroMobSpawnData;

import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MonsterEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.item.Item;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;

import net.ornithemc.osl.core.api.util.NamespacedIdentifier;

import java.util.List;

/**
 * The Aerbunny, a full port of the floaty puffball from aether-fabric-b1.7.3
 * (https://github.com/matthewperiut/aether-fabric-b1.7.3). Unlike the rest of the
 * showcase's mobs this is a COMPLEX entity: it does not just wander, it
 *
 *   - rides on the player's head when right-clicked, and slow-falls them (a glide), with
 *     a soft upward boost if they hold jump while gliding (Chapter ... walks the riding +
 *     jump-input networking),
 *   - breeds: an adult near another adult spawns a baby, with a population cap,
 *   - panics when a player hits it, pathfinding away in a random direction,
 *   - can be grabbed (held in place) and, when it lands from a grab, makes nearby monsters
 *     turn on it,
 *   - puffs up and tilts as it floats, render state the server must publish to clients
 *     through the DataTracker (the lesson the simpler mobs could not teach).
 *
 * It extends {@link AnimalEntity} for beta's passive wandering AI, then layers all of the
 * above on top in {@link #tick} and {@link #tickLiving}. Floats ride a DataTracker int as
 * raw bits via Float.floatToIntBits / intBitsToFloat.
 */
public class AerbunnyEntity extends AnimalEntity implements RetroMobSpawnData {

	public static final NamespacedIdentifier ID = ExampleMod.id("aerbunny");

	/** DataTracker slots. 16 holds a packed STATE byte, 17/18 hold floats as bits. */
	private static final int STATE_SLOT = 16;
	private static final int PUFFINESS_SLOT = 17;
	private static final int VELOCITY_Y_SLOT = 18;

	public int age;
	public int mate;
	public boolean grab;
	public boolean fear;
	public boolean gotRider;
	public Entity runFrom;
	/** Local (server-authoritative) puffiness, 0..~1.15, decays each tick. */
	public float puffiness;
	/** The rider's jump key, fed in from the client (mount mixin) or the jump packet. */
	public boolean vehicleJumping;

	public AerbunnyEntity(World world) {
		super(world);
		this.movementSpeed = 2.5F;
		this.texture = "/assets/example_mod/textures/mobs/aerbunny.png";
		this.standingEyeHeight = -0.16F;
		// Match the model's footprint so it sits ON the ground, not hovering above it.
		this.setBoundingBoxSpacing(0.4F, 0.4F);
		this.health = 6;
		// Render far: a floaty mob is easy to lose track of up close.
		if (this.renderDistanceMultiplier < 5.0) {
			this.renderDistanceMultiplier = 5.0;
		}
		this.age = this.random.nextInt(64);
		this.mate = 0;
	}

	@Override
	protected void initDataTracker() {
		super.initDataTracker();
		this.dataTracker.startTracking(STATE_SLOT, (byte) 0);
		this.dataTracker.startTracking(PUFFINESS_SLOT, 0);    // float bits
		this.dataTracker.startTracking(VELOCITY_Y_SLOT, 0);   // float bits
	}

	/** Pack everything the renderer/other clients need into the tracker, once per tick. */
	private void syncState() {
		byte state = 0;
		if (this.onGround) state |= 1;
		if (this.vehicle instanceof PlayerEntity) state |= 2;
		if (this.grab) state |= 4;
		this.dataTracker.set(STATE_SLOT, state);
		this.dataTracker.set(PUFFINESS_SLOT, Float.floatToIntBits(this.puffiness));
		this.dataTracker.set(VELOCITY_Y_SLOT, Float.floatToIntBits((float) this.velocityY));
	}

	public boolean isRidingPlayer() {
		if (this.world.isRemote) {
			return (this.dataTracker.getByte(STATE_SLOT) & 2) != 0;
		}
		return this.vehicle instanceof PlayerEntity;
	}

	/** The synced vertical velocity the renderer tilts by (client reads the tracker). */
	public float getSyncedVelocityY() {
		return Float.intBitsToFloat(this.dataTracker.getInt(VELOCITY_Y_SLOT));
	}

	@Override
	public void tick() {
		// LivingEntity position updates reset standingEyeHeight to 0 on the client; restore it.
		this.standingEyeHeight = -0.16F;

		if (!this.world.isRemote) {
			// A bunny saved while ridden re-mounts the nearest player on load.
			if (this.gotRider) {
				this.gotRider = false;
				if (this.vehicle == null) {
					PlayerEntity player = (PlayerEntity) this.findPlayerToRunFrom();
					if (player != null && this.getDistance(player) < 2.0F && player.passenger == null) {
						this.setVehicle(player);
					}
				}
			}

			// Breeding: a counter ages the bunny, then looks for an adult neighbour to mate
			// with, spawning a baby. A crowd of 12+ nearby suppresses it (a population cap).
			if (this.age < 1023) {
				++this.age;
			} else if (this.mate < 127) {
				++this.mate;
			} else {
				List<?> crowd = this.world.getEntities(this, this.boundingBox.expand(16.0, 16.0, 16.0));
				int nearby = 0;
				for (Object o : crowd) {
					if (o instanceof AerbunnyEntity) ++nearby;
				}
				if (nearby > 12) {
					this.proceed();
					super.tick();
					return;
				}
				List<?> close = this.world.getEntities(this, this.boundingBox.expand(1.0, 1.0, 1.0));
				boolean mated = false;
				for (Object o : close) {
					if (o instanceof AerbunnyEntity other && other != this
							&& other.vehicle == null && other.age >= 1023) {
						AerbunnyEntity baby = new AerbunnyEntity(this.world);
						baby.setPosition(this.x, this.y, this.z);
						this.world.spawnEntity(baby);
						this.world.playSound(this, "mob.chickenplop", 1.0F,
							(this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F);
						this.proceed();
						other.proceed();
						mated = true;
						break;
					}
				}
				if (!mated) {
					this.mate = this.random.nextInt(16);
				}
			}

			// Server: puffiness simply decays.
			this.puffiness = Math.max(0.0F, this.puffiness - 0.1F);
			syncState();
		} else {
			// Client: trust the synced puffiness, snapping up (with a particle burst) when
			// the server triggers a puff, and decaying locally at the same rate between updates.
			float serverPuff = Float.intBitsToFloat(this.dataTracker.getInt(PUFFINESS_SLOT));
			if (serverPuff > this.puffiness + 0.2F) {
				this.puffiness = serverPuff;
				this.cloudPoop();
			} else {
				this.puffiness = Math.max(0.0F, this.puffiness - 0.1F);
			}
		}
		super.tick();
	}

	@Override
	protected void tickLiving() {
		if (this.onGround) {
			// On the ground: hop when trying to move (the bunny's idle bounce).
			if (this.forwardSpeed != 0.0F) {
				this.jump();
			}
		} else if (this.vehicle != null) {
			// Riding a player: glide them. Authoritative side only (the riding client predicts
			// this in AerbunnyMountClientMixin), so it is never applied twice.
			if (!this.world.isRemote) {
				if (this.vehicle.dead) {
					this.setVehicle(null);
				} else if (!this.vehicle.onGround && !this.vehicle.checkWaterCollisions()) {
					((EntityFallDistanceAccessor) this.vehicle).setFallDistance(0.0F);
					this.vehicle.velocityY += 0.05;
					if (this.vehicle.velocityY < -0.225 && this.vehicle instanceof LivingEntity && this.vehicleJumping) {
						this.vehicle.velocityY = 0.125; // jump-while-gliding boost
						this.cloudPoop();
						this.puffiness = 1.15F;
					}
				}
			}
		} else if (!this.grab) {
			// Free fall: float over edges and cap descent so it parachutes down gently.
			if (this.forwardSpeed != 0.0F) {
				int bx = MathHelper.floor(this.x);
				int by = MathHelper.floor(this.boundingBox.minY);
				int below = MathHelper.floor(this.boundingBox.minY - 0.5);
				int bz = MathHelper.floor(this.z);
				if ((this.world.getBlockId(bx, by - 1, bz) != 0 || this.world.getBlockId(bx, below - 1, bz) != 0)
						&& this.world.getBlockId(bx, by + 2, bz) == 0 && this.world.getBlockId(bx, by + 1, bz) == 0) {
					if (this.velocityY < 0.0) {
						this.cloudPoop();
						this.puffiness = 0.9F;
					}
					this.velocityY = 0.2;
				}
			}
			if (this.velocityY < -0.1) {
				this.velocityY = -0.1; // terminal-velocity float
			}
		}

		if (!this.grab) {
			super.tickLiving();
			// Panic: once hit by a player, periodically bolt away from the nearest one.
			if (this.fear && this.random.nextInt(4) == 0) {
				if (this.runFrom != null) {
					this.runLikeHell();
					this.world.addParticle("splash", this.x, this.y, this.z, 0.0, 0.0, 0.0);
					if (!this.hasPath()) {
						this.lookAt(this.runFrom, 30.0F, 30.0F);
					}
					if (this.runFrom.dead || this.getDistance(this.runFrom) > 16.0F) {
						this.runFrom = null;
					}
				} else {
					this.runFrom = this.findPlayerToRunFrom();
				}
			}
		} else if (this.onGround) {
			// A grabbed bunny that touches down is released, and every nearby monster aggros it.
			this.grab = false;
			this.world.playSound(this, "example_mod:mobs.aerbunny.aerbunnyland", 1.0F,
				(this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F);
			List<?> list = this.world.getEntities(this, this.boundingBox.expand(12.0, 12.0, 12.0));
			for (Object o : list) {
				if (o instanceof MonsterEntity monster) {
					monster.setTarget(this);
				}
			}
		}

		if (this.checkWaterCollisions()) {
			this.jump();
		}
	}

	/** Right-click to pick up: the bunny mounts the player's head. */
	@Override
	public boolean interact(PlayerEntity player) {
		if (this.world.isRemote) {
			return true;
		}
		this.yaw = player.yaw;
		this.setVehicle(player);
		if (this.vehicle == null) {
			this.grab = true; // could not mount (player already has a passenger): hold instead
		} else {
			this.world.playSound(this, "example_mod:mobs.aerbunny.aerbunnylift", 1.0F,
				(this.random.nextFloat() - this.random.nextFloat()) * 0.2F + 1.0F);
		}
		// Beta does not auto-send mount packets, so tell the player's client about it. The
		// string class-name check (not instanceof) keeps the server-only ServerPlayerEntity
		// reference out of this common method, which also runs on the singleplayer client; the
		// actual send lives in MountSync so the class is only loaded server-side. See MountSync.
		if (player.getClass().getName().endsWith("ServerPlayerEntity")) {
			MountSync.send(player, this, this.vehicle);
		}
		this.jumping = false;
		this.forwardSpeed = 0.0F;
		this.sidewaysSpeed = 0.0F;
		this.setPath(null);
		this.velocityX = player.velocityX * 5.0;
		this.velocityY = player.velocityY / 2.0 + 0.5;
		this.velocityZ = player.velocityZ * 5.0;
		return true;
	}

	/** A little puff of cloud particles, emitted on every puff trigger. */
	public void cloudPoop() {
		double spread = (this.random.nextFloat() - 0.5F) * 0.4;
		this.world.addParticle("explode", this.x + spread, this.boundingBox.minY, this.z + spread,
			0.0, -0.075, 0.0);
	}

	@Override
	public boolean damage(Entity source, int amount) {
		boolean hit = super.damage(source, amount);
		if (hit && source instanceof PlayerEntity) {
			this.fear = true; // a player hit me: panic from now on
		}
		return hit;
	}

	/** Climbs while trying to move, so it can scrabble up out of holes. */
	@Override
	public boolean isOnLadder() {
		return this.forwardSpeed != 0.0F;
	}

	protected Entity findPlayerToRunFrom() {
		PlayerEntity player = this.world.getClosestPlayer(this, 12.0);
		return player != null && this.canSee(player) ? player : null;
	}

	/** Pathfind to a random nearby open spot, away from whatever is being feared. */
	public void runLikeHell() {
		double dx = this.x - this.runFrom.x;
		double dz = this.z - this.runFrom.z;
		double angle = Math.atan2(dx, dz) + (this.random.nextFloat() - this.random.nextFloat()) * 0.75;
		int tx = MathHelper.floor(this.x + Math.sin(angle) * 8.0);
		int ty = MathHelper.floor(this.boundingBox.minY);
		int tz = MathHelper.floor(this.z + Math.cos(angle) * 8.0);
		for (int tries = 0; tries < 16; ++tries) {
			int i = tx + this.random.nextInt(4) - this.random.nextInt(4);
			int j = ty + this.random.nextInt(4) - this.random.nextInt(4) - 1;
			int k = tz + this.random.nextInt(4) - this.random.nextInt(4);
			if (j > 4 && (this.world.getBlockId(i, j, k) == 0 || this.world.getBlockId(i, j, k) == Block.SNOW.id)
					&& this.world.getBlockId(i, j - 1, k) != 0) {
				this.setPath(this.world.findPath(this, i, j, k, 16.0F));
				break;
			}
		}
	}

	/** Reset the breeding counters after a birth (or a suppressed attempt). */
	public void proceed() {
		this.mate = 0;
		this.age = this.random.nextInt(64);
	}

	@Override
	protected void dropItems() {
		this.dropItem(Item.STRING.id, 1);
	}

	@Override
	public double getStandingEyeHeight() {
		return isRidingPlayer() ? this.standingEyeHeight - 1.15F : this.standingEyeHeight;
	}

	@Override
	protected boolean bypassesSteppingEffects() {
		return this.onGround;
	}

	/** The bunny never takes fall damage itself (it floats). */
	@Override
	protected void onLanding(float distance) {
	}

	@Override
	protected boolean canDespawn() {
		return false;
	}

	/**
	 * Natural-spawn gate: only in the Noisy dimension and only on grass. The overall
	 * population cap is RetroAPI's job (see RetroSpawnGroups), so this is just placement.
	 */
	@Override
	public boolean canSpawn() {
		if (ExampleMod.NOISY_DIMENSION == null
				|| this.world.dimension.id != ExampleMod.NOISY_DIMENSION.getSerialId()) {
			return false;
		}
		int bx = MathHelper.floor(this.x);
		int by = MathHelper.floor(this.boundingBox.minY);
		int bz = MathHelper.floor(this.z);
		return this.world.getBlockId(bx, by - 1, bz) == Block.GRASS_BLOCK.id && super.canSpawn();
	}

	@Override
	public void writeNbt(NbtCompound nbt) {
		super.writeNbt(nbt);
		if (this.passenger != null) {
			this.gotRider = true;
		}
		nbt.putBoolean("Fear", this.fear);
		nbt.putBoolean("GotRider", this.gotRider);
		nbt.putShort("Age", (short) this.age);
		nbt.putShort("Mate", (short) this.mate);
	}

	@Override
	public void readNbt(NbtCompound nbt) {
		super.readNbt(nbt);
		this.fear = nbt.getBoolean("Fear");
		this.gotRider = nbt.getBoolean("GotRider");
		this.age = nbt.getShort("Age");
		this.mate = nbt.getShort("Mate");
	}

	@Override
	protected String getHurtSound() {
		// Variant sounds: aerbunnyhurt1.ogg and aerbunnyhurt2.ogg collapse to one event id
		// and the engine picks one at random. The autoloader handles the nesting + the digit.
		return "example_mod:mobs.aerbunny.aerbunnyhurt";
	}

	@Override
	protected String getDeathSound() {
		return "example_mod:mobs.aerbunny.aerbunnydeath";
	}

	@Override
	public NamespacedIdentifier getHandlerId() {
		return ID;
	}
}
