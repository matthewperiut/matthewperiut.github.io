package com.example.example_mod;

import com.periut.retroapi.achievement.AchievementPage;
import com.periut.retroapi.achievement.RetroAchievements;

import net.minecraft.achievement.Achievement;
import net.minecraft.item.Item;

/**
 * Achievement registration. Call register() AFTER your blocks/items are registered
 * so the icons can reference them.
 *
 * Lang keys (see assets/example_mod/lang/en_US.lang):
 *   title       = "achievement." + name        e.g. achievement.example_mod.getting_started
 *   description = "achievement." + name + ".desc"
 * where name is the string passed as the second argument below.
 *
 * Pages: achievements you do NOT add to an AchievementPage show up on the vanilla
 * page, mixed in with vanilla's. Achievements added to a custom page get their own
 * page, reachable with the &lt; &gt; buttons on the achievements screen.
 */
public final class ExampleAchievements {
	private ExampleAchievements() {}

	/** Granted on join (ExamplePlayerSetup); lives on the VANILLA page. */
	public static Achievement GETTING_STARTED;
	/** Granted on first jump (LivingEntityJumpMixin); root of the mod's own page. */
	public static Achievement JUMP_FOR_JOY;
	/** Granted by walking into the portal (ExamplePortalBlock); child of JUMP_FOR_JOY. */
	public static Achievement DIMENSIONAL_TRAVELER;

	public static void register() {
		// A root achievement (parent == null). Icon is an Item here; Block and
		// ItemStack overloads exist too. The two ints are the column/row position
		// on the achievements screen. Not added to a page below, so it appears on
		// the vanilla page.
		GETTING_STARTED = RetroAchievements.register(
			ExampleMod.id("getting_started"),
			"example_mod.getting_started",
			-2, -2,
			ExampleMod.SUSPICIOUS_SUBSTANCE,
			null
		);

		// Root of our own page.
		JUMP_FOR_JOY = RetroAchievements.register(
			ExampleMod.id("jump_for_joy"),
			"example_mod.jump_for_joy",
			0, 0,
			Item.FEATHER,
			null
		);

		// A child achievement: pass the parent as the last argument and the
		// achievements screen draws the connecting line from it.
		DIMENSIONAL_TRAVELER = RetroAchievements.register(
			ExampleMod.id("dimensional_traveler"),
			"example_mod.dimensional_traveler",
			2, 1,
			ExampleMod.EXAMPLE_PORTAL,
			JUMP_FOR_JOY
		);

		// Give the mod its own page on the achievements screen (the < > buttons).
		// Page title lang key: gui.retroapi.achievementPage.example_mod.example_page
		AchievementPage page = new AchievementPage(ExampleMod.id("example_page"));
		page.addAchievements(JUMP_FOR_JOY, DIMENSIONAL_TRAVELER);
	}
}
