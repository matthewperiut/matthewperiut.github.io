package com.example.example_mod;

import com.periut.retroapi.register.block.RetroTexture;
import com.periut.retroapi.register.block.RetroTextures;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

/**
 * A block with a different texture on its top, bottom and sides (think grass or
 * a crafting table). For anything beyond "one texture on all faces" you make a
 * Block subclass, register each texture with RetroTextures.addBlockTexture(...),
 * and override getTexture(face).
 *
 * Faces: 0 = bottom, 1 = top, 2 = north, 3 = south, 4 = west, 5 = east.
 */
public class ExampleSidedBlock extends Block {

	private final RetroTexture bottom;
	private final RetroTexture top;
	private final RetroTexture side;

	public ExampleSidedBlock(int id, Material material) {
		super(id, material);
		// Each call loads assets/example_mod/textures/block/<name>.png into the
		// block atlas and returns a handle whose .id is the sprite index.
		this.bottom = RetroTextures.addBlockTexture(ExampleMod.id("sided_block_bottom"));
		this.top = RetroTextures.addBlockTexture(ExampleMod.id("sided_block_top"));
		this.side = RetroTextures.addBlockTexture(ExampleMod.id("sided_block_side"));
		// The default sprite (used for particles etc.) + keep the block/texture pair
		// tracked so the atlas can re-resolve it (e.g. when StationAPI is present).
		this.textureId = this.side.id;
		RetroTextures.trackBlock(this, this.side);
	}

	@Override
	public int getTexture(int face) {
		switch (face) {
			case 0: return this.bottom.id;
			case 1: return this.top.id;
			default: return this.side.id;
		}
	}
}
