package com.example.example_mod.worldgen;

import com.example.example_mod.ExampleMod;

import net.minecraft.block.Block;
import net.minecraft.client.gui.screen.LoadingDisplay;
import net.minecraft.util.math.noise.OctavePerlinNoiseSampler;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSource;

import java.util.Random;

/**
 * The Noisy dimension's terrain, a real NOISE-driven generator with everything the
 * Curvy dimension left out: Perlin height, two biomes, caves, trees, lakes, and a
 * flower patch. It is the worldgen teaching piece, so each stage is its own clearly
 * named method.
 *
 * Perlin noise is smooth, seamless, tileable randomness: sample it at (x, z) and
 * nearby points return nearby values, so summed octaves (one broad, one fine) make
 * natural-looking hills instead of white-noise spikes. We AMPLIFY it, the height swing
 * is deliberately large, so the dimension reads as dramatic.
 *
 * Stages, in order:
 *   1. heightOf      , base terrain height from two noise octaves
 *   2. fillColumn    , stone up to height, water up to sea level, grass/dirt cap
 *   3. generateOres  , sprinkle vanilla ore veins through the stone
 *   4. carveTunnels  , winding worm caves that tunnel through the chunk
 *   5. decorate      , place trees, lakes, and flowers AFTER the raw terrain exists
 *
 * The caves are the interesting part. A plain noise-threshold cave (sample &gt; t means
 * air) makes blobby Swiss cheese; real caves WIND. So carveTunnels uses the vanilla
 * trick: start a "worm" at a random point, step it forward along a slowly-turning
 * heading, and hollow a sphere at each step. Long, branching, sinuous tunnels result,
 * and because each worm is seeded per ORIGIN chunk and reaches into its neighbours,
 * tunnels cross chunk borders seamlessly.
 */
public class NoisyChunkSource implements ChunkSource {

	private static final int SEA_LEVEL = 60;
	private static final int BASE_HEIGHT = 64;
	private static final double HEIGHT_AMPLITUDE = 40.0; // amplified: tall, dramatic hills

	private final World world;
	private final OctavePerlinNoiseSampler broad;   // big rolling shape
	private final OctavePerlinNoiseSampler fine;     // small surface detail
	private final OctavePerlinNoiseSampler biomeNoise; // which of two biomes

	public NoisyChunkSource(World world) {
		this.world = world;
		long seed = world.getSeed();
		this.broad = new OctavePerlinNoiseSampler(new Random(seed), 4);
		this.fine = new OctavePerlinNoiseSampler(new Random(seed + 1), 2);
		this.biomeNoise = new OctavePerlinNoiseSampler(new Random(seed + 3), 2);
	}

	private static int index(int x, int y, int z) {
		return (x * 16 + z) * 128 + y;
	}

	/** Two octaves of Perlin summed and amplified, then offset to the base height. */
	private int heightOf(int worldX, int worldZ) {
		double broadN = this.broad.sample(worldX / 80.0, worldZ / 80.0);
		double fineN = this.fine.sample(worldX / 20.0, worldZ / 20.0) * 0.25;
		double combined = broadN + fineN;
		return BASE_HEIGHT + (int) Math.round(combined * HEIGHT_AMPLITUDE);
	}

	/** True in the "amplified" biome (orange grass), false in the "lush" biome. */
	private boolean isAmplifiedBiome(int worldX, int worldZ) {
		return this.biomeNoise.sample(worldX / 220.0, worldZ / 220.0) > 0.0;
	}

	@Override
	public Chunk loadChunk(int chunkX, int chunkZ) {
		return getChunk(chunkX, chunkZ);
	}

	@Override
	public Chunk getChunk(int chunkX, int chunkZ) {
		byte[] blocks = new byte[16 * 128 * 16];

		for (int lx = 0; lx < 16; lx++) {
			for (int lz = 0; lz < 16; lz++) {
				int worldX = chunkX * 16 + lx;
				int worldZ = chunkZ * 16 + lz;
				fillColumn(blocks, lx, lz, heightOf(worldX, worldZ));
			}
		}

		generateOres(blocks, chunkX, chunkZ);
		carveTunnels(blocks, chunkX, chunkZ);

		Chunk chunk = new Chunk(this.world, blocks, chunkX, chunkZ);
		chunk.populateHeightMap();
		return chunk;
	}

	/** One column: bedrock floor, stone body, grass/dirt cap, water filling low ground. */
	private void fillColumn(byte[] blocks, int lx, int lz, int surface) {
		for (int y = 0; y < 128; y++) {
			int id;
			if (y == 0) {
				id = Block.BEDROCK.id;
			} else if (y < surface - 4) {
				id = Block.STONE.id;
			} else if (y < surface) {
				id = Block.DIRT.id;
			} else if (y == surface) {
				id = surface < SEA_LEVEL ? Block.DIRT.id : Block.GRASS_BLOCK.id;
			} else if (y <= SEA_LEVEL) {
				id = Block.WATER.id; // lakes/oceans fill anything below sea level
			} else {
				id = 0;
			}
			blocks[index(lx, y, lz)] = (byte) id;
		}
	}

	// ----------------------------------------------------------------- ores --
	// One descriptor per ore: block, vein size, veins per chunk, and the y band it
	// spawns in, mirroring vanilla beta's distribution (coal high and common, diamond
	// low and rare). generateOres rolls each one and drops blobby veins into stone.

	private static final class Ore {
		final int blockId;
		final int veinSize;
		final int perChunk;
		final int minY;
		final int maxY;

		Ore(Block block, int veinSize, int perChunk, int minY, int maxY) {
			this.blockId = block.id;
			this.veinSize = veinSize;
			this.perChunk = perChunk;
			this.minY = minY;
			this.maxY = maxY;
		}
	}

	private static final Ore[] ORES = {
		new Ore(Block.COAL_ORE, 16, 20, 0, 127),
		new Ore(Block.IRON_ORE, 8, 20, 0, 63),
		new Ore(Block.GOLD_ORE, 8, 2, 0, 31),
		new Ore(Block.REDSTONE_ORE, 7, 8, 0, 15),
		new Ore(Block.DIAMOND_ORE, 7, 1, 0, 15),
		new Ore(Block.LAPIS_ORE, 6, 1, 0, 31),
	};

	/** Drops the standard ore veins into this chunk's stone, vanilla-style. */
	private void generateOres(byte[] blocks, int chunkX, int chunkZ) {
		Random rand = new Random(this.world.getSeed() ^ ((long) chunkX * 1234567L + (long) chunkZ * 7654321L));
		for (Ore ore : ORES) {
			for (int n = 0; n < ore.perChunk; n++) {
				int x = rand.nextInt(16);
				int z = rand.nextInt(16);
				int y = ore.minY + rand.nextInt(ore.maxY - ore.minY + 1);
				placeVein(blocks, ore, x, y, z, rand);
			}
		}
	}

	/** A blobby vein: a short random walk replacing stone with the ore block. */
	private void placeVein(byte[] blocks, Ore ore, int x, int y, int z, Random rand) {
		for (int i = 0; i < ore.veinSize; i++) {
			if (x >= 0 && x < 16 && z >= 0 && z < 16 && y >= 1 && y < 128) {
				int idx = index(x, y, z);
				if (blocks[idx] == (byte) Block.STONE.id) {
					blocks[idx] = (byte) ore.blockId;
				}
			}
			x += rand.nextInt(3) - 1;
			y += rand.nextInt(3) - 1;
			z += rand.nextInt(3) - 1;
		}
	}

	// --------------------------------------------------------------- caves --

	/**
	 * Winding worm caves. For each origin chunk in a neighbourhood, spawn a few worms
	 * and let any that wander into THIS chunk hollow it out, so tunnels never stop at a
	 * chunk wall. Each worm walks a slowly-turning heading and carves a sphere per step.
	 */
	private void carveTunnels(byte[] blocks, int chunkX, int chunkZ) {
		int reach = 4; // how many chunks away a worm can still reach into this one
		for (int ox = chunkX - reach; ox <= chunkX + reach; ox++) {
			for (int oz = chunkZ - reach; oz <= chunkZ + reach; oz++) {
				Random rand = new Random(this.world.getSeed() ^ ((long) ox * 341873128712L + (long) oz * 132897987541L) ^ 0x0CA7E5L);
				int worms = rand.nextInt(rand.nextInt(rand.nextInt(4) + 1) + 1); // usually 0-1, sometimes more
				for (int w = 0; w < worms; w++) {
					double startX = ox * 16 + rand.nextInt(16);
					double startY = rand.nextInt(SEA_LEVEL - 8) + 8;
					double startZ = oz * 16 + rand.nextInt(16);
					carveWorm(blocks, chunkX, chunkZ, startX, startY, startZ, rand);
				}
			}
		}
	}

	/** One worm: step forward along a wandering heading, hollowing a sphere each step. */
	private void carveWorm(byte[] blocks, int chunkX, int chunkZ,
			double x, double y, double z, Random rand) {
		double yaw = rand.nextDouble() * Math.PI * 2.0;
		double pitch = (rand.nextDouble() - 0.5) * 0.5;
		int length = 80 + rand.nextInt(120);
		double radius = 1.5 + rand.nextDouble() * 2.5;

		int chunkMinX = chunkX * 16;
		int chunkMinZ = chunkZ * 16;

		for (int step = 0; step < length; step++) {
			// Advance.
			x += Math.cos(yaw) * Math.cos(pitch);
			z += Math.sin(yaw) * Math.cos(pitch);
			y += Math.sin(pitch);
			// Wander the heading a little each step, the source of the winding shape.
			yaw += (rand.nextDouble() - 0.5) * 0.35;
			pitch += (rand.nextDouble() - 0.5) * 0.25;
			pitch *= 0.85; // bias back toward horizontal so tunnels mostly snake sideways
			double r = radius * (0.7 + rand.nextDouble() * 0.6);

			// Only carve the part of the sphere inside THIS chunk's column.
			int minX = (int) Math.floor(x - r) - chunkMinX;
			int maxX = (int) Math.ceil(x + r) - chunkMinX;
			int minZ = (int) Math.floor(z - r) - chunkMinZ;
			int maxZ = (int) Math.ceil(z + r) - chunkMinZ;
			int minY = Math.max(1, (int) Math.floor(y - r));
			int maxY = Math.min(120, (int) Math.ceil(y + r));

			for (int lx = Math.max(0, minX); lx <= Math.min(15, maxX); lx++) {
				for (int lz = Math.max(0, minZ); lz <= Math.min(15, maxZ); lz++) {
					double wx = chunkMinX + lx + 0.5;
					double wz = chunkMinZ + lz + 0.5;
					for (int ly = minY; ly <= maxY; ly++) {
						double dx = wx - x, dy = ly + 0.5 - y, dz = wz - z;
						if (dx * dx + dy * dy + dz * dz <= r * r) {
							int idx = index(lx, ly, lz);
							byte cur = blocks[idx];
							// Carve stone/dirt/ore, never bedrock, and don't drain water.
							if (cur != (byte) Block.BEDROCK.id && cur != (byte) Block.WATER.id && cur != 0) {
								blocks[idx] = 0;
							}
						}
					}
				}
			}
		}
	}

	@Override
	public void decorate(ChunkSource chunkSource, int chunkX, int chunkZ) {
		// Decoration runs after the raw terrain of this and neighbouring chunks exists,
		// so it can safely read/write blocks through the world. Offset by 8 like vanilla
		// to avoid touching not-yet-generated chunk edges.
		int baseX = chunkX * 16 + 8;
		int baseZ = chunkZ * 16 + 8;
		Random rand = new Random(this.world.getSeed() ^ ((long) chunkX * 341873128712L + (long) chunkZ * 132897987541L));

		boolean amplified = isAmplifiedBiome(baseX, baseZ);

		// Funky trees: tall, varied skyroot-ish trees, denser in the lush biome.
		int treeCount = amplified ? 2 : 6;
		for (int i = 0; i < treeCount; i++) {
			int tx = baseX + rand.nextInt(16);
			int tz = baseZ + rand.nextInt(16);
			placeTree(tx, tz, rand);
		}

		// A water feature: occasionally gouge a small spring-fed pool into the surface.
		if (rand.nextInt(4) == 0) {
			placePool(baseX + rand.nextInt(16), baseZ + rand.nextInt(16));
		}

		// Flower patch: pink flowers (our custom cross block) scattered on grass. This is
		// where a MODDED block enters worldgen, placed through world.setBlock so RetroAPI's
		// extended block storage handles its id >= 256, the byte[] above could not.
		int flowerClusters = amplified ? 5 : 3;
		for (int c = 0; c < flowerClusters; c++) {
			int fx = baseX + rand.nextInt(16);
			int fz = baseZ + rand.nextInt(16);
			placeFlowerPatch(fx, fz, rand);
		}
	}

	/** A tall, slightly wild tree: a trunk of logs and a blobby leaf crown. */
	private void placeTree(int x, int z, Random rand) {
		int groundY = this.world.getTopY(x, z) - 1;
		if (groundY < SEA_LEVEL || this.world.getBlockId(x, groundY, z) != Block.GRASS_BLOCK.id) {
			return;
		}
		int height = 6 + rand.nextInt(6); // 6..11, taller than vanilla oaks
		for (int i = 1; i <= height; i++) {
			this.world.setBlock(x, groundY + i, z, Block.LOG.id);
		}
		// Leaf crown: a few stacked rings of varying radius near the top.
		int crownBase = groundY + height - 3;
		for (int dy = 0; dy <= 4; dy++) {
			int radius = dy == 0 || dy == 4 ? 1 : 2;
			for (int dx = -radius; dx <= radius; dx++) {
				for (int dz = -radius; dz <= radius; dz++) {
					if (dx == 0 && dz == 0 && dy < 4) {
						continue; // leave room for the trunk
					}
					if (Math.abs(dx) == radius && Math.abs(dz) == radius && rand.nextInt(2) == 0) {
						continue; // ragged corners for a funky silhouette
					}
					int ly = crownBase + dy;
					if (this.world.getBlockId(x + dx, ly, z + dz) == 0) {
						this.world.setBlock(x + dx, ly, z + dz, Block.LEAVES.id);
					}
				}
			}
		}
	}

	/** Scoop a shallow pool and fill it with water, a tiny "water feature". */
	private void placePool(int x, int z) {
		int surface = this.world.getTopY(x, z) - 1;
		if (surface <= SEA_LEVEL) {
			return;
		}
		for (int dx = -2; dx <= 2; dx++) {
			for (int dz = -2; dz <= 2; dz++) {
				if (dx * dx + dz * dz > 5) {
					continue;
				}
				this.world.setBlock(x + dx, surface, z + dz, Block.WATER.id);
				this.world.setBlock(x + dx, surface - 1, z + dz, Block.DIRT.id);
			}
		}
	}

	/** A cluster of the custom pink flower on grass. */
	private void placeFlowerPatch(int x, int z, Random rand) {
		for (int i = 0; i < 6; i++) {
			int fx = x + rand.nextInt(5) - 2;
			int fz = z + rand.nextInt(5) - 2;
			int fy = this.world.getTopY(fx, fz);
			if (fy > SEA_LEVEL
					&& this.world.getBlockId(fx, fy, fz) == 0
					&& this.world.getBlockId(fx, fy - 1, fz) == Block.GRASS_BLOCK.id) {
				this.world.setBlock(fx, fy, fz, ExampleMod.PINK_FLOWER.id);
			}
		}
	}

	@Override
	public boolean isChunkLoaded(int x, int z) {
		return true;
	}

	@Override
	public boolean save(boolean full, LoadingDisplay display) {
		return true;
	}

	@Override
	public boolean tick() {
		return false;
	}

	@Override
	public boolean canSave() {
		return true;
	}

	@Override
	public String getDebugInfo() {
		return "NoisyChunkSource";
	}
}
