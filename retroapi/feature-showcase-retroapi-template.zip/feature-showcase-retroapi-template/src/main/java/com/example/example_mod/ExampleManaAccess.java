package com.example.example_mod;

/**
 * The "duck interface" for mixin example 10: a brand-new capability that every
 * PlayerEntity in the game gains via Example10PlayerManaMixin. Any code can do
 *
 *   ExampleManaAccess mana = (ExampleManaAccess) player;
 *   mana.example_mod$setMana(mana.example_mod$getMana() + 5);
 *
 * because at runtime the mixin makes PlayerEntity implement this interface.
 * This is the same pattern RetroAPI itself uses for RetroBlockAccess, it's
 * how libraries bolt fluent APIs onto vanilla classes.
 */
public interface ExampleManaAccess {

	int example_mod$getMana();

	void example_mod$setMana(int mana);
}
