package com.example.example_mod;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityVehicleSetS2CPacket;

/**
 * Tells a player's client that something just mounted them. Beta 1.7.3 does not auto-sync
 * mounts, so when the Aerbunny climbs onto a player on a dedicated server we send the vanilla
 * packet by hand.
 *
 * <p>This lives in its OWN class on purpose. It names {@link ServerPlayerEntity}, which is a
 * SERVER-only class the client class loader refuses to load. {@code AerbunnyEntity.interact}
 * runs on the client too (in singleplayer the one world is client-side, so {@code isRemote} is
 * false there), and if that common method referenced {@code ServerPlayerEntity} directly, even
 * in a branch it never takes, loading the method would blow up on the client. Routing the call
 * through here keeps the server-only reference out of the common code: the JVM only resolves
 * {@code ServerPlayerEntity} when {@link #send} actually runs, and the call site guards that
 * with a string class-name check so it only runs server-side.</p>
 */
public final class MountSync {

	private MountSync() {
	}

	public static void send(PlayerEntity player, Entity rider, Entity vehicle) {
		((ServerPlayerEntity) player).networkHandler.sendPacket(new EntityVehicleSetS2CPacket(rider, vehicle));
	}
}
