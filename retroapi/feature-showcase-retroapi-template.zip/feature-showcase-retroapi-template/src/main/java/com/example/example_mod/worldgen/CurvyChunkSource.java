package com.example.example_mod.worldgen;

import net.minecraft.block.Block;
import net.minecraft.client.gui.screen.LoadingDisplay;
import net.minecraft.world.World;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSource;

/**
 * The Curvy dimension's terrain, the simplest possible CUSTOM chunk generator: a pure
 * equation, no noise. The surface height at any (x, z) is
 *
 *     y = BASE + AMPLITUDE * (sin(x / PERIOD) + cos(z / PERIOD))
 *
 * which makes a smooth rolling egg-carton of hills. This is the "hello world" of
 * worldgen: it shows the SHAPE of a ChunkSource (fill a chunk's byte array column by
 * column, wrap it in a Chunk, hand it back) without any of the noise machinery the
 * Noisy dimension adds later.
 *
 * A beta chunk is 16 x 128 x 16 blocks stored in one flat byte[] indexed
 * {@code (x * 16 + z) * 128 + y}. Bytes only hold ids 0-255, which is plenty for the
 * vanilla grass/dirt/stone/bedrock this dimension uses; modded blocks would be placed
 * afterwards through {@code world.setBlock} (see the Noisy dimension's flowers).
 */
public class CurvyChunkSource implements ChunkSource {

	private static final int BASE = 64;        // sea-ish level the hills sit around
	private static final double AMPLITUDE = 18; // how tall the hills swing
	private static final double PERIOD = 12.0;  // how wide each hill is (bigger = broader)

	private final World world;

	public CurvyChunkSource(World world) {
		this.world = world;
	}

	private static int index(int x, int y, int z) {
		return (x * 16 + z) * 128 + y;
	}

	@Override
	public Chunk loadChunk(int chunkX, int chunkZ) {
		return getChunk(chunkX, chunkZ);
	}

	@Override
	public Chunk getChunk(int chunkX, int chunkZ) {
		byte[] blocks = new byte[16 * 128 * 16];

		for (int lx = 0; lx < 16; lx++) {
			for (int lz = 0; lz < 16; lz++) {
				int worldX = chunkX * 16 + lx;
				int worldZ = chunkZ * 16 + lz;

				// THE equation. Scaled-up sin(x) + cos(z), rounded to a block height.
				double curve = Math.sin(worldX / PERIOD) + Math.cos(worldZ / PERIOD);
				int surface = BASE + (int) Math.round(AMPLITUDE * curve);

				for (int y = 0; y < 128; y++) {
					int id;
					if (y == 0) {
						id = Block.BEDROCK.id;       // unbreakable floor
					} else if (y == surface) {
						id = Block.GRASS_BLOCK.id;    // one grass cap
					} else if (y >= surface - 3 && y < surface) {
						id = Block.DIRT.id;           // three dirt under the grass
					} else if (y < surface) {
						id = Block.STONE.id;          // stone all the way down
					} else {
						id = 0;                       // air above the surface
					}
					blocks[index(lx, y, lz)] = (byte) id;
				}
			}
		}

		Chunk chunk = com.periut.retroapi.world.RetroWorldGen.createChunk(this.world, blocks, chunkX, chunkZ);
		chunk.populateHeightMap();
		return chunk;
	}

	@Override
	public boolean isChunkLoaded(int x, int z) {
		return true;
	}

	@Override
	public void decorate(ChunkSource chunkSource, int chunkX, int chunkZ) {
		// Nothing to decorate: the Curvy dimension is bare hills on purpose, so the
		// equation is the whole story. The Noisy dimension is where decoration lives.
	}

	@Override
	public boolean save(boolean full, LoadingDisplay display) {
		return true;
	}

	@Override
	public boolean tick() {
		return false;
	}

	@Override
	public boolean canSave() {
		return true;
	}

	@Override
	public String getDebugInfo() {
		return "CurvyChunkSource";
	}
}
