package com.example.example_mod;

/**
 * The shape of one side of a wall: not connected, a low segment, or a full-height
 * segment (when something sits on the junction). Enum constants serialize as their
 * lowercase names, which is what the blockstate JSON's "north": "low" keys match.
 */
public enum WallShape {
	NONE,
	LOW,
	TALL
}
