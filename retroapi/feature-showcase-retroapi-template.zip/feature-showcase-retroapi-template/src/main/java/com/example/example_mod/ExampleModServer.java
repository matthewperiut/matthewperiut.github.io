package com.example.example_mod;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

import net.minecraft.entity.player.ServerPlayerEntity;

import net.ornithemc.osl.entrypoints.api.server.ServerModInitializer;
import net.ornithemc.osl.networking.api.server.ServerPlayNetworking;

/**
 * The dedicated-server entrypoint, runs ONLY on a dedicated server, after init().
 * Wired up in fabric.mod.json under "entrypoints" -> "server-init".
 *
 * Server-only classes (ServerPlayerEntity, ServerPlayNetworking, MinecraftServer)
 * stay in here for the same reason client-only classes stay in ExampleModClient.
 */
public class ExampleModServer implements ServerModInitializer {

	/** Players we've already welcomed (weak so it empties itself on logout). */
	private static final Set<ServerPlayerEntity> WELCOMED =
		Collections.newSetFromMap(new WeakHashMap<ServerPlayerEntity, Boolean>());

	@Override
	public void initServer() {
		// Listen for the client's PING reply (see ExampleNetworking for the plan).
		// ctx gives you the sending player, the server, and the network handler.
		ServerPlayNetworking.registerListener(ExampleNetworking.PING, (ctx, buf) -> {
			String note = buf.readString();
			ExampleMod.LOGGER.info("[server] ping from {}: {}", ctx.player().name, note);
		});

		// The rider's jump key, shipped by the client every tick while riding an Aerbunny.
		// We hand it to the Aerbunny the player is carrying so the glide boost fires on the
		// authoritative side. ensureOnMainThread because we touch live entity state.
		ServerPlayNetworking.registerListener(ExampleNetworking.AERBUNNY_JUMP, (ctx, buf) -> {
			boolean jumping = buf.readBoolean();
			ctx.ensureOnMainThread();
			ServerPlayerEntity player = ctx.player();
			if (player != null && player.passenger instanceof AerbunnyEntity bunny) {
				bunny.vehicleJumping = jumping;
			}
		});
	}

	/**
	 * Sends the WELCOME packet to a player exactly once per login. Called every
	 * server tick from ServerPlayerTickMixin; we wait until OSL's channel handshake
	 * with this client is done (isPlayReady) before sending, then remember them.
	 */
	public static void welcomeOnceReady(ServerPlayerEntity player) {
		if (WELCOMED.contains(player)) {
			return;
		}
		if (!ServerPlayNetworking.isPlayReady(player, ExampleNetworking.WELCOME)) {
			return; // handshake not finished yet (or the client doesn't have the mod)
		}
		WELCOMED.add(player);
		ServerPlayNetworking.send(player, ExampleNetworking.WELCOME, buf ->
			buf.writeString("Welcome to the server, " + player.name + "!"));
	}
}
