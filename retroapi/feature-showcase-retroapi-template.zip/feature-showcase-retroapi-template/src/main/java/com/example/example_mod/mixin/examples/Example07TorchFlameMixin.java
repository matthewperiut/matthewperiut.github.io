package com.example.example_mod.mixin.examples;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

import net.minecraft.block.TorchBlock;

/**
 * MIXIN EXAMPLE 7/10, @ModifyArg: rewriting one argument of one call.
 *
 * Effect in game: torches show extra flame particles instead of smoke.
 *
 * Instead of hooking a whole method, @ModifyArg surgically targets a CALL made
 * inside it. TorchBlock.randomDisplayTick calls
 *     world.addParticle("smoke", x, y, z, ...)   and
 *     world.addParticle("flame", x, y, z, ...)
 * We intercept every addParticle call in that method (the "target" selector
 * matches the callee by its descriptor), receive the first String argument,
 * and return what should be passed instead.
 *
 * Compared to @Redirect, @ModifyArg is the SAFER tool when all you want is to
 * change a parameter: multiple mods can @ModifyArg the same call site, but only
 * one mod's @Redirect can win.
 *
 * If you need to change SEVERAL arguments at once, or decide whether the call
 * happens at all, that's MixinExtras' @WrapOperation territory (the chainable
 * @Redirect replacement), see Example11WrapOperationMixin and
 * https://github.com/LlamaLad7/MixinExtras/wiki/WrapOperation
 *
 * Client-only: randomDisplayTick is decorative and only runs on the client.
 */
@Mixin(TorchBlock.class)
public class Example07TorchFlameMixin {

	@ModifyArg(
		method = "randomDisplayTick",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/world/World;addParticle(Ljava/lang/String;DDDDDD)V"
		),
		index = 0 // the first argument: the particle name
	)
	private String example_mod$moreFlames(String particle) {
		// "smoke" becomes "flame"; the existing "flame" call passes through.
		return "smoke".equals(particle) ? "flame" : particle;
	}
}
