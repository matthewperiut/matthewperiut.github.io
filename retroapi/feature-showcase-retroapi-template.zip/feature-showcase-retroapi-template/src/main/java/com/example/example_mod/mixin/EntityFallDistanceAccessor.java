package com.example.example_mod.mixin;

import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Reads/writes another entity's private {@code fallDistance}. The Aerbunny zeroes its
 * rider's fall distance every tick so a slow-falling player never takes fall damage when
 * they finally touch down. You can only reach a DIFFERENT entity's private field through
 * an accessor mixin like this; the Aerbunny's own fields it just touches directly.
 */
@Mixin(Entity.class)
public interface EntityFallDistanceAccessor {

	@Accessor("fallDistance")
	void setFallDistance(float fallDistance);
}
