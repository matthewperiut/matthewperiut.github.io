package com.example.example_mod;

import com.periut.retroapi.entity.client.RetroEntityRenderers;
import com.periut.retroapi.gui.client.RetroGuiHandler;
import com.periut.retroapi.gui.client.RetroGuiRegistry;

import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;

import net.ornithemc.osl.entrypoints.api.client.ClientModInitializer;
import net.ornithemc.osl.networking.api.client.ClientPlayNetworking;

/**
 * The client entrypoint, runs ONLY on the client, after the common init().
 * Wired up in fabric.mod.json under "entrypoints" -> "client-init".
 *
 * Anything that touches client-only classes (renderers, models, the Minecraft
 * client instance, ClientPlayNetworking) belongs here, never in ExampleMod , 
 * otherwise a dedicated server would crash trying to load those classes.
 */
public class ExampleModClient implements ClientModInitializer {

	@Override
	public void initClient() {
		// Tell the client how to draw the example mob: a generic biped (player/zombie
		// shaped) model with a 0.5-block shadow. Write your own EntityRenderer/model
		// subclass for custom shapes.
		RetroEntityRenderers.register(ExampleEntity.class,
			new LivingEntityRenderer(new BipedEntityModel(), 0.5F));

		// The Aerbunny gets a CUSTOM model + renderer (not the biped). The renderer
		// reads the entity's server-synced puffiness and velocity to drive the puff
		// and tilt, the payoff of the DataTracker sync in AerbunnyEntity.
		RetroEntityRenderers.register(AerbunnyEntity.class,
			new AerbunnyRenderer(new AerbunnyModel(), 0.5F));

		// Background music, the vanilla way: aether1.ogg lives in sounds/music/, so beta's
		// own music ticker shuffles it into the random rotation alongside the vanilla
		// tracks (SoundEntry.getSounds() picks randomly across everything registered). No
		// code needed. For a FORCED theme on every world load instead, there is
		// RetroMusic.playOnWorldLoad(streamingId) (puts the track in sounds/streaming/).

		// The client half of the crate GUI (the common half is in ExampleMod.init).
		// Two factories: how to build the screen, and how to build a stand-in
		// inventory on remote clients (multiplayer), which have no real block entity.
		RetroGuiRegistry.register(ExampleMod.id("crate"), new RetroGuiHandler(
			(player, inventory) -> new ExampleCrateScreen(player.inventory, (ExampleCrateBlockEntity) inventory),
			ExampleCrateBlockEntity::new));

		// Tint provider for the pedestal's gem faces (tintindex 0 in the model JSON):
		// a steady ruby red. Providers can also sample the world, see
		// RetroBlockColors.GRASS / .FOLIAGE for the biome colormap versions.
		com.periut.retroapi.client.render.RetroBlockColors.register(ExampleMod.PEDESTAL,
			(state, world, x, y, z, tintIndex) -> 0xE12D55);

		RetroGuiRegistry.register(ExampleMod.id("freezer"), new RetroGuiHandler(
			(player, inventory) -> new ExampleFreezerScreen(player.inventory, (ExampleFreezerBlockEntity) inventory),
			ExampleFreezerBlockEntity::new));

		// Listen for the server's WELCOME packet (see ExampleNetworking for the plan).
		// The lambda gets a Context (ctx.minecraft(), ctx.ensureOnMainThread(), ...)
		// and a PacketBuffer with read/write methods for all the usual types.
		ClientPlayNetworking.registerListener(ExampleNetworking.WELCOME, (ctx, buf) -> {
			String message = buf.readString();
			ExampleMod.LOGGER.info("[client] the server says: {}", message);

			// Reply on our client->server channel.
			ClientPlayNetworking.send(ExampleNetworking.PING, reply ->
				reply.writeString("Thanks for the welcome!"));
		});
	}
}
