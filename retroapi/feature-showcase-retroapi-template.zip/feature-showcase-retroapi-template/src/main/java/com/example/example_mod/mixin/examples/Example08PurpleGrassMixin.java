package com.example.example_mod.mixin.examples;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import com.example.example_mod.ExampleMod;

import com.periut.retroapi.world.RetroWorlds;

import net.minecraft.block.GrassBlock;
import net.minecraft.client.color.world.GrassColors;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

/**
 * MIXIN EXAMPLE 8/10, @Redirect: replacing a call entirely.
 *
 * Effect in game: grass renders purple, but ONLY inside the example dimension
 * (walk through the example portal to see it). The overworld stays green.
 *
 * GrassBlock.getColorMultiplier asks the biome for its grass color by calling
 * the static GrassColors.getColor(temperature, humidity). A @Redirect swaps
 * that call out for our method: we receive the exact arguments the call would
 * have received, and our handler can ALSO take the enclosing method's own
 * parameters appended after them (BlockView, x, y, z here), which is how we
 * know which dimension we're coloring. Outside the example dimension we call
 * the real GrassColors.getColor ourselves, so vanilla behavior is preserved.
 *
 * ╔═══════════════════════════════════════════════════════════════════════╗
 * ║  ⚠⚠⚠  STOP: @Redirect (and @Overwrite) ARE LAST RESORTS  ⚠⚠⚠           ║
 * ║                                                                       ║
 * ║  They are EXCLUSIVE: if two mods @Redirect the same call (or          ║
 * ║  @Overwrite the same method), the game CRASHES AT LAUNCH, mixin       ║
 * ║  refuses to apply the second one. In a mixin-heavy ecosystem like     ║
 * ║  beta modding, "my mod plus any other mod touching this method" is    ║
 * ║  not rare. It is the expected case.                                   ║
 * ║                                                                       ║
 * ║  USE MIXINEXTRAS INSTEAD, it ships with this stack already:           ║
 * ║    instead of @Redirect   → @WrapOperation (chainable; you can even   ║
 * ║                             still call the original, see              ║
 * ║                             Example11WrapOperationMixin for this      ║
 * ║                             exact grass-color case done right)        ║
 * ║    instead of @Overwrite  → @WrapMethod, or @Inject + ci.cancel()     ║
 * ║    instead of @Inject(RETURN) + CIR → @ModifyReturnValue              ║
 * ║                             (see Example12ModifyReturnValueMixin)     ║
 * ║                                                                       ║
 * ║  Docs: https://github.com/LlamaLad7/MixinExtras/wiki                  ║
 * ║   - Wiki: .../wiki/WrapOperation                                      ║
 * ║   - Wiki: .../wiki/WrapMethod                                         ║
 * ║   - Wiki: .../wiki/ModifyReturnValue                                  ║
 * ╚═══════════════════════════════════════════════════════════════════════╝
 *
 * This @Redirect stays in the showcase only so you can see the tool you're
 * being warned away from. Client-only: block coloring is rendering code.
 */
@Mixin(GrassBlock.class)
public class Example08PurpleGrassMixin {

	@Redirect(
		method = "getColorMultiplier",
		at = @At(
			value = "INVOKE",
			target = "Lnet/minecraft/client/color/world/GrassColors;getColor(DD)I"
		)
	)
	private int example_mod$purpleGrass(double temperature, double humidity,
			BlockView view, int x, int y, int z) {
		// GOTCHA worth knowing: during chunk rendering the BlockView is a WorldRegion
		// wrapper, NOT the World, so "view instanceof World" is false right when this
		// code matters most. RetroWorlds.unwrap sees through the wrapper.
		World world = RetroWorlds.unwrap(view);
		if (world != null
			&& ExampleMod.EXAMPLE_DIMENSION != null
			&& world.dimension.id == ExampleMod.EXAMPLE_DIMENSION.getSerialId()) {
			return 0x9B30FF;
		}
		return GrassColors.getColor(temperature, humidity);
	}
}
