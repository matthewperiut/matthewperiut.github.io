package com.example.example_mod.mixin.examples;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * MIXIN EXAMPLE 3/10, cancellable @Inject: stopping vanilla from running.
 *
 * Effect in game: players who are SNEAKING take no fall damage.
 *
 * With cancellable = true the CallbackInfo gains ci.cancel(), which makes the
 * target method return immediately, everything below your injection point is
 * skipped. onLanding(float fallDistance) is where LivingEntity turns a landing
 * into damage, so cancelling at HEAD swallows the fall entirely.
 *
 * SAFETY NOTES, this is where mixin discipline starts to matter:
 *   - Cancel CONDITIONALLY. An unconditional cancel here would disable fall
 *     damage for every living thing in the game and break other mods' hooks.
 *   - We check `self instanceof PlayerEntity` because onLanding runs for every
 *     living entity; mixins into broad base classes hit everything.
 *   - HEAD + cancel is still friendlier than @Overwrite: other mods' injections
 *     at HEAD still run; an @Overwrite would silently delete them.
 */
@Mixin(LivingEntity.class)
public class Example03NoSneakFallDamageMixin {

	@Inject(method = "onLanding", at = @At("HEAD"), cancellable = true)
	private void example_mod$softLanding(float fallDistance, CallbackInfo ci) {
		LivingEntity self = (LivingEntity) (Object) this;
		if (self instanceof PlayerEntity && self.isSneaking()) {
			ci.cancel(); // skip vanilla's fall-damage code entirely
		}
	}
}
