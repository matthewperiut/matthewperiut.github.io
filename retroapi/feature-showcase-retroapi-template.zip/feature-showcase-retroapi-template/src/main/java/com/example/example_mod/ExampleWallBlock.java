package com.example.example_mod;

import com.periut.retroapi.state.RetroBlockState;
import com.periut.retroapi.state.RetroBoolProperty;
import com.periut.retroapi.state.RetroEnumProperty;
import com.periut.retroapi.state.RetroStates;
import com.periut.retroapi.voxelshapes.HasCollisionVoxelShape;
import com.periut.retroapi.voxelshapes.HasVoxelShape;
import com.periut.retroapi.voxelshapes.VoxelBox;
import com.periut.retroapi.voxelshapes.VoxelData;
import com.periut.retroapi.voxelshapes.VoxelShape;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.util.math.Box;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;

/**
 * The stone wall: the real-world blockstate workout. Ported from
 * matthewperiut/stonewalls-fabric-b1.7.3 (a StationAPI mod) to RetroAPI.
 *
 * Five properties: up (the center post) and a none/low/tall shape per side, which
 * makes 2 x 3 x 3 x 3 x 3 = 162 states, an order of magnitude past the vanilla
 * nibble, so most of them live in secondary meta. The blockstate JSON is a
 * MULTIPART file straight out of the modern wall format: the post applies when
 * up=true, a rotated side segment applies per connected direction, and the tall
 * variant applies when something sits on the junction.
 *
 * The interesting lifecycle: connections are STATE, recomputed whenever the
 * neighborhood changes. onPlaced computes the initial state; neighborUpdate
 * recomputes it on every block update next door; RetroStates.set only fires when
 * the state actually changed (states are interned, so != is exact), which both
 * avoids redundant work and terminates the update ripple two walls would
 * otherwise bounce between forever.
 */
public class ExampleWallBlock extends Block implements HasVoxelShape, HasCollisionVoxelShape {

	public static final RetroBoolProperty UP = RetroBoolProperty.of("up");
	public static final RetroEnumProperty<WallShape> NORTH = RetroEnumProperty.of("north", WallShape.class);
	public static final RetroEnumProperty<WallShape> SOUTH = RetroEnumProperty.of("south", WallShape.class);
	public static final RetroEnumProperty<WallShape> WEST = RetroEnumProperty.of("west", WallShape.class);
	public static final RetroEnumProperty<WallShape> EAST = RetroEnumProperty.of("east", WallShape.class);

	public ExampleWallBlock(int id) {
		super(id, Material.STONE);
	}

	// ------------------------------------------------------------ voxel shapes --
	// The wall's REAL shape: a box per visible piece, built from the same state the
	// models render from. The post box appears when up=true, and every connected
	// side contributes its own segment box (mirroring the wall_side model geometry,
	// 14px tall for low and 16px for tall segments). Selection outlines hug each
	// box, you can mine through the gaps, and entities collide with the true shape.
	// The collision variant adds the fence-style +0.5 height so walls can't be
	// hopped over, while the selection shape stays at the visual height.

	private static final VoxelBox POST = new VoxelBox(0.25, 0, 0.25, 0.75, 1, 0.75);
	private static final VoxelBox SIDE_NORTH_LOW = new VoxelBox(0.3125, 0, 0, 0.6875, 0.875, 0.5);
	private static final VoxelBox SIDE_NORTH_TALL = new VoxelBox(0.3125, 0, 0, 0.6875, 1, 0.5);
	private static final VoxelBox CLIMB_GUARD = new VoxelBox(0, 0, 0, 0, 0.5, 0);

	/** Shapes are pure functions of the state; cache one VoxelData per interned state. */
	private static final Map<RetroBlockState, VoxelData> SHAPES = new HashMap<>();
	private static final Map<RetroBlockState, VoxelData> COLLISION_SHAPES = new HashMap<>();

	private VoxelData shapeData(RetroBlockState state, boolean collision) {
		Map<RetroBlockState, VoxelData> cache = collision ? COLLISION_SHAPES : SHAPES;
		VoxelData cached = cache.get(state);
		if (cached != null) {
			return cached;
		}
		VoxelData data = new VoxelData(new VoxelBox[0]);
		if (state.get(UP)) {
			data = data.withBox(collision ? POST.add(CLIMB_GUARD) : POST);
		}
		data = withSide(data, state.get(NORTH), 0, collision);
		data = withSide(data, state.get(EAST), 1, collision);
		data = withSide(data, state.get(SOUTH), 2, collision);
		data = withSide(data, state.get(WEST), 3, collision);
		if (!collision) {
			data = data.preCache(); // outline edges computed once per state
		}
		cache.put(state, data);
		return data;
	}

	/** Adds one side segment box, rotated from the north template in 90 degree steps. */
	private static VoxelData withSide(VoxelData data, WallShape shape, int rotation, boolean collision) {
		if (shape == WallShape.NONE) {
			return data;
		}
		VoxelBox box = shape == WallShape.TALL ? SIDE_NORTH_TALL : SIDE_NORTH_LOW;
		for (int i = 0; i < rotation; i++) {
			box = rotateY(box);
		}
		if (collision) {
			box = box.add(CLIMB_GUARD);
		}
		return data.withBox(box);
	}

	/** Rotates a box 90 degrees clockwise about the block center (x,z) -> (1-z, x). */
	private static VoxelBox rotateY(VoxelBox box) {
		return new VoxelBox(1 - box.maxZ(), box.minY(), box.minX(), 1 - box.minZ(), box.maxY(), box.maxX());
	}

	@Override
	public VoxelShape getVoxelShape(World world, int x, int y, int z) {
		RetroBlockState state = RetroStates.get(world, x, y, z);
		if (state == null) {
			return null;
		}
		return shapeData(state, false).withOffset(x, y, z);
	}

	@Override
	public VoxelShape getCollisionVoxelShape(World world, int x, int y, int z) {
		RetroBlockState state = RetroStates.get(world, x, y, z);
		if (state == null) {
			return null;
		}
		return shapeData(state, true).withOffset(x, y, z);
	}

	private static boolean canConnect(BlockView view, int x, int y, int z) {
		int blockId = view.getBlockId(x, y, z);
		if (blockId <= 0 || blockId >= Block.BLOCKS.length || Block.BLOCKS[blockId] == null) {
			return false;
		}
		Block block = Block.BLOCKS[blockId];
		return block.isFullCube() || block instanceof ExampleWallBlock;
	}

	/** Computes what this wall's state should be from its neighborhood. */
	public RetroBlockState determineState(World world, int x, int y, int z) {
		boolean up = true;
		boolean north = canConnect(world, x, y, z - 1);
		boolean south = canConnect(world, x, y, z + 1);
		boolean west = canConnect(world, x - 1, y, z);
		boolean east = canConnect(world, x + 1, y, z);

		// A straight run (and nothing else) hides the post.
		boolean nsWall = north && south && !(west || east);
		boolean weWall = west && east && !(north || south);
		boolean canUpBeFalse = nsWall || weWall;

		boolean tallNorth = false;
		boolean tallSouth = false;
		boolean tallWest = false;
		boolean tallEast = false;

		int aboveId = world.getBlockId(x, y + 1, z);
		Block above = (aboveId > 0 && aboveId < Block.BLOCKS.length) ? Block.BLOCKS[aboveId] : null;

		if (above instanceof ExampleWallBlock) {
			if (canUpBeFalse) {
				// Match the wall above: a post up there forces a post down here.
				RetroBlockState aboveState = ((ExampleWallBlock) above).determineState(world, x, y + 1, z);
				up = aboveState.get(UP);
			}
			tallNorth = canConnect(world, x, y + 1, z - 1);
			tallSouth = canConnect(world, x, y + 1, z + 1);
			tallWest = canConnect(world, x - 1, y + 1, z);
			tallEast = canConnect(world, x + 1, y + 1, z);
		} else {
			up = !canUpBeFalse;
		}

		if (above != null && above.isFullCube()) {
			tallNorth = true;
			tallSouth = true;
			tallWest = true;
			tallEast = true;
		}

		return RetroStates.getDefault(this)
			.with(UP, up)
			.with(NORTH, north ? (tallNorth ? WallShape.TALL : WallShape.LOW) : WallShape.NONE)
			.with(SOUTH, south ? (tallSouth ? WallShape.TALL : WallShape.LOW) : WallShape.NONE)
			.with(WEST, west ? (tallWest ? WallShape.TALL : WallShape.LOW) : WallShape.NONE)
			.with(EAST, east ? (tallEast ? WallShape.TALL : WallShape.LOW) : WallShape.NONE);
	}

	/** Recomputes and writes the state, but only when it actually changed (interned ==). */
	private void refresh(World world, int x, int y, int z) {
		RetroBlockState current = RetroStates.get(world, x, y, z);
		RetroBlockState next = determineState(world, x, y, z);
		if (current != next) {
			RetroStates.set(world, x, y, z, next);
		}
	}

	@Override
	public void onPlaced(World world, int x, int y, int z) {
		super.onPlaced(world, x, y, z);
		refresh(world, x, y, z);
	}

	@Override
	public void neighborUpdate(World world, int x, int y, int z, int neighborId) {
		refresh(world, x, y, z);
		// A wall below may need to grow or lose its post because of us.
		int belowId = world.getBlockId(x, y - 1, z);
		if (belowId > 0 && belowId < Block.BLOCKS.length && Block.BLOCKS[belowId] instanceof ExampleWallBlock) {
			((ExampleWallBlock) Block.BLOCKS[belowId]).refresh(world, x, y - 1, z);
		}
		super.neighborUpdate(world, x, y, z, neighborId);
	}

	// ------------------------------------------------------------------ shape --
	// Hitboxes follow the connections: a straight run is a thin slab, anything
	// with a post is the classic centered pillar stretched toward connections.
	// Models are visual only; collision stays code, which is what these are.

	private Box shape(RetroBlockState state, boolean collider, boolean bounding) {
		if (state == null || !(state.getBlock() instanceof ExampleWallBlock)) {
			return Box.create(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
		}
		float height = collider ? 1.5F : 1.0F;
		if (state.get(UP)) {
			if (bounding) {
				boolean north = state.get(NORTH) != WallShape.NONE;
				boolean south = state.get(SOUTH) != WallShape.NONE;
				boolean west = state.get(WEST) != WallShape.NONE;
				boolean east = state.get(EAST) != WallShape.NONE;
				return Box.create(west ? 0.0F : 0.25F, 0.0F, north ? 0.0F : 0.25F,
					east ? 1.0F : 0.75F, height, south ? 1.0F : 0.75F);
			}
			return Box.create(0.25F, 0.0F, 0.25F, 0.75F, height, 0.75F);
		}
		if (state.get(EAST) != WallShape.NONE && state.get(WEST) != WallShape.NONE) {
			boolean tall = state.get(EAST) == WallShape.TALL && state.get(WEST) == WallShape.TALL;
			return Box.create(0.0F, 0.0F, 0.3125F, 1.0F, collider ? 1.5F : (tall ? 1.0F : 0.875F), 0.6875F);
		}
		boolean tall = state.get(NORTH) == WallShape.TALL && state.get(SOUTH) == WallShape.TALL;
		return Box.create(0.3125F, 0.0F, 0.0F, 0.6875F, collider ? 1.5F : (tall ? 1.0F : 0.875F), 1.0F);
	}

	private static Box offset(Box box, int x, int y, int z) {
		box.minX += x;
		box.minY += y;
		box.minZ += z;
		box.maxX += x;
		box.maxY += y;
		box.maxZ += z;
		return box;
	}

	@Override
	public Box getCollisionShape(World world, int x, int y, int z) {
		return offset(shape(RetroStates.get(world, x, y, z), true, false), x, y, z);
	}

	@Override
	public Box getBoundingBox(World world, int x, int y, int z) {
		return offset(shape(RetroStates.get(world, x, y, z), false, false), x, y, z);
	}

	@Override
	public void updateBoundingBox(BlockView view, int x, int y, int z) {
		// RetroStates.get accepts any BlockView (it unwraps render-time WorldRegions).
		RetroBlockState state = RetroStates.get(view, x, y, z);
		Box box = shape(state, false, true);
		this.setBoundingBox((float) box.minX, (float) box.minY, (float) box.minZ,
			(float) box.maxX, (float) box.maxY, (float) box.maxZ);
	}
}
