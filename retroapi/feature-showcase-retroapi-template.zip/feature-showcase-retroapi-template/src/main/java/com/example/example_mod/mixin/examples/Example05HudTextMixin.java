package com.example.example_mod.mixin.examples;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;

/**
 * MIXIN EXAMPLE 5/10, @Shadow: using the target class's private fields.
 *
 * Effect in game: "example mod" is drawn in the top-left corner of the HUD.
 *
 * InGameHud keeps its Minecraft reference in a PRIVATE field. A @Shadow field
 * is a declaration that says "this field already exists in the target class , 
 * let me use it": at runtime the two are the same field. The name must match
 * the target's field name exactly. (@Shadow works for methods the same way.)
 *
 * Also shown: InGameHud extends DrawContext, vanilla's helper for drawing
 * text/textures, cast `this` to it and you can draw in any render hook.
 *
 * Client-only mixin -> listed under "client" in example_mod.mixins.json.
 */
@Mixin(InGameHud.class)
public class Example05HudTextMixin {

	// The real field is `private Minecraft minecraft` in InGameHud.
	@Shadow
	private Minecraft minecraft;

	@Inject(method = "render", at = @At("TAIL"))
	private void example_mod$drawBadge(float tickDelta, boolean inScreen, int mouseX, int mouseY, CallbackInfo ci) {
		DrawContext ctx = (DrawContext) (Object) this;
		ctx.drawTextWithShadow(this.minecraft.textRenderer, "example mod", 2, 2, 0x55FF55);
	}
}
