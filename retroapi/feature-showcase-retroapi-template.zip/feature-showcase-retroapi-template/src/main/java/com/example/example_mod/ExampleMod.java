package com.example.example_mod;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.periut.retroapi.dimension.DimensionRegistration;
import com.periut.retroapi.dimension.RetroDimensions;
import com.periut.retroapi.entity.EntityRegistration;
import com.periut.retroapi.biome.BiomeBuilder;
import com.periut.retroapi.biome.RetroBiomes;
import com.example.example_mod.worldgen.CurvyDimension;
import com.example.example_mod.worldgen.NoisyDimension;
import com.example.example_mod.worldgen.DimensionPortalBlock;
import net.minecraft.world.biome.Biome;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.passive.ChickenEntity;
import com.periut.retroapi.entity.RetroEntities;
import com.periut.retroapi.entity.client.MobFactory;
import com.periut.retroapi.register.block.RetroBlockAccess;
import com.periut.retroapi.register.blockentity.RetroBlockEntities;
import com.periut.retroapi.register.item.RetroItemAccess;
import com.periut.retroapi.register.recipe.RetroRecipes;
import com.periut.retroapi.register.recipe.event.RecipeRegistrationCallback;
import com.periut.retroapi.register.rendertype.RenderType;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

import net.ornithemc.osl.core.api.util.NamespacedIdentifier;
import net.ornithemc.osl.core.api.util.NamespacedIdentifiers;
import net.ornithemc.osl.entrypoints.api.ModInitializer;

/**
 * The common entrypoint of the mod, runs on BOTH the client and the dedicated server.
 * It is wired up in fabric.mod.json under "entrypoints" -> "init".
 *
 * Everything here is registered through RetroAPI, which takes care of block/item id
 * assignment, texture atlasing, world persistence, and multiplayer sync for you.
 */
public class ExampleMod implements ModInitializer {

	// Your mod id. Must match the "id" field in fabric.mod.json, the assets folder name
	// (src/main/resources/assets/example_mod/), and the "@" substitutions in your lang file.
	public static final String MOD_ID = "example_mod";

	// This logger is used to write text to the console and the log file.
	// It is considered best practice to use your mod name as the logger's name.
	// That way, it's clear which mod wrote info, warnings, and errors.
	public static final Logger LOGGER = LogManager.getLogger("Example Mod");

	// A custom render type lets a block draw itself however it wants (here: an inset cube
	// drawn with vanilla cobblestone's sprite). Registered once, then referenced from the
	// block below via .renderType(...). See ExampleModClient for entity renderers.
	public static final NamespacedIdentifier PIPE_RENDER_TYPE = RenderType.register(
		id("pipe"),
		ctx -> {
			// ctx is a BlockRenderContext: it knows the block, position, world, lighting,
			// and exposes helpers like renderFullCube(), renderLitFace(face, sprite), ...
			ctx.renderAllLitFaces(Block.COBBLESTONE.getTexture(0));
			return true;
		}
	);

	// Keep references to your registered content in static fields so the rest of your
	// code (recipes, achievements, player setup, ...) can use them.
	public static Block EXAMPLE_BLOCK;
	public static Block SIDED_BLOCK;
	public static Block PIPE_BLOCK;
	public static Block COUNTER_BLOCK;
	public static Block CRATE_BLOCK;
	public static Block FREEZER_BLOCK;
	public static Block EXAMPLE_PORTAL;
	public static Item SUSPICIOUS_SUBSTANCE;
	public static Item JUMP_STICK;

	// Asset platform demos (RetroAPI 1.0.23+): tags, states+models, animation, item models.
	public static Block RUBY_ORE;
	public static Block LAMP;
	public static Block EMBER_BLOCK;
	public static Block PEDESTAL;
	public static Block STONE_WALL;
	public static Block CONDENSED_DIRT;
	public static Block PACKED_LOG;
	public static Item RUBY;
	public static Item RUBY_PICK;
	public static Item ZANITE_HELMET;
	public static Item ZANITE_CHESTPLATE;
	public static Item ZANITE_LEGGINGS;
	public static Item ZANITE_BOOTS;
	public static Item ZANITE_SWORD;
	public static Item CANDIED_APPLE;
	public static Item POISONOUS_APPLE;
	public static Item SAMPLE_DISC;
	public static Item COUNTER;
	public static Item MOOD_GEM;
	public static Item STICKED_APPLE;
	public static Item SPECTRE_STAFF;

	// Data components (modern-style typed item data), see CounterItem / MoodGemItem.
	public static com.periut.retroapi.component.RetroComponentType<Integer> CLICK_COUNT;
	public static com.periut.retroapi.component.RetroComponentType<Integer> MOOD;
	// A RECORD component (structured, multi-field data), see GemAttunement.
	public static com.periut.retroapi.component.RetroComponentType<GemAttunement> ATTUNEMENT;
	// The Mood Gem is a LAYERED, tinted item (RetroLayeredTexture): one grayscale gem
	// sprite tinted by the MOOD component, plus a sparkle overlay that appears once the
	// ATTUNEMENT record says it is awakened. Drawn live at render time, nothing baked.
	public static int MOOD_GEM_BASE;
	public static int MOOD_GEM_SPARKLE;
	/** The 0xRRGGBB tint per mood (red, green, blue, gold), multiplied onto the gray gem. */
	public static final int[] MOOD_TINTS = {0xFF4D4D, 0x57E06A, 0x4D8AFF, 0xFFC233};
	public static DimensionRegistration EXAMPLE_DIMENSION;
	public static DimensionRegistration CURVY_DIMENSION;
	public static DimensionRegistration NOISY_DIMENSION;
	public static Block CURVY_PORTAL;
	public static Block NOISY_PORTAL;
	public static Block PINK_FLOWER;
	// Biomes are plain Biome objects a BiomeSource hands back; no global registry needed.
	public static Biome CURVY_BIOME;
	public static Biome NOISY_AMPLIFIED_BIOME;
	public static Biome NOISY_LUSH_BIOME;
	public static EntityRegistration EXAMPLE_MOB;
	public static EntityRegistration AERBUNNY;

	/** Small helper: every piece of registered content is identified by "example_mod:<name>". */
	public static NamespacedIdentifier id(String name) {
		return NamespacedIdentifiers.from(MOD_ID, name);
	}

	@Override
	public void init() {
		LOGGER.info("initializing example mod!");

		// ------------------------------------------------------------------ blocks --
		// The simplest possible block: stone-like, with its own texture.
		// The texture file lives at assets/example_mod/textures/block/example_block.png
		// and the display name comes from assets/example_mod/lang/en_US.lang
		// ("tile.@.example_block.name"). RetroAPI assigns the numeric block id for you
		// and keeps it stable per-world (ids are remapped on world load).
		EXAMPLE_BLOCK = RetroBlockAccess.create(Material.STONE)
			.sounds(Block.STONE_SOUND_GROUP)   // mine/place/step sounds
			.strength(1.5f, 10.0f)             // hardness, blast resistance
			.texture(id("example_block"))      // one texture used on all six faces
			.register(id("example_block"));
		// Other builder options you can chain before .register(...):
		//   .light(1.0f), glow like glowstone
		//   .opacity(0), let light pass through
		//   .nonOpaque(), neighbours draw their touching faces
		//   .bounds(minX,minY,minZ,maxX,maxY,maxZ), non-full-cube hitbox
		//   .sprite(Block.GLASS.getTexture(0)), reuse a vanilla texture instead
		//   .alwaysDrops() / .alwaysEffectiveTool() / .effectiveTool(PickaxeItem.class)

		// A block with a custom class: different texture per face (top/bottom/sides).
		// When you need a Block subclass, allocate the id yourself with allocateId()
		// and hand the instance to RetroBlockAccess.of(...).
		SIDED_BLOCK = RetroBlockAccess.of(new ExampleSidedBlock(RetroBlockAccess.allocateId(), Material.WOOD))
			.sounds(Block.WOOD_SOUND_GROUP)
			.strength(1.0f)
			.alwaysEffectiveTool()
			.alwaysDrops()
			.register(id("sided_block"));

		// A non-full-cube block using the custom render type registered above.
		PIPE_BLOCK = RetroBlockAccess.create(Material.STONE)
			.sounds(Block.METAL_SOUND_GROUP)
			.strength(2.0f)
			.nonOpaque()
			.bounds(4 / 16.0F, 4 / 16.0F, 4 / 16.0F, 12 / 16.0F, 12 / 16.0F, 12 / 16.0F)
			.renderType(PIPE_RENDER_TYPE)
			.sprite(Block.COBBLESTONE.getTexture(0)) // used for particles + item form
			.register(id("example_pipe"));

		// ----------------------------------------------------------- block entities --
		// A block that stores data in the world: right-click it to bump a counter
		// that persists through save/load. Two steps: register the block entity
		// class under a STABLE string id (it's written into NBT)...
		RetroBlockEntities.register(id("counter"), ExampleCounterBlockEntity.class);
		// ...then register the block whose createBlockEntity() returns one.
		COUNTER_BLOCK = RetroBlockAccess.of(new ExampleCounterBlock(RetroBlockAccess.allocateId()))
			.sounds(Block.STONE_SOUND_GROUP)
			.strength(1.5f)
			.texture(id("counter_block"))
			.register(id("counter_block"));

		// A block entity WITH a container GUI: a 27-slot crate (chest-style).
		// Same two steps; the client half of the GUI is registered in
		// ExampleModClient (RetroGuiRegistry) under this same "crate" id.
		RetroBlockEntities.register(id("crate"), ExampleCrateBlockEntity.class);
		CRATE_BLOCK = RetroBlockAccess.of(new ExampleCrateBlock(RetroBlockAccess.allocateId()))
			.sounds(Block.WOOD_SOUND_GROUP)
			.strength(2.0f)
			.alwaysEffectiveTool()
			.alwaysDrops()
			.texture(id("crate_block"))
			.register(id("crate_block"));

		// A furnace-style MACHINE: any fuel below, water bucket above -> ice
		// (the empty bucket stays behind). Its GUI draws live progress bars via
		// synced container variables, see ExampleFreezerContainer for the why
		// and how. Logic: ExampleFreezerBlockEntity (ticks like a furnace).
		RetroBlockEntities.register(id("freezer"), ExampleFreezerBlockEntity.class);
		// Directional machine (fabric-docs HorizontalFacingBlock pattern): one FACING
		// state, set from the placer's yaw in ExampleFreezerBlock.onPlaced, turned into
		// a y-rotated orientable model by retroapi/blockstates/freezer_block.json. The
		// art is aether-fabric-b1.7.3's freezer top/side plus a derived frosted front.
		FREEZER_BLOCK = RetroBlockAccess.of(new ExampleFreezerBlock(RetroBlockAccess.allocateId()))
			.sounds(Block.STONE_SOUND_GROUP)
			.strength(3.5f)
			.states(ExampleFreezerBlock.FACING)
			// The inventory icon renders the DEFAULT state. Face it south so the front lands
			// on the visible bottom-left face of the iso cube (where the furnace shows its
			// front); placed freezers ignore this and face the player (see onPlaced).
			.defaultState(s -> s.with(ExampleFreezerBlock.FACING, Facing.SOUTH))
			.register(id("freezer_block"));

		// ------------------------------------------------------------------- items --
		// The simplest possible item. Texture: assets/example_mod/textures/item/suspicious_substance.png
		// Display name: "item.@.suspicious_substance.name" in the lang file.
		SUSPICIOUS_SUBSTANCE = RetroItemAccess.create()
			.maxStackSize(64)
			.texture(id("suspicious_substance"))
			.register(id("suspicious_substance"));

		// An ANIMATED item. The texture is a vertical strip of 16x16 frames
		// (spectre_staff.png, 16x208 = 13 frames) and spectre_staff.png.mcmeta drives the
		// playback: frametime 3, a frame list, and one frame with its own longer time. The
		// plain .texture() call finds the .mcmeta sidecar and animates the sprite on the
		// item atlas, the same path the ember block uses, so an animated item needs no
		// extra API, just the strip plus its mcmeta.
		SPECTRE_STAFF = RetroItemAccess.create()
			.maxStackSize(1)
			.handheld()                        // held like a staff/tool, the through-the-fist pose
			.texture(id("spectre_staff"))
			.register(id("spectre_staff"));

		// An item with a custom CLASS and right-click behavior (and a mixin
		// @Invoker demo): the Jump Stick. See JumpStickItem.
		JUMP_STICK = RetroItemAccess.of(new JumpStickItem(RetroItemAccess.allocateId()))
			.maxStackSize(1)
			// Hold it like a tool: the diagonal through-the-fist pose vanilla sticks
			// get. Items with an item/handheld model JSON (the Ruby Pick below) get
			// this automatically; everything else opts in with one chained call.
			.handheld()
			.register(id("jump_stick"));

		// ---------------------------------------------------- the asset platform --
		// Mineable tags, modern semantics: ruby ore drops ONLY when mined with a
		// pickaxe, at pickaxe speed. The same tag also loads from data files; see
		// data/example_mod/tags/block/mineable/pickaxe.json, which re-adds this block
		// (a harmless union) and tags vanilla glass as pickaxe-mineable too.
		RUBY_ORE = RetroBlockAccess.of(new RubyOreBlock(RetroBlockAccess.allocateId()))
			.sounds(Block.STONE_SOUND_GROUP)
			.strength(3.0f)
			.texture(id("ruby_ore"))
			.mineable(com.periut.retroapi.tag.RetroTool.PICKAXE)
			.register(id("ruby_ore"));

		// Flattened blockstates + JSON models: the lamp declares 20 states in code
		// and gets its two looks from blockstates/lamp.json. See ExampleLampBlock.
		LAMP = RetroBlockAccess.of(new ExampleLampBlock(RetroBlockAccess.allocateId()))
			.sounds(Block.STONE_SOUND_GROUP)
			.strength(0.5f)
			.alwaysEffectiveTool()
			.alwaysDrops()
			.states(ExampleLampBlock.LIT, ExampleLampBlock.AGE)
			.register(id("lamp"));

		// Animated texture, zero code: ember_block.png is a 4-frame vertical strip
		// and ember_block.png.mcmeta sets frametime 6 + interpolate. The ordinary
		// .texture() call picks the animation up automatically.
		EMBER_BLOCK = RetroBlockAccess.create(Material.STONE)
			.sounds(Block.STONE_SOUND_GROUP)
			.strength(0.8f)
			.texture(id("ember_block"))
			.register(id("ember_block"));

		// A COMPLEX model: three elements (a slab base with cullfaces and custom UVs,
		// a column of free quads, and a 45-degree-rotated gem with tintindex 0, whose
		// color comes from the provider registered in ExampleModClient). Everything
		// lives in retroapi/models/block/pedestal.json; this class is a plain block.
		PEDESTAL = RetroBlockAccess.create(Material.STONE)
			.sounds(Block.STONE_SOUND_GROUP)
			.strength(2.0f)
			.nonOpaque()
			.bounds(1 / 16.0F, 0.0F, 1 / 16.0F, 15 / 16.0F, 1.0F, 15 / 16.0F)
			.register(id("pedestal"));

		// THE blockstate workout: a cobblestone wall ported from
		// matthewperiut/stonewalls-fabric-b1.7.3. Five properties (up + a
		// none/low/tall shape per side) make 162 states; connections are
		// recomputed from the neighborhood on placement and on every block
		// update (see ExampleWallBlock), and the multipart blockstate JSON
		// assembles post + rotated side models per state. The models reference
		// minecraft:block/cobblestone, resolved straight off the vanilla atlas.
		STONE_WALL = RetroBlockAccess.of(new ExampleWallBlock(RetroBlockAccess.allocateId()))
			.sounds(Block.STONE_SOUND_GROUP)
			.strength(2.0f, 10.0f)
			.nonOpaque()
			.states(ExampleWallBlock.UP, ExampleWallBlock.NORTH, ExampleWallBlock.EAST,
				ExampleWallBlock.WEST, ExampleWallBlock.SOUTH)
			.defaultState(s -> s.with(ExampleWallBlock.UP, true))
			.mineable(com.periut.retroapi.tag.RetroTool.PICKAXE)
			.register(id("stone_wall"));

		// The fabric-docs "first block", ported verbatim in style: a plain full cube
		// whose look is one cube_all model + an empty-key blockstate, and whose
		// inventory icon comes from a 26.1.2 item DEFINITION (items/condensed_dirt.json
		// pointing at the block model). See the Blocks chapter, "Your first block".
		CONDENSED_DIRT = RetroBlockAccess.create(Material.SOIL)
			.sounds(Block.GRAVEL_SOUND_GROUP)
			.strength(0.6f)
			.mineable(com.periut.retroapi.tag.RetroTool.SHOVEL)
			.register(id("condensed_dirt"));

		// fabric-docs' directional log: an AXIS state from the placement side, turned
		// into a rotated cube_column by the blockstate JSON. See ExampleLogBlock.
		PACKED_LOG = RetroBlockAccess.of(new ExampleLogBlock(RetroBlockAccess.allocateId()))
			.sounds(Block.WOOD_SOUND_GROUP)
			.strength(2.0f)
			.states(ExampleLogBlock.AXIS)
			.mineable(com.periut.retroapi.tag.RetroTool.AXE)
			.register(id("packed_log"));

		// Layered item model: models/item/ruby.json (parent item/generated) stacks
		// layer0 + layer1 into one sprite at atlas build. No .texture() call at all;
		// the model JSON is found by the item's id at registration.
		RUBY = RetroItemAccess.create()
			.maxStackSize(64)
			.register(id("ruby"));

		// Tool KIND and TIER, declared in one chain: this plain Item (no ToolItem
		// subclass anywhere) counts as an iron-tier pickaxe for the tag system, so it
		// harvests anything in mineable/pickaxe up through needs_iron_tool, including
		// the ruby ore above. Vanilla tools never need this, they infer kind from
		// their class and tier from their material. The handheld item model
		// (retroapi/models/item/ruby_pick.json) gives it the diagonal in-hand pose.
		RUBY_PICK = (Item) RetroItemAccess.create()
			.maxStackSize(1)
			.tool(com.periut.retroapi.tag.RetroTool.PICKAXE)
			.tier(com.periut.retroapi.tag.RetroToolTier.IRON)
			.register(id("ruby_pick"));

		// Custom ARMOR: a full zanite set, ported from aether-fabric-b1.7.3. RetroArmor is a
		// vanilla ArmorItem (material 2 = iron-tier protection and durability) that draws OUR
		// worn texture on the player through RetroArmorTexture; the inventory icons are the
		// vanilla armor sprites tinted zanite violet, so the set needs only the two worn
		// sheets, textures/armor/zanite_1.png (body + feet) and _2.png (legs). Slots are
		// 0 helmet, 1 chestplate, 2 leggings, 3 boots.
		String zaniteTex = "/assets/example_mod/textures/armor/zanite";
		int zaniteTint = 0x711EE8;
		ZANITE_HELMET = (Item) RetroItemAccess.of(
			new com.periut.retroapi.register.item.RetroArmor(2, 0, zaniteTex, zaniteTint)).register(id("zanite_helmet"));
		ZANITE_CHESTPLATE = (Item) RetroItemAccess.of(
			new com.periut.retroapi.register.item.RetroArmor(2, 1, zaniteTex, zaniteTint)).register(id("zanite_chestplate"));
		ZANITE_LEGGINGS = (Item) RetroItemAccess.of(
			new com.periut.retroapi.register.item.RetroArmor(2, 2, zaniteTex, zaniteTint)).register(id("zanite_leggings"));
		ZANITE_BOOTS = (Item) RetroItemAccess.of(
			new com.periut.retroapi.register.item.RetroArmor(2, 3, zaniteTex, zaniteTint)).register(id("zanite_boots"));

		// Layered item over a VANILLA texture: items/candied_apple.json is a 26.1.2
		// composite whose base layer references minecraft:item/apple (resolved straight
		// off the vanilla items.png by name) with our sugar sparkle stacked on top. No
		// apple.png is re-shipped. See the Items chapter, "Layering vanilla textures".
		// It is also FOOD, the simplest case of RetroAPI's food API: one .food(health) call
		// makes any item edible (right-click to eat, heal that many health points). Beta has
		// no hunger bar, so food restores hearts. See the Tools chapter's food section.
		CANDIED_APPLE = RetroItemAccess.create()
			.maxStackSize(16)
			.food(4)                       // eat to heal 4 (two hearts)
			.register(id("candied_apple"));

		// A food with a CUSTOM ON-EAT EFFECT: the Poisonous Apple heals a little, then bites
		// back. The .food(health, onEaten) overload runs our callback the instant it is eaten;
		// beta has no poison effect, so we just deal damage for a net-harmful bite. The
		// callback is the whole reason the food API exists: food that does more than heal.
		POISONOUS_APPLE = RetroItemAccess.create()
			.maxStackSize(16)
			.texture(id("poisonous_apple"))
			.food(1, (stack, world, player) -> player.damage(null, 6))
			.register(id("poisonous_apple"));

		// A custom TOOL the vanilla way: a SwordItem subclass. Unlike the ruby pick (which is
		// a plain item TAGGED as a pickaxe), a sword is a real vanilla tool class, so it comes
		// with attack damage, durability, and the block-breaking speed of its ToolMaterial
		// (IRON tier here) built in. Texture is the Aether's zanite sword art.
		ZANITE_SWORD = (Item) RetroItemAccess.of(
				new net.minecraft.item.SwordItem(RetroItemAccess.allocateId(), net.minecraft.item.ToolMaterial.IRON))
			.maxStackSize(1)
			.handheld()
			.texture(id("zanite_sword"))
			.register(id("zanite_sword"));

		// A jukebox record. RetroRecordItem is a vanilla MusicDiscItem under the hood,
		// so dropping it in a vanilla jukebox plays its streamed track exactly like a
		// vanilla disc (including the multiplayer broadcast). The audio is the
		// file-examples.com 1MB sample ogg at sounds/streaming/sample_disc.ogg.
		SAMPLE_DISC = (Item) RetroItemAccess.of(
				new com.periut.retroapi.sound.api.RetroRecordItem(
					RetroItemAccess.allocateId(), "example_mod:sample_disc"))
			.register(id("sample_disc"));

		// ------------------------------------------------------ data components --
		// Register two typed components (modern DataComponentType equivalent). They are
		// just ints here; RetroComponentType.compound(...) handles records.
		CLICK_COUNT = com.periut.retroapi.component.RetroComponents.register(
			id("click_count"), 0, com.periut.retroapi.component.RetroComponentType.INT);
		MOOD = com.periut.retroapi.component.RetroComponents.register(
			id("mood"), 0, com.periut.retroapi.component.RetroComponentType.INT);
		ATTUNEMENT = com.periut.retroapi.component.RetroComponents.register(
			id("attunement"), GemAttunement.EMPTY, GemAttunement.CODEC);

		// The Counter: clicks increment a component, the tooltip shows it. Beta items have
		// no storage of their own, so this is the components system at work.
		COUNTER = RetroItemAccess.of(new CounterItem(RetroItemAccess.allocateId()))
			.texture(id("counter"))
			.register(id("counter"));

		// The Mood Gem: a component-driven LAYERED texture. Register the grayscale gem and
		// the sparkle overlay as their own sprites and keep their atlas ids; MoodGemItem
		// returns a tinted base layer (from MOOD) plus, once awakened, the sparkle layer,
		// and RetroAPI draws them stacked live. One gray sprite covers every color, instead
		// of baking a PNG per variant, which matters for an item with many tints.
		MOOD_GEM_BASE = com.periut.retroapi.register.block.RetroTextures.addItemTexture(id("mood_gem_base")).id;
		MOOD_GEM_SPARKLE = com.periut.retroapi.register.block.RetroTextures.addItemTexture(id("mood_gem_sparkle")).id;
		MOOD_GEM = RetroItemAccess.of(new MoodGemItem(RetroItemAccess.allocateId()))
			.texture(id("mood_gem_base")) // fallback icon; the layered path overrides it
			.register(id("mood_gem"));

		// The Sticked Apple: the SIMPLEST layered item, two untinted vanilla sprites stacked
		// (a stick under an apple), with no texture or components of its own. See
		// StickedAppleItem, the plain-as-possible RetroLayeredTexture.
		STICKED_APPLE = RetroItemAccess.of(new StickedAppleItem(RetroItemAccess.allocateId()))
			.register(id("sticked_apple"));

		// --------------------------------------------------------------- dimension --
		// Register a whole dimension. The factory receives the serial id RetroAPI
		// assigns (it determines the DIM<id>/ save folder). ExampleDimension extends
		// OverworldDimension, so it generates normal terrain, swap in your own
		// Dimension subclass for custom generators.
		EXAMPLE_DIMENSION = RetroDimensions.register(id("example_dim"), ExampleDimension::new);
		LOGGER.info("registered dimension {} (serial id {})",
			EXAMPLE_DIMENSION.getId(), EXAMPLE_DIMENSION.getSerialId());

		// A walk-in portal block that sends the player to the dimension above.
		// See ExamplePortalBlock, it implements RetroAPI's CustomPortal interface.
		EXAMPLE_PORTAL = RetroBlockAccess.of(new ExamplePortalBlock(RetroBlockAccess.allocateId()))
			.sounds(Block.GLASS_SOUND_GROUP)
			.sprite(Block.GLASS.getTexture(0)) // reuse the vanilla glass texture
			.register(id("example_portal"));

		// ------------------------------------------------- custom worldgen --
		// The pink flower: a CROSS block (see ExampleFlowerBlock), scattered by the
		// noisy dimension's flower-patch decoration. Its look comes from a block/cross
		// model; collision and placement rules are in the class.
		PINK_FLOWER = RetroBlockAccess.of(new ExampleFlowerBlock(RetroBlockAccess.allocateId()))
			.sounds(Block.DIRT_SOUND_GROUP)
			.texture(id("pink_flower")) // terrain sprite shared by the cross and the flat icon
			.register(id("pink_flower"));

		// Biomes decide grass/sky tint and what spawns. The Curvy biome is gentle and
		// green; the Noisy dimension has two, an ORANGE amplified biome and a lush green
		// one, picked by noise (see NoisyBiomeSource). Friendly animals only in Curvy;
		// Aerbunnies in Noisy, added through the mod-friendly RetroBiomes API below.
		CURVY_BIOME = BiomeBuilder.start("Curvy Hills")
			.grassAndLeavesColor(0x88DD66)
			.passiveEntity(CowEntity.class, 8)
			.passiveEntity(PigEntity.class, 8)
			.passiveEntity(SheepEntity.class, 8)
			.passiveEntity(ChickenEntity.class, 6)
			.build();
		NOISY_AMPLIFIED_BIOME = BiomeBuilder.start("Amplified Wastes")
			.grassAndLeavesColor(0xFF8A3D) // funky orange grass
			.build();
		NOISY_LUSH_BIOME = BiomeBuilder.start("Lush Hollows")
			.grassAndLeavesColor(0x5Fae3a)
			.build();
		// RetroBiomes.addPassiveSpawn is ADDITIVE and de-dupes, so it never clobbers
		// another mod's spawns; here it drops Aerbunnies into both Noisy biomes.
		RetroBiomes.addPassiveSpawn(NOISY_AMPLIFIED_BIOME, AerbunnyEntity.class, 4);
		RetroBiomes.addPassiveSpawn(NOISY_LUSH_BIOME, AerbunnyEntity.class, 4);

		// Two fully custom dimensions. CurvyDimension uses a pure sin+cos generator;
		// NoisyDimension uses Perlin noise with ores, winding caves, trees and water.
		CURVY_DIMENSION = RetroDimensions.register(id("curvy_dim"), CurvyDimension::new);
		NOISY_DIMENSION = RetroDimensions.register(id("noisy_dim"), NoisyDimension::new);
		LOGGER.info("registered curvy dim {} and noisy dim {}",
			CURVY_DIMENSION.getSerialId(), NOISY_DIMENSION.getSerialId());

		// Each dimension gets its OWN portal block (one shared class, two configs). The
		// destination/portal-block are suppliers because dimensions register after blocks.
		CURVY_PORTAL = RetroBlockAccess.of(new DimensionPortalBlock(RetroBlockAccess.allocateId(),
				() -> CURVY_DIMENSION.getId(), () -> CURVY_PORTAL.id))
			.sounds(Block.GLASS_SOUND_GROUP)
			.texture(id("green_glass"))
			.register(id("curvy_portal"));
		NOISY_PORTAL = RetroBlockAccess.of(new DimensionPortalBlock(RetroBlockAccess.allocateId(),
				() -> NOISY_DIMENSION.getId(), () -> NOISY_PORTAL.id))
			.sounds(Block.GLASS_SOUND_GROUP)
			.texture(id("orange_glass"))
			.register(id("noisy_portal"));

		// ---------------------------------------------------------------- entities --
		// Register a custom mob. The MobFactory tells RetroAPI (and the multiplayer
		// spawn packet handler on the client) how to construct one from a World.
		// The renderer is registered on the client only, see ExampleModClient.
		EXAMPLE_MOB = RetroEntities.register(ExampleEntity.ID, ExampleEntity.class)
			.factory((MobFactory) ExampleEntity::new);

		// The Aerbunny: a custom mob whose RENDER state (puff + tilt) is computed on the
		// server and synced to clients via the DataTracker. See AerbunnyEntity for the
		// sync, AerbunnyModel/AerbunnyRenderer for the draw. Ported from
		// github.com/matthewperiut/aether-fabric-b1.7.3. It spawns in the noisy
		// dimension (see the biome spawn wiring in registerSpawns).
		AERBUNNY = RetroEntities.register(AerbunnyEntity.ID, AerbunnyEntity.class)
			.factory((MobFactory) AerbunnyEntity::new);

		// ----------------------------------------------------------------- recipes --
		// Recipes are registered through a callback that fires after vanilla's recipes
		// exist (the recipe list is re-sorted afterwards), so modded recipes always
		// take priority correctly.
		RecipeRegistrationCallback.EVENT.register(ExampleMod::registerRecipes);

		// ------------------------------------------------------------ achievements --
		// Register achievements AFTER blocks/items, so their icons can reference them.
		ExampleAchievements.register();

		// -------------------------------------------------------------- networking --
		// Channels must be registered on both sides, so this happens here in the
		// common entrypoint. The client listener lives in ExampleModClient, the server
		// listener in ExampleModServer.
		ExampleNetworking.registerChannels();

		LOGGER.info("example mod registered its blocks, item, mob, dimension, achievements and recipes!");
	}

	private static void registerRecipes() {
		// Shaped recipe: four cobblestone in a 2x2 square craft one Example Block.
		// Bare Block/Item ingredients match ANY metadata; pass an ItemStack with a
		// damage value (e.g. new ItemStack(Block.WOOL, 1, 14)) for exact-meta matching.
		RetroRecipes.addShaped(new ItemStack(EXAMPLE_BLOCK),
			"CC",
			"CC",
			'C', Block.COBBLESTONE);

		// Shapeless recipe: one Example Block anywhere in the grid gives four Suspicious Substances.
		RetroRecipes.addShapeless(new ItemStack(SUSPICIOUS_SUBSTANCE, 4), EXAMPLE_BLOCK);

		// Smelting: cook an Example Block back into an Suspicious Substance.
		RetroRecipes.addSmelting(EXAMPLE_BLOCK.id, new ItemStack(SUSPICIOUS_SUBSTANCE));

		// Fuel: Suspicious Substances burn in a furnace for 1600 ticks (= 8 smelted items).
		RetroRecipes.addFuel(SUSPICIOUS_SUBSTANCE.id, 1600);

		// The classic wall recipe, straight from the stonewalls mod: two rows of
		// cobblestone craft six walls.
		RetroRecipes.addShaped(new ItemStack(STONE_WALL, 6),
			"CCC",
			"CCC",
			'C', Block.COBBLESTONE);

		// The ruby pick: classic pickaxe shape, rubies over sticks.
		RetroRecipes.addShaped(new ItemStack(RUBY_PICK, 1),
			"RRR",
			" S ",
			" S ",
			'R', RUBY, 'S', Item.STICK);

		// fabric-docs style recipes. Shapeless: four dirt pack into one condensed dirt
		// (and the 2x2 reverses it loosely via the shaped block below is omitted for
		// brevity). Shaped: four packed logs from a square of planks. Shapeless: an
		// apple plus sugar candies it.
		RetroRecipes.addShapeless(new ItemStack(CONDENSED_DIRT, 1),
			new ItemStack(Block.DIRT), new ItemStack(Block.DIRT),
			new ItemStack(Block.DIRT), new ItemStack(Block.DIRT));
		RetroRecipes.addShaped(new ItemStack(PACKED_LOG, 4),
			"PP",
			"PP",
			'P', Block.PLANKS);
		RetroRecipes.addShapeless(new ItemStack(CANDIED_APPLE, 1),
			new ItemStack(Item.APPLE), new ItemStack(Item.SUGAR));
	}
}
