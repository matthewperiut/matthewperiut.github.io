package com.example.example_mod;

/**
 * The three pillar axes a log-like block can run along. Enum constants serialize as
 * their lowercase names (x, y, z), which is what the blockstate's "axis=y" keys match.
 *
 * Y is listed FIRST on purpose: the default state (index 0) is what renders in the
 * inventory and in the hand, and an upright log is what you expect to see there, not a
 * log lying on its side.
 */
public enum Axis {
	Y,
	X,
	Z;

	/**
	 * The axis a pillar should run along when placed against {@code side}. Beta side
	 * indices: 0/1 are the bottom/top faces (a vertical pillar), 4/5 are the x faces,
	 * 2/3 are the z faces. The pillar runs along the axis of the face's NORMAL, so a
	 * log placed on an x-facing wall runs along x.
	 */
	public static Axis fromSide(int side) {
		switch (side) {
			case 0: case 1: return Y;
			case 2: case 3: return X; // z faces -> run along x (flipped from the face normal)
			default: return Z;        // sides 4/5, the x faces -> run along z
		}
	}
}
