package com.example.example_mod;

import com.periut.retroapi.state.RetroBlockState;
import com.periut.retroapi.state.RetroBoolProperty;
import com.periut.retroapi.state.RetroIntProperty;
import com.periut.retroapi.state.RetroStates;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

/**
 * The state lamp: flattened blockstates and JSON models working together.
 *
 * Properties are declared in code (.states(LIT, AGE) at registration); 2 x 10 = 20
 * states, deliberately MORE than the 16 a vanilla meta nibble can hold, so the
 * extra bits ("secondary meta") ride RetroAPI's region sidecar and sync channels.
 * You never see any of that: RetroStates.get/set are the whole API.
 *
 * The look comes from assets/example_mod/retroapi/blockstates/lamp.json, which
 * maps lit=false / lit=true to two cube_all models. Because that JSON exists,
 * the block was auto-wired to the model render type at registration; no render
 * code anywhere in this class.
 *
 * Right-click to walk the state space and watch the chat line + the model flip.
 */
public class ExampleLampBlock extends Block {

	public static final RetroBoolProperty LIT = RetroBoolProperty.of("lit");
	public static final RetroIntProperty AGE = RetroIntProperty.of("age", 0, 9);

	public ExampleLampBlock(int id) {
		super(id, Material.STONE);
	}

	@Override
	public boolean onUse(World world, int x, int y, int z, PlayerEntity player) {
		RetroBlockState state = RetroStates.get(world, x, y, z);
		if (state == null) {
			return false;
		}
		// Bump age each click; toggle lit when it wraps. with() returns the interned
		// sibling state, set() writes meta + xmeta, marks dirty and syncs to clients.
		int age = state.get(AGE);
		RetroBlockState next = age == 9
			? state.with(AGE, 0).with(LIT, !state.get(LIT))
			: state.with(AGE, age + 1);
		RetroStates.set(world, x, y, z, next);
		if (!world.isRemote) {
			player.sendMessage("lamp is now " + next + " (flattened index " + next.getIndex() + ")");
		}
		return true;
	}
}
