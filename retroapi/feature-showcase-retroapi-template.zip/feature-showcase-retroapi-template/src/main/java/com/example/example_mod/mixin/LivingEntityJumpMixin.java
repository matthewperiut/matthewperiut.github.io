package com.example.example_mod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.example_mod.ExampleAchievements;
import com.periut.retroapi.achievement.RetroAchievements;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;

/**
 * Grants the "Jump for Joy" achievement the first time the player jumps.
 *
 * Mixins must target the class that DECLARES the method, jump() lives on
 * LivingEntity (PlayerEntity inherits it), so we target LivingEntity and check
 * at runtime whether this particular living entity is a player.
 *
 * jump() runs where the entity's physics run: in singleplayer that's the local
 * world (isRemote == false), so the grant sticks. On a dedicated server player
 * physics run client-side, so this fires on remote worlds, the isRemote check
 * keeps the grant out of there (server-side stats would need a packet instead).
 */
@Mixin(LivingEntity.class)
public class LivingEntityJumpMixin {

	/** Jumping happens a lot, gate the grant so it only ever runs once per session. */
	private static boolean example_mod$jumpGranted = false;

	@Inject(method = "jump", at = @At("HEAD"))
	private void example_mod$onJump(CallbackInfo ci) {
		if (example_mod$jumpGranted) {
			return;
		}
		LivingEntity self = (LivingEntity) (Object) this;
		if (self instanceof PlayerEntity && !self.world.isRemote) {
			example_mod$jumpGranted = true;
			RetroAchievements.grant(ExampleAchievements.JUMP_FOR_JOY, (PlayerEntity) self);
		}
	}
}
