package com.example.example_mod.mixin.examples;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

import net.minecraft.entity.passive.PigEntity;

/**
 * MIXIN EXAMPLE 12 (bonus), MixinExtras @ModifyReturnValue: the cleaner way
 * to do what example 4 did with @Inject(at = RETURN) + CallbackInfoReturnable.
 *
 * Effect in game: hurting a pig also plays our custom click sound.
 *
 * Compare with Example04PigSoundMixin (the same job on the sibling method):
 *
 *   vanilla mixin:                          mixinextras:
 *   @Inject(method = "getRandomSound",      @ModifyReturnValue(
 *       at = @At("RETURN"),                     method = "getHurtSound",
 *       cancellable = true)                     at = @At("RETURN"))
 *   void m(CallbackInfoReturnable<String>   String m(String original) {
 *           cir) {                              return "...";
 *       cir.setReturnValue("...");          }
 *   }
 *
 * The original return value arrives as a plain parameter (no cir juggling,
 * no cancellable flag), you return the replacement, and, the important part , 
 * multiple mods' @ModifyReturnValue handlers CHAIN: each receives the previous
 * one's output. With raw setReturnValue, order-dependent fights are easy.
 *
 * Docs: https://github.com/LlamaLad7/MixinExtras/wiki/ModifyReturnValue
 */
@Mixin(PigEntity.class)
public class Example12ModifyReturnValueMixin {

	@ModifyReturnValue(method = "getHurtSound", at = @At("RETURN"))
	private String example_mod$clickOnHurt(String original) {
		return "example_mod:counter.click";
	}
}
