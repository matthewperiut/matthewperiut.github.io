package com.example.example_mod;

import com.example.example_mod.mixin.examples.Example06JumpInvoker;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

/**
 * A custom Item CLASS: the Jump Stick, right-click to hop.
 *
 * Two things this demonstrates:
 *   - Items with behavior: override use(stack, world, player) for right-click
 *     (useOnBlock / useOnEntity exist for targeted clicks). Return the stack
 *     (possibly shrunk/damaged) when you're done.
 *   - Mixin example 6 in action: LivingEntity.jump() is protected, so normal
 *     code can't call it, the @Invoker interface in
 *     mixin/examples/Example06JumpInvoker makes it callable from outside.
 *
 * Like custom blocks, custom items allocate their id with allocateId() and are
 * wrapped with RetroItemAccess.of(...) in ExampleMod.init().
 *
 * No texture file: overriding getTextureId lets it reuse vanilla's stick sprite.
 */
public class JumpStickItem extends Item {

	public JumpStickItem(int id) {
		super(id);
	}

	@Override
	public int getTextureId(int damage) {
		return Item.STICK.getTextureId(0); // borrow the vanilla stick's sprite
	}

	@Override
	public ItemStack use(ItemStack stack, World world, PlayerEntity player) {
		// The whole trick: call the protected jump() through the invoker bridge.
		((Example06JumpInvoker) player).example_mod$jump();

		// A puff of our own particle under the player's feet. This is COMMON code, and it
		// mentions no client class: RetroParticles.spawn hands the identifier to the world,
		// and the client resolves it through the particle registry (ExampleModClient).
		// On a dedicated server RetroAPI bridges it to everyone in range - beta's protocol
		// has no particle packet, so without that bridge this would be silent in multiplayer.
		com.periut.retroapi.particle.RetroParticles.spawnCloud(
			world, ExampleMod.SPARK, player.x, player.y - 1.0, player.z, 8, 0.3);
		return stack;
	}
}
