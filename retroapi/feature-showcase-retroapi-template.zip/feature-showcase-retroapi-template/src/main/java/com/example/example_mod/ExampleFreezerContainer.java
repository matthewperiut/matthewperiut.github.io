package com.example.example_mod;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerListener;
import net.minecraft.screen.slot.FurnaceOutputSlot;
import net.minecraft.screen.slot.Slot;

/**
 * The freezer's container, and the home of its SYNCED VARIABLES.
 *
 * Why this matters: the machine's progress/fuel counters live in the block
 * entity ON THE SERVER. The client drawing the GUI never runs that logic, so
 * without help its bars would never move. Vanilla's container property channel
 * fixes this with three pieces, all shown below:
 *
 *   1. sendContentUpdates(), runs server-side every tick while the GUI is
 *      open. Compare each live value to the last one you sent; if it changed,
 *      push it to every listener with onPropertyUpdate(container, id, value).
 *      Only deltas are sent: a quiet machine costs zero bandwidth.
 *   2. setProperty(id, value), runs CLIENT-side when that packet arrives.
 *      Write the value back into the client's copy of the block entity so the
 *      screen can read it as if it were local.
 *   3. The property ids (0, 1, 2 here) are yours to define, just keep both
 *      methods in agreement.
 *
 * This is exactly how the vanilla furnace animates its arrow, and it's the
 * pattern to copy for any machine that should LOOK alive while it works.
 * (Based on the Aether's ContainerFreezer, aether-fabric-b1.7.3.)
 */
public class ExampleFreezerContainer extends ScreenHandler {

	private final ExampleFreezerBlockEntity freezer;

	// Last values we broadcast, so we only send changes.
	private int lastProgress = 0;
	private int lastFuelRemaining = 0;
	private int lastFuelTotal = 0;

	public ExampleFreezerContainer(PlayerInventory playerInventory, ExampleFreezerBlockEntity freezer) {
		this.freezer = freezer;

		// The machine's slots; coordinates match textures/gui/freezer.png.
		this.addSlot(new Slot(freezer, 0, 56, 17));                                  // input (water bucket)
		this.addSlot(new Slot(freezer, 1, 56, 53));                                  // fuel
		this.addSlot(new FurnaceOutputSlot(playerInventory.player, freezer, 2, 116, 35)); // output (take-only)

		// Player inventory + hotbar, vanilla layout.
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				this.addSlot(new Slot(playerInventory, col + row * 9 + 9, 8 + col * 18, 84 + row * 18));
			}
		}
		for (int col = 0; col < 9; col++) {
			this.addSlot(new Slot(playerInventory, col, 8 + col * 18, 142));
		}
	}

	/** SERVER, every tick the GUI is open: broadcast the properties that changed. */
	@Override
	public void sendContentUpdates() {
		super.sendContentUpdates();
		for (int i = 0; i < this.listeners.size(); i++) {
			ScreenHandlerListener listener = this.listeners.get(i);
			if (this.lastProgress != this.freezer.progress) {
				listener.onPropertyUpdate(this, 0, this.freezer.progress);
			}
			if (this.lastFuelRemaining != this.freezer.fuelRemaining) {
				listener.onPropertyUpdate(this, 1, this.freezer.fuelRemaining);
			}
			if (this.lastFuelTotal != this.freezer.fuelTotal) {
				listener.onPropertyUpdate(this, 2, this.freezer.fuelTotal);
			}
		}
		this.lastProgress = this.freezer.progress;
		this.lastFuelRemaining = this.freezer.fuelRemaining;
		this.lastFuelTotal = this.freezer.fuelTotal;
	}

	/** CLIENT: a property packet arrived, mirror it into our local block entity. */
	@Override
	public void setProperty(int id, int value) {
		if (id == 0) {
			this.freezer.progress = value;
		} else if (id == 1) {
			this.freezer.fuelRemaining = value;
		} else if (id == 2) {
			this.freezer.fuelTotal = value;
		}
	}

	@Override
	public boolean canUse(PlayerEntity player) {
		return this.freezer.canPlayerUse(player);
	}

	/** Shift-click: output goes to the inventory, anything else tries the machine. */
	@Override
	public ItemStack quickMove(int slotIndex) {
		ItemStack moved = null;
		Slot clicked = this.slots.get(slotIndex);

		if (clicked != null && clicked.hasStack()) {
			ItemStack stack = clicked.getStack();
			moved = stack.copy();
			if (slotIndex == 2) {
				// from the output slot into the player inventory
				this.insertItem(stack, 3, this.slots.size(), true);
			} else if (slotIndex < 3) {
				// from input/fuel into the player inventory
				this.insertItem(stack, 3, this.slots.size(), false);
			} else if (ExampleFreezerBlockEntity.fuelTime(stack) > 0) {
				// fuel from the inventory into the fuel slot
				this.insertItem(stack, 1, 2, false);
			} else {
				// everything else tries the input slot
				this.insertItem(stack, 0, 1, false);
			}

			if (stack.count == 0) {
				clicked.setStack(null);
			} else {
				clicked.markDirty();
			}
		}

		return moved;
	}
}
