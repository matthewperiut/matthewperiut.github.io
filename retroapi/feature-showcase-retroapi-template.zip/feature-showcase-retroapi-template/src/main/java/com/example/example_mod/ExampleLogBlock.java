package com.example.example_mod;

import com.periut.retroapi.state.RetroEnumProperty;
import com.periut.retroapi.state.RetroStates;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.world.World;

/**
 * A directional pillar block, the beta port of fabric-docs' condensed oak log. One
 * AXIS state (x/y/z), set from the face it is placed against; the blockstate JSON
 * turns each axis into a cube_column model rotated to match, so the end-grain caps
 * always point along the pillar. This is the same data-driven directional pattern as
 * the freezer, with a different rotation set and no block entity.
 */
public class ExampleLogBlock extends Block {

	public static final RetroEnumProperty<Axis> AXIS = RetroEnumProperty.of("axis", Axis.class);

	public ExampleLogBlock(int id) {
		super(id, Material.WOOD);
	}

	@Override
	public void onPlaced(World world, int x, int y, int z, int side) {
		super.onPlaced(world, x, y, z, side);
		RetroStates.set(world, x, y, z,
			RetroStates.getDefault(this).with(AXIS, Axis.fromSide(side)));
	}
}
