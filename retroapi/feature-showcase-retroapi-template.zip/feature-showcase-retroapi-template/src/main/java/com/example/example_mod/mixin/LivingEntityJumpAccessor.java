package com.example.example_mod.mixin;

import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/**
 * Reads another living entity's private {@code jumping} flag (true while its jump key is
 * held). The Aerbunny needs its RIDER'S jump input to decide when to fire the glide boost.
 * On the client the rider is the local player, so this reads it directly; on a dedicated
 * server the input does not exist server-side, so the client ships it over via the
 * {@code aerbunny_jump} packet instead (see ExampleNetworking).
 */
@Mixin(LivingEntity.class)
public interface LivingEntityJumpAccessor {

	@Accessor("jumping")
	boolean getJumping();
}
