package com.example.example_mod;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

import com.periut.retroapi.achievement.RetroAchievements;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

/**
 * One-shot per-player setup so you can try everything immediately: a starter kit
 * of the mod's content, the join achievement, and an example mob at your feet.
 *
 * It is called every tick from two hooks (PlayerTickMixin in singleplayer,
 * ServerPlayerTickMixin on a dedicated server). The once-guard lives here, keyed weakly
 * per player instance, AND it only fires for a player whose inventory is being created
 * fresh (a new player / first join), never one loaded from disk. The "loaded from disk"
 * signal comes from {@link PlayerLoadMixin}, which marks any player whose
 * {@code readNbt} runs, so a returning player keeps whatever they had and is not handed
 * the kit again every world load.
 *
 * This is demo scaffolding: in a real mod you'd delete this class and the two
 * tick mixins, and let players find your content through recipes/world gen.
 */
public final class ExamplePlayerSetup {
	private ExamplePlayerSetup() {}

	private static final Set<PlayerEntity> DONE =
		Collections.newSetFromMap(new WeakHashMap<PlayerEntity, Boolean>());

	/** Players whose data was read from disk (existing players); they skip the kit. */
	private static final Set<PlayerEntity> LOADED_FROM_DISK =
		Collections.newSetFromMap(new WeakHashMap<PlayerEntity, Boolean>());

	/** Called from {@link PlayerLoadMixin} when a player's NBT is read (loaded from disk). */
	public static void markLoadedFromDisk(PlayerEntity player) {
		LOADED_FROM_DISK.add(player);
	}

	/** Runs once per NEW player; does nothing on remote worlds or for loaded players. */
	public static void run(PlayerEntity player) {
		World world = player.world;
		if (world == null || world.isRemote || !DONE.add(player)) {
			return;
		}
		// The whole point of this change: a player loaded from disk already has their
		// inventory (even if they spent every item), so we leave them alone. Only a
		// freshly created player , one whose readNbt never ran , gets the starter setup.
		if (LOADED_FROM_DISK.contains(player)) {
			return;
		}

		// Starter kit. ItemStack works directly with Block/Item references , 
		// RetroAPI made sure they all have valid item forms.
		PlayerInventory inventory = player.inventory;
		inventory.addStack(new ItemStack(ExampleMod.EXAMPLE_BLOCK, 64));
		inventory.addStack(new ItemStack(ExampleMod.SIDED_BLOCK, 64));
		inventory.addStack(new ItemStack(ExampleMod.PIPE_BLOCK, 64));
		inventory.addStack(new ItemStack(ExampleMod.COUNTER_BLOCK, 16));
		inventory.addStack(new ItemStack(ExampleMod.CRATE_BLOCK, 16));
		inventory.addStack(new ItemStack(ExampleMod.FREEZER_BLOCK, 4));
		inventory.addStack(new ItemStack(ExampleMod.EXAMPLE_PORTAL, 16));
		inventory.addStack(new ItemStack(ExampleMod.SUSPICIOUS_SUBSTANCE, 16));
		inventory.addStack(new ItemStack(ExampleMod.JUMP_STICK, 1));
		// Asset platform demos: tagged ore, the state lamp, the animated ember
		// block and the layered-model ruby.
		inventory.addStack(new ItemStack(ExampleMod.RUBY_ORE, 16));
		inventory.addStack(new ItemStack(ExampleMod.LAMP, 16));
		inventory.addStack(new ItemStack(ExampleMod.EMBER_BLOCK, 16));
		inventory.addStack(new ItemStack(ExampleMod.RUBY, 16));
		inventory.addStack(new ItemStack(ExampleMod.PEDESTAL, 16));
		inventory.addStack(new ItemStack(ExampleMod.STONE_WALL, 64));
		inventory.addStack(new ItemStack(ExampleMod.RUBY_PICK, 1));
		inventory.addStack(new ItemStack(ExampleMod.CONDENSED_DIRT, 64));
		inventory.addStack(new ItemStack(ExampleMod.PACKED_LOG, 64));
		inventory.addStack(new ItemStack(ExampleMod.CANDIED_APPLE, 16));
		inventory.addStack(new ItemStack(ExampleMod.POISONOUS_APPLE, 16));
		inventory.addStack(new ItemStack(ExampleMod.SAMPLE_DISC, 1));
		inventory.addStack(new ItemStack(ExampleMod.CURVY_PORTAL, 8));
		inventory.addStack(new ItemStack(ExampleMod.NOISY_PORTAL, 8));
		inventory.addStack(new ItemStack(ExampleMod.PINK_FLOWER, 16));
		inventory.addStack(new ItemStack(ExampleMod.COUNTER, 1));
		inventory.addStack(new ItemStack(ExampleMod.MOOD_GEM, 1));
		inventory.addStack(new ItemStack(ExampleMod.STICKED_APPLE, 1));
		inventory.addStack(new ItemStack(ExampleMod.SPECTRE_STAFF, 1));
		inventory.addStack(new ItemStack(ExampleMod.ZANITE_HELMET, 1));
		inventory.addStack(new ItemStack(ExampleMod.ZANITE_CHESTPLATE, 1));
		inventory.addStack(new ItemStack(ExampleMod.ZANITE_LEGGINGS, 1));
		inventory.addStack(new ItemStack(ExampleMod.ZANITE_BOOTS, 1));
		inventory.addStack(new ItemStack(ExampleMod.ZANITE_SWORD, 1));
		// Stone pick for contrast: it breaks ruby ore but drops nothing (needs_iron_tool).
		inventory.addStack(new ItemStack(Item.STONE_PICKAXE, 1));
		// ...plus water buckets and coal so the freezer can run right away.
		inventory.addStack(new ItemStack(Item.WATER_BUCKET, 1));
		inventory.addStack(new ItemStack(Item.WATER_BUCKET, 1));
		inventory.addStack(new ItemStack(Item.COAL, 8));

		// Grant the join achievement, the toast pops and it un-greys on the screen.
		RetroAchievements.grant(ExampleAchievements.GETTING_STARTED, player);

		// Spawn one example mob where the player stands.
		ExampleEntity mob = new ExampleEntity(world);
		mob.setPositionAndAngles(player.x, player.y, player.z, player.yaw, 0.0F);
		world.spawnEntity(mob);

		ExampleMod.LOGGER.info("gave {} the example starter kit", player.name);
	}
}
