package com.example.example_mod;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import net.minecraft.world.dimension.PortalForcer;

/**
 * The example portal's travel agent. Vanilla's PortalForcer searches for, and if
 * needed BUILDS, a full obsidian nether portal at the destination. This one is
 * gentler: reuse an Example Portal block near the arrival point if one exists,
 * otherwise place a single portal block on the ground and stand the player in it.
 *
 * RetroAPI calls moveToPortal(newWorld, player) after switching the player's
 * dimension; everything this method does happens in the DESTINATION world.
 */
public class ExamplePortalForcer extends PortalForcer {

	private static final int SEARCH_RADIUS = 16;

	@Override
	public void moveToPortal(World world, Entity entity) {
		int ex = MathHelper.floor(entity.x);
		int ez = MathHelper.floor(entity.z);

		// Reuse a portal placed on an earlier trip if one is nearby.
		for (int x = ex - SEARCH_RADIUS; x <= ex + SEARCH_RADIUS; x++) {
			for (int z = ez - SEARCH_RADIUS; z <= ez + SEARCH_RADIUS; z++) {
				for (int y = 127; y >= 0; y--) {
					if (world.getBlockId(x, y, z) == ExampleMod.EXAMPLE_PORTAL.id) {
						entity.setPositionAndAngles(x + 0.5, y + 1.5, z + 0.5, entity.yaw, entity.pitch);
						return;
					}
				}
			}
		}

		// First arrival here: one portal block on the ground, player standing in it.
		// getTopY gives the first air block above the terrain at this column.
		int y = world.getTopY(ex, ez);
		world.setBlock(ex, y, ez, ExampleMod.EXAMPLE_PORTAL.id);
		entity.setPositionAndAngles(ex + 0.5, y + 1.5, ez + 0.5, entity.yaw, entity.pitch);
	}
}
