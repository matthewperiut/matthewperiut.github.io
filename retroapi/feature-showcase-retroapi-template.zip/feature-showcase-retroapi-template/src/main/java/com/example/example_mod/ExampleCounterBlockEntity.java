package com.example.example_mod;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;

/**
 * The block entity for ExampleCounterBlock: a single int that survives world
 * save/load. Override writeNbt/readNbt (always call super!) to persist fields.
 *
 * RetroAPI stores modded block entities in a sidecar file next to the vanilla
 * chunk data, so the world still opens fine in unmodded Beta 1.7.3, your block
 * entities simply reappear when the mod is back.
 *
 * Registered in ExampleMod.init() via:
 *   RetroBlockEntities.register(id("counter"), ExampleCounterBlockEntity.class);
 * The string id is what gets written into NBT, so never change it after release.
 */
public class ExampleCounterBlockEntity extends BlockEntity {

	public int clicks = 0;

	@Override
	public void writeNbt(NbtCompound nbt) {
		super.writeNbt(nbt);
		nbt.putInt("Clicks", this.clicks);
	}

	@Override
	public void readNbt(NbtCompound nbt) {
		super.readNbt(nbt);
		this.clicks = nbt.getInt("Clicks");
	}
}
