package com.example.example_mod;

import net.minecraft.block.BlockWithEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.material.Material;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;

/**
 * A block with a block entity: every right-click increments a counter that is
 * saved with the world (see ExampleCounterBlockEntity) and plays a custom sound.
 *
 * Extend BlockWithEntity and return your block entity from createBlockEntity() , 
 * vanilla creates/removes it automatically when the block is placed/broken.
 *
 * Want a full container GUI (furnace/chest style) on top of this? The pattern is:
 *   - your ScreenHandler (container) + client screen class,
 *   - RetroGuis.openGUI(player, id, blockEntity, container) here in onUse,
 *   - RetroGuiRegistry.register(id, new RetroGuiHandler(...)) in client-init.
 * The guide's Block Entities page walks through it.
 */
public class ExampleCounterBlock extends BlockWithEntity {

	public ExampleCounterBlock(int id) {
		super(id, Material.STONE);
	}

	@Override
	protected BlockEntity createBlockEntity() {
		return new ExampleCounterBlockEntity();
	}

	@Override
	public boolean onUse(World world, int x, int y, int z, PlayerEntity player) {
		BlockEntity be = world.getBlockEntity(x, y, z);
		if (be instanceof ExampleCounterBlockEntity) {
			ExampleCounterBlockEntity counter = (ExampleCounterBlockEntity) be;
			counter.clicks++;
			counter.markDirty(); // tells the world this block entity needs saving

			// Custom sound: assets/example_mod/sounds/sound/counter/click.ogg is
			// auto-loaded by RetroAPI under the event id "example_mod:counter.click".
			world.playSound(x + 0.5, y + 0.5, z + 0.5, "example_mod:counter.click", 1.0F, 1.0F);

			if (!world.isRemote) {
				player.sendMessage("Counter: " + counter.clicks + " (saved with the world!)");
			}
		}
		return true; // we handled the click, don't place blocks/use items through it
	}
}
