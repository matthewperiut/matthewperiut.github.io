package com.example.example_mod;

import com.periut.retroapi.component.RetroComponents;
import com.periut.retroapi.component.RetroLayeredTexture;
import com.periut.retroapi.component.RetroTextureLayer;
import com.periut.retroapi.component.RetroTooltipProvider;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * The Mood Gem, a COMPONENT-DRIVEN LAYERED TEXTURE. Right click cycles a MOOD component
 * (0..3), and the gem's rendered look changes to match, live, everywhere it is drawn.
 *
 * This is the beta-friendly take on modern's component-driven, dyed/layered item models.
 * Rather than baking one PNG per color, we ship a single grayscale gem and TINT it at
 * render time from the component, exactly how modern recolors a layer. The gem is a list
 * of {@link RetroTextureLayer}: a base layer tinted by MOOD, plus a sparkle overlay that
 * only appears once the ATTUNEMENT record component says the gem is awakened, so BOTH a
 * primitive component (the tint) and a structured one (the extra layer) drive the picture.
 * RetroAPI draws the layers stacked in the hotbar, inventory, hand and on the ground, and
 * because nothing is cached an item could have thousands of tints for free.
 */
public class MoodGemItem extends Item implements RetroLayeredTexture, RetroTooltipProvider {

	private static final String[] MOOD_NAMES = {"Ruby", "Emerald", "Sapphire", "Amber"};

	public MoodGemItem(int id) {
		super(id);
		this.setMaxCount(1);
	}

	@Override
	public ItemStack use(ItemStack stack, World world, PlayerEntity player) {
		// Cycle on BOTH sides: the client side predicts so the gem's sprite changes the
		// instant you click, the server side is the authority that persists and reconciles
		// (RetroAPI syncs the component down). See CounterItem for why a server-only guard
		// is wrong here, the gem would simply never change on a dedicated server.
		cycle(stack);
		return stack;
	}

	@Override
	public boolean useOnBlock(ItemStack stack, PlayerEntity player, World world, int x, int y, int z, int side) {
		// The reliable dedicated-server path: block right-clicks always reach the server.
		cycle(stack);
		return true;
	}

	private static void cycle(ItemStack stack) {
		int mood = RetroComponents.getOrDefault(stack, ExampleMod.MOOD, 0);
		int next = (mood + 1) % ExampleMod.MOOD_TINTS.length;
		RetroComponents.set(stack, ExampleMod.MOOD, next);
		// Every full loop back to the first colour bumps a RECORD component (level +
		// awakened), to show components hold structured data, not just one number.
		if (next == 0) {
			GemAttunement att = RetroComponents.getOrDefault(stack, ExampleMod.ATTUNEMENT, GemAttunement.EMPTY);
			RetroComponents.set(stack, ExampleMod.ATTUNEMENT, att.leveledUp());
		}
	}

	/** The layers for the current state: a tinted base, plus a sparkle once awakened. */
	@Override
	public List<RetroTextureLayer> getTextureLayers(ItemStack stack) {
		int mood = RetroComponents.getOrDefault(stack, ExampleMod.MOOD, 0);
		GemAttunement att = RetroComponents.getOrDefault(stack, ExampleMod.ATTUNEMENT, GemAttunement.EMPTY);
		List<RetroTextureLayer> layers = new ArrayList<>(2);
		layers.add(RetroTextureLayer.tinted(ExampleMod.MOOD_GEM_BASE, ExampleMod.MOOD_TINTS[mood]));
		if (att.awakened()) {
			layers.add(RetroTextureLayer.plain(ExampleMod.MOOD_GEM_SPARKLE));
		}
		return layers;
	}

	@Override
	public void appendTooltip(ItemStack stack, List<String> lines) {
		int mood = RetroComponents.getOrDefault(stack, ExampleMod.MOOD, 0);
		GemAttunement att = RetroComponents.getOrDefault(stack, ExampleMod.ATTUNEMENT, GemAttunement.EMPTY);
		lines.add("§bMood: " + MOOD_NAMES[mood]);
		lines.add("§7Attunement " + att.level() + (att.awakened() ? " §d(awakened)" : ""));
		lines.add("§8Right-click to change");
	}
}
