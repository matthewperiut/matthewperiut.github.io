package com.example.example_mod.mixin.examples;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

import net.minecraft.entity.TntEntity;

/**
 * MIXIN EXAMPLE 9/10, @ModifyConstant: changing a hard-coded number.
 *
 * Effect in game: TNT explodes after 1 second instead of 4.
 *
 * Vanilla constructs primed TNT with `this.fuse = 80`, a bare 80 baked into
 * the constructor's bytecode. There is no method call to redirect and no
 * argument to modify; @ModifyConstant finds the constant itself (every LDC/
 * bipush of 80 in the chosen method) and routes it through our handler.
 *
 * Pitfalls to know:
 *   - It matches EVERY 80 in that method. Fine here (there's one); in bigger
 *     methods, narrow it with @Constant(ordinal = ...) or pick another tool.
 *   - The JIT-visible constant must really be a constant, values computed at
 *     runtime can't be caught this way.
 *   - Like example 2, targeting a constructor needs the full descriptor; this
 *     is the (World, x, y, z) overload used when TNT is ignited.
 */
@Mixin(TntEntity.class)
public class Example09FastTntMixin {

	@ModifyConstant(
		method = "<init>(Lnet/minecraft/world/World;DDD)V",
		constant = @Constant(intValue = 80)
	)
	private int example_mod$shortFuse(int fuse) {
		return 20; // ticks: 20 = one second of sizzle
	}
}
