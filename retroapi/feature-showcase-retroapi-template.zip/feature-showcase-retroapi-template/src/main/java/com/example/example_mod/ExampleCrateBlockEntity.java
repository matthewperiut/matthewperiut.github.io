package com.example.example_mod;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;

/**
 * The crate's block entity: a 12-slot inventory implemented by hand (based on
 * matthewperiut/crates-fabric-b1.7.3). Implementing the Inventory interface
 * yourself is the general pattern for machines, chests/furnaces do exactly this.
 *
 * The contents are persisted in writeNbt/readNbt using the same "Items" list
 * layout vanilla containers use (one compound per occupied slot, with a "Slot"
 * byte). RetroAPI's inventory sidecar keeps all of it, including modded items , 
 * out of the vanilla chunk data, so the world still opens safely without mods.
 */
public class ExampleCrateBlockEntity extends BlockEntity implements Inventory {

	private ItemStack[] contents = new ItemStack[12];

	@Override
	public int size() {
		return this.contents.length;
	}

	@Override
	public ItemStack getStack(int slot) {
		return this.contents[slot];
	}

	@Override
	public ItemStack removeStack(int slot, int amount) {
		ItemStack stack = this.contents[slot];
		if (stack == null) {
			return null;
		}
		if (stack.count <= amount) {
			// taking everything: empty the slot
			this.contents[slot] = null;
			this.markDirty();
			return stack;
		}
		// taking part of the stack: split it
		ItemStack taken = stack.split(amount);
		if (stack.count == 0) {
			this.contents[slot] = null;
		}
		this.markDirty();
		return taken;
	}

	@Override
	public void setStack(int slot, ItemStack stack) {
		this.contents[slot] = stack;
		if (stack != null && stack.count > this.getMaxCountPerStack()) {
			stack.count = this.getMaxCountPerStack();
		}
		this.markDirty();
	}

	@Override
	public String getName() {
		return "Crate"; // drawn as the title by ExampleCrateScreen
	}

	@Override
	public int getMaxCountPerStack() {
		return 64;
	}

	@Override
	public boolean canPlayerUse(PlayerEntity player) {
		// Standard container rules: still placed, and the player is within 8 blocks.
		if (this.world.getBlockEntity(this.x, this.y, this.z) != this) {
			return false;
		}
		return player.getSquaredDistance(this.x + 0.5, this.y + 0.5, this.z + 0.5) <= 64.0;
	}

	@Override
	public void writeNbt(NbtCompound nbt) {
		super.writeNbt(nbt);
		NbtList items = new NbtList();
		for (int slot = 0; slot < this.contents.length; slot++) {
			if (this.contents[slot] != null) {
				NbtCompound entry = new NbtCompound();
				entry.putByte("Slot", (byte) slot);
				this.contents[slot].writeNbt(entry);
				items.add(entry);
			}
		}
		nbt.put("Items", items);
	}

	@Override
	public void readNbt(NbtCompound nbt) {
		super.readNbt(nbt);
		NbtList items = nbt.getList("Items");
		this.contents = new ItemStack[this.size()];
		for (int i = 0; i < items.size(); i++) {
			NbtCompound entry = (NbtCompound) items.get(i);
			int slot = entry.getByte("Slot") & 255;
			if (slot >= 0 && slot < this.contents.length) {
				this.contents[slot] = new ItemStack(entry);
			}
		}
	}
}
