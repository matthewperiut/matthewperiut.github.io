package com.example.example_mod;

import com.periut.retroapi.component.RetroComponents;
import com.periut.retroapi.component.RetroTooltipProvider;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;

import java.util.List;

/**
 * The Counter, the fabric-docs custom-data-components example ported to beta
 * (https://docs.fabricmc.net/develop/items/custom-data-components). Each right click
 * bumps a CLICK_COUNT component on the stack, and the tooltip shows the running total.
 *
 * The whole point: beta ItemStacks have NO storage of their own, yet this stack
 * remembers how many times it was clicked, and the count survives copying the stack,
 * saving the world, and (in singleplayer) is simply there because the client is the
 * world. That is the data-component system doing its job (see ExampleMod for the
 * CLICK_COUNT registration, and RetroComponents for the get/set API).
 *
 * In modern Minecraft this is {@code stack.get(...)} / {@code stack.set(...)} and an
 * {@code appendHoverText} override; here it is {@code RetroComponents.get/set} and
 * {@code RetroTooltipProvider}, because beta cannot add methods to ItemStack or Item.
 */
public class CounterItem extends Item implements RetroTooltipProvider {

	public CounterItem(int id) {
		super(id);
		this.setMaxCount(1);
	}

	@Override
	public ItemStack use(ItemStack stack, World world, PlayerEntity player) {
		// Right-clicking AIR. We bump on BOTH sides on purpose: the client side is a
		// prediction so the tooltip updates the instant you click, and the server side is
		// the authority that persists and (via RetroAPI's component packet sync) reconciles
		// the client. They land on the same number, so there is no flicker. Guarding this
		// with !world.isRemote (the usual server-only pattern) is exactly what made the
		// count never move on a dedicated server: the client did nothing and, with no
		// visible change, never told the server to do anything either.
		bump(stack);
		return stack;
	}

	@Override
	public boolean useOnBlock(ItemStack stack, PlayerEntity player, World world, int x, int y, int z, int side) {
		// Right-clicking a BLOCK. Beta routes block right-clicks to useOnBlock, not use, and
		// the server always processes them, so this is the reliable path on a dedicated
		// server. Returning true consumes the interaction (no block-place attempt).
		bump(stack);
		return true;
	}

	private static void bump(ItemStack stack) {
		int count = RetroComponents.getOrDefault(stack, ExampleMod.CLICK_COUNT, 0);
		RetroComponents.set(stack, ExampleMod.CLICK_COUNT, count + 1);
	}

	@Override
	public void appendTooltip(ItemStack stack, List<String> lines) {
		// section sign + 6 = gold, matching the fabric example's ChatFormatting.GOLD.
		lines.add("§6Clicks: " + RetroComponents.get(stack, ExampleMod.CLICK_COUNT));
	}
}
