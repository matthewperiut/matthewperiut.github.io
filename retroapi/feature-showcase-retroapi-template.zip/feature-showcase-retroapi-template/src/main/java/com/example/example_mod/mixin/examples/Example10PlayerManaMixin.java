package com.example.example_mod.mixin.examples;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.example_mod.ExampleManaAccess;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.nbt.NbtCompound;

/**
 * MIXIN EXAMPLE 10/10, the capstone: @Unique state + a duck interface + NBT
 * persistence. This is the pattern real mods are built on.
 *
 * Goal: every player has a brand-new "mana" stat that saves with them.
 *
 * Three tools working together:
 *   - @Unique adds a NEW field to PlayerEntity. The prefix (example_mod$) is
 *     mixin convention AND collision insurance: two mods adding plain `mana`
 *     would clash; prefixed uniques never do.
 *   - `implements ExampleManaAccess`, a mixin's interfaces are merged into
 *     the target, so AT RUNTIME every PlayerEntity IS an ExampleManaAccess.
 *     Outside code just casts: ((ExampleManaAccess) player).example_mod$getMana().
 *     (The interface lives in the normal source tree, not the mixin package.)
 *   - Two @Injects piggyback on the player's own NBT save/load, so mana
 *     persists exactly as long as the player does. Namespace your keys!
 *
 * Try it: mana starts at 0 and you can wire anything to it. Nothing in the
 * showcase consumes it, it's the foundation pattern, kept pure.
 */
@Mixin(PlayerEntity.class)
public class Example10PlayerManaMixin implements ExampleManaAccess {

	@Unique
	private int example_mod$mana = 0;

	@Override
	public int example_mod$getMana() {
		return this.example_mod$mana;
	}

	@Override
	public void example_mod$setMana(int mana) {
		this.example_mod$mana = mana;
	}

	@Inject(method = "writeNbt", at = @At("TAIL"))
	private void example_mod$saveMana(NbtCompound nbt, CallbackInfo ci) {
		nbt.putInt("example_mod:mana", this.example_mod$mana);
	}

	@Inject(method = "readNbt", at = @At("TAIL"))
	private void example_mod$loadMana(NbtCompound nbt, CallbackInfo ci) {
		this.example_mod$mana = nbt.getInt("example_mod:mana");
	}
}
