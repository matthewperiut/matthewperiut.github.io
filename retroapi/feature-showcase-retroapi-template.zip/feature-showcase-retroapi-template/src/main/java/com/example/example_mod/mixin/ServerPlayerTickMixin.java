package com.example.example_mod.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.example.example_mod.ExampleModServer;
import com.example.example_mod.ExamplePlayerSetup;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.ServerPlayerEntity;

/**
 * Dedicated-server hook for the one-shot starter kit + the welcome packet.
 * Listed under "server" in example_mod.mixins.json so it never loads on the
 * client (where ServerPlayerEntity doesn't exist).
 *
 * ServerPlayerEntity.tick() is driven by the server's world tick every tick,
 * which makes it a reliable "this player is in the world" hook on join.
 */
@Mixin(ServerPlayerEntity.class)
public class ServerPlayerTickMixin {

	@Inject(method = "tick", at = @At("HEAD"))
	private void example_mod$onTick(CallbackInfo ci) {
		ServerPlayerEntity self = (ServerPlayerEntity) (Object) this;
		ExamplePlayerSetup.run((PlayerEntity) self);
		ExampleModServer.welcomeOnceReady(self);
	}
}
