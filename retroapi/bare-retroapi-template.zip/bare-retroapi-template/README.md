# Bare RetroAPI Template

A preconfigured modding environment for **Minecraft Beta 1.7.3** using **Ornithe gen2** tooling and **[RetroAPI](https://github.com/matthewperiut/RetroAPI)**.

This is the official [ornithe-mod-template](https://github.com/OrnitheMC/ornithe-mod-template) with its build files already switched over to:

- Minecraft `b1.7.3` (gen2 intermediary)
- **biny-ornithe** mappings (instead of Feather)
- **RetroAPI** (blocks, items, entities, achievements, dimensions, recipes, rendering)
- **retrodragon** (LWJGL 3) as a development convenience
- OSL (Ornithe Standard Libraries) for entrypoints, networking, and more

The full guide lives at **https://matthewperiut.github.io/retroapi/**, start there.

## Quick start

1. Unzip (or use this repo as a template) and open the folder in IntelliJ IDEA / VS Code / Eclipse. Java 21 is required to run Gradle.
2. Make it yours:
    - `gradle.properties`, set `maven_group` and `archives_base_name`
    - `src/main/resources/fabric.mod.json`, set your mod `id`, `name`, `description`, `authors`
    - Rename the `com.example.example_mod` package and `example_mod.mixins.json` to match
3. Run the game:

```bash
./gradlew runClient
```

4. Build a distributable jar (lands in `build/libs/`):

```bash
./gradlew build
```

## What's inside

| File | Purpose |
|---|---|
| `build.gradle` | Loom + Ploceus setup with biny mappings and the RetroAPI dependency |
| `gradle.properties` | All dependency versions in one place |
| `src/main/resources/fabric.mod.json` | Mod metadata + OSL `init` entrypoint + `depends` on retroapi |
| `src/.../ExampleMod.java` | Minimal OSL `ModInitializer` entrypoint |
| `src/.../mixin/TitleScreenMixin.java` | Minimal example mixin (client side) |

For a version of this template with every RetroAPI feature filled out and commented (custom blocks, items, a mob, a dimension, achievements, recipes, networking), grab the **feature-showcase-retroapi-template** from the guide instead.

## License

The template itself is CC0 (see `LICENSE-TEMPLATE.md`), mods you build from it are yours to license however you like.
