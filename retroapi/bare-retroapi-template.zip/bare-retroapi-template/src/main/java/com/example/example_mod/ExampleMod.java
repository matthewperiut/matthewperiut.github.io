package com.example.example_mod;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.periut.retroapi.entrypoint.RetroModInitializer;

public class ExampleMod implements RetroModInitializer {

	// This logger is used to write text to the console and the log file.
	// It is considered best practice to use your mod name as the logger's name.
	// That way, it's clear which mod wrote info, warnings, and errors.
	public static final Logger LOGGER = LogManager.getLogger("Example Mod");

	// The `retroapi` entrypoint, not OSL's `init`. RetroAPI runs this at the one moment when
	// registering content is guaranteed to work: after its registries, tags and lang files are
	// ready, before its registration events fire, before recipes are sorted, and before any world
	// assigns ids. The `init` stage runs mods in an unspecified order, so a mod could get there
	// first and register into a platform that was not built yet - the cause of the classic
	// "sometimes my recipes/blocks just don't exist" bug.
	//
	// Sided halves exist too: RetroClientModInitializer (`retroapi-client`, initRetroClient) for
	// renderers, screens and particle factories, and RetroServerModInitializer (`retroapi-server`,
	// initRetroServer) for dedicated-server-only logic.
	@Override
	public void initRetro() {
		LOGGER.info("initializing example mod!");
	}
}
